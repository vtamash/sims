package com.kenco.oms.repository;

import com.kenco.oms.entity.Shiptocustomers;
import org.apache.log4j.Logger;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;
import java.util.ArrayList;
import java.util.List;

/**
 * Contains logic for communicating with the provided EntityManager for the Shiptocustomers entity.
 */
public final class ShiptoCustomersRepository {
	private EntityManager entityManager;

	private static Logger logger = Logger.getLogger(ShiptoCustomersRepository.class);

	/**
	 * Default constructor.  This exists to accommodate any future Spring-backed projects that may require OMS.
	 */
	public ShiptoCustomersRepository() {}

	/**
	 * Convenience constructor to pass in the EntityManager.  This will (mostly) accommodate non-spring-backed implementations.
	 *
	 * @param entityManager The EntityManager to be used.
	 */
	public ShiptoCustomersRepository(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	/**
	 * Persists the given Shiptocustomers entity.
	 *
	 * @param shipToCustomers Shiptocustomers entity to persist.
	 * @return The persisted Shiptocustomers entity.
	 */
	public Shiptocustomers create(Shiptocustomers shipToCustomers) {
		EntityTransaction et = entityManager.getTransaction();
		et.begin();

		Shiptocustomers v = entityManager.merge(shipToCustomers);
		try { et.commit(); }
		catch (Exception e) { if (et.isActive()) et.rollback(); throw new IllegalStateException(e); }

		return v;
	}

	/**
	 * Reads a collection of Shiptocustomers objects based on the provided Customer ID.
	 *
	 * @param pCustomerId Customer ID for the Shiptocustomers requested.
	 * @return Typed List of Shiptocustomers.
	 */
	public List<Shiptocustomers> list(int pCustomerId) {
		logger.info("Reading Shiptocustomers for: Customer Id - " + pCustomerId);

		String sql  = "select t from Shiptocustomers t where t.customer.id = :id";
		Query query = entityManager.createQuery(sql).setParameter("id", pCustomerId);

		List<Shiptocustomers> shiptoCustomers = new ArrayList<Shiptocustomers>();
		for (Object curObject : query.getResultList())
			if (curObject instanceof Shiptocustomers)
				shiptoCustomers.add((Shiptocustomers) curObject);

		logger.info("Finished reading Shiptocustomers for: Customer Id - " + pCustomerId);
		return shiptoCustomers;
	}

	/**
	 * Reads a single Shiptocustomers entity based upon the provided ID (<i>Primary Key</i>).
	 *
	 * @param id The ID (<i>Primary Key</i>) for the Shiptocustomers entity to fetch.
	 * @return The Shiptocustomers entity for the provided ID (<i>Primary Key</i>).
	 */
	public Shiptocustomers readById(int id) {
		logger.info("Reading Shiptocustomers for: ID - " + id);

		Shiptocustomers s = (Shiptocustomers) entityManager.createQuery("SELECT s FROM Shiptocustomers s WHERE s.id = :id")
				.setParameter("id",id)
				.getSingleResult();

		logger.info("Finished reading Shiptocustomers for: ID - " + id);

		return s;
	}

	/**
	 * Reads a single Shiptocustomers entity based on the provided Shiptocustomer name.
	 *
	 * @param name The name for the Shiptocustomers entity to fetch.
	 * @return The Shiptocustomers for the provided <b>name</b>.
	 */
	public Shiptocustomers readByName(String name) {
		logger.info("Reading Shiptocustomer for: Name - " + name);

		Shiptocustomers s = (Shiptocustomers) entityManager.createQuery("SELECT s FROM Shiptocustomers s WHERE s.name = :name")
				.setParameter("name", name.trim())
				.getSingleResult();

		logger.info("Finished reading Shiptocustomers for: Name - " + name);

		return s;
	}

	/**
	 * Reads a single Shiptocustomers entity based on the provided Shiptocustomer number.
	 *
	 * @param number The number for the Shiptocustomers entity to fetch.
	 * @return The Shiptocustomers for the provided <b>number</b>.
	 */
	public Shiptocustomers readByNumber(String number) {
		logger.info("Reading Shiptocustomer for: ShipToCustomerNumber - " + number);

		Shiptocustomers s = (Shiptocustomers) entityManager.createQuery("SELECT s FROM Shiptocustomers s WHERE s.shiptocustomernumber = :number")
				.setParameter("number", number.trim().toUpperCase())
				.getSingleResult();

		logger.info("Finished reading Shiptocustomers for: ShipToCustomerNumber - " + number);

		return s;
	}

	/**
	 * Saves the given Shiptocustomers entity.
	 *
	 * @param shipToCustomers (<b>Detached</b>) Shiptocustomers entity to save.
	 */
	public void update(Shiptocustomers shipToCustomers) {
		EntityTransaction et = entityManager.getTransaction();
		et.begin();

		entityManager.merge(shipToCustomers);
		try { et.commit(); }
		catch (Exception e) { if (et.isActive()) et.rollback(); throw new IllegalStateException(e); }
	}

	/**
	 * This doesn't actually <i>delete</i> the given Shiptocustomers entity.  Instead, we perform a <i>soft delete</i> by flipping
	 * the <i>active</i> flag.
	 *
	 * @param shipToCustomers The (<b>detached</b>) Shiptocustomers entity to "delete."
	 */
	public void delete(Shiptocustomers shipToCustomers) {
		EntityTransaction et = entityManager.getTransaction();
		et.begin();

		shipToCustomers.setActive((short) 0);
		entityManager.merge(shipToCustomers);
		try { et.commit(); }
		catch (Exception e) { if (et.isActive()) et.rollback(); throw new IllegalStateException(e); }
	}
}
