package com.kenco.oms.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import java.io.Serializable;
import java.util.Collection;
import java.util.Date;

@Entity
@Table(name = "STATES")
@XmlRootElement
public class States implements Serializable {
   @Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
   @Column(name = "ID", nullable = false)
   private Integer id;

   @NotNull
   @Size(min = 1, max = 2)
   @Column(name = "STATE", nullable = false)
   private String state;

   @NotNull
   @Size(min = 1, max = 40)
   @Column(name = "NAME", nullable = false)
   private String name;

   @NotNull
   @Column(name = "CREATETIMESTAMP", nullable = false)
   @Temporal(TemporalType.TIMESTAMP)
   private Date createtimestamp;

   @NotNull
   @Size(min = 1, max = 10)
   @Column(name = "CREATEUSERNAME", nullable = false)
   private String createusername;

   @NotNull
   @Size(min = 1, max = 50)
   @Column(name = "CREATEPROGRAM", nullable = false)
   private String createprogram;

   @Column(name = "UPDATETIMESTAMP", nullable = false)
   @Temporal(TemporalType.TIMESTAMP)
   private Date updatetimestamp;

   @NotNull
   @Size(min = 1, max = 10)
   @Column(name = "UPDATEUSERNAME", nullable = false)
   private String updateusername;

   @NotNull
   @Size(min = 1, max = 50)
   @Column(name = "UPDATEPROGRAM", nullable = false)
   private String updateprogram;

   @JsonIgnore
   @OneToMany(mappedBy = "shiptostateId")
   private Collection<Outboundorderheader> outboundorderheaderCollection;

   @JsonIgnore
   @OneToMany(mappedBy = "state")
   private Collection<Shiptocustomers> shiptocustomersCollection;

   public States() {
   }

   public States(Integer id) {
      this.id = id;
   }

   public States(Integer id, String state, String name, Date createtimestamp, String createusername, String createprogram, Date updatetimestamp, String updateusername, String updateprogram) {
      this.id = id;
      this.state = state;
      this.name = name;
      this.createtimestamp = createtimestamp;
      this.createusername = createusername;
      this.createprogram = createprogram;
      this.updatetimestamp = updatetimestamp;
      this.updateusername = updateusername;
      this.updateprogram = updateprogram;
   }

   public Integer getId() {
      return id;
   }

   public void setId(Integer id) {
      this.id = id;
   }

   public String getState() {
      return state;
   }

   public void setState(String state) {
      this.state = state;
   }

   public String getName() {
      return name;
   }

   public void setName(String name) {
      this.name = name;
   }

   public Date getCreatetimestamp() {
      return createtimestamp;
   }

   public void setCreatetimestamp(Date createtimestamp) {
      this.createtimestamp = createtimestamp;
   }

   public String getCreateusername() {
      return createusername;
   }

   public void setCreateusername(String createusername) {
      this.createusername = createusername;
   }

   public String getCreateprogram() {
      return createprogram;
   }

   public void setCreateprogram(String createprogram) {
      this.createprogram = createprogram;
   }

   public Date getUpdatetimestamp() {
      return updatetimestamp;
   }

   public void setUpdatetimestamp(Date updatetimestamp) {
      this.updatetimestamp = updatetimestamp;
   }

   public String getUpdateusername() {
      return updateusername;
   }

   public void setUpdateusername(String updateusername) {
      this.updateusername = updateusername;
   }

   public String getUpdateprogram() {
      return updateprogram;
   }

   public void setUpdateprogram(String updateprogram) {
      this.updateprogram = updateprogram;
   }

   @XmlTransient
   public Collection<Outboundorderheader> getOutboundorderheaderCollection() {
      return outboundorderheaderCollection;
   }

   public void setOutboundorderheaderCollection(Collection<Outboundorderheader> outboundorderheaderCollection) {
      this.outboundorderheaderCollection = outboundorderheaderCollection;
   }

   @XmlTransient
   public Collection<Shiptocustomers> getShiptocustomersCollection() {
      return shiptocustomersCollection;
   }

   public void setShiptocustomersCollection(Collection<Shiptocustomers> shiptocustomersCollection) {
      this.shiptocustomersCollection = shiptocustomersCollection;
   }

   @Override
   public int hashCode() {
      int hash = 0;
      hash += (id != null ? id.hashCode() : 0);
      return hash;
   }

   @Override
   public boolean equals(Object object) {
      // TODO: Warning - this method won't work in the case the id fields are not set
      if (!(object instanceof States)) {
         return false;
      }
      States other = (States) object;
      if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
         return false;
      }
      return true;
   }

   @Override
   public String toString() {
      return "com.kenco.oms.entity.States[ id=" + id + " ]";
   }
   
}
