package com.kenco.oms.service.impl;

import com.kenco.oms.entity.*;
import com.kenco.oms.service.OmsDownloadAbstractService;

import javax.persistence.EntityManager;
import java.util.List;

/**
 * Basic extension of the <i>OmsDownloadAbstractService</i>.  This offers no additional business logic other than what
 * is absolutely enforced upon any extending class.  To implement custom business logic for any process, extend the
 * WesInboundOrderAbstractService.  However, you may use this bean if the you need nothing more than <b>basic</b>
 * CRUD functionality with no additional business logic.
 *
 * @see com.kenco.oms.service.OmsDownloadAbstractService
 */
public final class GenericOmsDownloadService extends OmsDownloadAbstractService {
	/**
	 * {@inheritDoc}
	 */
	public GenericOmsDownloadService(EntityManager entityManager) {
		super(entityManager);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected String generateOutboundHeaderDataString(Outboundorderheader order, String whsid) {
		return ""; // TODO We should probably find a Generic way of building one of these...though I'm unsure if this is possible.
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected String generateOutboundDetailDataString(Outboundorderdetail detail, String whsid) {
		return ""; // TODO We should probably find a Generic way of building one of these...though I'm unsure if this is possible.
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected String generateInboundHeaderDataString(Inboundorderheader order, String whsid) {
		return ""; // TODO We should probably find a Generic way of building one of these...though I'm unsure if this is possible.
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected String generateInboundDetailDataString(Inboundorderdetail detail, String whsid) {
		return ""; // TODO We should probably find a Generic way of building one of these...though I'm unsure if this is possible.
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Omsdownload createPreProcess(Omsdownload omsdownload, Object... args) {
		return omsdownload;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Omsdownload updatePreProcess(Omsdownload omsdownload, Object... args) {
		return omsdownload;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Omsdownload deletePreProcess(Omsdownload omsdownload, Object... args) {
		return omsdownload;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Omsdownload createPostProcess(Omsdownload omsdownload, Object... args) {
		return omsdownload;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public List<Omsdownload> readPostProcess(List<Omsdownload> l, Object... args) {
		return l;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Omsdownload readSinglePostProcess(Omsdownload omsdownload, Object... args) {
		return omsdownload;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Omsdownload updatePostProcess(Omsdownload omsdownload, Object... args) {
		return omsdownload;
	}
}
