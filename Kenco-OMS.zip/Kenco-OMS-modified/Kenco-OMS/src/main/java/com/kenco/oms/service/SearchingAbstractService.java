package com.kenco.oms.service;

import com.kenco.oms.search.SearchRequest;

import java.util.List;

/**
 * Intermediate class for all Abstract Services that work with Entities that require searching - as opposed to full
 * table reads.
 *
 * @param <T> The entity type with which the Service will work.
 * @param <S> The SearchRequest type with which the Service will work.
 */
abstract class SearchingAbstractService<T, S extends SearchRequest> extends AbstractService<T> {
	/**
	 * Second phase of any of our Searches: Finding out the total number of results that match the provided
	 * <i>SearchRequest</i>.
	 *
	 * @param request The <i>SearchRequest</i> which was used to perform the original Search Operation.
	 * @return Count of the number of results that match the provided <i>SearchRequest</i>.
	 */
	public abstract long readSearchTotal(S request);

	/**
	 * Forward facing method to access a <b>search</b> for the Typed entity.
	 *
	 * @param request The <i>SearchRequest</i> object that is being used.
	 * @param args Any arguments passed required for the search.
	 * @return Typed List of results matching the privided <i>SearchRequest</i>.
	 */
	public abstract List<T> search(S request, Object... args);

	/**
	 * Pre-Processing hook for the <b>read</b> Operation for any Entity that requires a <b>search</b> rather than full-table
	 * reads.  This method will allow implementing classes to implement custom business logic that will run <i>before</i>
	 * the <b>read</b> operation runs.
	 *
	 * @param s The typed Object that is being persisted.
	 * @param args Any arguments passed required for the search.
	 * @return The SearchRequest with any modifications made during pre-processing.
	 */
	protected abstract S searchPreProcess(S s, Object... args);

	/**
	 * Accommodates Post-Processing for the ResultSet that is returned from the Search operation.
	 *
	 * @param results Typed List of results that were returned from the search operation.
	 * @param args Any arguments passed into the <b>search</b> method.
	 * @return Typed List of results after processing has completed.
	 */
	protected abstract List<T> searchPostProcessing(List<T> results, Object... args);
}
