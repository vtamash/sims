package com.kenco.oms.repository;

import com.kenco.oms.entity.Omsdownload;
import org.apache.log4j.Logger;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import java.util.ArrayList;
import java.util.List;

/**
 * Contains logic for communicating with the provided EntityManager for the Omsdownload entity.
 */
public final class OmsdownloadRepository {
	private static Logger logger = Logger.getLogger(OmsdownloadRepository.class);

	private EntityManager entityManager;

	/**
	 * Default constructor. This exists to accommodate any future Spring-backed projects that may require OMS.
	 */
	public OmsdownloadRepository() {}

	/**
	 * Convenience constructor to pass in the EntityManager. This will (mostly) accommodate non-spring-backed
	 * implementations.
	 *
	 * @param entityManager The EntityManager to be used.
	 */
	public OmsdownloadRepository(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	/**
	 * Accessor for the EntityManager. This exists to accommodate any future Spring-backed projects that may require OMS.
	 *
	 * @param entityManager The EntityManager that this Repository will use.
	 */
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	/**
	 * Persists the given <i>OmsDownload</i> entity.
	 *
	 * @return The persisted <i>OmsDownload</i> entity.
	 */
	public Omsdownload create(Omsdownload download) {
		EntityTransaction et = entityManager.getTransaction();
		et.begin();

		Omsdownload od = entityManager.merge(download);
		try { et.commit(); }
        catch (Exception e) { if (et.isActive()) et.rollback(); logger.error(e); throw new IllegalStateException(e); }
		return od;
	}

    /**
     * Persists a set of <i>OmsDownload</i> entities within a single Transactional Boundary.
     *
     * @param downloads Collection of <i>OmsDownload</i> entities to be persisted.
     * @return Typed Collection of persisted <i>OmsDownload</i> entities.
     */
    public List<Omsdownload> createBatch(List<Omsdownload> downloads) {
        EntityTransaction et = entityManager.getTransaction();
        et.begin();

        List<Omsdownload> persisted = new ArrayList<Omsdownload>();
        for (Omsdownload curDownload : downloads)
            persisted.add(entityManager.merge(curDownload));

        try { et.commit(); }
        catch (Exception e) { if (et.isActive()) et.rollback(); logger.error(e); throw new IllegalStateException(e); }
        return persisted;
    }
}
