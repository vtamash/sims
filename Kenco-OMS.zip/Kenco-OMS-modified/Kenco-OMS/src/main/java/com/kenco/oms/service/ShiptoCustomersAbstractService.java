package com.kenco.oms.service;

import com.kenco.oms.entity.Shiptocustomers;
import com.kenco.oms.repository.ShiptoCustomersRepository;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import java.util.List;

/**
 * Class embodies the actual work for communicating with a ShiptoCustomersRepository.  To implement custom business logic for
 * any of the provided operations, simply extend this class and enter your business logic into the appropriate hook.
 *
 * @see com.kenco.oms.service.impl.GenericShiptoCustomersService
 */
public abstract class ShiptoCustomersAbstractService extends AbstractService<Shiptocustomers> {
	private ShiptoCustomersRepository repository;

	/**
	 * Constructor.
	 *
	 * @param entityManager The EntityManager that this Service will need to use.
	 */
	public ShiptoCustomersAbstractService(EntityManager entityManager) {
		repository = new ShiptoCustomersRepository(entityManager);
	}

	/**
	 * Provides access to check if a Shiptocustomers Name is already taken or if it is available.
	 *
	 * @param name The String to check against the taken names.
	 * @return True if the name is taken, false if it is available.
	 */
	public boolean existsByName(String name) {
		try {
			repository.readByName(name);
			return true;
		} catch (NoResultException nre) {
			return false;
		}
	}

	/**
	 * Provides access to check if a Shiptocustomers Number is already taken or if it is available.
	 *
	 * @param number The String to check against the taken numbers.
	 * @return True if the number is taken, false if it is available.
	 */
	public boolean existsByNumber(String number) {
		try {
			repository.readByNumber(number);
			return true;
		} catch (NoResultException nre) {
			return false;
		}
	}

	/**
	 * Defines base communication between the <i>ShiptoCustomersService</i> and the <i>ShiptoCustomersRepository</i> for <b>create</b>
	 * operations.  This method accommodates pre- and post- processing hooks such that extending classes can implement
	 * custom business logic at any time during processing.
	 *
	 * @param shiptoCustomer The shiptoCustomers object to be <b>created</b>.
	 * @param args Any arguments extending class requires during pre-processing.
	 * @return The <b>persisted</b> Shiptocustomers object.
	 */
	public Shiptocustomers create(Shiptocustomers shiptoCustomer, Object... args) {
		// Pre-Processing hook.
		createPreProcess(shiptoCustomer, args);

		// Perform the actual create from the Repository.
		repository.create(shiptoCustomer);

		// Post-Processing hook && Return.
		return createPostProcess(shiptoCustomer, args);
	}

	/**
	 * Defines base communication between the <i>ShiptoCustomersService</i> and the <i>ShiptoCustomersRepository</i> for <b>read</b>
	 * operations.  This method accommodates pre- and post- processing hooks such that extending classes can implement
	 * custom business logic at any time during processing.
	 *
	 * @param customerId The Customer Id by which to delimit the read results.
	 * @param args Any arguments extending class requires during pre-processing.
	 * @return Typed List of Shiptocustomers retrieved from the <b>read</b> operation.
	 */
	public List<Shiptocustomers> readAll(int customerId, Object... args) {
		// Perform the actual read from the Repository.
		List<Shiptocustomers> shipToCustomers = repository.list(customerId);

		// Post-Processing hook && Return.
		return readPostProcess(shipToCustomers, args);
	}

	/**
	 * Defines base communication between the <i>ShiptoCustomersService</i> and the <i>ShiptoCustomersRepository</i> for <b>read</b>
	 * operations.  This method accommodates pre- and post- processing hooks such that extending classes can implement
	 * custom business logic at any time during processing.
	 *
	 * @param id The id (<i>primary key</i>) of the Shiptocustomers entity to retrieve.
	 * @param args Any arguments extending class requires during pre-processing.
	 * @return Typed List of Shiptocustomers retrieved from the <b>read</b> operation.
	 */
	public Shiptocustomers readById(int id, Object... args) {
		// Perform the actual read from the Repository.
		Shiptocustomers shipToCustomers = repository.readById(id);

		// Post-Processing hook && Return.
		return readSinglePostProcess(shipToCustomers, args);
	}

	/**
	 * Defines base communication between the <i>ShiptoCustomersService</i> and the <i>ShiptoCustomersRepository</i> for <b>read</b>
	 * operations.  This method accommodates pre- and post- processing hooks such that extending classes can implement
	 * custom business logic at any time during processing.
	 *
	 * @param name The name of the Shiptocustomers to retrieve.
	 * @param args Any arguments extending class requires during pre-processing.
	 * @return Typed List of Shiptocustomers retrieved from the <b>read</b> operation.
	 */
	public Shiptocustomers readByName(String name, Object... args) {
		// Perform the actual read from the Repository.
		Shiptocustomers shiptToCustomers = repository.readByName(name);

		// Post-Processing hook && Return.
		return readSinglePostProcess(shiptToCustomers, args);
	}

	/**
	 * Defines base communication between the <i>ShiptoCustomersService</i> and the <i>ShiptoCustomersRepository</i> for <b>update</b>
	 * operations.  This method accommodates pre- and post- processing hooks such that extending classes can implement
	 * custom business logic at any time during processing.
	 *
	 * @param shiptoCustomer The Shiptocustomers object to be <b>updated</b>.
	 * @param args Any arguments extending class requires during pre-processing.
	 * @return The <b>updated</b> Shiptocustomers object.
	 */
	public Shiptocustomers update(Shiptocustomers shiptoCustomer, Object... args) {
		// Pre-Processing hook.
		updatePreProcess(shiptoCustomer, args);

		// Perform the actual update.
		repository.update(shiptoCustomer);

		// Post-Processing hook && Return.
		return updatePostProcess(shiptoCustomer, args);
	}

	/**
	 * Defines base communication between the <i>ShiptoCustomersService</i> and the <i>ShiptoCustomersRepository</i> for <b>delete</b>
	 * operations.  This method accommodates pre- and post- processing hooks such that extending classes can implement
	 * custom business logic at any time during processing.
	 *
	 * @param shiptoCustomer The TeShiptoCustomerobject to be <b>deleted</b>.
	 * @param args Any arguments extending class requires during pre-processing.
	 */
	public void delete(Shiptocustomers shiptoCustomer, Object... args) {
		// Pre-Processing hook.
		deletePreProcess(shiptoCustomer, args);

		// Perform the actual delete from the Repository.
		repository.delete(shiptoCustomer);
	}
}
