package com.kenco.oms.repository;

import com.kenco.oms.entity.Customers;
import com.kenco.oms.entity.Teams;
import com.kenco.oms.search.TeamsSearchRequest;
import org.apache.log4j.Logger;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;
import javax.persistence.criteria.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Contains logic for communicating with the provided EntityManager for the Teams entity.
 *
 */
public final class TeamsRepository {
	private EntityManager entityManager;

	public static final int MAX_PAGE_SIZE = 200;

	private static Logger logger = Logger.getLogger(TeamsRepository.class);

	/**
	 * Default constructor.  This exists to accommodate any future Spring-backed projects that may require OMS.
	 */
	public TeamsRepository() {}

	/**
	 * Convenience constructor to pass in the EntityManager.  This will (mostly) accommodate non-spring-backed implementations.
	 *
	 * @param entityManager The EntityManager to be used.
	 */
	public TeamsRepository(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	/**
	 * Accessor for the EntityManager.  This exists to accommodate any future Spring-backed projects that may require OMS.
	 *
	 * @param entityManager The EntityManager that this Repository will use.
	 */
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	/**
	 * Partner method for our Paging Search (<i>readPage(...)</i>).  This method will determine the <b>total</b> number
	 * of results that match the provided <i>SearchRequest</i>.
	 *
	 * @param request The <i>SearchRequest</i> submitted by the User.
	 * @return The total number of results that match the provided <i>SearchRequest</i>.
	 */
	public long readSearchTotal(TeamsSearchRequest request) {
		CriteriaBuilder     builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Long> query   = builder.createQuery(Long.class);
		Root<Teams>         team    = query.from(Teams.class);

		// Define what we are counting.
		query.select(builder.count(team));

		// Generate our predicates.
		List<Predicate> predicates = createSearchPredicates(builder, team, request);

		// Set WHERE clause.
		query.where(predicates.toArray(new Predicate[predicates.size()]));

		return entityManager.createQuery(query)
				.getSingleResult();
	}

	/**
	 * Persists the given Teams entity.
	 *
	 * @param team Teams entity to persist.
	 * @return The persisted Teams entity.
	 */
	public Teams create(Teams team) {
		EntityTransaction et = entityManager.getTransaction();
		et.begin();

		Teams t = entityManager.merge(team);
		try { et.commit(); }
		catch (Exception e) { if (et.isActive()) et.rollback(); throw new IllegalStateException(e); }

		return t;
	}

	/**
	 * Searches <i>Teams</i> entities for a <b>page</b> of results matching the provided <i>SearchRequest</i>.
	 *
	 * <b>Note</b>: Since not all of the search-able fields are required, we must dynamically build our query - at least
	 * the predicate portion thereof.  Therefore, this method is built using the JPA 2.x Criteria API.
	 *
	 * <b>Note</b>: Ordering is <b>not</b> assignable by the user.  It isn't that this functionality is impossible -
	 * quite the opposite - but it is not (at the time of this writing) desired.
	 *
	 * @param request The <i>SearchRequest</i> submitted by the User.
	 * @return Typed Collection containing all <i>Teams</i> entities that matched the <i>SearchRequest</i>.
	 */
	public List<Teams> readPage(TeamsSearchRequest request) {
		// Setup.
		CriteriaBuilder      builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Teams> query   = builder.createQuery(Teams.class);
		Root<Teams>          team    = query.from(Teams.class);

		// Generate our predicates.
		List<Predicate> predicates = createSearchPredicates(builder, team, request);

		// Set WHERE clause.
		query.where(predicates.toArray(new Predicate[predicates.size()]));

		// Build ORDER BY clause.
		List<Order> ordersBy = new ArrayList<Order>();

		// Order By: Order Number
		ordersBy.add(builder.asc(team.<String>get("team")));

		// Set ORDER BY clause.
		query.orderBy(ordersBy);

		// Run the (Typed) Query and return.
		return entityManager.createQuery(query)
				.setFirstResult(request.getStart())
				.setMaxResults(Math.min(MAX_PAGE_SIZE, request.getLimit()))
				.getResultList();
	}

	/**
	 * Retrieves all <i>Teams</i> entities for the provided <i>Customers</i>.
	 *
	 * @param customer The <i>Customers</i> entity by which to delimit the results.
	 * @return Typed List of <i>Teams</i> for the provided <i>Customers</i> entity.
	 */
	public List<Teams> readByCustomer(Customers customer) {
		logger.info("Reading Teams for: CustomerId - " + customer.getId());

		Query query = entityManager.createQuery("SELECT t FROM Teams t WHERE t.customerId.id = :customerId")
				.setParameter("customerId", customer.getId());

		List<Teams> teams = new ArrayList<Teams>();
		for (Object curObject : query.getResultList())
			if (curObject instanceof Teams)
				teams.add((Teams) curObject);

		logger.info("Finished reading Teams for: " + customer.getId());
		return teams;
	}

	/**
	 * Reads a single Teams entity based on the provided Teams name.
	 *
	 * @param name The Teams name for which the record is being requested.
	 * @return The Teams entity read.
	 */
	public Teams readByName(String name) {
		logger.info("Reading Vendor for: Team Name - " + name);

		Query query = entityManager.createQuery("SELECT t FROM Teams t WHERE UPPER(t.team) = :name")
				.setParameter("name", name.trim().toUpperCase());

		logger.info("Finished reading Vendors for: Team Name - " + name);

		return (Teams) query.getSingleResult();
	}

	/**
	 * Retrieves a single <i>Teams</i> entity based on the provided ID (<b>Primary Key</b>).
	 *
	 * @param id The ID (<b>Primary Key</b>) for the <i>Teams</i> entity to be retrieved.
	 * @return The <i>Teams</i> entity matching the provided ID (<b>Primary Key</b>).
	 */
	public Teams readyById(int id) {
		logger.info("Reading Teams for: Team ID - " + id);

		Teams t = (Teams) entityManager.createQuery("SELECT t FROM Teams t WHERE t.id = :id")
				.setParameter("id", id)
				.getSingleResult();

		logger.info("Finished reading Teams for: Team ID - " + id);

		return t;
	}

	/**
	 * Saves the given Teams entity.
	 *
	 * @param team (<b>Detached</b>) Teams entity to save.
	 */
	public Teams update(Teams team) {
		EntityTransaction et = entityManager.getTransaction();
		et.begin();

		Teams t = entityManager.merge(team);
		try { et.commit(); }
		catch (Exception e) { if (et.isActive()) et.rollback(); throw new IllegalStateException(e); }
		return t;
	}

	/**
	 * This method should (probably) not be used.  We do not intend to perform hard-deletes on the <i>Team</i> entity.
	 * Rather, we are using soft-deletes.  The <i>TeamsService</i> is configured to call the <i>update(...)</i> method
	 * herein when its <i>delete(...)</i> method is invoked.
	 *
	 * @param team The Teams entity to "delete."
	 */
	public void delete(Teams team) {
		EntityTransaction et = entityManager.getTransaction();
		et.begin();

		entityManager.remove(readyById(team.getId()));
		try { et.commit(); }
		catch (Exception e) { if (et.isActive()) et.rollback(); throw new IllegalStateException(e); }
	}

	/**
	 * Our (paged) searches consist of two portions: 1.) Obtain a Collection of results that match the provided search
	 * criteria and 2.) Obtain a count of the <b>total</b> number of results that match the provided <i>SearchRequest</i>.
	 *
	 * Because of this, our Predicates must be built by two separate methods.  Therefore, that work is abstracted here,
	 * and any interested method may use it.
	 *
	 * @param builder The CriteriaBuilder that is being used to construct the query.
	 * @param team The Root of the Criteria to be queried that is being used (FROM clause).
	 * @param request The User-Provided Search Request.
	 * @return A (Typed) Collection of Predicates to be used in the query's WHERE clause.
	 */
	private List<Predicate> createSearchPredicates(CriteriaBuilder builder, Root<Teams> team, TeamsSearchRequest request) {
		List<Predicate> predicates = new ArrayList<Predicate>();

		// Predicate: Customer (required)
		predicates.add(builder.equal(team.<Customers>get("customerId").<Integer>get("id"), request.getCustomerId()));

		// Predicate: Name (optional).
		if (request.getName() != null && !request.getName().trim().isEmpty())
			predicates.add(builder.and(builder.equal(team.<String>get("team"), request.getName())));

		// Predicate: Creator (optional).
		if (request.getCreator() != null && !request.getCreator().trim().isEmpty())
			predicates.add(builder.and(builder.equal(team.<String>get("createusername"), request.getCreator())));

		// Predicate: Last Updater (optional).
		if (request.getUpdater() != null && !request.getUpdater().trim().isEmpty())
			predicates.add(builder.and(builder.equal(team.<String>get("updateusername"), request.getUpdater())));

		// Predicate: Active (optional).
		if (request.getActive() != null)
			predicates.add(builder.and(builder.equal(team.<Boolean>get("active"), request.getActive())));

		return predicates;
	}

}
