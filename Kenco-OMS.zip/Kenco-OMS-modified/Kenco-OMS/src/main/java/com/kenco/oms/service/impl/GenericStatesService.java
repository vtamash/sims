package com.kenco.oms.service.impl;

import com.kenco.oms.entity.States;
import com.kenco.oms.service.StatesAbstractService;

import javax.persistence.EntityManager;
import java.util.List;

/**
 * Basic extension of the StatesAbstractService.  This offers no additional business logic other than what is absolutely
 * enforced upon any extending class.  To implement custom business logic for any process, extend the StatesAbstractService.
 * However, you may use this bean if the you need nothing more than <b>basic</b> CRUD functionality with no additional
 * business logic.
 *
 * @see com.kenco.oms.service.StatesAbstractService
 */
public final class GenericStatesService extends StatesAbstractService {
	public GenericStatesService(EntityManager entityManager) {
		super(entityManager);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void createPreProcess(States state, Object... args) {
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void readPreProcess(Object... args) {
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void readSinglePreProcess(Object... args) {
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void updatePreProcess(Object... args) {
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void deletePreProcess(Object... args) {
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public States createPostProcess(States state, Object... args) {
		return state;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public List<States> readPostProcess(List<States> states, Object... args) {
		return states;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public States readSinglePostProcess(States state, Object... args) {
		return state;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public States updatePostProcess(States state, Object... args) {
		return state;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void deletePostProcess(States state, Object... args) {
	}
}
