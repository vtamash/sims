package com.kenco.oms.service;

/**
 * Interface for hooking into pre-processing for a Service's operation(s).
 *
 * @param <T> The type of Entity with which implementing Service is working.
 */
public interface PreProcessors<T> {
	/**
	 * Pre-Processing hook for the <b>create</b> Operation.  This method will allow implementing classes to implement custom
	 * business logic that will run <i>before</i> the <b>create</b> operation runs.
	 *
	 * @param t The typed Object that is being persisted.
	 * @param args Any arguments passed into the Service's create(...) method.
	 */
	public void createPreProcess(T t, Object... args);

	/**
	 * Pre-Processing hook for the <b>read</b> Operation.  This method will allow implementing classes to implement custom
	 * business logic that will run <i>before</i> the <b>read</b> operation runs.
	 *
	 * @param args Any arguments passed into the Service's read(...) method.
	 */
	public void readPreProcess(Object... args);

	/**
	 * Pre-Processing hook for the <b>read</b> Operation.  This method will allow implementing classes to implement custom
	 * business logic that will run <i>before</i> the <b>read</b> operation runs.
	 *
	 * @param args Any arguments passed into the Service's read(...) method.
	 */
	public void readSinglePreProcess(Object... args);

	/**
	 * Pre-Processing hook for the <b>update</b> Operation.  This method will allow implementing classes to implement custom
	 * business logic that will run <i>before</i> the <b>update</b> operation runs.
	 *
	 * @param args Any arguments passed into the Service's update(...) method.
	 */
	public void updatePreProcess(Object... args);

	/**
	 * Pre-Processing hook for the <b>delete</b> Operation.  This method will allow implementing classes to implement custom
	 * business logic that will run <i>before</i> the <b>delete</b> operation runs.
	 *
	 * @param args Any arguments passed into the Service's delete(...) method.
	 */
	public void deletePreProcess(Object... args);
}
