package com.kenco.oms.service.impl;

import com.kenco.oms.entity.Outboundorderheader;
import com.kenco.oms.service.OmsDownloadAbstractService;
import com.kenco.oms.service.OutboundOrderAbstractService;

import javax.persistence.EntityManager;
import java.util.List;

public final class GenericOutboundOrderService extends OutboundOrderAbstractService {
	/**
	 * {@inheritDoc}
	 */
	public GenericOutboundOrderService(EntityManager entityManager) {
		super(entityManager);
	}

	/**
	 * {@inheritDoc}
	 */
	public GenericOutboundOrderService(EntityManager entityManager, OmsDownloadAbstractService service) {
		super(entityManager,service);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String getNextOutboundOrderNumberPostProcess(String orderNumber, Object... args) {
		return orderNumber;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Outboundorderheader createPreProcess(Outboundorderheader outboundorderheader, Object... args) {
		return outboundorderheader;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Outboundorderheader updatePreProcess(Outboundorderheader outboundorderheader, Object... args) {
		return outboundorderheader;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Outboundorderheader deletePreProcess(Outboundorderheader outboundorderheader, Object... args) {
		return outboundorderheader;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Outboundorderheader createPostProcess(Outboundorderheader outboundorderheader, Object... args) {
		return outboundorderheader;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public List<Outboundorderheader> readPostProcess(List<Outboundorderheader> l, Object... args) {
		return l;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Outboundorderheader readSinglePostProcess(Outboundorderheader outboundorderheader, Object... args) {
		return outboundorderheader;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Outboundorderheader updatePostProcess(Outboundorderheader outboundorderheader, Object... args) {
		return outboundorderheader;
	}
}
