package com.kenco.oms.repository;

import com.kenco.oms.entity.BusinessUnits;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;
import java.util.ArrayList;
import java.util.List;

/**
 * Contains logic for communicating with the provided <i>EntityManager</i> for the <i>BusinessUnits</i> entity.
 *
 */
public final class BusinessUnitsRepository {
	@Autowired
	private EntityManager entityManager;

	private static Logger logger = Logger.getLogger(BusinessUnitsRepository.class);

	/**
	 * Default constructor.  Implementations that do not leverage IoC will need to provide an <i>EntityManager</i>
	 * by using the second constructor.
	 */
	public BusinessUnitsRepository() {}

	/**
	 * Convenience constructor to pass in the EntityManager.  This will (mostly) accommodate non-spring-backed
	 * implementations.
	 *
	 * @param entityManager The <i>EntityManager</i> to be used.
	 */
	public BusinessUnitsRepository(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	/**
	 * Persists the given <i>BusinessUnits</i> entity.
	 *
	 * @param businessUnit <i>BusinessUnits</i> entity to persist.
	 * @return The persisted <i>BusinessUnits</i> entity.
	 */
	public BusinessUnits create(BusinessUnits businessUnit) {
		EntityTransaction et = entityManager.getTransaction();
		et.begin();

		BusinessUnits bu = entityManager.merge(businessUnit);
		try { et.commit(); }
		catch (Exception e) { if (et.isActive()) et.rollback(); throw new IllegalStateException(e); }
		return bu;
	}

	/**
	 * Retrieves a single <i>BusinessUnits</i> entity that matches the provided ID (<b>Primary Key</b>).
	 *
	 * @param id The ID (<b>Primary Key</b>) that the <i>BusinessUnit</i> must match.
	 * @return The <i>BusinessUnit</i> entity matching the provided ID (<b>Primary Key</b>).
	 *
	 * @throws javax.persistence.NoResultException When there is no result.
     * @throws javax.persistence.NonUniqueResultException When more than one result exists.
	 */
	public BusinessUnits readById(int id) {
		logger.info("Starting BusinessUnitsRepository.readById()");

		Query query = entityManager.createQuery("SELECT b FROM BusinessUnits b WHERE b.id = :id")
				.setParameter("id", id);

		logger.info("Exiting BusinessUnitsRepository.readById()");

		return (BusinessUnits) query.getSingleResult();
	}

	/**
	 * Retrieves a single <i>BusinessUnits</i> that matches the provided <b>name</b>.
	 *
	 * @param name The name of the <i>BusinessUnits</i> entity to retrieve.
	 * @return The <i>BusinessUnits</i> entity that matches the provided <b>name</b>.
	 *
	 * @throws javax.persistence.NoResultException When there is no result.
     * @throws javax.persistence.NonUniqueResultException WHen more than one result exists.
	 */
	public BusinessUnits readByName(String name) {
		logger.info("Starting BusinessUnitsRepository.readByName()");

		Query query = entityManager.createQuery("SELECT b FROM BusinessUnits b WHERE UPPER(b.businessunit) = :name").
				setParameter("name", name);

		logger.info("Exiting BusinessUnitsRepository.readByName()");

		return (BusinessUnits) query.getSingleResult();
	}

	/**
	 * Retrieves all <i>BusinessUnits</i> for the provided <i>Customers</i> Id.
	 *
	 * @param customerId <i>Customers</i> ID for the <i>BusinessUnits</i> to be retrieved.
	 * @return Typed Collection of <i>BusinessUnits</i> owned by the <i>Customers</i> entity for the provided <b>Id</b>.
	 */
	public List<BusinessUnits> readByCustomerId(int customerId) {
		logger.info("Starting BusinessUnitsRepository.readByCustomerId()");

		Query qry = entityManager.createQuery("SELECT b FROM BusinessUnits b WHERE b.customer.id = :customerId").
				setParameter("customerId", customerId);

		List<BusinessUnits> businessUnits = new ArrayList<BusinessUnits>();
		for (Object curObject : qry.getResultList())
			if (curObject instanceof BusinessUnits)
				businessUnits.add((BusinessUnits) curObject);

		logger.info("Exiting BusinessUnitsRepository.readByCustomerId()");

		return businessUnits;
	}

	/**
	 * Retrieves all <i>BusinessUnits</i> for the provided <i>Customers</i> Id that match the provided <b>active</b>
	 * state.
	 *
	 * @param customerId <i>Customers</i> ID for the <i>BusinessUnits</i> to be retrieved.
	 * @param active The state of activity that the <i>BusinessUnits</i> should match.
	 * @return Typed Collection of <i>BusinessUnits</i>.
	 */
	public List<BusinessUnits> readActiveByCustomerId(int customerId, boolean active) {
		logger.info("Starting BusinessUnitsRepository.readActiveByCustomerId()");

		Query qry = entityManager.createQuery("SELECT b FROM BusinessUnits b WHERE b.customer.id = :customerid AND b.active = :active").
				setParameter("customerid", customerId)
				.setParameter("active", active);

		List<BusinessUnits> businessUnits = new ArrayList<BusinessUnits>();
		for (Object curObject : qry.getResultList())
			if (curObject instanceof BusinessUnits)
				businessUnits.add((BusinessUnits) curObject);

		logger.info("Exiting BusinessUnitsRepository.readActiveByCustomerId()");

		return businessUnits;
	}

	/**
	 * Saves the given <i>BusinessUnits</i> entity.
	 *
	 * @param businessUnit <i>BusinessUnits</i> entity to save.
	 * @return Updated <i>BusinessUnits</i> entity.
	 */
	public BusinessUnits update(BusinessUnits businessUnit) {
		EntityTransaction et = entityManager.getTransaction();
		et.begin();

		BusinessUnits bu = entityManager.merge(businessUnit);
		try { et.commit(); }
		catch (Exception e) { if (et.isActive()) et.rollback(); throw new IllegalStateException(e); }
		return bu;
	}
}