package com.kenco.oms.search;

public class OmsInventoryInquirySearchRequest extends SearchRequest {

	private String skunumb;
	private String lotid;
	private String deptno;
	private String holdcode;
	private boolean hasholdcode;
	
	public String getSkunumb() {
		return skunumb;
	}
	public void setSkunumb(String skunumb) {
		this.skunumb = skunumb;
	}
	public String getLotid() {
		return lotid;
	}
	public void setLotid(String lotid) {
		this.lotid = lotid;
	}
	public String getDeptno() {
		return deptno;
	}
	public void setDeptno(String deptno) {
		this.deptno = deptno;
	}
	public String getHoldcode() {
		return holdcode;
	}
	public void setHoldcode(String holdcode) {
		this.holdcode = holdcode;
	}
	public boolean isHasholdcode() {
		return hasholdcode;
	}
	public void setHasholdcode(boolean hasholdcode) {
		this.hasholdcode = hasholdcode;
	}
}
