package com.kenco.oms.search;

import com.kenco.oms.entity.Customers;

/**
 * Generic, abstract wrapper for a SearchRequest.
 *
 */
public abstract class SearchRequest {
	private Integer limit;
	private Short page;
	private Short start;

	private Integer customerId;
	private Customers customer;

	public Short getPage() {
		return page;
	}

	public void setPage(Short page) {
		this.page = page;
	}

	public Integer getLimit() {
		return limit;
	}

	public void setLimit(Integer limit) {
		this.limit = limit;
	}

	public Short getStart() {
		return start;
	}

	public void setStart(Short start) {
		this.start = start;
	}

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public Customers getCustomer() {
		return customer;
	}

	public void setCustomer(Customers customer) {
		this.customer = customer;
	}
}
