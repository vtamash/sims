/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kenco.oms.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name = "TABLEDEFAULTS")
@XmlRootElement
@NamedQueries({
   @NamedQuery(name = "Tabledefaults.findAll", query = "SELECT t FROM Tabledefaults t"),
   @NamedQuery(name = "Tabledefaults.findById", query = "SELECT t FROM Tabledefaults t WHERE t.id = :id"),
   @NamedQuery(name = "Tabledefaults.findByActive", query = "SELECT t FROM Tabledefaults t WHERE t.active = :active"),
   @NamedQuery(name = "Tabledefaults.findByTablename", query = "SELECT t FROM Tabledefaults t WHERE t.tablename = :tablename"),
   @NamedQuery(name = "Tabledefaults.findByColumnname", query = "SELECT t FROM Tabledefaults t WHERE t.columnname = :columnname"),
   @NamedQuery(name = "Tabledefaults.findByValue", query = "SELECT t FROM Tabledefaults t WHERE t.value = :value"),
   @NamedQuery(name = "Tabledefaults.findByCreatetimestamp", query = "SELECT t FROM Tabledefaults t WHERE t.createtimestamp = :createtimestamp"),
   @NamedQuery(name = "Tabledefaults.findByCreateusername", query = "SELECT t FROM Tabledefaults t WHERE t.createusername = :createusername"),
   @NamedQuery(name = "Tabledefaults.findByCreateprogram", query = "SELECT t FROM Tabledefaults t WHERE t.createprogram = :createprogram"),
   @NamedQuery(name = "Tabledefaults.findByUpdatetimestamp", query = "SELECT t FROM Tabledefaults t WHERE t.updatetimestamp = :updatetimestamp"),
   @NamedQuery(name = "Tabledefaults.findByUpdateusername", query = "SELECT t FROM Tabledefaults t WHERE t.updateusername = :updateusername"),
   @NamedQuery(name = "Tabledefaults.findByUpdateprogram", query = "SELECT t FROM Tabledefaults t WHERE t.updateprogram = :updateprogram")})
public class Tabledefaults implements Serializable {
   private static final long serialVersionUID = 1L;
   @Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
   @Basic(optional = false)
   @Column(name = "ID")
   private Integer id;
   @Basic(optional = false)
   @NotNull
   @Column(name = "ACTIVE")
   private short active;
   @Basic(optional = false)
   @NotNull
   @Size(min = 1, max = 100)
   @Column(name = "TABLENAME")
   private String tablename;
   @Basic(optional = false)
   @NotNull
   @Size(min = 1, max = 100)
   @Column(name = "COLUMNNAME")
   private String columnname;
   @Basic(optional = false)
   @NotNull
   @Size(min = 1, max = 256)
   @Column(name = "VALUE")
   private String value;
   @Basic(optional = false)
   @NotNull
   @Column(name = "CREATETIMESTAMP")
   @Temporal(TemporalType.TIMESTAMP)
   private Date createtimestamp;
   @Basic(optional = false)
   @NotNull
   @Size(min = 1, max = 10)
   @Column(name = "CREATEUSERNAME")
   private String createusername;
   @Basic(optional = false)
   @NotNull
   @Size(min = 1, max = 50)
   @Column(name = "CREATEPROGRAM")
   private String createprogram;
   @Column(name = "UPDATETIMESTAMP")
   @Temporal(TemporalType.TIMESTAMP)
   private Date updatetimestamp;
   @Basic(optional = false)
   @NotNull
   @Size(min = 1, max = 10)
   @Column(name = "UPDATEUSERNAME")
   private String updateusername;
   @Basic(optional = false)
   @NotNull
   @Size(min = 1, max = 50)
   @Column(name = "UPDATEPROGRAM")
   private String updateprogram;
   @JoinColumn(name = "CUSTOMER_ID", referencedColumnName = "ID")
   @ManyToOne
   private Customers customerId;
   @JoinColumn(name = "BUSINESSUNIT_ID", referencedColumnName = "ID")
   @ManyToOne
   private BusinessUnits businessunitId;

   public Tabledefaults() {
   }

   public Tabledefaults(Integer id) {
      this.id = id;
   }

   public Tabledefaults(Integer id, short active, String tablename, String columnname, String value, Date createtimestamp, String createusername, String createprogram, Date updatetimestamp, String updateusername, String updateprogram) {
      this.id = id;
      this.active = active;
      this.tablename = tablename;
      this.columnname = columnname;
      this.value = value;
      this.createtimestamp = createtimestamp;
      this.createusername = createusername;
      this.createprogram = createprogram;
      this.updatetimestamp = updatetimestamp;
      this.updateusername = updateusername;
      this.updateprogram = updateprogram;
   }

   public Integer getId() {
      return id;
   }

   public void setId(Integer id) {
      this.id = id;
   }

   public short getActive() {
      return active;
   }

   public void setActive(short active) {
      this.active = active;
   }

   public String getTablename() {
      return tablename;
   }

   public void setTablename(String tablename) {
      this.tablename = tablename;
   }

   public String getColumnname() {
      return columnname;
   }

   public void setColumnname(String columnname) {
      this.columnname = columnname;
   }

   public String getValue() {
      return value;
   }

   public void setValue(String value) {
      this.value = value;
   }

   public Date getCreatetimestamp() {
      return createtimestamp;
   }

   public void setCreatetimestamp(Date createtimestamp) {
      this.createtimestamp = createtimestamp;
   }

   public String getCreateusername() {
      return createusername;
   }

   public void setCreateusername(String createusername) {
      this.createusername = createusername;
   }

   public String getCreateprogram() {
      return createprogram;
   }

   public void setCreateprogram(String createprogram) {
      this.createprogram = createprogram;
   }

   public Date getUpdatetimestamp() {
      return updatetimestamp;
   }

   public void setUpdatetimestamp(Date updatetimestamp) {
      this.updatetimestamp = updatetimestamp;
   }

   public String getUpdateusername() {
      return updateusername;
   }

   public void setUpdateusername(String updateusername) {
      this.updateusername = updateusername;
   }

   public String getUpdateprogram() {
      return updateprogram;
   }

   public void setUpdateprogram(String updateprogram) {
      this.updateprogram = updateprogram;
   }

   public Customers getCustomerId() {
      return customerId;
   }

   public void setCustomerId(Customers customerId) {
      this.customerId = customerId;
   }

   public BusinessUnits getBusinessunitId() {
      return businessunitId;
   }

   public void setBusinessunitId(BusinessUnits businessunitId) {
      this.businessunitId = businessunitId;
   }

   @Override
   public int hashCode() {
      int hash = 0;
      hash += (id != null ? id.hashCode() : 0);
      return hash;
   }

   @Override
   public boolean equals(Object object) {
      // TODO: Warning - this method won't work in the case the id fields are not set
      if (!(object instanceof Tabledefaults)) {
         return false;
      }
      Tabledefaults other = (Tabledefaults) object;
      if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
         return false;
      }
      return true;
   }

   @Override
   public String toString() {
      return "com.kenco.oms.entity.Tabledefaults[ id=" + id + " ]";
   }
   
}
