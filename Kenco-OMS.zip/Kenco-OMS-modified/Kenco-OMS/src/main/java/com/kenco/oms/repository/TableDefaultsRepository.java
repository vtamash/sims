package com.kenco.oms.repository;

import com.kenco.oms.entity.Tabledefaults;
import org.apache.log4j.Logger;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

/**
 * Contains logic for communicating with the provided EntityManager for the
 * Tabledefaults entity.
 */
public final class TableDefaultsRepository {

   private EntityManager em;
   private static Logger logger = Logger.getLogger(TableDefaultsRepository.class);

   /**
    * Default constructor. This exists to accommodate any future Spring-backed
    * projects that may require OMS.
    */
   public TableDefaultsRepository() {
   }

   /**
    * Convenience constructor to pass in the EntityManager. This will (mostly)
    * accommodate non-spring-backed implementations.
    *
    * @param entityManager The EntityManager to be used.
    */
   public TableDefaultsRepository(EntityManager entityManager) {
      this.em = entityManager;
   }

   /**
    * Returns a Tabledefaults entity for the specified parms.
    *
    * @param pCustomerId The Customer Id for record needed.
    * @param pBusinessUnitId The BusinessUnit Id for record needed.
    * @param pTableName The table name for record needed.
    * @param pColumnName The column name for record needed.
    *
    * @return a TableDefaults object
    */
   public Tabledefaults get(int pCustomerId, int pBusinessUnitId, String pTableName, String pColumnName) {
      logger.info("Reading TableDefaults for: Customer ID: " + pCustomerId);

      try {
         String sql = "select t from Tabledefaults t where t.customerId.id = :cusid and t.businessunitId.id = :busid and upper(t.tablename) = :tablename and upper(t.columnname) = :columnname and t.active = 1";
         TypedQuery<Tabledefaults> q = em.createQuery(sql, Tabledefaults.class).
                 setParameter("cusid", pCustomerId).
                 setParameter("busid", pBusinessUnitId).
                 setParameter("tablename", pTableName.toUpperCase()).
                 setParameter("columnname", pColumnName.toUpperCase());
         Tabledefaults tabledft = q.getSingleResult();
         logger.info("Finished reading TableDefaults for: Customer ID - " + pCustomerId);
         return tabledft;
      } catch (Exception e) {
         logger.error("Error reading TableDefaults: ", e);
         return null;
      }
   }

   /**
    * Returns a value for specific tabledefault record..
    *
    * @param pCustomerId The Customer Id for record needed.
    * @param pBusinessUnitId The BusinessUnit Id for record needed.
    * @param pTableName The table name for record needed.
    * @param pColumnName The column name for record needed.
    *
    * @return the value from the record
    */
   public String getValue(int pCustomerId, int pBusinessUnitId, String pTableName, String pColumnName) {
      logger.info("Reading TableDefaults for: Customer ID: " + pCustomerId + ", Table: " + pTableName.trim() + ", Column: " + pColumnName.trim());
      Tabledefaults t = get(pCustomerId, pBusinessUnitId, pTableName, pColumnName);
      logger.info("Finished reading TableDefaults for: Customer ID: " + pCustomerId + ", Table: " + pTableName.trim() + ", Column: " + pColumnName.trim());
      return t == null ? "" : t.getValue();
   }
}
