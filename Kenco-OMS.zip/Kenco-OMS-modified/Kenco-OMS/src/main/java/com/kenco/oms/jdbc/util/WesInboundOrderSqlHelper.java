package com.kenco.oms.jdbc.util;

import com.kenco.oms.jdbc.model.Delimiter;
import com.kenco.oms.search.SearchRequest;
import com.kenco.oms.search.WesInboundSearchRequest;

import java.util.ArrayList;
import java.util.List;

/**
 * SqlHelper implementation for the WesInboundOrder entity.
 *
 * @see com.kenco.oms.jdbc.util.SqlHelper
 */
public final class WesInboundOrderSqlHelper extends SqlHelper {
	private static final String TABLE_NAME   = "Inthdr";
	private static final String ORDER_COLUMN = "ORDERNO";

	/**
	 * {@inheritDoc}
	 */
	public WesInboundOrderSqlHelper(SearchRequest request, int maxPageSize) {
		super(request, maxPageSize, WesInboundOrderSqlHelper.TABLE_NAME, WesInboundOrderSqlHelper.ORDER_COLUMN);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	List<Delimiter> findDelimiters() {
		WesInboundSearchRequest search = (WesInboundSearchRequest) request;

		List<Delimiter> delimiters = new ArrayList<>();

		if (search.getPrefix() != null)
			delimiters.add(new Delimiter("ORDERNO", search.getPrefix() + "%", Delimiter.OPERATOR_LIKE));

		if (search.getNumber() != null)
			delimiters.add(new Delimiter("ORDERNO", "%" + search.getNumber() + "%", Delimiter.OPERATOR_LIKE));

		if (search.getStatus() != null)
			delimiters.add(new Delimiter("STATUS", search.getStatus(), Delimiter.OPERATOR_EQUAL));

		if (search.getType() != null)
			delimiters.add(new Delimiter("RCPTTYPE", search.getType(), Delimiter.OPERATOR_EQUAL));

		if (search.getVendor() != null)
			delimiters.add(new Delimiter("NAME", search.getVendor() + "%", Delimiter.OPERATOR_LIKE));

		if (search.getScac() != null)
			delimiters.add(new Delimiter("SCAC", search.getScac() + "%", Delimiter.OPERATOR_LIKE));

		if (search.getScdDate() != null)
			delimiters.add(new Delimiter("SCDADATE", format.format(search.getScdDate()), Delimiter.OPERATOR_EQUAL));

		if (search.getActDate() != null)
			delimiters.add(new Delimiter("ACTADATE", format.format(search.getActDate()), Delimiter.OPERATOR_EQUAL));

		return delimiters;
	}
}
