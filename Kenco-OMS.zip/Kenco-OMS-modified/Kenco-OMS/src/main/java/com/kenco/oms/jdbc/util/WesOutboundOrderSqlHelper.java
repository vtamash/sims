package com.kenco.oms.jdbc.util;

import com.kenco.oms.jdbc.model.Delimiter;
import com.kenco.oms.search.SearchRequest;
import com.kenco.oms.search.WesOutboundSearchRequest;

import java.util.ArrayList;
import java.util.List;

/**
 * SqlHelper implementation for the WesOutboundOrder entity.
 *
 * @see com.kenco.oms.jdbc.util.SqlHelper
 */
public final class WesOutboundOrderSqlHelper extends SqlHelper {
	private static final String TABLE_NAME   = "Ordhdr";
	private static final String ORDER_COLUMN = "ORDERNO";

	/**
	 * {@inheritDoc}
	 */
	public WesOutboundOrderSqlHelper(SearchRequest request, int maxPageSize) {
		super(request, maxPageSize, WesOutboundOrderSqlHelper.TABLE_NAME, WesOutboundOrderSqlHelper.ORDER_COLUMN);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	List<Delimiter> findDelimiters() {
		WesOutboundSearchRequest search = (WesOutboundSearchRequest) request;

		List<Delimiter> delimiters = new ArrayList<>();

		if (search.getPrefix() != null)
			delimiters.add(new Delimiter("ORDERNO", search.getPrefix().toUpperCase() + "%", Delimiter.OPERATOR_LIKE));

		if (search.getDoor() != null)
			delimiters.add(new Delimiter("DOOR", search.getDoor().toUpperCase() + "%", Delimiter.OPERATOR_LIKE));

		if (search.getLoad() != null)
			delimiters.add(new Delimiter("LOADNO", search.getLoad().toUpperCase() + "%", Delimiter.OPERATOR_LIKE));

		if (search.getNumber() != null)
			delimiters.add(new Delimiter("ORDERNO", "%" + search.getNumber().toUpperCase() + "%", Delimiter.OPERATOR_LIKE));

		if (search.getShipTo() != null)
			delimiters.add(new Delimiter("TNAME", search.getShipTo().toUpperCase() + "%", Delimiter.OPERATOR_LIKE));

		if (search.getStatus() != null)
			delimiters.add(new Delimiter("STATUS", search.getStatus(), Delimiter.OPERATOR_EQUAL));

		if (search.getType() != null)
			delimiters.add(new Delimiter("ORDTYPE", search.getType(), Delimiter.OPERATOR_EQUAL));

		if (search.getZipcode() != null)
			delimiters.add(new Delimiter("TZIP", search.getZipcode().toUpperCase() + "%", Delimiter.OPERATOR_LIKE));

		if (search.getScd() != null)
			delimiters.add(new Delimiter("SCDDDATE", format.format(search.getScd()), Delimiter.OPERATOR_EQUAL));

		if (search.getAct() != null)
			delimiters.add(new Delimiter("ACTDDATE", format.format(search.getAct()), Delimiter.OPERATOR_EQUAL));

		return delimiters;
	}
}
