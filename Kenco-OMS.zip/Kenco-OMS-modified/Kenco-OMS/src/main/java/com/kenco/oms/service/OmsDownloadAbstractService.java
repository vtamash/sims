package com.kenco.oms.service;

import com.kenco.oms.entity.*;
import com.kenco.oms.repository.OmsdownloadRepository;
import com.kenco.oms.repository.TableDefaultsRepository;
import com.kenco.oms.service.impl.GenericSkumasService;
import com.kenco.oms.utilities.Enums;
import javax.persistence.EntityManager;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Class embodies the actual work for communicating with a OmsDownloadRepository. To implement custom business logic for any
 * of the provided operations, simply extend this class and enter your business logic into the appropriate hook.
 *
 * @see com.kenco.oms.service.impl.GenericOmsDownloadService
 */
public abstract class OmsDownloadAbstractService extends AbstractService<Omsdownload> {
	private final OmsdownloadRepository repository;

	protected final SkuMasAbstractService   skuService;
	protected final TableDefaultsRepository tableDefaultRepo;

	protected final DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
	protected final DateFormat timeFormat = new SimpleDateFormat("HHmmss");

	/**
	 * Convenience constructor when no custom business logic is required.
	 *
	 * @param entityManager The EntityManager that this Service will need to use.
	 */
	public OmsDownloadAbstractService(EntityManager entityManager) {
		this.repository       = new OmsdownloadRepository(entityManager);
		this.tableDefaultRepo = new TableDefaultsRepository(entityManager);
		this.skuService       = new GenericSkumasService(entityManager);
	}

	/**
	 * Constructor for when implementor requires using their own impelmentation of the <i>SkuMasAbstractService</i>.
	 *
	 * @param entityManager The EntityManager that this Service will need to use.
	 */
	public OmsDownloadAbstractService(EntityManager entityManager, SkuMasAbstractService skuService) {
		this.repository       = new OmsdownloadRepository(entityManager);
		this.tableDefaultRepo = new TableDefaultsRepository(entityManager);
		this.skuService       = skuService;
	}

	/**
	 * Generates the Data String for an <i>OutboundOrderHeader</i>.
	 *
	 * The format of this may be application specific, so each implementation will need to provide their own Data
	 * String for the creation.
	 *
	 * @param order The OutboundOrderHeader triggering this event.
	 * @param whsid System property.
	 * @return Data String to be used.
	 */
	protected abstract String generateOutboundHeaderDataString(Outboundorderheader order, String whsid);

	/**
	 * Generates the Data String for an <i>OutboundOrderDetail</i>.
	 *
	 * The format of this may be application specific, so each implementation will need to provide their own Data
	 * String for the creation.
	 *
	 * <b>Note</b>: This is called for each <i>OutboundOrderDetail</i> contained within the <i>OutboundOrderHeader</i>.
	 * Implementors should build and return a Data String for the <i>OutboundOrderDetail</i> passed in <b>only</b>.
	 *
	 * @param detail The (current) OutboundOrderDetail.
	 * @param whsid System property.
	 * @return Data String to be used.
	 */
	protected abstract String generateOutboundDetailDataString(Outboundorderdetail detail, String whsid);

	/**
	 * Generates the Data String for an <i>InboundOrderHeader</i>.
	 *
	 * The format of this may be application specific, so each implementation will need to provide their own Data
	 * String for the creation.
	 *
	 * @param order The InboundOrderHeader triggering this event.
	 * @param whsid System property.
	 * @return Data String to be used.
	 */
	protected abstract String generateInboundHeaderDataString(Inboundorderheader order, String whsid);

	/**
	 * Generates the Data String for an <i>InboundOrderDetail</i>.
	 *
	 * The format of this may be application specific, so each implementation will need to provide their own Data
	 * String for the creation.
	 *
	 * <b>Note</b>: This is called for each <i>InboundOrderDetail</i> contained within the <i>InboundOrderHeader</i>.
	 * Implementors should build and return a Data String for the <i>InboundOrderDetail</i> passed in <b>only</b>.
	 *
	 * @param detail The (current) OutboundOrderDetail.
	 * @param whsid System property.
	 * @return Data String to be used.
	 */
	protected abstract String generateInboundDetailDataString(Inboundorderdetail detail, String whsid);

	/**
	 * Forward facing method to initiate the process of creating a sequence of OmsDownload entities.  This action
	 * is triggered by creating an <i>OutboundOrderHeader</i>.
	 *
	 * @param order The <i>OutboundOrderHeader</i> entity whose creation has triggered this call.
	 * @param args Any arguments extending class requires during pre-processing.
	 * @return A Typed List containing each OmsDownload that was persisted.
	 */
	public final List<Omsdownload> create(Outboundorderheader order, Object... args) {
        // Generate the <i>OmsDownload</i> entities.
		List<Omsdownload> lstDownload = generateDownloads(order);

        // Abstract business logic.
        for (Omsdownload curDownload : lstDownload) {
            curDownload.setCreateprogram("OmsDownloadService.create(...)"); // Extending classes are encouraged to override this.
            curDownload.setCreateusername(order.getUpdateusername());
            curDownload.setCreatetimestamp(new Date());

            curDownload.setUpdateprogram("OmsDownloadService.create(...)"); // Extending classes are encouraged to override this.
            curDownload.setUpdateusername(order.getUpdateusername());
        }

		// Pre-Processing hook.
        List<Omsdownload> preProcessed = new ArrayList<Omsdownload>();
        for (Omsdownload curDownload : lstDownload)
    		preProcessed.add(createPreProcess(curDownload, args));

		// Perform the actual create.
		List<Omsdownload> persisted = repository.createBatch(preProcessed);

		// Post-Processing hook and return.
        List<Omsdownload> postProcessed = new ArrayList<Omsdownload>();
        for (Omsdownload curDownload : persisted)
    		postProcessed.add(createPostProcess(curDownload, args));

		return postProcessed;
	}

	/**
	 * Forward facing method to initiate the process of creating a sequence of OmsDownload entities.  This action
	 * is triggered by creating an <i>InboundOrderHeader</i>.
	 *
	 * @param order The <i>OutboundOrderHeader</i> entity whose creation has triggered this call.
	 * @param args Any arguments extending class requires during pre-processing.
	 * @return A Typed List containing each OmsDownload that was persisted.
	 */
	public final List<Omsdownload> create(Inboundorderheader order, Object... args) {
        // Generate the <i>OmsDownload</i> entities.
		List<Omsdownload> lstDownload = generateDownloads(order);

        // Abstract business logic.
        for (Omsdownload curDownload : lstDownload) {
            curDownload.setCreateprogram("OmsDownloadService.create(...)"); // Extending classes are encouraged to override this.
            curDownload.setCreateusername(order.getUpdateusername());
            curDownload.setCreatetimestamp(new Date());

            curDownload.setUpdateprogram("OmsDownloadService.create(...)"); // Extending classes are encouraged to override this.
            curDownload.setUpdateusername(order.getUpdateusername());
        }

		// Pre-Processing hook.
        List<Omsdownload> preProcessed = new ArrayList<Omsdownload>();
        for (Omsdownload curDownload : lstDownload)
    		preProcessed.add(createPreProcess(curDownload, args));

		// Perform the actual create.
		List<Omsdownload> persisted = repository.createBatch(preProcessed);

		// Post-Processing hook and return.
        List<Omsdownload> postProcessed = new ArrayList<Omsdownload>();
        for (Omsdownload curDownload : persisted)
    		postProcessed.add(createPostProcess(curDownload, args));

		return postProcessed;
	}

	/**
	 * Performs the work of generating each <i>OmsDownload</i> entity for the given OutboundOrderHeader.
	 *
	 * @param order The <i>OutboundOrderHeader</i> whose creation triggered this call.
	 * @return A Typed List containing each OmsDownload that will need to be persisted.
	 */
	private List<Omsdownload> generateDownloads(Outboundorderheader order) {
		String whsid = tableDefaultRepo.getValue(order.getCustomerId().getId(),
				                                 order.getBusinessunitId().getId(),
				                                 Enums.eOMSTableNames.OMSDOWNLOAD.toString(),
				                                 Enums.eOMSDOWNLOADColumnNames.WHSID.toString());

		List<Omsdownload> downloads = new ArrayList<Omsdownload>();

		// Step 1: Generate an OmsDownload for the OutboundOrderHeader.
		downloads.add(createOutboundHeaderDownload(order, whsid));

		// Step 2: Generate an OmsDownload for each OutboundOrderDetail.
		for (Outboundorderdetail curDetail : order.getOutboundorderdetailCollection())
			downloads.add(createOutboundDetailsDownload(curDetail, whsid));

		return downloads;
	}

	/**
	 * Performs the work of generating each <i>OmsDownload</i> entity for the given InboundOrderHeader.
	 *
	 * @param order The <i>OutboundOrderHeader</i> whose creation triggered this call.
	 * @return A Typed List containing each OmsDownload that will need to be persisted.
	 */
	private List<Omsdownload> generateDownloads(Inboundorderheader order) {
		String whsid = tableDefaultRepo.getValue(order.getCustomerId().getId(),
				                                 order.getBusinessunitId().getId(),
				                                 Enums.eOMSTableNames.OMSDOWNLOAD.toString(),
				                                 Enums.eOMSDOWNLOADColumnNames.WHSID.toString());

		List<Omsdownload> downloads = new ArrayList<Omsdownload>();

		// Step 1: Generate an OmsDownload for the OutboundOrderHeader.
		downloads.add(createInboundHeaderDownload(order, whsid));

		// Step 2: Generate an OmsDownload for each OutboundOrderDetail.
		for (Inboundorderdetail curDetail : order.getInboundorderdetailCollection())
			downloads.add(createInboundDetailsDownload(curDetail, whsid));

		return downloads;
	}

	/**
	 * Creates the First portion of the total <i>Omsdownload</i> Collection.
	 *
	 * @param order The <i>OutboundOrderHeader</i> entity that is to be converted.
	 * @return The fully created Omsdownload entity ready to be persisted.
	 */
	private Omsdownload createOutboundHeaderDownload(Outboundorderheader order, String whsid) {
		Omsdownload download = new Omsdownload();
		download.setSequence(0);
		download.setTransactiontype(Enums.eOMSDownloadTransactionTypes.ORDH.toString());
		download.setCustomerId(order.getCustomerId());
		download.setOrdernumber(order.getOrdernumber());
		download.setThedata(generateOutboundHeaderDataString(order,whsid));
		download.setStatus(Enums.eOMSDownloadStatuses.O.toString());
		return download;
	}

	/**
	 * Creates the First portion of the total <i>Omsdownload</i> Collection.
	 *
	 * @param order The <i>InboundOrderHeader</i> entity that is to be converted.
	 * @return The fully created Omsdownload entity ready to be persisted.
	 */
	private Omsdownload createInboundHeaderDownload(Inboundorderheader order, String whsid) {
		Omsdownload download = new Omsdownload();
		download.setSequence(0);
		download.setTransactiontype(Enums.eOMSDownloadTransactionTypes.INTH.toString());
		download.setCustomerId(order.getCustomerId());
		download.setOrdernumber(order.getOrdernumber());
		download.setThedata(generateInboundHeaderDataString(order,whsid));
		download.setStatus(Enums.eOMSDownloadStatuses.O.toString());
		return download;
	}

	/**
	 * Creates the second portion of the total <i>Omsdownload</i> Collection for an <i>OutboundOrderHeader</i>.
	 *
	 * @param detail The <i>OutboundOrderDetail</i> entity that is to be converted.
	 * @return The fully created Omsdownload entity ready to be persisted.
	 */
	private Omsdownload createOutboundDetailsDownload(Outboundorderdetail detail, String whsid) {
		Outboundorderheader order = detail.getOutboundorderheaderId();

		Omsdownload download = new Omsdownload();
		download.setSequence(1);
		download.setTransactiontype(Enums.eOMSDownloadTransactionTypes.ORDT.toString());
		download.setCustomerId(order.getCustomerId());
		download.setOrdernumber(order.getOrdernumber());
		download.setThedata(generateOutboundDetailDataString(detail, whsid));
		download.setStatus(Enums.eOMSDownloadStatuses.O.toString());
		return download;
	}

	/**
	 * Creates the second portion of the total <i>Omsdownload</i> Collection for an <i>InboundOrderHeader</i>.
	 *
	 * @param detail The <i>InboundOrderDetail</i> entity that is to be converted.
	 * @return The fully created Omsdownload entity ready to be persisted.
	 */
	private Omsdownload createInboundDetailsDownload(Inboundorderdetail detail, String whsid) {
		Inboundorderheader order = detail.getInboundorderheaderId();

		Omsdownload download = new Omsdownload();
		download.setSequence(1);
		download.setTransactiontype(Enums.eOMSDownloadTransactionTypes.INTD.toString());
		download.setCustomerId(order.getCustomerId());
		download.setOrdernumber(order.getOrdernumber());
		download.setThedata(generateInboundDetailDataString(detail,whsid));
		download.setStatus(Enums.eOMSDownloadStatuses.O.toString());
		return download;
	}
}
