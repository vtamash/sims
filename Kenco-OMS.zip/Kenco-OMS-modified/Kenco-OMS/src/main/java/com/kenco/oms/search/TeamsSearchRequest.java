package com.kenco.oms.search;

public final class TeamsSearchRequest extends SearchRequest {
	private String name;
	private Boolean active;
	private String creator;
	private String updater;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Boolean getActive() {
		return active;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public String getUpdater() {
		return updater;
	}

	public void setUpdater(String updator) {
		this.updater = updator;
	}
}
