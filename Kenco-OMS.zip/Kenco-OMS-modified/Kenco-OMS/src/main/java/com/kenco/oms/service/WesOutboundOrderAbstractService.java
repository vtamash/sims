package com.kenco.oms.service;

import com.kenco.oms.entity.Customers;
import com.kenco.oms.jdbc.model.WesOutboundOrder;
import com.kenco.oms.search.WesOutboundSearchRequest;
import com.kenco.oms.repository.WesOutboundOrderRepository;

import javax.sql.DataSource;
import java.util.List;
import java.util.Map;

/**
 * Class embodies the actual work for communicating with a OutboundOrderRepository.  To implement custom business logic
 * for any of the provided operations, simply extend this class and enter your business logic into the appropriate hook.
 *
 * @see com.kenco.oms.service.impl.GenericWesOutboundOrderService
 */
public abstract class WesOutboundOrderAbstractService extends AbstractService<WesOutboundOrder> {
	private WesOutboundOrderRepository repository;

	/**
	 * Constructor.
	 *
	 * @param dataSource The DataSource that this Service will need to use.
	 */
	public WesOutboundOrderAbstractService(DataSource dataSource) {
		repository = new WesOutboundOrderRepository(dataSource);
	}

	/** TODO Change return type?
	 * Simple search on the <i>WesOutboundOrderNumber</i>'s <b>number</b> field.
	 *
	 * @param number The <i>number</i> to search for.
	 * @param customer The <i>Customer</i> by which we will delimit the search.
	 * @return Typed collection holding all matching results.
	 */
	public List<Map<String,Object>> searchByOrderNumbers(String number, String prefix, Customers customer) {
		return repository.searchOrderNumbers(number, prefix, customer);
	}

	/** TODO Change return type?
	 * Simple search on the <i>WesOutboundOrderNumber</i>'s <b>door</b> field.
	 *
	 * @param door The <i>door</i> to search for.
	 * @param customer The <i>Customer</i> by which we will delimit the search.
	 * @return Typed collection holding all matching results.
	 */
	public List<Map<String,Object>> searchByDoor(String door, Customers customer) {
		return repository.searchDoors(door, customer);
	}

	/** TODO Change return type?
	 * Simple search on the <i>WesOutboundOrderNumber</i>'s <b>scac</b> field.
	 *
	 * @param scac The <i>scac</i> to search for.
	 * @param customer The <i>Customer</i> by which we will delimit the search.
	 * @return Typed collection holding all matching results.
	 */
	public List<Map<String,Object>> searchByScac(String scac, Customers customer) {
		return repository.searchScac(scac, customer);
	}

	/** TODO Change return type?
	 * Simple search on the <i>WesOutboundOrderNumber</i>'s <b>name</b> field.
	 *
	 * @param name The <i>name</i> to search for.
	 * @param customer The <i>Customer</i> by which we will delimit the search.
	 * @return Typed collection holding all matching results.
	 */
	public List<Map<String,Object>> searchByCustomerName(String name, Customers customer) {
		return repository.searchCustomerName(name, customer);
	}

	/**
	 * Defines base communication between the <i>WesOutboundOrderService</i> and the <i>WesOutboundOrderRepository</i>
	 * for <b>read</b> operations.  This method accommodates pre- and post- processing hooks such that extending classes
	 * can implement custom business logic at any time during processing.
	 *
	 * @param request The SearchRequest object by which to delimit the read results.
	 * @param args Any arguments extending class requires during pre-processing.
	 * @return Typed List of Vendors retrieved from the <b>read</b> operation.
	 */
	public List<WesOutboundOrder> readPage(WesOutboundSearchRequest request, Object... args) {
		// Perform the actual read from the Repository.
		List<WesOutboundOrder> orders = repository.readPage(request);

		// Post-Processing hook && Return.
		return readPostProcess(orders, args);
	}

	public Long readSearchTotal(WesOutboundSearchRequest request) {
		return repository.getCount(request);
	}
}
