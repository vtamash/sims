package com.kenco.oms.service;

import com.kenco.oms.entity.Customers;
import com.kenco.oms.repository.CustomersRepository;

import javax.persistence.EntityManager;
import java.util.List;

/**
 * Class embodies the actual work for communicating with a <i>CustomersRepository</i>.  To implement custom business
 * logic for any of the provided operations, simply extend this class and enter your business logic into the appropriate
 * hook.
 *
 * @see com.kenco.oms.service.impl.GenericCustomersService
 */
public abstract class CustomersAbstractService extends AbstractService<Customers> {
	private final CustomersRepository repository;

	/**
	 * Constructs a <i>CustomersService</i> with the provided <i>EntityManager</i>.
	 *
	 * @param entityManager <i>EntityManager</i> to use.
	 */
	public CustomersAbstractService(EntityManager entityManager) {
		repository = new CustomersRepository(entityManager);
	}

	/**
	 * Defines base communication between the <i>CustomersService</i> and the <i>CustomersRepository</i> for <b>read</b>
	 * operations.  This method accommodates post- processing such that extending classes can implement custom business
	 * logic.
	 *
	 * @param args Any arguments extending class requires during pre-processing.
	 * @return Typed Collection of Customers retrieved from the <b>read</b> operation.
	 */
	public final List<Customers> readAll(Object... args) {
		// Perform the actual read from the Repository.
		List<Customers> customers = repository.readAll();

		// Post-Processing hook && Return.
		return readPostProcess(customers, args);
	}

	/**
	 * Defines base communication between the <i>CustomersService</i> and the <i>CustomersRepository</i> for <b>read</b>
	 * operations.  This method accommodates post- processing such that extending classes can implement custom business
	 * logic.
	 *
	 * @param args Any arguments extending class requires during pre-processing.
	 * @return Typed Collection of Customers retrieved from the <b>read</b> operation.
	 */
	public final List<Customers> readAllActive(Object... args) {
		// Perform the actual read from the Repository.
		List<Customers> customers = repository.readByActive(true);

		// Post-Processing hook && Return.
		return readPostProcess(customers, args);
	}

	/**
	 * Defines base communication between the <i>CustomersService</i> and the <i>CustomersRepository</i> for <b>read</b>
	 * operations.  This method accommodates post- processing such that extending classes can implement custom business
	 * logic.
	 *
	 * @param id   The ID (<b>Primary Key</b>) of the <i>Customer</i> entity to be retrieved.
	 * @param args Any arguments extending class requires during pre-processing.
	 * @return The <i>Customer</i> entity matching the provided ID (<b>Primary Key</b>).
	 */
	public final Customers readById(int id, Object... args) {
		// Perform the actual read from the Repository.
		Customers customer = repository.readById(id);

		// Post-Processing hook && Return.
		return readSinglePostProcess(customer, args);
	}

	/**
	 * Defines base communication between the <i>CustomersService</i> and the <i>CustomersRepository</i> for
	 * <b>update</b> operations.  This method accommodates pre- and post- processing hooks such that extending classes
	 * can implement custom business logic.
	 *
	 * @param customer The Customers object to be <b>updated</b>.
	 * @param username The user performing the operation.
	 * @param args     Any arguments extending class requires during pre-processing.
	 * @return The <b>updated</b> <i>BusinessUnits</i> object.
	 */
	public final Customers update(Customers customer, String username, Object... args) {
		// Abstract business logic.
		customer.setUpdateprogram("CustomersService.update(...)");
		customer.setUpdateusername(username);

		// Pre-Processing Hook.
		Customers processed = updatePreProcess(customer, args);

		// Perform the actual update.
		Customers updated = repository.update(processed);

		// Post-Processing Hook && Return.
		return updatePostProcess(updated, args);
	}

	/**
	 * Defines base communication between the <i>CustomersService</i> and the <i>CustomersRepository</i> for
	 * <b>delete</b> operations.  This method accommodates pre-processing such that extending classes can implement
	 * custom business logic.
	 * <p/>
	 * <b>Note</b>: We do not actually delete a <i>Teams</i> entity.  Rather, we use a soft-delete by flipping the
	 * <i>active</i> flag.
	 *
	 * @param customer The <i>Customers</i> object to be <b>deleted</b>.
	 * @param username The user performing the operation.
	 * @param args     Any arguments extending class requires during pre-processing.
	 */
	public final void delete(Customers customer, String username, Object... args) {
		// Abstract business logic.
		customer.setActive((short) 0);
		customer.setUpdateusername(username);
		customer.setUpdateprogram("CustomersService.delete()");

		// Pre-Processing hook.
		Customers processed = deletePreProcess(customer, args);

		// Perform the actual delete from the Repository.
		repository.update(processed);
	}
}
