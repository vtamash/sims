package com.kenco.oms.service;

import com.kenco.oms.entity.Skumas;
import com.kenco.oms.repository.SkumasRepository;
import javax.persistence.EntityManager;
import java.util.List;

/**
 * Class embodies the actual work for communicating with a SkumasRepository. To
 * implement custom business logic for any of the provided operations, simply
 * extend this class and enter your business logic into the appropriate hook.
 *
 */
public abstract class SkuMasAbstractService implements PreProcessors<Skumas>, PostProcessors<Skumas> {

   private SkumasRepository repository;

   /**
    * Constructor.
    *
    * @param entityManager The EntityManager that this Service will need to use.
    */
   public SkuMasAbstractService(EntityManager entityManager) {
      repository = new SkumasRepository(entityManager);
   }

   /**
    * Defines base communication between the <i>SkumasService</i> and the
    * <i>SkumasRepository</i> for <b>read</b>
    * operations. This method accommodates pre- and post- processing hooks such
    * that extending classes can implement custom business logic at any time
    * during processing.
    *
    * @param customerid - customer ID for which records will be retrieved.
    * @param limit - Maximum records to retrieve from query.
    * @param query - query string to use to search for SKUs matching.
    * @param args Any arguments extending class requires during pre-processing.
    * @return Typed List of Skumas records retrieved from the <b>read</b>
    * operation.
    */
   public List<Skumas> read(int customerid, int limit, String query, Object... args) {
      readPreProcess(args);
      List<Skumas> skus = repository.list(customerid, limit, query);
      return readPostProcess(skus, args);
   }

   public Skumas read(int customerId, String productCode, Object... args) {
      readPreProcess(args);
      Skumas skus = repository.readSingle(customerId, productCode);
      return readSinglePostProcess(skus, args);
   }

   public List<Skumas> list(int customerId, int limit, String query, Object... args) {
      readPreProcess(args);
      List<Skumas> skus = repository.list(customerId, limit, query);
      return readPostProcess(skus, args);
   }
}
