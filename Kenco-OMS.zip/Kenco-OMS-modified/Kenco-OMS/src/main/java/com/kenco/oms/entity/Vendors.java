/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kenco.oms.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "VENDORS")
@XmlRootElement
@NamedQueries({
   @NamedQuery(name = "Vendors.findAll", query = "SELECT v FROM Vendors v"),
   @NamedQuery(name = "Vendors.findById", query = "SELECT v FROM Vendors v WHERE v.id = :id"),
   @NamedQuery(name = "Vendors.findByActive", query = "SELECT v FROM Vendors v WHERE v.active = :active"),
   @NamedQuery(name = "Vendors.findByVendornumber", query = "SELECT v FROM Vendors v WHERE v.vendornumber = :vendornumber"),
   @NamedQuery(name = "Vendors.findByName", query = "SELECT v FROM Vendors v WHERE v.name = :name"),
   @NamedQuery(name = "Vendors.findByAddress1", query = "SELECT v FROM Vendors v WHERE v.address1 = :address1"),
   @NamedQuery(name = "Vendors.findByAddress2", query = "SELECT v FROM Vendors v WHERE v.address2 = :address2"),
   @NamedQuery(name = "Vendors.findByAddress3", query = "SELECT v FROM Vendors v WHERE v.address3 = :address3"),
   @NamedQuery(name = "Vendors.findByCity", query = "SELECT v FROM Vendors v WHERE v.city = :city"),
   @NamedQuery(name = "Vendors.findByState", query = "SELECT v FROM Vendors v WHERE v.state.id = :stateId"),
   @NamedQuery(name = "Vendors.findByZipcode", query = "SELECT v FROM Vendors v WHERE v.zipcode = :zipcode"),
   @NamedQuery(name = "Vendors.findByCreatetimestamp", query = "SELECT v FROM Vendors v WHERE v.createtimestamp = :createtimestamp"),
   @NamedQuery(name = "Vendors.findByCreateusername", query = "SELECT v FROM Vendors v WHERE v.createusername = :createusername"),
   @NamedQuery(name = "Vendors.findByCreateprogram", query = "SELECT v FROM Vendors v WHERE v.createprogram = :createprogram"),
   @NamedQuery(name = "Vendors.findByUpdatetimestamp", query = "SELECT v FROM Vendors v WHERE v.updatetimestamp = :updatetimestamp"),
   @NamedQuery(name = "Vendors.findByUpdateusername", query = "SELECT v FROM Vendors v WHERE v.updateusername = :updateusername"),
   @NamedQuery(name = "Vendors.findByUpdateprogram", query = "SELECT v FROM Vendors v WHERE v.updateprogram = :updateprogram")})
public class Vendors implements Serializable {
   private static final long serialVersionUID = 1L;

   @Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
   @Column(name = "ID", nullable = false)
   private Integer id;

   @NotNull
   @Column(name = "ACTIVE", nullable = false)
   private short active;

   @NotNull
   @Size(min = 1, max = 10)
   @Column(name = "VENDORNUMBER", nullable = false)
   private String vendornumber;

   @NotNull
   @Size(min = 1, max = 50)
   @Column(name = "NAME", nullable = false, unique = true)
   private String name;

   @NotNull
   @Size(min = 1, max = 50)
   @Column(name = "ADDRESS1", nullable = false)
   private String address1;

   @Column(name = "ADDRESS2", nullable = false)
   private String address2;

   @Column(name = "ADDRESS3", nullable = false)
   private String address3;

   @NotNull
   @Size(min = 1, max = 50)
   @Column(name = "CITY", nullable = false)
   private String city;

   @ManyToOne(optional=false)
   @JoinColumn(name = "STATE_ID", referencedColumnName = "ID")
   private States state;

   @NotNull
   @Size(min = 1, max = 6)
   @Column(name = "ZIPCODE", nullable = false)
   private String zipcode;

   @JsonIgnore
   @NotNull
   @Temporal(TemporalType.TIMESTAMP)
   @Column(name = "CREATETIMESTAMP", nullable = false)
   private Date createtimestamp;

   @JsonIgnore
   @NotNull
   @Size(min = 1, max = 10)
   @Column(name = "CREATEUSERNAME", nullable = false)
   private String createusername;

   @JsonIgnore
   @NotNull
   @Size(min = 1, max = 50)
   @Column(name = "CREATEPROGRAM", nullable = false)
   private String createprogram;

   @JsonIgnore
   @Temporal(TemporalType.TIMESTAMP)
   @Column(name = "UPDATETIMESTAMP", insertable = false, updatable = false, nullable = false)
   private Date updatetimestamp;

   @JsonIgnore
   @NotNull
   @Size(min = 1, max = 10)
   @Column(name = "UPDATEUSERNAME", nullable = false)
   private String updateusername;

   @JsonIgnore
   @NotNull
   @Size(min = 1, max = 50)
   @Column(name = "UPDATEPROGRAM", nullable = false)
   private String updateprogram;

   @ManyToOne
   @JoinColumn(name = "CUSTOMER_ID", referencedColumnName = "ID")
   private Customers customerId;

   public Vendors() {
   }

   public Vendors(Integer id) {
      this.id = id;
   }

   public Vendors(Integer id, short active, String vendornumber, String name, String address1, String address2, String address3, String city, String zipcode, Date createtimestamp, String createusername, String createprogram, Date updatetimestamp, String updateusername, String updateprogram) {
      this.id = id;
      this.active = active;
      this.vendornumber = vendornumber;
      this.name = name;
      this.address1 = address1;
      this.address2 = address2;
      this.address3 = address3;
      this.city = city;
      this.zipcode = zipcode;
      this.createtimestamp = createtimestamp;
      this.createusername = createusername;
      this.createprogram = createprogram;
      this.updatetimestamp = updatetimestamp;
      this.updateusername = updateusername;
      this.updateprogram = updateprogram;
   }

   public Integer getId() {
      return id;
   }

   public void setId(Integer id) {
      this.id = id;
   }

   public short getActive() {
      return active;
   }

   public void setActive(short active) {
      this.active = active;
   }

   public String getVendornumber() {
      return vendornumber;
   }

   public void setVendornumber(String vendornumber) {
      this.vendornumber = vendornumber;
   }

   public String getName() {
      return name;
   }

   public void setName(String name) {
      this.name = name;
   }

   public String getAddress1() {
      return address1;
   }

   public void setAddress1(String address1) {
      this.address1 = address1;
   }

   public String getAddress2() {
      return address2;
   }

   public void setAddress2(String address2) {
      this.address2 = address2;
   }

   public String getAddress3() {
      return address3;
   }

   public void setAddress3(String address3) {
      this.address3 = address3;
   }

   public String getCity() {
      return city;
   }

   public void setCity(String city) {
      this.city = city;
   }

   public States getState() {
      return state;
   }

   public void setState(States state) {
      this.state = state;
   }

   public String getZipcode() {
      return zipcode;
   }

   public void setZipcode(String zipcode) {
      this.zipcode = zipcode;
   }

   public Date getCreatetimestamp() {
      return createtimestamp;
   }

   public void setCreatetimestamp(Date createtimestamp) {
      this.createtimestamp = createtimestamp;
   }

   public String getCreateusername() {
      return createusername;
   }

   public void setCreateusername(String createusername) {
      this.createusername = createusername;
   }

   public String getCreateprogram() {
      return createprogram;
   }

   public void setCreateprogram(String createprogram) {
      this.createprogram = createprogram;
   }

   public Date getUpdatetimestamp() {
      return updatetimestamp;
   }

   public void setUpdatetimestamp(Date updatetimestamp) {
      this.updatetimestamp = updatetimestamp;
   }

   public String getUpdateusername() {
      return updateusername;
   }

   public void setUpdateusername(String updateusername) {
      this.updateusername = updateusername;
   }

   public String getUpdateprogram() {
      return updateprogram;
   }

   public void setUpdateprogram(String updateprogram) {
      this.updateprogram = updateprogram;
   }

   public Customers getCustomerId() {
      return customerId;
   }

   public void setCustomerId(Customers customerId) {
      this.customerId = customerId;
   }

   @Override
   public int hashCode() {
      int hash = 0;
      hash += (id != null ? id.hashCode() : 0);
      return hash;
   }

   @Override
   public boolean equals(Object object) {
      // TODO: Warning - this method won't work in the case the id fields are not set
      if (!(object instanceof Vendors)) {
         return false;
      }
      Vendors other = (Vendors) object;
      if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
         return false;
      }
      return true;
   }

   @Override
   public String toString() {
      return "com.kenco.oms.entity.Vendors[ id=" + id + " ]";
   }
   
}
