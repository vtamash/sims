package com.kenco.oms.service.impl;

import com.kenco.oms.entity.Vendors;
import com.kenco.oms.service.VendorsAbstractService;

import javax.persistence.EntityManager;
import java.util.List;

/**
 * Basic extension of the VendorsAbstractService.  This offers no additional business logic other than what is absolutely
 * enforced upon any extending class.  To implement custom business logic for any process, extend the VendorsAbstractService.
 * However, you may use this bean if the you need nothing more than <b>basic</b> CRUD functionality with no additional
 * business logic.
 *
 * @see com.kenco.oms.service.VendorsAbstractService
 */
public final class GenericVendorsService extends VendorsAbstractService {
	/**
	 * {@inheritDoc}
	 */
	public GenericVendorsService(EntityManager entityManager) {
		super(entityManager);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Vendors createPreProcess(Vendors vendor, Object... args) {
		return vendor;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Vendors updatePreProcess(Vendors vendor, Object... args) {
		return vendor;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Vendors deletePreProcess(Vendors vendor, Object... args) {
		return vendor;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Vendors createPostProcess(Vendors vendor, Object... args) {
		return vendor;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public List<Vendors> readPostProcess(List<Vendors> vendors, Object... args) {
		return vendors;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Vendors readSinglePostProcess(Vendors vendors, Object... args) {
		return vendors;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Vendors updatePostProcess(Vendors vendor, Object... args) {
		return vendor;
	}
}
