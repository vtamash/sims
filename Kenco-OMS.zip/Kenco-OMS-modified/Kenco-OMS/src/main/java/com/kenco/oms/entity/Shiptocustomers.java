package com.kenco.oms.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import java.util.Collection;
import java.util.Date;

@Entity
@Table(name = "SHIPTOCUSTOMERS")
@XmlRootElement
public class Shiptocustomers {
   @Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
   @Column(name = "ID", nullable = false)
   private Integer id;

   @NotNull
   @Column(name = "ACTIVE", nullable = false)
   private short active;

   @NotNull
   @Size(min = 1, max = 10)
   @Column(name = "SHIPTOCUSTOMERNUMBER", nullable = false)
   private String shiptocustomernumber;

   @NotNull
   @Size(min = 1, max = 50)
   @Column(name = "NAME", nullable = false)
   private String name;

   @NotNull
   @Size(min = 1, max = 50)
   @Column(name = "ADDRESS1", nullable = false)
   private String address1;

   @Column(name = "ADDRESS2", nullable = false)
   private String address2;

   @Column(name = "ADDRESS3", nullable = false)
   private String address3;

   @NotNull
   @Size(min = 1, max = 50)
   @Column(name = "CITY", nullable = false)
   private String city;

   @NotNull
   @Size(min = 1, max = 6)
   @Column(name = "ZIPCODE", nullable = false)
   private String zipcode;

   @NotNull
   @Temporal(TemporalType.TIMESTAMP)
   @Column(name = "CREATETIMESTAMP", nullable = false)
   private Date createtimestamp;

   @NotNull
   @Size(min = 1, max = 10)
   @Column(name = "CREATEUSERNAME", nullable = false)
   private String createusername;

   @NotNull
   @Size(min = 1, max = 50)
   @Column(name = "CREATEPROGRAM", nullable = false)
   private String createprogram;

   @Temporal(TemporalType.TIMESTAMP)
   @Column(name = "UPDATETIMESTAMP", nullable = false, insertable = false, updatable = false)
   private Date updatetimestamp;

   @NotNull
   @Size(min = 1, max = 10)
   @Column(name = "UPDATEUSERNAME", nullable = false)
   private String updateusername;

   @NotNull
   @Size(min = 1, max = 50)
   @Column(name = "UPDATEPROGRAM", nullable = false)
   private String updateprogram;

   @JsonIgnore // If these need to be returned in the JSON string, we will need to address the infinite recursion.
   @OneToMany(mappedBy = "shiptocustomerId")
   private Collection<Shiptodeliverylocations> shiptodeliverylocationsCollection;

   @JsonIgnore // If these need to be returned in the JSON string, we will need to address the infinite recursion.
   @OneToMany(mappedBy = "shiptocustomerId")
   private Collection<Outboundorderheader> outboundorderheaderCollection;

   @ManyToOne
   @JoinColumn(name = "STATE_ID", referencedColumnName = "ID")
   private States state;

   @ManyToOne
   @JoinColumn(name = "CUSTOMER_ID", referencedColumnName = "ID")
   private Customers customer;

   public Shiptocustomers() {
   }

   public Shiptocustomers(Integer id) {
      this.id = id;
   }

   public Shiptocustomers(Integer id, short active, String shiptocustomernumber, String name, String address1, String address2, String address3, String city, String zipcode, Date createtimestamp, String createusername, String createprogram, Date updatetimestamp, String updateusername, String updateprogram) {
      this.id = id;
      this.active = active;
      this.shiptocustomernumber = shiptocustomernumber;
      this.name = name;
      this.address1 = address1;
      this.address2 = address2;
      this.address3 = address3;
      this.city = city;
      this.zipcode = zipcode;
      this.createtimestamp = createtimestamp;
      this.createusername = createusername;
      this.createprogram = createprogram;
      this.updatetimestamp = updatetimestamp;
      this.updateusername = updateusername;
      this.updateprogram = updateprogram;
   }

   public Integer getId() {
      return id;
   }

   public void setId(Integer id) {
      this.id = id;
   }

   public short getActive() {
      return active;
   }

   public void setActive(short active) {
      this.active = active;
   }

   public String getShiptocustomernumber() {
      return shiptocustomernumber;
   }

   public void setShiptocustomernumber(String shiptocustomernumber) {
      this.shiptocustomernumber = shiptocustomernumber;
   }

   public String getName() {
      return name;
   }

   public void setName(String name) {
      this.name = name;
   }

   public String getAddress1() {
      return address1;
   }

   public void setAddress1(String address1) {
      this.address1 = address1;
   }

   public String getAddress2() {
      return address2;
   }

   public void setAddress2(String address2) {
      this.address2 = address2;
   }

   public String getAddress3() {
      return address3;
   }

   public void setAddress3(String address3) {
      this.address3 = address3;
   }

   public String getCity() {
      return city;
   }

   public void setCity(String city) {
      this.city = city;
   }

   public String getZipcode() {
      return zipcode;
   }

   public void setZipcode(String zipcode) {
      this.zipcode = zipcode;
   }

   public Date getCreatetimestamp() {
      return createtimestamp;
   }

   public void setCreatetimestamp(Date createtimestamp) {
      this.createtimestamp = createtimestamp;
   }

   public String getCreateusername() {
      return createusername;
   }

   public void setCreateusername(String createusername) {
      this.createusername = createusername;
   }

   public String getCreateprogram() {
      return createprogram;
   }

   public void setCreateprogram(String createprogram) {
      this.createprogram = createprogram;
   }

   public Date getUpdatetimestamp() {
      return updatetimestamp;
   }

   public void setUpdatetimestamp(Date updatetimestamp) {
      this.updatetimestamp = updatetimestamp;
   }

   public String getUpdateusername() {
      return updateusername;
   }

   public void setUpdateusername(String updateusername) {
      this.updateusername = updateusername;
   }

   public String getUpdateprogram() {
      return updateprogram;
   }

   public void setUpdateprogram(String updateprogram) {
      this.updateprogram = updateprogram;
   }

   @XmlTransient
   public Collection<Shiptodeliverylocations> getShiptodeliverylocationsCollection() {
      return shiptodeliverylocationsCollection;
   }

   public void setShiptodeliverylocationsCollection(Collection<Shiptodeliverylocations> shiptodeliverylocationsCollection) {
      this.shiptodeliverylocationsCollection = shiptodeliverylocationsCollection;
   }

   @XmlTransient
   public Collection<Outboundorderheader> getOutboundorderheaderCollection() {
      return outboundorderheaderCollection;
   }

   public void setOutboundorderheaderCollection(Collection<Outboundorderheader> outboundorderheaderCollection) {
      this.outboundorderheaderCollection = outboundorderheaderCollection;
   }

   public States getState() {
      return state;
   }

   public void setState(States state) {
      this.state = state;
   }

   public Customers getCustomer() {
      return customer;
   }

   public void setCustomer(Customers customerId) {
      this.customer = customerId;
   }

   @Override
   public int hashCode() {
      int hash = 0;
      hash += (id != null ? id.hashCode() : 0);
      return hash;
   }

   @Override
   public boolean equals(Object object) {
      // TODO: Warning - this method won't work in the case the id fields are not set
      if (!(object instanceof Shiptocustomers)) {
         return false;
      }
      Shiptocustomers other = (Shiptocustomers) object;
      if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
         return false;
      }
      return true;
   }

   @Override
   public String toString() {
      return "com.kenco.oms.entity.Shiptocustomers[ id=" + id + " ]";
   }
   
}
