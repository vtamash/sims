package com.kenco.oms.service.impl;

import com.kenco.oms.entity.Systemvalues;
import com.kenco.oms.service.SystemValuesAbstractService;
import com.kenco.oms.utilities.Enums;
import javax.persistence.EntityManager;
import java.util.List;

/**
 * Basic extension of the SystemValuesAbstractService.  This offers no additional business logic other than what is absolutely
 * enforced upon any extending class.  To implement custom business logic for any process, extend the SystemValuesAbstractService.
 * However, you may use this bean if the you need nothing more than <b>basic</b> CRUD functionality with no additional
 * business logic.
 *
 * @see com.kenco.oms.service.SystemValuesAbstractService
 */
public final class GenericSystemValuesService extends SystemValuesAbstractService {
	public GenericSystemValuesService(EntityManager entityManager) {
		super(entityManager);
	}

	public Systemvalues get(int customerId, Enums.eSystemValues systemValueName) {
		return super.get(customerId, systemValueName);
	}
	
	/**
	 * {@inheritDoc}
	 */
	public void createPreProcess(Systemvalues systemValue, Object... args) {
	}

	/**
	 * {@inheritDoc}
	 */
	public void readPreProcess(Object... args) {
	}

	/**
	 * {@inheritDoc}
	 */
	public void readSinglePreProcess(Object... args) {
	}

	/**
	 * {@inheritDoc}
	 */
	public void updatePreProcess(Object... args) {
	}

	/**
	 * {@inheritDoc}
	 */
	public void deletePreProcess(Object... args) {
	}

	/**
	 * {@inheritDoc}
	 */
	public Systemvalues createPostProcess(Systemvalues systemValue, Object... args) {
		return systemValue;
	}

	/**
	 * {@inheritDoc}
	 */
	public List<Systemvalues> readPostProcess(List<Systemvalues> systemValue, Object... args) {
		return systemValue;
	}

	/**
	 * {@inheritDoc}
	 */
	public Systemvalues readSinglePostProcess(Systemvalues systemvalues, Object... args) {
		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	public Systemvalues updatePostProcess(Systemvalues systemValue, Object... args) {
		return systemValue;
	}

	/**
	 * {@inheritDoc}
	 */
	public void deletePostProcess(Systemvalues systemValue, Object... args) {
	}
}
