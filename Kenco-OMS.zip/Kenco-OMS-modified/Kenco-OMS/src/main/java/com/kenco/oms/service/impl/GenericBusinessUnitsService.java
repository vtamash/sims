package com.kenco.oms.service.impl;

import com.kenco.oms.entity.BusinessUnits;
import com.kenco.oms.service.BusinessUnitsAbstractService;

import javax.persistence.EntityManager;
import java.util.List;

/**
 * Basic extension of the BusinessUnitsAbstractService.  This offers no additional business logic other than what is absolutely
 * enforced upon any extending class.  To implement custom business logic for any process, extend the BusinessUnitsAbstractService.
 * However, you may use this bean if the you need nothing more than <b>basic</b> CRUD functionality with no additional
 * business logic.
 *
 * @see com.kenco.oms.service.BusinessUnitsAbstractService
 */
public final class GenericBusinessUnitsService extends BusinessUnitsAbstractService {
	/**
	 * {@inheritDoc}
	 */
	public GenericBusinessUnitsService(EntityManager entityManager) {
		super(entityManager);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public BusinessUnits createPreProcess(BusinessUnits businessunit, Object... args) {
		return businessunit;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public BusinessUnits updatePreProcess(BusinessUnits businessunit, Object... args) {
		return businessunit;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public BusinessUnits deletePreProcess(BusinessUnits businessunit, Object... args) {
		return businessunit;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public BusinessUnits createPostProcess(BusinessUnits businessunit, Object... args) {
		return businessunit;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public List<BusinessUnits> readPostProcess(List<BusinessUnits> businessunits, Object... args) {
		return businessunits;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public BusinessUnits readSinglePostProcess(BusinessUnits businessunit, Object... args) {
		return businessunit;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public BusinessUnits updatePostProcess(BusinessUnits businessunit, Object... args) {
		return businessunit;
	}
}
