/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kenco.oms.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name = "OMSDOWNLOAD")
@XmlRootElement
@NamedQueries({
   @NamedQuery(name = "Omsdownload.findAll", query = "SELECT o FROM Omsdownload o"),
   @NamedQuery(name = "Omsdownload.findById", query = "SELECT o FROM Omsdownload o WHERE o.id = :id"),
   @NamedQuery(name = "Omsdownload.findByStatus", query = "SELECT o FROM Omsdownload o WHERE o.status = :status"),
   @NamedQuery(name = "Omsdownload.findByThedata", query = "SELECT o FROM Omsdownload o WHERE o.thedata = :thedata"),
   @NamedQuery(name = "Omsdownload.findByCreatetimestamp", query = "SELECT o FROM Omsdownload o WHERE o.createtimestamp = :createtimestamp"),
   @NamedQuery(name = "Omsdownload.findByCreateusername", query = "SELECT o FROM Omsdownload o WHERE o.createusername = :createusername"),
   @NamedQuery(name = "Omsdownload.findByCreateprogram", query = "SELECT o FROM Omsdownload o WHERE o.createprogram = :createprogram"),
   @NamedQuery(name = "Omsdownload.findByUpdateusername", query = "SELECT o FROM Omsdownload o WHERE o.updateusername = :updateusername"),
   @NamedQuery(name = "Omsdownload.findByUpdateprogram", query = "SELECT o FROM Omsdownload o WHERE o.updateprogram = :updateprogram")})
public class Omsdownload implements Serializable {
   @Basic(optional = false)
   @NotNull
   @Column(name = "STATUS")
   private String status;
   @Basic(optional = false)
   @NotNull
   @Size(min = 1, max = 4)
   @Column(name = "TRANSACTIONTYPE")
   private String transactiontype;
   @Basic(optional = false)
   @NotNull
   @Column(name = "SEQUENCE")
   private int sequence;
   @Basic(optional = false)
   @NotNull
   @Size(min = 1, max = 25)
   @Column(name = "ORDERNUMBER")
   private String ordernumber;

   @Column(name = "UPDATETIMESTAMP", insertable = false, updatable = false)
   @Temporal(TemporalType.TIMESTAMP)
   private Date updatetimestamp;
   private static final long serialVersionUID = 1L;
   @Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
   @Basic(optional = false)
   @Column(name = "ID")
   private Integer id;
   @Basic(optional = false)
   @NotNull
   @Size(min = 1, max = 1500)
   @Column(name = "THEDATA")
   private String thedata;
   @Basic(optional = false)
   @NotNull
   @Column(name = "CREATETIMESTAMP")
   @Temporal(TemporalType.TIMESTAMP)
   private Date createtimestamp;
   @Basic(optional = false)
   @NotNull
   @Size(min = 1, max = 10)
   @Column(name = "CREATEUSERNAME")
   private String createusername;
   @Basic(optional = false)
   @NotNull
   @Size(min = 1, max = 50)
   @Column(name = "CREATEPROGRAM")
   private String createprogram;
   @Basic(optional = false)
   @NotNull
   @Size(min = 1, max = 10)
   @Column(name = "UPDATEUSERNAME")
   private String updateusername;
   @Basic(optional = false)
   @NotNull
   @Size(min = 1, max = 50)
   @Column(name = "UPDATEPROGRAM")
   private String updateprogram;
   @JoinColumn(name = "CUSTOMER_ID", referencedColumnName = "ID")
   @ManyToOne
   private Customers customerId;

   public Omsdownload() {
   }

   public Omsdownload(Integer id) {
      this.id = id;
   }

   public Omsdownload(Integer id, String status, String thedata, Date createtimestamp, String createusername, String createprogram, String updateusername, String updateprogram) {
      this.id = id;
      this.status = status;
      this.thedata = thedata;
      this.createtimestamp = createtimestamp;
      this.createusername = createusername;
      this.createprogram = createprogram;
      this.updateusername = updateusername;
      this.updateprogram = updateprogram;
   }

   public Integer getId() {
      return id;
   }

   public void setId(Integer id) {
      this.id = id;
   }

   public String getThedata() {
      return thedata;
   }

   public void setThedata(String thedata) {
      this.thedata = thedata;
   }

   public Date getCreatetimestamp() {
      return createtimestamp;
   }

   public void setCreatetimestamp(Date createtimestamp) {
      this.createtimestamp = createtimestamp;
   }

   public String getCreateusername() {
      return createusername;
   }

   public void setCreateusername(String createusername) {
      this.createusername = createusername;
   }

   public String getCreateprogram() {
      return createprogram;
   }

   public void setCreateprogram(String createprogram) {
      this.createprogram = createprogram;
   }

   public String getUpdateusername() {
      return updateusername;
   }

   public void setUpdateusername(String updateusername) {
      this.updateusername = updateusername;
   }

   public String getUpdateprogram() {
      return updateprogram;
   }

   public void setUpdateprogram(String updateprogram) {
      this.updateprogram = updateprogram;
   }

   public Customers getCustomerId() {
      return customerId;
   }

   public void setCustomerId(Customers customerId) {
      this.customerId = customerId;
   }

   @Override
   public int hashCode() {
      int hash = 0;
      hash += (id != null ? id.hashCode() : 0);
      return hash;
   }

   @Override
   public boolean equals(Object object) {
      // TODO: Warning - this method won't work in the case the id fields are not set
      if (!(object instanceof Omsdownload)) {
         return false;
      }
      Omsdownload other = (Omsdownload) object;
      if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
         return false;
      }
      return true;
   }

   @Override
   public String toString() {
      return "com.kenco.oms.entity.Omsdownload[ id=" + id + " ]";
   }

   public Date getUpdatetimestamp() {
      return updatetimestamp;
   }

   public void setUpdatetimestamp(Date updatetimestamp) {
      this.updatetimestamp = updatetimestamp;
   }

   public String getOrdernumber() {
      return ordernumber;
   }

   public void setOrdernumber(String ordernumber) {
      this.ordernumber = ordernumber;
   }

   public String getStatus() {
      return status;
   }

   public void setStatus(String status) {
      this.status = status;
   }

   public String getTransactiontype() {
      return transactiontype;
   }

   public void setTransactiontype(String transactiontype) {
      this.transactiontype = transactiontype;
   }

   public int getSequence() {
      return sequence;
   }

   public void setSequence(int sequence) {
      this.sequence = sequence;
   }


}
