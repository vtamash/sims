package com.kenco.oms.service;

import com.kenco.oms.entity.Customers;
import com.kenco.oms.entity.Inboundorderheader;
import com.kenco.oms.repository.InboundOrderHeaderRepository;
import com.kenco.oms.repository.SystemValuesRepository;
import com.kenco.oms.search.InboundOrderSearchRequest;
import com.kenco.oms.service.impl.GenericOmsDownloadService;
import com.kenco.oms.utilities.Enums;

import javax.persistence.EntityManager;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Class embodies the actual work for communicating with a <i>InboundOrderHeaderRepository</i>.  To implement custom
 * business logic for any of the provided operations, simply extend this class and enter your business logic into the
 * appropriate hook.
 *
 * <b>Note</b>: The creation of an <i>InboundOrderHeader</i> will <b>always</b> trigger the creation of an
 * <i>OmsDownload</i> entity.
 *
 */
public abstract class InboundOrderAbstractService extends AbstractService<Inboundorderheader> {
	private final InboundOrderHeaderRepository repository;
	private final SystemValuesRepository       sysRepository;

	private final OmsDownloadAbstractService downloadService;

	/**
	 * Abstract method to allow extending classes to hook into the <b>read</b> (post) process for obtaining Inbound
	 * Order Numbers.  This is primarily used to Prepend / Append an application-specific String to the Order Number
	 * as a part of the <b>read</b> process.
	 *
	 * @param orderNumber The Order Number that was read.
	 * @return The Order Number that was read <b>after</b> processing has occurred.
	 */
	public abstract String getNextInboundOrderNumberPostProcess(String orderNumber, Object... args);

	/**
	 * Convenience constructor.  The creation of an <i>InboundOrderHeader</i> entity will <b>always</b> trigger the
	 * creation of an OmsDownload entity.  Implementers may still extend the <i>OmsDownloadAbstractService</i> to implement
	 * their custom business logic for the <i>OmsDownload</i> creation and use the second constructor to pass it in here.
	 *
	 * @param entityManager The EntityManager that this Service will need to use.
	 * @see com.kenco.oms.service.OmsDownloadAbstractService
	 */
	public InboundOrderAbstractService(EntityManager entityManager) {
		repository    = new InboundOrderHeaderRepository(entityManager);
		sysRepository = SystemValuesRepository.getSystemValuesRepository(entityManager);

		downloadService = new GenericOmsDownloadService(entityManager);
	}

	/**
	 * Constructs an <i>InboundOrderService</i> using the provided <i>OmsDownloadService</i>.  Use this constructor
	 * when you require custom business logic within the <i>OmsDownloadService</i>.
	 *
	 * @param entityManager The EntityManager that this Service will need to use.
	 * @see com.kenco.oms.service.OmsDownloadAbstractService
	 */
	public InboundOrderAbstractService(EntityManager entityManager, OmsDownloadAbstractService service) {
		repository    = new InboundOrderHeaderRepository(entityManager);
		sysRepository = SystemValuesRepository.getSystemValuesRepository(entityManager);

		downloadService = service;
	}


	/**
	 * Simple exposure of the same method in the repository.  This should be called to find the <b>total</b> number
	 * of results that a search has returned, rather than simply the size of the current page (which the frontend
	 * should already know).
	 *
	 * @param request The <i>SearchRequest</i> object - preferably the same one that was used to perform the search.
	 * @return The number of rows matching the provided <i>SearchRequest</i>.
	 */
	public final long readSearchTotal(InboundOrderSearchRequest request) {
		return repository.readSearchTotal(request);
	}

	/**
	 * Simple search on the <i>InboundOrderHeader</i>'s <b>OrderNumber</b> field.
	 *
	 * @param number The <i>Order Number</i> to search for.
	 * @param customer The <i>Customer</i> by which we will delimit the search.
	 * @return Typed Collection holding all matching results.
	 */
	public final List<Map<String,Object>> searchOrderNumbers(String number, Customers customer) {
		return repository.searchOrderNumbers(number, customer);
	}

	/**
	 * Simple search on the <i>InboundOrderHeader</i>'s <b>CreatedUserName</b> field.
	 *
	 * @param name The <i>Creator's UserName</i> to search for.
	 * @param customer The <i>Customer</i> by which we will delimit the search.
	 * @return Typed Collection holding all matching results.
	 */
	public final List<Map<String,Object>> searchCreators(String name, Customers customer) {
		return repository.searchCreators(name, customer);
	}

	/**
	 * Simple search on the <i>InboundOrderHeader</i>'s <b>Vendor</b> field.
	 *
	 * @param name The <i>Vendor Name</i> to search for.
	 * @param customer The <i>Customer</i> by which we will delimit the search.
	 * @return Typed Collection holding all matching results.
	 */
	public final List<Map<String,Object>> searchVendors(String name, Customers customer) {
		return repository.searchVendors(name, customer);
	}

	/**
	 * Defines base communication between the <i>InboundOrderHeaderService</i> and the <i>InboundOrderHeaderRepository</i>
	 * for <b>create</b> operations.  This method accommodates pre- and post- processing hooks such that extending
	 * classes can implement custom business logic at any time during processing.
	 *
	 * @param order The Inboundorderheader object to be <b>created</b>.
	 * @param args Any arguments extending class requires during pre-processing.
	 * @return The <b>persisted</b> Inboundorderheader object.
	 */
	public final Inboundorderheader create(Inboundorderheader order, String username, Object... args) {
		// Abstract business logic.
		order.setCreatetimestamp(new Date());
		order.setCreateusername(username);
		order.setCreateprogram("InboundOrderService.create()");

		order.setUpdatetimestamp(new Date());
		order.setUpdateusername(username);
		order.setUpdateprogram("InboundOrderService.create()");

		// Pre-Processing hook.
		Inboundorderheader processed = createPreProcess(order, args);

		// Perform the actual create from the Repository.
		Inboundorderheader persisted = repository.create(processed);

		// Post-Processing hook && Return.
		return createPostProcess(persisted, args);
	}

	/**
	 * Defines base communication between the <i>InboundOrderHeaderService</i> and the <i>InboundOrderHeaderRepository</i>
	 * for <b>read</b> operations.  This method accommodates post-processing such that extending classes can implement
	 * custom business logic.
	 *
	 * @param orderId The ID of the Inboundorderheader to retrieve.
	 * @param args Any arguments extending class requires during pre-processing.
	 * @return Inboundorderheader entity that matches the provided Inbound Order Number.
	 */
	public final Inboundorderheader readById(int orderId, Object... args) {
		// Perform the actual read from the Repository.
		Inboundorderheader order = repository.readById(orderId);

		// Post-Processing hook && Return.
		return readSinglePostProcess(order, args);
	}

	/**
	 * Defines base communication between the <i>InboundOrderHeaderService</i> and the <i>InboundOrderHeaderRepository</i>
	 * for <b>read</b> operations.  This method accommodates post-processing such that extending classes can implement
	 * custom business logic.
	 *
	 * <b>Note</b>: <b>Read</b> operations are paged for this entity.
	 *
	 * @param request The <i>SearchRequest</i> provided by the User.
	 * @param args Any arguments extending class requires during pre-processing.
	 * @return Typed Collection of InboundOrderHeader entities that matched the given <i>SearchRequest</i>.
	 */
	public final List<Inboundorderheader> readPage(InboundOrderSearchRequest request, Object... args) {
		// Abstract business logic.
		request.setStatus(Enums.eOMSInboundOrderStatus.P);

		// Perform the actual read.
		List<Inboundorderheader> orders = repository.readPage(request);

		// Post-Processing hook && Return.
		return readPostProcess(orders, args);
	}

	/**
	 * Defines base communication between the <i>InboundOrderHeaderService</i> and the <i>InboundOrderHeaderRepository</i>
	 * for <b>read</b> operations.  This method accommodates post-processing such that extending classes can implement
	 * custom business logic.
	 *
	 * @param number The number of the Inboundorderheader to retrieve.
	 * @param args Any arguments extending class requires during pre-processing.
	 * @return Inboundorderheader entity that matches the provided Inbound Order Number.
	 */
	public final Inboundorderheader readByName(String number, Object... args) {
		// Perform the actual read from the Repository.
		Inboundorderheader order = repository.readByNumber(number); // Isn't this "readByName" ?  Why is it reading the number ?

		// Post-Processing hook && Return.
		return readSinglePostProcess(order, args);
	}

	/**
	 * Defines base communication between the <i>InboundOrderHeaderService</i> and the <i>InboundOrderHeaderRepository</i>
	 * for <b>update</b> operations.  This method accommodates pre- and post- processing hooks such that extending
	 * classes can implement custom business logic at any time during processing.
	 *
	 * @param order The Inboundorderheader object to be <b>updated</b>.
	 * @param args Any arguments extending class requires during pre-processing.
	 * @return The <b>updated</b> Inboundorderheader object.
	 */
	public final Inboundorderheader update(Inboundorderheader order, String username, Object... args) {
		// Abstract business logic.
		order.setUpdateusername(username);
		order.setUpdateprogram("InboundOrderService.update()");

		// Pre-Processing hook.
		Inboundorderheader processed = updatePreProcess(order, args);

		// Perform the actual update.
		Inboundorderheader updated = repository.update(processed);

		// Trigger the creation of an OmsDownload if required.
		if (updated.getStatus().equals(Enums.eOMSInboundOrderStatus.C.toString()))
			downloadService.create(updated, args);

		// Post-Processing hook && Return.
		return updatePostProcess(updated, args);
	}

	/**
	 * Defines base communication between the <i>InboundOrderHeaderService</i> and the <i>InboundOrderHeaderRepository</i> for <b>delete</b>
	 * operations.  This method accommodates pre- and post- processing hooks such that extending classes can implement
	 * custom business logic at any time during processing.
	 *
	 * @param inboundorderheader The Inboundorderheader object to be <b>deleted</b>.
	 * @param args Any arguments extending class requires during pre-processing.
	 */
	public final void delete(Inboundorderheader inboundorderheader, Object... args) {
		// Pre-Processing hook.
		deletePreProcess(inboundorderheader, args);

		// Perform the actual delete from the Repository.
		repository.delete(inboundorderheader);
	}

	/**
	 * Get next inbound Order Number.
	 *
	 * @param customerId Customer ID for order in question.
	 * @return The next (system provided) Order Number.
	 */
	public final String getNextInboundOrderNumber(int customerId) {
		int nextNumber = sysRepository.get(customerId, Enums.eSystemValues.NEXT_INBOUND_ORDERNUMBER).getIntegervalue();

		return getNextInboundOrderNumberPostProcess(Integer.toString(nextNumber), customerId);
	}

	/**
	 * Get prefix for inbound order...
	 *
	 * @param customerId customer ID for order in question.
	 * @return order prefix.
	 */
	public final String getInboundOrderPrefix(int customerId) {
		return sysRepository.get(customerId, Enums.eSystemValues.INBOUND_ORDERNUMBER_PREFIX).getStringvalue();
	}
}