package com.kenco.oms.entity;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Date;

@Entity
@Table(name = "TEAMS")
@XmlRootElement
public class Teams {
   @Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
   @Column(name = "ID", nullable = false)
   private Integer id;

   @NotNull
   @Column(name = "ACTIVE", nullable = false)
   private short active;

   @NotNull
   @Size(min = 1, max = 3)
   @Column(name = "TEAM", nullable = false)
   private String team;

   @NotNull
   @Column(name = "CREATETIMESTAMP", nullable = false)
   @Temporal(TemporalType.TIMESTAMP)
   private Date createtimestamp;

   @NotNull
   @Size(min = 1, max = 10)
   @Column(name = "CREATEUSERNAME", nullable = false)
   private String createusername;

   @NotNull
   @Size(min = 1, max = 50)
   @Column(name = "CREATEPROGRAM", nullable = false)
   private String createprogram;

   @Temporal(TemporalType.TIMESTAMP)
   @Column(name = "UPDATETIMESTAMP", insertable = false, updatable = false, nullable = false)
   private Date updatetimestamp;

   @NotNull
   @Size(min = 1, max = 10)
   @Column(name = "UPDATEUSERNAME", nullable = false)
   private String updateusername;

   @NotNull
   @Size(min = 1, max = 50)
   @Column(name = "UPDATEPROGRAM", nullable = false)
   private String updateprogram;

   @ManyToOne(optional = false)
   @JoinColumn(name = "CUSTOMER_ID", referencedColumnName = "ID", nullable = false)
   private Customers customerId;

   public Teams() {
   }

   public Teams(Integer id) {
      this.id = id;
   }

   public Teams(Integer id, short active, String team, Date createtimestamp, String createusername, String createprogram, Date updatetimestamp, String updateusername, String updateprogram) {
      this.id = id;
      this.active = active;
      this.team = team;
      this.createtimestamp = createtimestamp;
      this.createusername = createusername;
      this.createprogram = createprogram;
      this.updatetimestamp = updatetimestamp;
      this.updateusername = updateusername;
      this.updateprogram = updateprogram;
   }

   public Integer getId() {
      return id;
   }

   public void setId(Integer id) {
      this.id = id;
   }

   public short getActive() {
      return active;
   }

   public void setActive(short active) {
      this.active = active;
   }

   public String getTeam() {
      return team;
   }

   public void setTeam(String team) {
      this.team = team;
   }

   public Date getCreatetimestamp() {
      return createtimestamp;
   }

   public void setCreatetimestamp(Date createtimestamp) {
      this.createtimestamp = createtimestamp;
   }

   public String getCreateusername() {
      return createusername;
   }

   public void setCreateusername(String createusername) {
      this.createusername = createusername;
   }

   public String getCreateprogram() {
      return createprogram;
   }

   public void setCreateprogram(String createprogram) {
      this.createprogram = createprogram;
   }

   public Date getUpdatetimestamp() {
      return updatetimestamp;
   }

   public void setUpdatetimestamp(Date updatetimestamp) {
      this.updatetimestamp = updatetimestamp;
   }

   public String getUpdateusername() {
      return updateusername;
   }

   public void setUpdateusername(String updateusername) {
      this.updateusername = updateusername;
   }

   public String getUpdateprogram() {
      return updateprogram;
   }

   public void setUpdateprogram(String updateprogram) {
      this.updateprogram = updateprogram;
   }

   public Customers getCustomerId() {
      return customerId;
   }

   public void setCustomerId(Customers customerId) {
      this.customerId = customerId;
   }

   @Override
   public int hashCode() {
      int hash = 0;
      hash += (id != null ? id.hashCode() : 0);
      return hash;
   }

   @Override
   public boolean equals(Object object) {
      // TODO: Warning - this method won't work in the case the id fields are not set
      if (!(object instanceof Teams)) {
         return false;
      }
      Teams other = (Teams) object;
      if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
         return false;
      }
      return true;
   }

   @Override
   public String toString() {
      return "com.kenco.oms.entity.Teams[ id=" + id + " ]";
   }
   
}
