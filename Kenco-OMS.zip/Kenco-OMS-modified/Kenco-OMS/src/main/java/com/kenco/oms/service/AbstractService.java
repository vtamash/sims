package com.kenco.oms.service;

import java.util.List;

/**
 * Top-Level class for all Abstract Services and defines Pre- and Post- Processing for implementation.
 *
 * @param <T> The entity type with which the Service will work.
 */
abstract class AbstractService<T> {
	/**
	 * Pre-Processing hook for the <b>create</b> Operation.  This method will allow implementing classes to implement custom
	 * business logic that will run <i>before</i> the <b>create</b> operation runs.
	 *
	 * @param t The typed Object that is being persisted.
	 * @param args Any arguments passed into the Service's create(...) method.
	 */
	protected abstract T createPreProcess(T t, Object... args);

	/**
	 * Pre-Processing hook for the <b>update</b> Operation.  This method will allow implementing classes to implement custom
	 * business logic that will run <i>before</i> the <b>update</b> operation runs.
	 *
	 * @param t The typed Object that is being updated.
	 * @param args Any arguments passed into the Service's update(...) method.
	 */
	protected abstract T updatePreProcess(T t, Object... args);

	/**
	 * Pre-Processing hook for the <b>delete</b> Operation.  This method will allow implementing classes to implement custom
	 * business logic that will run <i>before</i> the <b>delete</b> operation runs.
	 *
	 * @param t The typed Object that is being deleted.
	 * @param args Any arguments passed into the Service's delete(...) method.
	 */
	protected abstract T deletePreProcess(T t, Object... args);

	/**
	 * Post-Processing hook for the <b>create</b> Operation.  This method will allow implementing classes to implement custom
	 * business logic that will run <i>after</i> the <b>create</b> operation runs.
	 *
	 *
	 * @param t The typed Object that is being persisted.
	 * @param args Any arguments passed into the Service's delete(...) method.
	 * @return The typed Object that was persisted.
	 */
	protected abstract T createPostProcess(T t, Object... args);

	/**
	 * Post-Processing hook for the <b>read</b> Operation.  This method will allow implementing classes to implement custom
	 * business logic that will run <i>after</i> the <b>read</b> operation runs.
	 *
	 *
	 * @param l Typed List containing all objects read.
	 * @param args Any arguments passed into the Service's delete(...) method.
	 * @return Typed List containing all objects read.
	 */
	protected abstract List<T> readPostProcess(List<T> l, Object... args);

	/**
	 * Post-Processing hook for the <b>read</b> Operation.  This method will allow implementing classes to implement custom
	 * business logic that will run <i>after</i> the <b>read</b> operation runs.
	 *
	 *
	 * @param t Typed object returned from the <b>read</b> operation.
	 * @param args Any arguments passed into the Service's delete(...) method.
	 * @return Typed object returned from the <b>read</b> operation after implementing code has run.
	 */
	protected abstract T readSinglePostProcess(T t, Object... args);

	/**
	 * Post-Processing hook for the <b>update</b> Operation.  This method will allow implementing classes to implement custom
	 * business logic that will run <i>after</i> the <b>update</b> operation runs.
	 *
	 *
	 * @param t Typed object that was updated.
	 * @param args Any arguments passed into the Service's delete(...) method.
	 * @return Typed object that was updated.
	 */
	protected abstract T updatePostProcess(T t, Object... args);
}
