package com.kenco.oms.service.impl;

import com.kenco.oms.entity.Shiptocustomers;
import com.kenco.oms.service.ShiptoCustomersAbstractService;

import javax.persistence.EntityManager;
import java.util.List;

/**
 * Basic extension of the ShiptoCustomersAbstractService.  This offers no additional business logic other than what is absolutely
 * enforced upon any extending class.  To implement custom business logic for any process, extend the ShiptoCustomersAbstractService.
 * However, you may use this bean if the you need nothing more than <b>basic</b> CRUD functionality with no additional
 * business logic.
 *
 * @see com.kenco.oms.service.ShiptoCustomersAbstractService
 */
public final class GenericShiptoCustomersService extends ShiptoCustomersAbstractService {
	/**
	 * {@inheritDoc}
	 */
	public GenericShiptoCustomersService(EntityManager entityManager) {
		super(entityManager);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Shiptocustomers createPreProcess(Shiptocustomers shiptoCustomer, Object... args) {
		return shiptoCustomer;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Shiptocustomers updatePreProcess(Shiptocustomers shiptoCustomer, Object... args) {
		return shiptoCustomer;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Shiptocustomers deletePreProcess(Shiptocustomers shiptoCustomer, Object... args) {
		return shiptoCustomer;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Shiptocustomers createPostProcess(Shiptocustomers shiptoCustomer, Object... args) {
		return shiptoCustomer;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public List<Shiptocustomers> readPostProcess(List<Shiptocustomers> shiptoCustomers, Object... args) {
		return shiptoCustomers;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Shiptocustomers readSinglePostProcess(Shiptocustomers shiptocustomers, Object... args) {
		return shiptocustomers;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Shiptocustomers updatePostProcess(Shiptocustomers shiptoCustomer, Object... args) {
		return shiptoCustomer;
	}
}
