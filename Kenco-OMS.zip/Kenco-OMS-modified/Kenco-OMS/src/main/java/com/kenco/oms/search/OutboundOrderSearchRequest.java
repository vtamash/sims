package com.kenco.oms.search;

import com.kenco.oms.utilities.Enums;

public final class OutboundOrderSearchRequest extends SearchRequest {
	private String number;
	private String creator;
	private String shipTo;
	private Enums.eOMSOrderStatus status;

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public String getShipTo() {
		return shipTo;
	}

	public void setShipTo(String shipTo) {
		this.shipTo = shipTo;
	}

	public Enums.eOMSOrderStatus getStatus() {
		return status;
	}

	public void setStatus(Enums.eOMSOrderStatus status) {
		this.status = status;
	}
}
