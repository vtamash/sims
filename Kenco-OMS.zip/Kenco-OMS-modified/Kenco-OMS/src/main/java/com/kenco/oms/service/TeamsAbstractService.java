package com.kenco.oms.service;

import com.kenco.oms.entity.Teams;
import com.kenco.oms.repository.TeamsRepository;
import com.kenco.oms.search.TeamsSearchRequest;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import java.util.Date;
import java.util.List;

/**
 * Class embodies the actual work for communicating with a TeamsRepository.  To implement custom business logic for
 * any of the provided operations, simply extend this class and enter your business logic into the appropriate hook.
 *
 * @see com.kenco.oms.service.impl.GenericTeamsService
 */
public abstract class TeamsAbstractService extends SearchingAbstractService<Teams, TeamsSearchRequest> {
	private TeamsRepository repository;

	/**
	 * Constructor.
	 *
	 * @param entityManager The EntityManager that this Service will need to use.
	 */
	public TeamsAbstractService(EntityManager entityManager) {
		repository = new TeamsRepository(entityManager);
	}

	/**
	 * Provides search functionality for the <i>Teams</i> entity.
	 *
	 * @param request The <i>SearchRequest</i> object that is being used.
	 * @param args Any arguments passed required for the search.
	 * @return Typed List of <i>Teams</i> that match the <i>SearchRequest</i>.
	 */
	@Override
	public List<Teams> search(TeamsSearchRequest request, Object... args) {
		// Pre-Processing hook.
		TeamsSearchRequest processed = searchPreProcess(request, args);

		// Perform the search.
		List<Teams> results = repository.readPage(processed);

		// Post-Processing hook && return.
		return searchPostProcessing(results, args);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public long readSearchTotal(TeamsSearchRequest request) {
		return repository.readSearchTotal(request);
	}

	/**
	 * Provides access to check if a Team Name is already taken or if it is available.
	 *
	 * @param name The String to check against the taken names.
	 * @return True if the name is taken, false if it is available.
	 */
	public boolean existsByName(String name) {
		try {
			repository.readByName(name);
			return true;
		} catch (NoResultException nre) {
			return false;
		}
	}

	/**
	 * Defines base communication between the <i>TeamsService</i> and the <i>TeamsRepository</i> for <b>create</b>
	 * operations.  This method accommodates pre- and post- processing hooks such that extending classes can implement
	 * custom business logic at any time during processing.
	 *
	 * @param team The Teams object to be <b>created</b>.
	 * @param args Any arguments extending class requires during pre-processing.
	 * @param username The username belonging to the <i>User</i> performing this action.
	 * @return The <b>persisted</b> Teams object.
	 */
	public Teams create(Teams team, String username, Object... args) {
		// Pre-Processing hook.
		Teams processed = createPreProcess(team, args);

		// Abstract business logic.
		processed.setCreatetimestamp(new Date());
		processed.setCreateusername(username);
		processed.setCreateprogram("TeamsService.create()");

		processed.setUpdateusername(username);
		processed.setUpdateprogram("TeamsService.create()");

		// Perform the actual create from the Repository.
		Teams persisted = repository.create(processed);

		// Post-Processing hook && Return.
		return createPostProcess(persisted, args);
	}

    /**
     * Defines base communication between the <i>TeamsService</i> and the <i>TeamsRepository</i> for <b>read</b>
     * operations.  This method accommodates pre- and post- processing hooks such that extending classes can implement
     * custom business logic at any time during processing.
     *
     * @param args Any arguments extending class requires during pre-processing.
     * @return Typed List of Teams retrieved from the <b>read</b> operation.
     */
    public List<Teams> readAllActive(Integer customerId, Object... args) {
        // Create and fill TeamsSearchRequest instance
        TeamsSearchRequest request = new TeamsSearchRequest();
		request.setStart((short) 0);
		request.setLimit(TeamsRepository.MAX_PAGE_SIZE);
        request.setCustomerId(customerId);
        request.setActive(true);

        // Perform the actual read from the Repository.
        List<Teams> teams = repository.readPage(request);

        // Post-Processing hook && Return.
        return searchPostProcessing(teams, args);
    }

    /**
	 * Defines base communication between the <i>TeamsService</i> and the <i>TeamsRepository</i> for <b>read</b>
	 * operations.  This method accommodates post-processing such that extending classes can implement custom business
	 * logic.
	 *
	 * @param name The name of the team to retrieve.
	 * @param args Any arguments extending class requires during pre-processing.
	 * @return Teams entity that matches the provided Customer ID and Team Name.
	 */
	public Teams readByName(String name, Object... args) {
		// Perform the actual read from the Repository.
		Teams team = repository.readByName(name);

		// Post-Processing hook && Return.
		return readSinglePostProcess(team, args);
	}

	/**
	 * Defines base communication between the <i>TeamsService</i> and the <i>TeamsRepository</i> for <b>read</b>
	 * operations.  This method accommodates post-processing such that extending classes can implement custom business
	 * logic.
	 *
	 * @param id The id (<i>primary key</i>) of the Teams entity to retrieve.
	 * @param args Any arguments extending class requires during pre-processing.
	 * @return The Teams entity for the given ID.
	 */
	public Teams readById(int id, Object... args) {
		// Perform the actual read from the Repository.
		Teams team = repository.readyById(id);

		// Post-Processing hook && Return.
		return readSinglePostProcess(team, args);
	}

	/**
	 * Defines base communication between the <i>TeamsService</i> and the <i>TeamsRepository</i> for <b>update</b>
	 * operations.  This method accommodates pre- and post- processing hooks such that extending classes can implement
	 * custom business logic.
	 *
	 * @param team The Teams object to be <b>updated</b>.
	 * @param args Any arguments extending class requires during pre-processing.
	 * @return The <b>updated</b> Teams object.
	 */
	public Teams update(Teams team, String username, Object... args) {
		// Pre-Processing hook.
		Teams processed = updatePreProcess(team, args);

		// Abstract business logic.
		processed.setUpdateusername(username);
		processed.setUpdateprogram("TeamsService.update()");

		// Perform the actual update.
		Teams updated = repository.update(processed);

		// Post-Processing hook && Return.
		return updatePostProcess(updated, args);
	}

	/**
	 * Defines base communication between the <i>TeamsService</i> and the <i>TeamsRepository</i> for <b>delete</b>
	 * operations.  This method accommodates pre-processing such that extending classes can implement custom business
	 * logic.
	 *
	 * <b>Note</b>: We do not actually delete a <i>Teams</i> entity.  Rather, we use a soft-delete by flipping the
	 * <i>active</i> flag.
	 *
	 * @param team The Teams object to be <b>deleted</b>.
	 * @param args Any arguments extending class requires during pre-processing.
	 */
	public void delete(Teams team, String username, Object... args) {
		// Pre-Processing hook.
		Teams processed = deletePreProcess(team, args);

		// Abstract business logic.
		processed.setActive((short) 0);
		processed.setUpdateusername(username);
		processed.setUpdateprogram("TeamsService.delete()");

		// Perform the actual update.
		repository.update(processed);
	}
}
