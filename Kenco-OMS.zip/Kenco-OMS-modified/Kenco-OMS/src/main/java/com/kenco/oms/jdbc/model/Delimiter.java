package com.kenco.oms.jdbc.model;

/**
 * Thin wrapper for holding information about a SQL Statement's WHERE Clause.
 *
 * @see com.kenco.oms.repository.WesOutboundOrderRepository
 */
public class Delimiter {
	private String property;
	private String value;
	private String operator;

	private String value1;
	private String value2;

	public static final String OPERATOR_EQUAL   = " = ";
	public static final String OPERATOR_LIKE    = " LIKE ";
	public static final String OPERATOR_GREATER = " > ";
	public static final String OPERATOR_LESS    = " < ";
	public static final String OPERATOR_BETWEEN = " BETWEEN ";

	public Delimiter(String property, String value, String operator) {
		this.property = property;
		this.value    = value;
		this.operator = operator;
	}

	public Delimiter(String property, String value1, String value2, String operator) {
		this.property = property;
		this.value1   = value1;
		this.value2   = value2;
		this.operator = OPERATOR_BETWEEN;
	}

	public String getProperty() {
		return property;
	}

	public void setProperty(String property) {
		this.property = property;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getOperator() {
		return operator;
	}

	public void setOperator(String operator) {
		this.operator = operator;
	}

	public String getValue1() {
		return value1;
	}

	public void setValue1(String value1) {
		this.value1 = value1;
	}

	public String getValue2() {
		return value2;
	}

	public void setValue2(String value2) {
		this.value2 = value2;
	}

	public String generateSql() {
		return this.property + this.operator +
				(this.operator.equals(Delimiter.OPERATOR_BETWEEN) ? this.value1 + "? AND ?" + this.value2 : "?") +
				" AND ";
	}
}
