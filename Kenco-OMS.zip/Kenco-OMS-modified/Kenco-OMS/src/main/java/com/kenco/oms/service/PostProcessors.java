package com.kenco.oms.service;

import java.util.List;

/**
 * Interface for hooking into post-processing for a Service's operation(s).
 *
 * @param <T> The type of Entity with which implementing Service is working.
 */
public interface PostProcessors<T> {
	/**
	 * Post-Processing hook for the <b>create</b> Operation.  This method will allow implementing classes to implement custom
	 * business logic that will run <i>after</i> the <b>create</b> operation runs.
	 *
	 *
	 * @param t The typed Object that is being persisted.
	 * @param args
	 * @return The typed Object that was persisted.
	 */
	public T createPostProcess(T t, Object... args);

	/**
	 * Post-Processing hook for the <b>read</b> Operation.  This method will allow implementing classes to implement custom
	 * business logic that will run <i>after</i> the <b>read</b> operation runs.
	 *
	 *
	 * @param l Typed List containing all objects read.
	 * @param args
	 * @return Typed List containing all objects read.
	 */
	public List<T> readPostProcess(List<T> l, Object... args);

	/**
	 * Post-Processing hook for the <b>read</b> Operation.  This method will allow implementing classes to implement custom
	 * business logic that will run <i>after</i> the <b>read</b> operation runs.
	 *
	 *
	 * @param t Typed object returned from the <b>read</b> operation.
	 * @param args
	 * @return Typed object returned from the <b>read</b> operation after implementing code has run.
	 */
	public T readSinglePostProcess(T t, Object... args);

	/**
	 * Post-Processing hook for the <b>update</b> Operation.  This method will allow implementing classes to implement custom
	 * business logic that will run <i>after</i> the <b>update</b> operation runs.
	 *
	 *
	 * @param t Typed object that was updated.
	 * @param args
	 * @return Typed object that was updated.
	 */
	public T updatePostProcess(T t, Object... args);

	/**
	 * Post-Processing hook for the <b>delete</b> Operation.  This method will allow implementing classes to implement custom
	 * business logic that will run <i>after</i> the <b>delete</b> operation runs.
	 *
	 * @param t Typed object that was deleted.
	 * @param args
	 */
	public void deletePostProcess(T t, Object... args);
}
