package com.kenco.oms.repository;

import com.kenco.oms.entity.Skudepartments;
import org.apache.log4j.Logger;

import javax.persistence.EntityManager;
import java.util.List;
import javax.persistence.TypedQuery;

/**
 * Contains logic for communicating with the provided EntityManager for the
 * Skudepartments entity.
 */
public class SkuDepartmentsRepository {

   private EntityManager entityManager;
   private static Logger logger = Logger.getLogger(SkuDepartmentsRepository.class);

   /**
    * Default constructor. This exists to accommodate any future Spring-backed
    * projects that may require OMS.
    */
   public SkuDepartmentsRepository() {
   }

   /**
    * Convenience constructor to pass in the EntityManager. This will (mostly)
    * accommodate non-spring-backed implementations.
    *
    * @param entityManager The EntityManager to be used.
    */
   public SkuDepartmentsRepository(EntityManager entityManager) {
      this.entityManager = entityManager;
   }

   /**
    * Accessor for the EntityManager. This exists to accommodate any future
    * Spring-backed projects that may require OMS.
    *
    * @param entityManager The EntityManager that this Repository will use.
    */
   public void setEntityManager(EntityManager entityManager) {
      this.entityManager = entityManager;
   }

   /**
    * Reads all Skudepartments entities for passed customer.
    *
    * @param  pCustomerId the customer ID for departments wanting retrieved.
    * 
    * @return Typed List of Skudepartments
    */
   public List<Skudepartments> list(int pCustomerId) {
      logger.info("Reading SkuDepartments for Customer: " + pCustomerId);
      TypedQuery<Skudepartments> query;
      String sql = "select s from Skudepartments s where s.customerId.id = :custid and s.active = 1";
      query = entityManager.createQuery(sql, Skudepartments.class);
      query.setParameter("custid", pCustomerId);
      List<Skudepartments> list = query.getResultList();
      logger.info("Finished reading SkuDepartments for Customer: " + pCustomerId);
      return list;
   }
   
   
}
