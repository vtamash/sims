package com.kenco.oms.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "INBOUNDORDERHEADER")
@XmlRootElement
public class Inboundorderheader {
   @Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
   @Column(name = "ID", nullable = false)
   private Integer id;

   @NotNull
   @Size(min = 1, max = 30)
   @Column(name = "ORDERNUMBER", nullable = false)
   private String ordernumber;

   @NotNull
   @Column(name = "STATUS", nullable = false)
   private String status;

   @NotNull
   @Size(min = 1, max = 10)
   @Column(name = "VENDORNUMBER", nullable = false)
   private String vendornumber;

   @NotNull
   @Size(min = 1, max = 50)
   @Column(name = "VENDORNAME", nullable = false)
   private String vendorname;

   @NotNull
   @Size(min = 1, max = 50)
   @Column(name = "VENDORADDRESS1", nullable = false)
   private String vendoraddress1;

   @Column(name = "VENDORADDRESS2", nullable = false)
   private String vendoraddress2;

   @Column(name = "VENDORADDRESS3", nullable = false)
   private String vendoraddress3;

   @NotNull
   @Size(min = 1, max = 50)
   @Column(name = "VENDORCITY", nullable = false)
   private String vendorcity;

   @NotNull
   @Size(min = 1, max = 6)
   @Column(name = "VENDORZIP", nullable = false)
   private String vendorzip;

   @NotNull
   @Temporal(TemporalType.DATE)
   @Column(name = "SCHEDULEDARRIVALDATE", nullable = false)
   private Date scheduledarrivaldate;

   @NotNull
   @Size(min = 1, max = 2)
   @Column(name = "RECEIPTTYPE", nullable = false)
   private String receipttype;

   @NotNull
   @Size(min = 1, max = 4)
   @Column(name = "SCAC", nullable = false)
   private String scac;

   @NotNull
   @Size(min = 1, max = 20)
   @Column(name = "TRAILERNUMBER", nullable = false)
   private String trailernumber;

   @NotNull
   @Temporal(TemporalType.TIMESTAMP)
   @Column(name = "CREATETIMESTAMP", nullable = false)
   private Date createtimestamp;

   @NotNull
   @Size(min = 1, max = 10)
   @Column(name = "CREATEUSERNAME", nullable = false)
   private String createusername;

   @NotNull
   @Size(min = 1, max = 50)
   @Column(name = "CREATEPROGRAM", nullable = false)
   private String createprogram;

   @Temporal(TemporalType.TIMESTAMP)
   @Column(name = "UPDATETIMESTAMP", insertable = false, updatable = false, nullable = false)
   private Date updatetimestamp;

   @NotNull
   @Size(min = 1, max = 10)
   @Column(name = "UPDATEUSERNAME", nullable = false)
   private String updateusername;

   @NotNull
   @Size(min = 1, max = 50)
   @Column(name = "UPDATEPROGRAM", nullable = false)
   private String updateprogram;

   @JsonIgnore
   @OneToMany(mappedBy = "inboundorderheaderId", cascade = { CascadeType.ALL }, orphanRemoval = true, fetch = FetchType.EAGER)
   private List<Inboundorderdetail> inboundorderdetailCollection;

   @ManyToOne
   @JoinColumn(name = "VENDOR_ID", referencedColumnName = "ID")
   private Vendors vendorId;

   @ManyToOne(optional=false)
   @JoinColumn(name = "VENDORSTATE_ID", referencedColumnName = "ID")
   private States vendorstate;

   @ManyToOne
   @JoinColumn(name = "CUSTOMER_ID", referencedColumnName = "ID")
   private Customers customerId;

   @ManyToOne
   @JoinColumn(name = "BUSINESSUNIT_ID", referencedColumnName = "ID")
   private BusinessUnits businessunitId;

   public Inboundorderheader() {
   }

   public Inboundorderheader(Integer id) {
      this.id = id;
   }

   public Inboundorderheader(Integer id, String ordernumber, String status, String vendornumber, String vendorname, String vendoraddress1, String vendoraddress2, String vendoraddress3, String vendorcity, String vendorzip, Date scheduledarrivaldate, String receipttype, String scac, String trailernumber, Date createtimestamp, String createusername, String createprogram, Date updatetimestamp, String updateusername, String updateprogram) {
      this.id = id;
      this.ordernumber = ordernumber;
      this.status = status;
      this.vendornumber = vendornumber;
      this.vendorname = vendorname;
      this.vendoraddress1 = vendoraddress1;
      this.vendoraddress2 = vendoraddress2;
      this.vendoraddress3 = vendoraddress3;
      this.vendorcity = vendorcity;
      this.vendorzip = vendorzip;
      this.scheduledarrivaldate = scheduledarrivaldate;
      this.receipttype = receipttype;
      this.scac = scac;
      this.trailernumber = trailernumber;
      this.createtimestamp = createtimestamp;
      this.createusername = createusername;
      this.createprogram = createprogram;
      this.updatetimestamp = updatetimestamp;
      this.updateusername = updateusername;
      this.updateprogram = updateprogram;
   }

   public Integer getId() {
      return id;
   }

   public void setId(Integer id) {
      this.id = id;
   }

   public String getOrdernumber() {
      return ordernumber;
   }

   public void setOrdernumber(String ordernumber) {
      this.ordernumber = ordernumber;
   }

   public String getStatus() {
      return status;
   }

   public void setStatus(String status) {
      this.status = status;
   }

   

   public String getVendornumber() {
      return vendornumber;
   }

   public void setVendornumber(String vendornumber) {
      this.vendornumber = vendornumber;
   }

   public String getVendorname() {
      return vendorname;
   }

   public void setVendorname(String vendorname) {
      this.vendorname = vendorname;
   }

   public String getVendoraddress1() {
      return vendoraddress1;
   }

   public void setVendoraddress1(String vendoraddress1) {
      this.vendoraddress1 = vendoraddress1;
   }

   public String getVendoraddress2() {
      return vendoraddress2;
   }

   public void setVendoraddress2(String vendoraddress2) {
      this.vendoraddress2 = vendoraddress2;
   }

   public String getVendoraddress3() {
      return vendoraddress3;
   }

   public void setVendoraddress3(String vendoraddress3) {
      this.vendoraddress3 = vendoraddress3;
   }

   public String getVendorcity() {
      return vendorcity;
   }

   public void setVendorcity(String vendorcity) {
      this.vendorcity = vendorcity;
   }

   public String getVendorzip() {
      return vendorzip;
   }

   public void setVendorzip(String vendorzip) {
      this.vendorzip = vendorzip;
   }

   public Date getScheduledarrivaldate() {
      return scheduledarrivaldate;
   }

   public void setScheduledarrivaldate(Date scheduledarrivaldate) {
      this.scheduledarrivaldate = scheduledarrivaldate;
   }

   public String getReceipttype() {
      return receipttype;
   }

   public void setReceipttype(String receipttype) {
      this.receipttype = receipttype;
   }

   public String getScac() {
      return scac;
   }

   public void setScac(String scac) {
      this.scac = scac;
   }

   public String getTrailernumber() {
      return trailernumber;
   }

   public void setTrailernumber(String trailernumber) {
      this.trailernumber = trailernumber;
   }

   public Date getCreatetimestamp() {
      return createtimestamp;
   }

   public void setCreatetimestamp(Date createtimestamp) {
      this.createtimestamp = createtimestamp;
   }

   public String getCreateusername() {
      return createusername;
   }

   public void setCreateusername(String createusername) {
      this.createusername = createusername;
   }

   public String getCreateprogram() {
      return createprogram;
   }

   public void setCreateprogram(String createprogram) {
      this.createprogram = createprogram;
   }

   public Date getUpdatetimestamp() {
      return updatetimestamp;
   }

   public void setUpdatetimestamp(Date updatetimestamp) {
      this.updatetimestamp = updatetimestamp;
   }

   public String getUpdateusername() {
      return updateusername;
   }

   public void setUpdateusername(String updateusername) {
      this.updateusername = updateusername;
   }

   public String getUpdateprogram() {
      return updateprogram;
   }

   public void setUpdateprogram(String updateprogram) {
      this.updateprogram = updateprogram;
   }

//   @XmlTransient
   public List<Inboundorderdetail> getInboundorderdetailCollection() {
      return inboundorderdetailCollection;
   }

   public void setInboundorderdetailCollection(List<Inboundorderdetail> inboundorderdetailCollection) {
      this.inboundorderdetailCollection = inboundorderdetailCollection;
   }

   public Vendors getVendorId() {
      return vendorId;
   }

   public void setVendorId(Vendors vendorId) {
      this.vendorId = vendorId;
   }

   public States getVendorstate() {
      return vendorstate;
   }

   public void setVendorstate(States vendorstate) {
      this.vendorstate = vendorstate;
   }

   public Customers getCustomerId() {
      return customerId;
   }

   public void setCustomerId(Customers customerId) {
      this.customerId = customerId;
   }

   public BusinessUnits getBusinessunitId() {
      return businessunitId;
   }

   public void setBusinessunitId(BusinessUnits businessunitId) {
      this.businessunitId = businessunitId;
   }

   @Override
   public int hashCode() {
      int hash = 0;
      hash += (id != null ? id.hashCode() : 0);
      return hash;
   }

   @Override
   public boolean equals(Object object) {
      // TODO: Warning - this method won't work in the case the id fields are not set
      if (!(object instanceof Inboundorderheader)) {
         return false;
      }
      Inboundorderheader other = (Inboundorderheader) object;
      if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
         return false;
      }
      return true;
   }

   @Override
   public String toString() {
      return "com.kenco.oms.entity.Inboundorderheader[ id=" + id + " ]";
   }
   
}
