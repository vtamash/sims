package com.kenco.oms.repository;

import com.kenco.oms.entity.Vendors;
import org.apache.log4j.Logger;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;
import java.util.ArrayList;
import java.util.List;

/**
 * Contains logic for communicating with the provided EntityManager for the Vendors entity.
 *
 */
public final class VendorsRepository {
	private EntityManager entityManager;

	private static Logger logger = Logger.getLogger(VendorsRepository.class);

	/**
	 * Default constructor.  This exists to accommodate any future Spring-backed projects that may require OMS.
	 */
	public VendorsRepository() {}

	/**
	 * Convenience constructor to pass in the EntityManager.  This will (mostly) accommodate non-spring-backed implementations.
	 *
	 * @param entityManager The EntityManager to be used.
	 */
	public VendorsRepository(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	/**
	 * Persists the given Teams entity.
	 *
	 * @param vendor Teams entity to persist.
	 * @return The persisted Teams entity.
	 */
	public Vendors create(Vendors vendor) {
		EntityTransaction et = entityManager.getTransaction();
		et.begin();

		Vendors v = entityManager.merge(vendor);
		try { et.commit(); }
		catch (Exception e) { if (et.isActive()) et.rollback(); throw new IllegalStateException(e); }

		return v;
	}

	/**
	 * Reads a collection of Vendors entities based upon the provided Customer ID.
	 *
	 * @param pCustomerId Customer ID for the vendors requested.
	 * @return Typed List of Vendors.
	 */
	public List<Vendors> list(int pCustomerId) {
		logger.info("Reading Vendors for: CustomerId - " + pCustomerId);

		String sql  = "select t from Vendors t where t.customerId.id = :id";
		Query query = entityManager.createQuery(sql).setParameter("id", pCustomerId);

		List<Vendors> vendors = new ArrayList<Vendors>();
		for (Object curObject : query.getResultList())
			if (curObject instanceof Vendors)
				vendors.add((Vendors) curObject);

		logger.info("Finished reading Vendors for: " + pCustomerId);
		return vendors;
	}

	/**
	 * Reads a single Vendors entity based on the provided Vendor name.
	 *
	 * @param name The Vendor name for which the record is being requested.
	 * @return The Vendors entity read.
	 */
	public Vendors readByName(String name) {
		logger.info("Reading Vendor for: Vendor Name - " + name);

		Query query = entityManager.createQuery("SELECT v FROM Vendors v WHERE UPPER(v.name) = :name")
				.setParameter("name", name.trim().toUpperCase());

		logger.info("Finished reading Vendors for: Vendor Name - " + name);

		return (Vendors) query.getSingleResult();
	}

	/**
	 * Reads a single Vendors entity based on the provided Vendor number.
	 *
	 * @param number The Vendor number for which the record is being requested.
	 * @return The Vendors entity read.
	 */
	public Vendors readByNumber(String number) {
		logger.info("Reading Vendor for: Vendor Number - " + number);

		Query query = entityManager.createQuery("SELECT v FROM Vendors v WHERE v.vendornumber = :number")
				.setParameter("number", number.trim());

		logger.info("Finished reading Vendors for: Vendor Number - " + number);

		return (Vendors) query.getSingleResult();
	}

	/**
	 * Reads a single Vendors entity based on the provided ID (Primary Key).
	 *
	 * @param id The id (Primary Key) of the Vendors entity to retrieve.
	 * @return The Vendors entity retrieved.
	 */
	public Vendors readById(int id) {
		logger.info("Reading Vendors for: ID - " + id);

		String sql  = "select v from Vendors v where v.id = :id";
		Query query = entityManager.createQuery(sql)
				.setParameter("id", id);

		logger.info("Finished reading Vendors for: ID - " + id);

		return (Vendors) query.getSingleResult();
	}

	/**
	 * Saves the given Vendors entity.
	 *
	 * @param vendor (<b>Detached</b>) Vendors entity to save.
	 * @return The updated <i>Vendors</i>.
	 */
	public Vendors update(Vendors vendor) {
		EntityTransaction et = entityManager.getTransaction();
		et.begin();

		Vendors v = entityManager.merge(vendor);
		try { et.commit(); }
		catch (Exception e) { if (et.isActive()) et.rollback(); throw new IllegalStateException(e); }
		return v;
	}

	/**
	 * This doesn't actually <i>delete</i> the given Vendors entity.  Instead, we perform a <i>soft delete</i> by flipping
	 * the <i>active</i> flag.
	 *
	 * @param vendor The (<b>detached</b>) Vendors entity to "delete."
	 */
	public void delete(Vendors vendor) {
		EntityTransaction et = entityManager.getTransaction();
		et.begin();

		vendor.setActive((short) 0);
		entityManager.merge(vendor);
		try { et.commit(); }
		catch (Exception e) { if (et.isActive()) et.rollback(); throw new IllegalStateException(e); }
	}
}
