package com.kenco.oms.service;

import com.kenco.oms.entity.Shiptodeliverylocations;
import com.kenco.oms.repository.ShipToDeliveryLocationsRepository;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import java.util.List;

/**
 * Class embodies the actual work for communicating with a ShipToDeliveryLocationsRepository.  To implement custom business logic for
 * any of the provided operations, simply extend this class and enter your business logic into the appropriate hook.
 *
 * @see com.kenco.oms.service.impl.GenericShipToDeliveryLocationService
 */
public abstract class ShipToDeliveryLocationsAbstractService extends AbstractService<Shiptodeliverylocations> {
	private ShipToDeliveryLocationsRepository repository;

	/**
	 * Constructor.
	 *
	 * @param entityManager The EntityManager that this Service will need to use.
	 */
	public ShipToDeliveryLocationsAbstractService(EntityManager entityManager) {
		repository = new ShipToDeliveryLocationsRepository(entityManager);
	}

	/**
	 * Provides access to check if a Shiptodeliverylocations Name is already taken or if it is available.
	 *
	 * @param name The String to check against the taken names.
	 * @return True if the name is taken, false if it is available.
	 */
	public boolean existsByName(String name) {
		try {
			repository.readByName(name);
			return true;
		} catch (NoResultException nre) {
			return false;
		}
	}

	/**
	 * Defines base communication between the <i>ShipToDeliverLocationsService</i> and the <i>ShipToDeliveryLocationsRepository</i> for <b>create</b>
	 * operations.  This method accommodates pre- and post- processing hooks such that extending classes can implement
	 * custom business logic at any time during processing.
	 *
	 * @param shipToDeliverLocation The Shiptodeliverylocations object to be <b>created</b>.
	 * @param args Any arguments extending class requires during pre-processing.
	 * @return The <b>persisted</b> Shiptodeliverylocations object.
	 */
	public Shiptodeliverylocations create(Shiptodeliverylocations shipToDeliverLocation, Object... args) {
		// Pre-Processing hook.
		createPreProcess(shipToDeliverLocation, args);

		// Perform the actual create from the Repository.
		repository.create(shipToDeliverLocation);

		// Post-Processing hook && Return.
		return createPostProcess(shipToDeliverLocation, args);
	}

	/**
	 * Defines base communication between the <i>ShipToDeliverLocationsService</i> and the <i>ShipToDeliveryLocationsRepository</i> for <b>read</b>
	 * operations.  This method accommodates pre- and post- processing hooks such that extending classes can implement
	 * custom business logic at any time during processing.
	 *
	 * @param id The id (<i>primary key</i>) of the ShipToCustomers entity which owns the collection.
	 * @param args Any arguments extending class requires during pre-processing.
	 * @return Typed List of Shiptodeliverylocations retrieved from the <b>read</b> operation.
	 */
	public List<Shiptodeliverylocations> readByShipToCustomerId(int id, Object... args) {
		// Perform the actual read from the Repository.
		List<Shiptodeliverylocations> shipToDeliveryLocations = repository.readByShipToCustomerId(id);

		// Post-Processing hook && Return.
		return readPostProcess(shipToDeliveryLocations, args);
	}

	/**
	 * Defines base communication between the <i>ShipToDeliverLocationsService</i> and the <i>ShipToDeliveryLocationsRepository</i> for <b>read</b>
	 * operations.  This method accommodates pre- and post- processing hooks such that extending classes can implement
	 * custom business logic at any time during processing.
	 *
	 * @param id The id (<i>primary key</i>) of the Shiptodeliverylocations entity to retrieve.
	 * @param args Any arguments extending class requires during pre-processing.
	 * @return Typed List of Shiptodeliverylocations retrieved from the <b>read</b> operation.
	 */
	public Shiptodeliverylocations readById(int id, Object... args) {
		// Perform the actual read from the Repository.
		Shiptodeliverylocations shipToDeliveryLocations = repository.readById(id);

		// Post-Processing hook && Return.
		return readSinglePostProcess(shipToDeliveryLocations, args);
	}

	/**
	 * Defines base communication between the <i>ShipToDeliverLocationsService</i> and the <i>ShipToDeliveryLocationsRepository</i> for <b>read</b>
	 * operations.  This method accommodates pre- and post- processing hooks such that extending classes can implement
	 * custom business logic at any time during processing.
	 *
	 * @param name The name of the Shiptodeliverylocations to retrieve.
	 * @param args Any arguments extending class requires during pre-processing.
	 * @return Typed List of Shiptodeliverylocations retrieved from the <b>read</b> operation.
	 */
	public Shiptodeliverylocations readByName(String name, Object... args) {
		// Perform the actual read from the Repository.
		Shiptodeliverylocations shipToDeliveryLocation = repository.readByName(name);

		// Post-Processing hook && Return.
		return readSinglePostProcess(shipToDeliveryLocation, args);
	}

	/**
	 * Defines base communication between the <i>ShipToDeliverLocationsService</i> and the <i>ShipToDeliveryLocationsRepository</i> for <b>update</b>
	 * operations.  This method accommodates pre- and post- processing hooks such that extending classes can implement
	 * custom business logic at any time during processing.
	 *
	 * @param shipToDeliveryLocation The Shiptodeliverylocations object to be <b>updated</b>.
	 * @param args Any arguments extending class requires during pre-processing.
	 * @return The <b>updated</b> Shiptodeliverylocations object.
	 */
	public Shiptodeliverylocations update(Shiptodeliverylocations shipToDeliveryLocation, Object... args) {
		// Pre-Processing hook.
		updatePreProcess(shipToDeliveryLocation, args);

		// Perform the actual update.
		repository.update(shipToDeliveryLocation);

		// Post-Processing hook && Return.
		return updatePostProcess(shipToDeliveryLocation, args);
	}

	/**
	 * Defines base communication between the <i>ShipToDeliverLocationsService</i> and the <i>ShipToDeliveryLocationsRepository</i> for <b>delete</b>
	 * operations.  This method accommodates pre- and post- processing hooks such that extending classes can implement
	 * custom business logic at any time during processing.
	 *
	 * @param shipToDeliveryLocation The Shiptodeliverylocations to be <b>deleted</b>.
	 * @param args Any arguments extending class requires during pre-processing.
	 */
	public void delete(Shiptodeliverylocations shipToDeliveryLocation, Object... args) {
		// Pre-Processing hook.
		deletePreProcess(shipToDeliveryLocation, args);

		// Perform the actual delete from the Repository.
		repository.delete(shipToDeliveryLocation);
	}
}
