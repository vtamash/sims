package com.kenco.oms.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import java.util.Collection;
import java.util.Date;

@Entity
@Table(name = "CUSTOMERS")
@XmlRootElement
public class Customers {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID", nullable = false)
	private Integer id;

	@NotNull
	@Column(name = "ACTIVE", nullable = false)
	private short active;

	@NotNull
	@Size(min = 1, max = 10)
	@Column(name = "CUSTOMERNUMBER", nullable = false)
	private String customernumber;

	@NotNull
	@Size(min = 1, max = 50)
	@Column(name = "CUSTOMERNAME", nullable = false)
	private String customername;

	@NotNull
	@Size(min = 1, max = 10)
	@Column(name = "DATALIBRARY", nullable = false)
	private String datalibrary;

	@Size(max = 20)
	@Column(name = "EDI_WHSID")
	private String ediWhsid;

	@NotNull
	@Column(name = "CREATETIMESTAMP", nullable = false)
	@Temporal(TemporalType.TIMESTAMP)
	private Date createtimestamp;

	@NotNull
	@Size(min = 1, max = 10)
	@Column(name = "CREATEUSERNAME", nullable = false)
	private String createusername;

	@NotNull
	@Size(min = 1, max = 50)
	@Column(name = "CREATEPROGRAM", nullable = false)
	private String createprogram;

	@Column(name = "UPDATETIMESTAMP", insertable = false, updatable = false, nullable = false)
	@Temporal(TemporalType.TIMESTAMP)
	private Date updatetimestamp;

	@NotNull
	@Size(min = 1, max = 10)
	@Column(name = "UPDATEUSERNAME", nullable = false)
	private String updateusername;

	@NotNull
	@Size(min = 1, max = 50)
	@Column(name = "UPDATEPROGRAM", nullable = false)
	private String updateprogram;

	@JsonIgnore
	@OneToMany(mappedBy = "customerId")
	private Collection<Vendors> vendorsCollection;

	@JsonIgnore
	@OneToMany(mappedBy = "customerId")
	private Collection<Outboundorderheader> outboundorderheaderCollection;

	@JsonIgnore
	@OneToMany(mappedBy = "customer")
	private Collection<Shiptocustomers> shiptocustomersCollection;

	@JsonIgnore
	@OneToMany(mappedBy = "customer")
	private Collection<BusinessUnits> businessunitsCollection;

	@JsonIgnore
	@OneToMany(mappedBy = "customerId")
	private Collection<Teams> teamsCollection;

	@JsonIgnore
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "customerId")
	private Collection<Systemvalues> systemvaluesCollection;

	@JsonIgnore
	@OneToMany(mappedBy = "customerId")
	private Collection<Tabledefaults> tabledefaultsCollection;

	public Customers() {}

	public Customers(Integer id) {
		this.id = id;
	}

	public Customers(Integer id, short active, String customernumber, String customername, String datalibrary, Date createtimestamp, String createusername, String createprogram, Date updatetimestamp, String updateusername, String updateprogram) {
		this.id = id;
		this.active = active;
		this.customernumber = customernumber;
		this.customername = customername;
		this.datalibrary = datalibrary;
		this.createtimestamp = createtimestamp;
		this.createusername = createusername;
		this.createprogram = createprogram;
		this.updatetimestamp = updatetimestamp;
		this.updateusername = updateusername;
		this.updateprogram = updateprogram;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public short getActive() {
		return active;
	}

	public void setActive(short active) {
		this.active = active;
	}

	public String getCustomernumber() {
		return customernumber;
	}

	public void setCustomernumber(String customernumber) {
		this.customernumber = customernumber;
	}

	public String getCustomername() {
		return customername;
	}

	public void setCustomername(String customername) {
		this.customername = customername;
	}

	public String getDatalibrary() {
		return datalibrary;
	}

	public void setDatalibrary(String datalibrary) {
		this.datalibrary = datalibrary;
	}

	public String getEdiWhsid() {
		return ediWhsid;
	}

	public void setEdiWhsid(String ediWhsid) {
		this.ediWhsid = ediWhsid;
	}

	public Date getCreatetimestamp() {
		return createtimestamp;
	}

	public void setCreatetimestamp(Date createtimestamp) {
		this.createtimestamp = createtimestamp;
	}

	public String getCreateusername() {
		return createusername;
	}

	public void setCreateusername(String createusername) {
		this.createusername = createusername;
	}

	public String getCreateprogram() {
		return createprogram;
	}

	public void setCreateprogram(String createprogram) {
		this.createprogram = createprogram;
	}

	public Date getUpdatetimestamp() {
		return updatetimestamp;
	}

	public void setUpdatetimestamp(Date updatetimestamp) {
		this.updatetimestamp = updatetimestamp;
	}

	public String getUpdateusername() {
		return updateusername;
	}

	public void setUpdateusername(String updateusername) {
		this.updateusername = updateusername;
	}

	public String getUpdateprogram() {
		return updateprogram;
	}

	public void setUpdateprogram(String updateprogram) {
		this.updateprogram = updateprogram;
	}

	@XmlTransient
	public Collection<Vendors> getVendorsCollection() {
		return vendorsCollection;
	}

	public void setVendorsCollection(Collection<Vendors> vendorsCollection) {
		this.vendorsCollection = vendorsCollection;
	}

	@XmlTransient
	public Collection<Outboundorderheader> getOutboundorderheaderCollection() {
		return outboundorderheaderCollection;
	}

	public void setOutboundorderheaderCollection(Collection<Outboundorderheader> outboundorderheaderCollection) {
		this.outboundorderheaderCollection = outboundorderheaderCollection;
	}

	@XmlTransient
	public Collection<Shiptocustomers> getShiptocustomersCollection() {
		return shiptocustomersCollection;
	}

	public void setShiptocustomersCollection(Collection<Shiptocustomers> shiptocustomersCollection) {
		this.shiptocustomersCollection = shiptocustomersCollection;
	}

	@XmlTransient
	public Collection<BusinessUnits> getBusinessunitsCollection() {
		return businessunitsCollection;
	}

	public void setBusinessunitsCollection(Collection<BusinessUnits> businessunitsCollection) {
		this.businessunitsCollection = businessunitsCollection;
	}

	@XmlTransient
	public Collection<Teams> getTeamsCollection() {
		return teamsCollection;
	}

	public void setTeamsCollection(Collection<Teams> teamsCollection) {
		this.teamsCollection = teamsCollection;
	}

	@XmlTransient
	public Collection<Systemvalues> getSystemvaluesCollection() {
		return systemvaluesCollection;
	}

	public void setSystemvaluesCollection(Collection<Systemvalues> systemvaluesCollection) {
		this.systemvaluesCollection = systemvaluesCollection;
	}

	@XmlTransient
	public Collection<Tabledefaults> getTabledefaultsCollection() {
		return tabledefaultsCollection;
	}

	public void setTabledefaultsCollection(Collection<Tabledefaults> tabledefaultsCollection) {
		this.tabledefaultsCollection = tabledefaultsCollection;
	}

	@Override
	public int hashCode() {
		int hash = 0;
		hash += (id != null ? id.hashCode() : 0);
		return hash;
	}

	@Override
	public boolean equals(Object object) {
		// TODO: Warning - this method won't work in the case the id fields are not set
		if (!(object instanceof Customers)) {
			return false;
		}
		Customers other = (Customers) object;
		if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return "com.kenco.oms.entity.Customers[ id=" + id + " ]";
	}
}
