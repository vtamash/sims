package com.kenco.oms.service.impl;

import com.kenco.oms.entity.Skudepartments;
import com.kenco.oms.service.SkuDepartmentsAbstractService;
import javax.persistence.EntityManager;
import java.util.List;

/**
 * Basic extension of the AbstractService. This offers no additional business
 * logic other than what is absolutely enforced upon any extending class. To
 * implement custom business logic for any process, extend the
 * StatesAbstractService. However, you may use this bean if the you need nothing
 * more than <b>basic</b> CRUD functionality with no additional business logic.
 *
 */
public final class GenericSkuDepartmentsService extends SkuDepartmentsAbstractService {

   public GenericSkuDepartmentsService(EntityManager entityManager) {
      super(entityManager);
   }

   public List<Skudepartments> readAll(int customerId, Object... args) {
      return super.readAll(customerId);
   }

   public void createPreProcess(Skudepartments t, Object... args) {
   }

   public void readPreProcess(Object... args) {
   }

   public void readSinglePreProcess(Object... args) {
   }

   public void updatePreProcess(Object... args) {
   }

   public void deletePreProcess(Object... args) {
   }

   public Skudepartments createPostProcess(Skudepartments t, Object... args) {
      return t;
   }

   public List<Skudepartments> readPostProcess(List<Skudepartments> l, Object... args) {
      return l;
   }

   public Skudepartments readSinglePostProcess(Skudepartments t, Object... args) {
      return t;
   }

   public Skudepartments updatePostProcess(Skudepartments t, Object... args) {
      return t;
   }

   public void deletePostProcess(Skudepartments t, Object... args) {
   }
}
