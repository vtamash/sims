package com.kenco.oms.service.impl;

import com.kenco.oms.entity.Teams;
import com.kenco.oms.search.TeamsSearchRequest;
import com.kenco.oms.service.TeamsAbstractService;

import javax.persistence.EntityManager;
import java.util.List;

/**
 * Basic extension of the TeamsAbstractService.  This offers no additional business logic other than what is absolutely
 * enforced upon any extending class.  To implement custom business logic for any process, extend the TeamsAbstractService.
 * However, you may use this bean if the you need nothing more than <b>basic</b> CRUD functionality with no additional
 * business logic.
 *
 * @see com.kenco.oms.service.TeamsAbstractService
 */
public final class GenericTeamsService extends TeamsAbstractService {
	/**
	 * {@inheritDoc}
	 */
	public GenericTeamsService(EntityManager entityManager) {
		super(entityManager);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Teams createPreProcess(Teams team, Object... args) {
		return team;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Teams updatePreProcess(Teams team, Object... args) {
		return team;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Teams deletePreProcess(Teams team, Object... args) {
		return team;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Teams createPostProcess(Teams team, Object... args) {
		return team;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public List<Teams> readPostProcess(List<Teams> teams, Object... args) {
		return teams;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Teams readSinglePostProcess(Teams teams, Object... args) {
		return teams;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Teams updatePostProcess(Teams team, Object... args) {
		return team;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected TeamsSearchRequest searchPreProcess(TeamsSearchRequest teamsSearchRequest, Object... args) {
		return teamsSearchRequest;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected List<Teams> searchPostProcessing(List<Teams> results, Object... args) {
		return results;
	}
}
