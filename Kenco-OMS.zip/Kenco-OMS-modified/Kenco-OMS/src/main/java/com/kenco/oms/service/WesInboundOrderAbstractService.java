package com.kenco.oms.service;

import com.kenco.oms.entity.Customers;
import com.kenco.oms.jdbc.model.WesInboundOrder;
import com.kenco.oms.search.WesInboundSearchRequest;
import com.kenco.oms.repository.WesInboundOrderRepository;

import javax.sql.DataSource;
import java.util.List;
import java.util.Map;

/**
 * Class embodies the actual work for communicating with a InboundOrderRepository.  To implement custom business logic
 * for any of the provided operations, simply extend this class and enter your business logic into the appropriate hook.
 *
 * @see com.kenco.oms.service.impl.GenericWesInboundOrderService
 */
public abstract class WesInboundOrderAbstractService implements PreProcessors<WesInboundOrder>, PostProcessors<WesInboundOrder> {
	private WesInboundOrderRepository repository;

	/**
	 * Constructor.
	 *
	 * @param dataSource The DataSource that this Service will need to use.
	 */
	public WesInboundOrderAbstractService(DataSource dataSource) {
		repository = new WesInboundOrderRepository(dataSource);
	}

	/**
	 * Simple search on the <i>WesInboundOrderNumber</i>'s <b>number</b> field.
	 *
	 * @param number The <i>number</i> to search for.
	 * @param customer The <i>Customer</i> by which we will delimit the search.
	 * @return Typed collection holding all matching results.
	 */
	public List<Map<String,Object>> searchByOrderNumbers(String number, String prefix, Customers customer) {
		return repository.searchOrderNumbers(number, prefix, customer);
	}

	/**
	 * Simple search on the <i>WesInboundOrderNumber</i>'s <b>scac</b> field.
	 *
	 * @param scac The <i>scac</i> to search for.
	 * @param customer The <i>Customer</i> by which we will delimit the search.
	 * @return Typed collection holding all matching results.
	 */
	public List<Map<String,Object>> searchByScac(String scac, Customers customer) {
		return repository.searchScac(scac, customer);
	}

	/**
	 * Simple search on the <i>WesInboundOrderNumber</i>'s <b>name</b> field.
	 *
	 * @param name The <i>name</i> to search for.
	 * @param customer The <i>Customer</i> by which we will delimit the search.
	 * @return Typed collection holding all matching results.
	 */
	public List<Map<String,Object>> searchByCustomerName(String name, Customers customer) {
		return repository.searchVendorName(name, customer);
	}

	/**
	 * Defines base communication between the <i>WesInboundOrderService</i> and the <i>WesInboundOrderRepository</i>
	 * for <b>read</b> operations.  This method accommodates pre- and post- processing hooks such that extending classes
	 * can implement custom business logic at any time during processing.
	 *
	 * @param request The SearchRequest object by which to delimit the read results.
	 * @param args Any arguments extending class requires during pre-processing.
	 * @return Typed List of Vendors retrieved from the <b>read</b> operation.
	 */
	public List<WesInboundOrder> readPage(WesInboundSearchRequest request, Object... args) {
		// Pre-Processing hook.
		readPreProcess(args);

		// Perform the actual read from the Repository.
		List<WesInboundOrder> orders = repository.readPage(request);

		// Post-Processing hook && Return.
		return readPostProcess(orders, args);
	}

	public Long readSearchTotal(WesInboundSearchRequest request) {
		return repository.getCount(request);
	}
}
