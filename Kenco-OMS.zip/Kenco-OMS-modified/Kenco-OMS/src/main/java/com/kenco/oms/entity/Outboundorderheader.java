package com.kenco.oms.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import java.util.Collection;
import java.util.Date;

@Entity
@Table(name = "OUTBOUNDORDERHEADER")
@XmlRootElement
public class Outboundorderheader {
   @Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
   @Column(name = "ID", nullable = false)
   private Integer id;

   @NotNull
   @Size(min = 1, max = 25)
   @Column(name = "ORDERNUMBER", nullable = false)
   private String ordernumber;

   @NotNull
   @Column(name = "STATUS", nullable = false)
   private String status;

   @Size(max = 50)
   @Column(name = "SHIPTONUMBER")
   private String shiptonumber;

   @Size(max = 50)
   @Column(name = "SHIPTONAME")
   private String shiptoname;

   @Size(max = 50)
   @Column(name = "SHIPTOADDRESS1")
   private String shiptoaddress1;

   @Size(max = 50)
   @Column(name = "SHIPTOADDRESS2")
   private String shiptoaddress2;

   @Size(max = 50)
   @Column(name = "SHIPTOADDRESS3")
   private String shiptoaddress3;

   @Size(max = 50)
   @Column(name = "SHIPTOCITY")
   private String shiptocity;

   @Size(max = 6)
   @Column(name = "SHIPTOZIP")
   private String shiptozip;

   @NotNull
   @Column(name = "SCHEDULEDDEPARTUREDATE", nullable = false)
   @Temporal(TemporalType.DATE)
   private Date scheduleddeparturedate;

   @NotNull
   @Column(name = "SCHEDULEDDEPARTURETIME", nullable = false)
   @Temporal(TemporalType.TIME)
   private Date scheduleddeparturetime;

   @NotNull
   @Size(min = 1, max = 2)
   @Column(name = "ORDERTYPE", nullable = false)
   private String ordertype;

   @NotNull
   @Column(name = "ROUTED", nullable = false)
   private String routed;

   @NotNull
   @Size(min = 1, max = 4)
   @Column(name = "SCAC", nullable = false)
   private String scac;

   @NotNull
   @Column(name = "FREIGHTTERMS", nullable = false)
   private String freightterms;

   @NotNull
   @Column(name = "CREATETIMESTAMP", nullable = false)
   @Temporal(TemporalType.TIMESTAMP)
   private Date createtimestamp;

   @NotNull
   @Size(min = 1, max = 10)
   @Column(name = "CREATEUSERNAME", nullable = false)
   private String createusername;

   @NotNull
   @Size(min = 1, max = 50)
   @Column(name = "CREATEPROGRAM", nullable = false)
   private String createprogram;

   @Column(name = "UPDATETIMESTAMP", insertable=false, updatable=false, nullable = false)
   @Temporal(TemporalType.TIMESTAMP)
   private Date updatetimestamp;

   @NotNull
   @Size(min = 1, max = 10)
   @Column(name = "UPDATEUSERNAME", nullable = false)
   private String updateusername;

   @NotNull
   @Size(min = 1, max = 50)
   @Column(name = "UPDATEPROGRAM", nullable = false)
   private String updateprogram;

   @ManyToOne
   @JoinColumn(name = "SHIPTOSTATE_ID", referencedColumnName = "ID")
   private States shiptostateId;

   @ManyToOne
   @JoinColumn(name = "SHIPTOCUSTOMER_ID", referencedColumnName = "ID")
   private Shiptocustomers shiptocustomerId;

   @ManyToOne
   @JoinColumn(name = "CUSTOMER_ID", referencedColumnName = "ID")
   private Customers customerId;

   @ManyToOne
   @JoinColumn(name = "BUSINESSUNIT_ID", referencedColumnName = "ID")
   private BusinessUnits businessunitId;

   @JsonIgnore
   @OneToMany(mappedBy = "outboundorderheaderId", cascade = { CascadeType.ALL }, orphanRemoval = true, fetch = FetchType.EAGER)
   private Collection<Outboundorderdetail> outboundorderdetailCollection;

   public Outboundorderheader() {
   }

   public Outboundorderheader(Integer id) {
      this.id = id;
   }

   public Outboundorderheader(Integer id, String ordernumber, String status, Date scheduleddeparturedate, Date scheduleddeparturetime, String ordertype, String routed, String scac, String freightterms, Date createtimestamp, String createusername, String createprogram, Date updatetimestamp, String updateusername, String updateprogram) {
      this.id = id;
      this.ordernumber = ordernumber;
      this.status = status;
      this.scheduleddeparturedate = scheduleddeparturedate;
      this.scheduleddeparturetime = scheduleddeparturetime;
      this.ordertype = ordertype;
      this.routed = routed;
      this.scac = scac;
      this.freightterms = freightterms;
      this.createtimestamp = createtimestamp;
      this.createusername = createusername;
      this.createprogram = createprogram;
      this.updatetimestamp = updatetimestamp;
      this.updateusername = updateusername;
      this.updateprogram = updateprogram;
   }

   public Integer getId() {
      return id;
   }

   public void setId(Integer id) {
      this.id = id;
   }

   public String getOrdernumber() {
      return ordernumber;
   }

   public void setOrdernumber(String ordernumber) {
      this.ordernumber = ordernumber;
   }

   public String getStatus() {
      return status;
   }

   public void setStatus(String status) {
      this.status = status;
   }

   public String getShiptonumber() {
      return shiptonumber;
   }

   public void setShiptonumber(String shiptonumber) {
      this.shiptonumber = shiptonumber;
   }

   public String getShiptoname() {
      return shiptoname;
   }

   public void setShiptoname(String shiptoname) {
      this.shiptoname = shiptoname;
   }

   public String getShiptoaddress1() {
      return shiptoaddress1;
   }

   public void setShiptoaddress1(String shiptoaddress1) {
      this.shiptoaddress1 = shiptoaddress1;
   }

   public String getShiptoaddress2() {
      return shiptoaddress2;
   }

   public void setShiptoaddress2(String shiptoaddress2) {
      this.shiptoaddress2 = shiptoaddress2;
   }

   public String getShiptoaddress3() {
      return shiptoaddress3;
   }

   public void setShiptoaddress3(String shiptoaddress3) {
      this.shiptoaddress3 = shiptoaddress3;
   }

   public String getShiptocity() {
      return shiptocity;
   }

   public void setShiptocity(String shiptocity) {
      this.shiptocity = shiptocity;
   }

   public String getShiptozip() {
      return shiptozip;
   }

   public void setShiptozip(String shiptozip) {
      this.shiptozip = shiptozip;
   }

   public Date getScheduleddeparturedate() {
      return scheduleddeparturedate;
   }

   public void setScheduleddeparturedate(Date scheduleddeparturedate) {
      this.scheduleddeparturedate = scheduleddeparturedate;
   }

   public Date getScheduleddeparturetime() {
      return scheduleddeparturetime;
   }

   public void setScheduleddeparturetime(Date scheduleddeparturetime) {
      this.scheduleddeparturetime = scheduleddeparturetime;
   }

   public String getOrdertype() {
      return ordertype;
   }

   public void setOrdertype(String ordertype) {
      this.ordertype = ordertype;
   }

   public String getRouted() {
      return routed;
   }

   public void setRouted(String routed) {
      this.routed = routed;
   }

   public String getScac() {
      return scac;
   }

   public void setScac(String scac) {
      this.scac = scac;
   }

   public String getFreightterms() {
      return freightterms;
   }

   public void setFreightterms(String freightterms) {
      this.freightterms = freightterms;
   }

  
   public Date getCreatetimestamp() {
      return createtimestamp;
   }

   public void setCreatetimestamp(Date createtimestamp) {
      this.createtimestamp = createtimestamp;
   }

   public String getCreateusername() {
      return createusername;
   }

   public void setCreateusername(String createusername) {
      this.createusername = createusername;
   }

   public String getCreateprogram() {
      return createprogram;
   }

   public void setCreateprogram(String createprogram) {
      this.createprogram = createprogram;
   }

   public Date getUpdatetimestamp() {
      return updatetimestamp;
   }

   public void setUpdatetimestamp(Date updatetimestamp) {
      this.updatetimestamp = updatetimestamp;
   }

   public String getUpdateusername() {
      return updateusername;
   }

   public void setUpdateusername(String updateusername) {
      this.updateusername = updateusername;
   }

   public String getUpdateprogram() {
      return updateprogram;
   }

   public void setUpdateprogram(String updateprogram) {
      this.updateprogram = updateprogram;
   }

   public States getShiptostateId() {
      return shiptostateId;
   }

   public void setShiptostateId(States shiptostateId) {
      this.shiptostateId = shiptostateId;
   }

   public Shiptocustomers getShiptocustomerId() {
      return shiptocustomerId;
   }

   public void setShiptocustomerId(Shiptocustomers shiptocustomerId) {
      this.shiptocustomerId = shiptocustomerId;
   }

   public Customers getCustomerId() {
      return customerId;
   }

   public void setCustomerId(Customers customerId) {
      this.customerId = customerId;
   }

   public BusinessUnits getBusinessunitId() {
      return businessunitId;
   }

   public void setBusinessunitId(BusinessUnits businessunitId) {
      this.businessunitId = businessunitId;
   }

   @XmlTransient
   public Collection<Outboundorderdetail> getOutboundorderdetailCollection() {
      return outboundorderdetailCollection;
   }

   public void setOutboundorderdetailCollection(Collection<Outboundorderdetail> outboundorderdetailCollection) {
      this.outboundorderdetailCollection = outboundorderdetailCollection;
   }

   @Override
   public int hashCode() {
      int hash = 0;
      hash += (id != null ? id.hashCode() : 0);
      return hash;
   }

   @Override
   public boolean equals(Object object) {
      // TODO: Warning - this method won't work in the case the id fields are not set
      if (!(object instanceof Outboundorderheader)) {
         return false;
      }
      Outboundorderheader other = (Outboundorderheader) object;
      if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
         return false;
      }
      return true;
   }

   @Override
   public String toString() {
      return "com.kenco.oms.entity.Outboundorderheader[ id=" + id + " ]";
   }
   
}
