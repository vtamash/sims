package com.kenco.oms.service;

import com.kenco.oms.entity.BusinessUnits;
import com.kenco.oms.repository.BusinessUnitsRepository;

import javax.persistence.EntityManager;
import java.util.Date;
import java.util.List;

/**
 * Class embodies the actual work for communicating with a <i>BusinessUnitsRepository</i>.  To implement custom business
 * logic for any of the provided operations, simply extend this class and enter your business logic into the appropriate
 * hook.
 *
 * @see com.kenco.oms.service.impl.GenericBusinessUnitsService
 */
public abstract class BusinessUnitsAbstractService extends AbstractService<BusinessUnits> {
	private final BusinessUnitsRepository repository;

	/**
	 * Constructs a <i>BusinessUnitsService</i> with the provided <i>EntityManager</i>.
	 *
	 * @param entityManager <i>EntityManager</i> to use.
	 */
	public BusinessUnitsAbstractService(EntityManager entityManager) {
		repository = new BusinessUnitsRepository(entityManager);
	}

	/**
	 * Defines base communication between the <i>BusinessUnitsService</i> and the <i>BusinessUnitsRepository</i> for
	 * <b>create</b> operations.  This method accommodates pre- and post- processing hooks such that extending classes
	 * can implement custom business logic.
	 *
	 * @param businessUnit The <i>BusinessUnits</i> object to be <b>created</b>.
	 * @param username The user performing the operation.
	 * @param args Any arguments extending class requires during pre-processing.
	 * @return The <b>persisted</b> <i>BusinessUnits</i> object.
	 */
	public final BusinessUnits create(BusinessUnits businessUnit, String username, Object... args) {
		// Abstract business logic.
		businessUnit.setCreatetimestamp(new Date());
		businessUnit.setCreateusername(username);
		businessUnit.setCreateprogram("BusinessUnitService.create(...)");
		businessUnit.setUpdateusername(username);
		businessUnit.setUpdateprogram("BusinessUnitService.create(...)");

		// Pre-Processing hook.
		BusinessUnits processed = createPreProcess(businessUnit, args);

		// Perform the actual create from the Repository.
		repository.create(processed);

		// Post-Processing hook && Return.
		return createPostProcess(businessUnit, args);
	}

	/**
	 * Defines base communication between the <i>BusinessUnitsService</i> and the <i>BusinessUnitsRepository</i> for
	 * <b>read</b> operations.  This method accommodates post-processing such that extending classes can implement
	 * custom business logic.
	 *
	 * @param id The <i>BusinessUnits</i>'s Id by which to delimit the read results.
	 * @param args Any arguments extending class requires during pre-processing.
	 * @return Typed <i>BusinessUnits</i> record retrieved from the <b>read</b> operation.
	 */
	public final BusinessUnits readById(int id, Object... args) {
		// Perform the actual read from the Repository.
		BusinessUnits businessUnit = repository.readById(id);

		// Post-Processing hook && Return.
		return readSinglePostProcess(businessUnit, args);
	}

	/**
	 * Defines base communication between the <i>BusinessUnitsService</i> and the <i>BusinessUnitsRepository</i> for
	 * <b>read</b> operations.  This method accommodates post-processing such that extending classes can implement
	 * custom business logic.
	 *
	 * @param name The Customer Id by which to delimit the read results.
	 * @param args Any arguments extending class requires during pre-processing.
	 * @return The <i>BusinessUnit</i> entity matching the provided <b>Name</b>.
	 */
	public final BusinessUnits readByName(String name, Object... args) {
		// Perform the actual read from the Repository.
		BusinessUnits businessUnit = repository.readByName(name);

		// Post-Processing hook && Return.
		return readSinglePostProcess(businessUnit, args);
	}

	/**
	 * Defines base communication between the <i>BusinessUnitsService</i> and the <i>BusinessUnitsRepository</i> for
	 * <b>read</b> operations.  This method accommodates post-processing such that extending classes can implement
	 * custom business logic.
	 *
	 * @param customerId The Customer Id by which to delimit the read results.
	 * @param args Any arguments extending class requires during pre-processing.
	 * @return Typed List of <i>BusinessUnits</i> retrieved from the <b>read</b> operation.
	 */
	public final List<BusinessUnits> read(int customerId, Object... args) {
		// Perform the actual read from the Repository.
		List<BusinessUnits> businessunits = repository.readByCustomerId(customerId);

		// Post-Processing hook && Return.
		return readPostProcess(businessunits, args);
	}

	/**
	 * Defines base communication between the <i>BusinessUnitsService</i> and the <i>BusinessUnitsRepository</i> for
	 * <b>update</b> operations.  This method accommodates pre- and post- processing hooks such that extending classes
	 * can implement custom business logic.
	 *
	 * @param businessUnit The BusinessUnits object to be <b>updated</b>.
	 * @param username The user performing the operation.
	 * @param args Any arguments extending class requires during pre-processing.
	 * @return The <b>updated</b> <i>BusinessUnits</i> object.
	 */
	public final BusinessUnits update(BusinessUnits businessUnit, String username, Object... args) {
		// Abstract business logic.
		businessUnit.setUpdateusername(username);
		businessUnit.setUpdateprogram("BusinessUnitsService.update(...)");

		// Pre-Processing hook.
		BusinessUnits processed = updatePreProcess(businessUnit, args);

		// Perform the actual update.
		BusinessUnits updated = repository.update(processed);

		// Post-Processing hook && Return.
		return updatePostProcess(updated, args);
	}

	/**
	 * Defines base communication between the <i>BusinessUnitsService</i> and the <i>BusinessUnitsRepository</i> for
	 * <b>delete</b> operations.  This method accommodates pre-processing such that extending classes can implement
	 * custom business logic.
	 *
	 * <b>Note</b>: We do not actually delete a <i>Teams</i> entity.  Rather, we use a soft-delete by flipping the
	 * <i>active</i> flag.
	 *
	 * @param businessUnit The <i>BusinessUnits</i> object to be <b>deleted</b>.
	 * @param username The user performing the operation.
	 * @param args Any arguments extending class requires during pre-processing.
	 */
	public final void delete(BusinessUnits businessUnit, String username, Object... args) {
		// Abstract business logic.
		businessUnit.setActive((short) 0);
		businessUnit.setUpdateusername(username);
		businessUnit.setUpdateprogram("BusinessUnitService.delete()");

		// Pre-Processing hook.
		BusinessUnits processed = deletePreProcess(businessUnit, args);

		// Perform the actual delete from the Repository.
		repository.update(processed);
	}
}
