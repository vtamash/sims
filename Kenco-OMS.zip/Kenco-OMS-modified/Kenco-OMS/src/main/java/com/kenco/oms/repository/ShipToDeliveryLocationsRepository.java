package com.kenco.oms.repository;

import com.kenco.oms.entity.Shiptodeliverylocations;
import org.apache.log4j.Logger;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;
import java.util.ArrayList;
import java.util.List;

/**
 * Contains logic for communicating with the provided EntityManager for the Shiptodeliverlocations entity.
 *
 */
public final class ShipToDeliveryLocationsRepository {
	private EntityManager entityManager;

	private static final Logger logger = Logger.getLogger(ShipToDeliveryLocationsRepository.class);

	/**
	 * Default constructor.  This exists to accommodate any future Spring-backed projects that may require OMS.
	 */
	public ShipToDeliveryLocationsRepository() {}

	/**
	 * Convenience constructor to pass in the EntityManager.  This will (mostly) accommodate non-spring-backed implementations.
	 *
	 * @param entityManager The EntityManager to be used.
	 */
	public ShipToDeliveryLocationsRepository(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	/**
	 * Persists the given Shiptodeliverylocations entity.
	 *
	 * @param shipToDeliverylocation Shiptodeliverylocations entity to persist.
	 * @return The persisted Shiptodeliverylocations entity.
	 */
	public Shiptodeliverylocations create(Shiptodeliverylocations shipToDeliverylocation) {
		EntityTransaction et = entityManager.getTransaction();
		et.begin();

		Shiptodeliverylocations v = entityManager.merge(shipToDeliverylocation);
		try { et.commit(); }
		catch (Exception e) { if (et.isActive()) et.rollback(); throw new IllegalStateException(e); }

		return v;
	}

	/**
	 * Reads a single Shiptodeliverlocations entity based upon the provided ID (<i>Primary Key</i>).
	 *
	 * @param id The ID (<i>Primary Key</i>) for the Shiptodeliverlocations entity to fetch.
	 * @return The Shiptodeliverlocations entity for the provided ID (<i>Primary Key</i>).
	 */
	public Shiptodeliverylocations readById(int id) {
		logger.info("Reading Shiptodeliverlocations for: ID - " + id);

		Shiptodeliverylocations s = (Shiptodeliverylocations) entityManager.createQuery("SELECT s FROM Shiptodeliverylocations s WHERE s.id = :id")
				.setParameter("id",id)
				.getSingleResult();

		logger.info("Finished reading Shiptodeliverylocations for: ID - " + id);

		return s;
	}

	/**
	 * Reads all Shiptodeliverylocations for the provided ShipToCustomerId.
	 *
	 * @param shipToCustomerId The ShipToCustomer entity which owns the collection to be returned.
	 * @return The typed collection of Shiptodeliverylocations owned by the ShipToCustomer matching the provided id.
	 */
	public List<Shiptodeliverylocations> readByShipToCustomerId(int shipToCustomerId) {
		Query query = entityManager.createQuery("SELECT s FROM Shiptodeliverylocations s WHERE s.shiptocustomerId.id = :id")
				.setParameter("id", shipToCustomerId);

		List<Shiptodeliverylocations> locations = new ArrayList<Shiptodeliverylocations>();
		for (Object curObject : query.getResultList())
			if (curObject instanceof Shiptodeliverylocations)
				locations.add((Shiptodeliverylocations) curObject);
		return locations;
	}

	/**
	 * Reads a single Shiptodeliverylocations entity based on the provided Shiptodeliverylocations name.
	 *
	 * @param name The name for the Shiptodeliverylocations entity to fetch.
	 * @return The Shiptodeliverylocations for the provided <b>name</b>.
	 */
	public Shiptodeliverylocations readByName(String name) {
		logger.info("Reading Shiptodeliverylocations for: Name - " + name);

		Shiptodeliverylocations s = (Shiptodeliverylocations) entityManager.createQuery("SELECT s FROM Shiptodeliverylocations s WHERE UPPER(s.deliverylocation) = :name")
				.setParameter("name", name.trim().toUpperCase())
				.getSingleResult();

		logger.info("Finished reading Shiptodeliverylocations for: Name - " + name);

		return s;
	}

	/**
	 * Saves the given Shiptodeliverylocations entity.
	 *
	 * @param shipToDeliveryLocation (<b>Detached</b>) Shiptodeliverylocations entity to save.
	 */
	public void update(Shiptodeliverylocations shipToDeliveryLocation) {
		EntityTransaction et = entityManager.getTransaction();
		et.begin();

		entityManager.merge(shipToDeliveryLocation);
		try { et.commit(); }
		catch (Exception e) { if (et.isActive()) et.rollback(); throw new IllegalStateException(e); }
	}

	/**
	 * This doesn't actually <i>delete</i> the given Shiptodeliverylocations entity.  Instead, we perform a <i>soft delete</i> by flipping
	 * the <i>active</i> flag.
	 *
	 * @param shipToDeliverLocation The (<b>detached</b>) Shiptodeliverylocations entity to "delete."
	 */
	public void delete(Shiptodeliverylocations shipToDeliverLocation) {
		EntityTransaction et = entityManager.getTransaction();
		et.begin();

		shipToDeliverLocation.setActive((short) 0);
		entityManager.merge(shipToDeliverLocation);
		try { et.commit(); }
		catch (Exception e) { if (et.isActive()) et.rollback(); throw new IllegalStateException(e); }
	}
}
