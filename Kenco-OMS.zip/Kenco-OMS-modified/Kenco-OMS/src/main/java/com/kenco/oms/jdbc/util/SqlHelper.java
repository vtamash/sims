package com.kenco.oms.jdbc.util;

import com.kenco.oms.jdbc.model.Delimiter;
import com.kenco.oms.search.SearchRequest;

import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.List;

/**
 * Primarily to help create SQL for Pagination, since DB2 / AS400 isn't as slick as MySQL is in this respect.  Score
 * one for the Open Source community...
 *
 */
public abstract class SqlHelper {
	protected final Integer maxPageSize;
	protected final String tableName;
	protected final String orderColumn;
	protected final SearchRequest request;
	protected final List<Delimiter> delimiters;

	protected final SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

	private static final String ROW_ID = "rowId";

	/**
	 * Constructs a SqlHelper.  Implementations set the <i>tableName</i>, <i>orderColumn</i>, and <i>request</i> by
	 * calling super(...).
	 */
	public SqlHelper(SearchRequest request, int maxPageSize, String tableName, String orderColumn) {
		this.request     = request;
		this.tableName   = tableName;
		this.orderColumn = orderColumn;
		this.maxPageSize = maxPageSize;
		this.delimiters  = findDelimiters();
	}

	/**
	 * Abstract method.  Implementations need to define their delimiters.  <b>Important</b>: The order matters - this is
	 * why we use a List - so keep this in mind when building your collection.  Eventually, a PreparedStatementSetter
	 * is going to have to run, and it <b>will</b> need to know what order of your delimiters to assign the correct value(s).
	 */
	abstract List<Delimiter> findDelimiters();

	/**
	 * Accessor for the Collection of Delimiters.
	 */
	public List<Delimiter> getDelimiters() {
		return Collections.unmodifiableList(delimiters);
	}

	/**
	 * Accessor to create a statement to give a count of the <b>total</b> number of rows that a search would perform.
	 */
	public String generateSqlCount() {
		String sql = generateSqlQuery();

		return sql.substring(0, sql.lastIndexOf("WHERE")).replace("SELECT *","SELECT COUNT(1) AS rowCount");
	}

	/**
	 * Accessor to create a statement to give a <b>single page</b> of results.
	 */
	public String generateSqlQuery() {
		return "SELECT * FROM (" + generateInnerSql() + ") AS NumberedTable " + generateOuterWhereClause();
	}

	/**
	 * This builds the inner portion of the statement.  The complexity of the statement - this portion in particular -
	 * is why this resides in its own method.
	 *
	 * Statement form: SELECT ROW_NUMBER() OVER (ORDER BY <i>[column]</i>) AS rowId, x.* FROM <i>[lib]</i>/<i>[table]</i> AS x
	 */
	private String generateInnerSql() {
		return "SELECT ROW_NUMBER() OVER (ORDER BY " + this.orderColumn + ") AS " +
				SqlHelper.ROW_ID + ", x.* FROM " + request.getCustomer().getDatalibrary() + "/" + this.tableName + " AS x " +
				generateInnerWhereClause();
	}

	/**
	 * Generates the WHERE clause for the inner portion of the statement.  This is what will delimit the actuaol search
	 * results.  However, this has <b>no bearing what-so-ever</b> on the page beyond delimiting the resultset returned
	 * to be numbered.
	 */
	private String generateInnerWhereClause() {
		if (delimiters.isEmpty())
			return "";

		String sql = "WHERE ";
		for (Delimiter curDelimiter : delimiters)
			sql += curDelimiter.generateSql();
		sql = sql.substring(0, sql.length() - 4);

		return sql.trim();
	}

	/**
	 * Generates the outter WHERE clause.  This is the portion of the statement that will handle the actual <i>paging,</i>
	 * so-to-speak.  In reality, it will select only a range based on their "row number" - held constant by the <i>ORDER
	 * BY</i> statement.
	 *
	 * Statement form: WHERE rowId BETWEEN <i>[start]</i> AND <i>[end]</i>
	 */
	private String generateOuterWhereClause() {
		return "WHERE " + SqlHelper.ROW_ID + " BETWEEN " + request.getStart() + " AND " + (Math.min(request.getLimit(),maxPageSize) * request.getPage());
	}
}
