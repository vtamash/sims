package com.kenco.oms.service.impl;

import com.kenco.oms.jdbc.model.WesOutboundOrder;
import com.kenco.oms.service.WesOutboundOrderAbstractService;

import javax.sql.DataSource;
import java.util.List;

/**
 * Basic extension of the <i>WesOutboundOrderAbstractService</i>.  This offers no additional business logic other than
 * what is absolutely enforced upon any extending class.  To implement custom business logic for any process, extend the
 * <i>WesOutboundOrderAbstractService</i>.  However, you may use this bean if the you need nothing more than <b>basic</b>
 * CRUD functionality with no additional business logic.
 *
 * @see com.kenco.oms.service.WesOutboundOrderAbstractService
 */
public final class GenericWesOutboundOrderService extends WesOutboundOrderAbstractService {
	/**
	 * {@inheritDoc}
	 */
	public GenericWesOutboundOrderService(DataSource dataSource) {
		super(dataSource);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected WesOutboundOrder createPreProcess(WesOutboundOrder order, Object... args) {
		return order;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected WesOutboundOrder updatePreProcess(WesOutboundOrder order, Object... args) {
		return order;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected WesOutboundOrder deletePreProcess(WesOutboundOrder order, Object... args) {
		return order;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected WesOutboundOrder createPostProcess(WesOutboundOrder order, Object... args) {
		return order;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected List<WesOutboundOrder> readPostProcess(List<WesOutboundOrder> orders, Object... args) {
		return orders;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected WesOutboundOrder readSinglePostProcess(WesOutboundOrder order, Object... args) {
		return order;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected WesOutboundOrder updatePostProcess(WesOutboundOrder order, Object... args) {
		return order;
	}
}
