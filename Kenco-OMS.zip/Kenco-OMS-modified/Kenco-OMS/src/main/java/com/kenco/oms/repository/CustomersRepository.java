package com.kenco.oms.repository;

import com.kenco.oms.entity.Customers;
import org.apache.log4j.Logger;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;
import java.util.ArrayList;
import java.util.List;

/**
 * Contains logic for communicating with the provided EntityManager for the <i>Customers</i> entity.
 *
 */
public final class CustomersRepository {
	private EntityManager entityManager;

	private static final Logger logger = Logger.getLogger(CustomersRepository.class);

	/**
	 * Default constructor.  This exists to accommodate any future Spring-backed projects that may require OMS.
	 */
	public CustomersRepository() {}

	/**
	 * Convenience constructor to pass in the EntityManager.  This will (mostly) accommodate non-spring-backed
	 * implementations.
	 *
	 * @param entityManager The EntityManager to be used.
	 */
	public CustomersRepository(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	/**
	 * Accessor for the EntityManager.  This exists to accommodate any future Spring-backed projects that may require
	 * OMS.
	 *
	 * @param entityManager The EntityManager that this Repository will use.
	 */
	private void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	/**
	 * Retrieves a Collection of <b>all</b> <i>Customers</i> entities.
	 *
	 * @return Typed Collection of <b>all</b> <i>Customers</i> entities.
	 */
	public List<Customers> readAll() {
		logger.info("Reading all Customers.");

		Query query = entityManager.createQuery("SELECT c FROM Customers c");

		List<Customers> customers = new ArrayList<Customers>();
		for (Object curObject : query.getResultList())
			if (curObject instanceof Customers)
				customers.add((Customers) curObject);

		logger.info("Finished reading all Customers.");

		return customers;
	}

	/**
	 * Retrieves a Collection of <i>Customers</i> entities whose <b>active</b> state matches the provided <b>active</b>
	 * state.
	 *
	 * @param active The <b>active</b> state the <i>Customers</i> entities must be in to be retrieved.
	 * @return Typed List of <i>Customers</i> matching the provided <b>active</b> state.
	 */
	public List<Customers> readByActive(boolean active) {
		logger.info("Reading all Customers that are " + (active ? "" : "NOT") + " active");

		Query query = entityManager.createQuery("SELECT c FROM Customers c WHERE c.active = :active")
				.setParameter("active", active ? 1 : 0);

		List<Customers> customers = new ArrayList<Customers>();
		for (Object curObject : query.getResultList())
			if (curObject instanceof Customers)
				customers.add((Customers) curObject);

		logger.info("Finished reading all Customers that are " + (active ? "" : "NOT") + " active");

		return customers;
	}

	/**
	 * Attempts to retrieve a single <i>Customers</i> entity based upon the provided <b>Name</b>.  This type of read
	 * will locate the <i>Customers</i> entity regardless of the <i>active</i> flag.
	 *
	 * @param name The name for the <i>Customers</i> record requested.
	 * @return <i>Customers</i> entity matching the provided name.
	 * @throws javax.persistence.NoResultException
	 *          if there is no result
	 * @throws javax.persistence.NonUniqueResultException
	 *          if more than one result
	 */
	public Customers readByName(String name) {
		logger.info("Reading Customers for: Name - " + name);

		Customers customer = (Customers) entityManager.createQuery("SELECT c FROM Customers c WHERE c.customername = :name")
				                                      .setParameter("name", name)
				                                      .getSingleResult();

		logger.info("Finished reading Customers for: Name - " + name);

		return customer;
	}

	/**
	 * Attempts to retrieve a single <i>Customers</i> entity based upon the provided ID (<b>Primary Key</b>).  This type
	 * of read will locate the <i>Customers</i> entity regardless of the <i>active</i> flag.
	 *
	 * @param id The ID (<b>Primary Key</b>) of the <i>Customers</i> entity to be retrieved.
	 * @return The <i>Customers</i> entity matching the provided ID (<b>Primary Key</b>).
	 * @throws javax.persistence.NoResultException
	 *          if there is no result
	 * @throws javax.persistence.NonUniqueResultException
	 *          if more than one result
	 */
	public Customers readById(int id) {
		logger.info("Reading Customers for: ID - " + id);

		Customers customer = (Customers) entityManager.createQuery("SELECT c FROM Customers c WHERE c.id = :id")
				.setParameter("id", id)
				.getSingleResult();

		logger.info("Finished reading Customers for: ID - " + id);

		return customer;
	}

	/**
	 * Saves the given <i>Customers</i> entity.
	 *
	 * @param customer <i>Customers</i> entity to save.
	 * @return Updated <i>Customers</i> entity.
	 */
	public Customers update(Customers customer) {
		EntityTransaction et = entityManager.getTransaction();
		et.begin();

		Customers c = entityManager.merge(customer);
		try { et.commit(); }
		catch (Exception e) { if (et.isActive()) et.rollback(); throw new IllegalStateException(e); }
		return c;
	}

	/**
	 * Deletes the provided <i>Customers</i> entity.
	 *
	 * @param customer The <i>Customers</i> entity to delete.
	 */
	public void delete(Customers customer) {
		EntityTransaction et = entityManager.getTransaction();
		et.begin();

		entityManager.remove(readById(customer.getId()));
		try { et.commit(); }
		catch (Exception e) { if (et.isActive()) et.rollback(); throw new IllegalStateException(e); }
	}
}
