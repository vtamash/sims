package com.kenco.oms.service;

import com.kenco.oms.entity.Customers;
import com.kenco.oms.entity.Outboundorderheader;
import com.kenco.oms.repository.OutboundOrderHeaderRepository;
import com.kenco.oms.repository.SystemValuesRepository;
import com.kenco.oms.search.OutboundOrderSearchRequest;
import com.kenco.oms.service.impl.GenericOmsDownloadService;
import com.kenco.oms.utilities.Enums;

import javax.persistence.EntityManager;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Contains <i>global</i> business logic for handling an OutboundOrder.
 * <p/>
 * <b>Note</b>: The creation of an OutboundOrderHeader will <b>always</b> trigger the creation of an OmsDownload entity.
 *
 * @see com.kenco.oms.service.OmsDownloadAbstractService
 */
public abstract class OutboundOrderAbstractService extends AbstractService<Outboundorderheader> {
    private final OutboundOrderHeaderRepository repository;
    private final SystemValuesRepository sysRepository;

    private final OmsDownloadAbstractService downloadService;

    /**
     * Abstract method to allow extending classes to hook into the <b>read</b> (post) process for obtaining Outbound
     * Order Numbers.  This is primarily used to Prepend / Append an application-specific String to the Order Number
     * as a part of the <b>read</b> process.
     *
     * @param orderNumber The Order Number that was read.
     * @return The Order Number that was read <b>after</b> processing has occurred.
     */
    public abstract String getNextOutboundOrderNumberPostProcess(String orderNumber, Object... args);

    /**
     * Convenience constructor.  The creation of an <i>OutboundOrderHeader</i> entity will <b>always</b> trigger the
     * creation of an OmsDownload entity.  Implementors may still extend the <i>OmsDownloadAbstractService</i> to implement
     * their custom business logic for the <i>OmsDownload</i> creation and use the second constructor to pass it in here.
     *
     * @param entityManager The EntityManager that this Service will need to use.
     * @see com.kenco.oms.service.OmsDownloadAbstractService
     */
    public OutboundOrderAbstractService(EntityManager entityManager) {
        repository = new OutboundOrderHeaderRepository(entityManager);
        sysRepository = SystemValuesRepository.getSystemValuesRepository(entityManager);

        downloadService = new GenericOmsDownloadService(entityManager);
    }

    /**
     * Constructs an <i>OutboundOrderService</i> using the provided <i>OmsDownloadService</i>.  Use this constructor
     * when you require custom business logic within the <i>OmsDownloadService</i>.
     *
     * @param entityManager The EntityManager that this Service will need to use.
     * @see com.kenco.oms.service.OmsDownloadAbstractService
     */
    public OutboundOrderAbstractService(EntityManager entityManager, OmsDownloadAbstractService service) {
        repository = new OutboundOrderHeaderRepository(entityManager);
        sysRepository = SystemValuesRepository.getSystemValuesRepository(entityManager);

        downloadService = service;
    }

    /**
     * Simple exposure of the same method in the repository.  This should be called to find the <b>total</b> number
     * of results that a search has returned, rather than simply the size of the current page (which the frontend
     * should already know).
     *
     * @param request The <i>SearchRequest</i> object - preferably the same one that was used to perform the search.
     * @return The number of rows matching the provided <i>SearchRequest</i>.
     */
    public final long readSearchTotal(OutboundOrderSearchRequest request) {
        return repository.readSearchTotal(request);
    }

    /**
     * Simple search on the <i>OutboundOrderHeader</i>'s <b>OrderNumber</b> field.
     *
     * @param number   The <i>Order Number</i> to search for.
     * @param customer The <i>Customer</i> by which we will delimit the search.
     * @return Typed Collection holding all matching results.
     */
    public final List<Map<String, Object>> searchOrderNumbers(String number, Customers customer) {
        return repository.searchOrderNumbers(number, customer);
    }

    /**
     * Simple search on the <i>OutboundOrderHeader</i>'s <b>CreatedUserName</b> field.
     *
     * @param name     The <i>Creator's UserName</i> to search for.
     * @param customer The <i>Customer</i> by which we will delimit the search.
     * @return Typed Collection holding all matching results.
     */
    public final List<Map<String, Object>> searchCreators(String name, Customers customer) {
        return repository.searchCreators(name, customer);
    }

    /**
     * Simple search on the <i>OutboundOrderHeader</i>'s <b>ShipToName</b> field.
     *
     * @param name     The <i>Ship-To Name</i> to search for.
     * @param customer The <i>Customer</i> by which we will delimit the search.
     * @return Typed Collection holding all matching results.
     */
    public final List<Map<String, Object>> searchShipTos(String name, Customers customer) {
        return repository.searchShipTos(name, customer);
    }

    /**
     * Defines base communication between the <i>OutboundOrderHeaderService</i> and the <i>OutboundOrderHeaderRepository</i> for <b>create</b>
     * operations.  This method accommodates pre- and post- processing hooks such that extending classes can implement
     * custom business logic at any time during processing.
     *
     * @param outboundorderheader The Outboundorderheader object to be <b>created</b>.
     * @param args                Any arguments extending class requires during pre-processing.
     * @return The <b>persisted</b> Outboundorderheader object.
     */
    public final Outboundorderheader create(Outboundorderheader outboundorderheader, Object... args) {
        // Pre-Processing hook.
    	Outboundorderheader processed = createPreProcess(outboundorderheader, args);

		if (args == null || args.length < 1 || !(args[0] instanceof String))
			throw new IllegalArgumentException("Insufficient parameters to create OutboundOrderHeader!");
		
		String username = (String) args[0];

		// Abstract business logic.
		processed.setCreatetimestamp(new Date());
		processed.setCreateusername(username);
		processed.setCreateprogram("OutboundOrderAbstractService.create()");

		processed.setUpdatetimestamp(new Date());
		processed.setUpdateusername(username);
		processed.setUpdateprogram("OutboundOrderAbstractService.create()");

        // Perform the actual create from the Repository.
		Outboundorderheader order = outboundorderheader = repository.create(processed);

        // Post-Processing hook && Return.
        return createPostProcess(order, args);
    }

    /**
     * Defines base communication between the <i>OutboundOrderhHeaderService</i> and the <i>OutboundOrderhHeaderRepository</i>
     * for <b>read</b> operations. This method accommodates post-processing hooks such that extending classes
     * can implement custom business logic at any time during processing.
     * <p/>
     * <b>Note</b>: <b>Read</b> operations are paged for this entity.
     *
     * @param request The <i>SearchRequest</i> provided by the User.
     * @param args    Any arguments extending class requires during pre-processing.
     * @return Typed Collection of OutboundOrderHeader entities that matched the given <i>SearchRequest</i>.
     */
    public final List<Outboundorderheader> readPage(OutboundOrderSearchRequest request, Object... args) {
		// Abstract Business Logic.
		request.setStatus(Enums.eOMSOrderStatus.P);

        // Perform the actual read.
        List<Outboundorderheader> orders = repository.readPage(request);

        // Post-Processing hook && Return.
        return readPostProcess(orders, args);
    }


    /**
     * Defines base communication between the <i>OutboundOrderHeaderService</i> and the <i>OutboundOrderHeaderRepository</i>
     * for <b>read</b> operations.  This method accommodates post-processing such that extending classes can implement
     * custom business logic.
     *
     * @param number The number of the Outboundorderheader to retrieve.
     * @param args   Any arguments extending class requires during pre-processing.
     * @return Outboundorderheader entity that matches the provided Outbound Order Number.
     */
    public Outboundorderheader readByNumber(String number, Object... args) {

        //  Perform the actual read from the repository
        Outboundorderheader order = repository.readByNumber(number);

        // Post-Processing hook && Return.
        return readSinglePostProcess(order, args);
    }


    /**
     * Defines base communication between the <i>OutboundOrderHeaderService</i> and the <i>OutboundOrderHeaderRepository</i>
     * for <b>read</b> operations.  This method accommodates post-processing such that extending classes can implement
     * custom business logic.
     *
     * @param number The number of the Outboundorderheader to retrieve.
     * @param args   Any arguments extending class requires during pre-processing.
     * @return Outboundorderheader entity that matches the provided Outbound Order Number.
     */
    public Outboundorderheader readById(int id, Object... args) {

        //  Perform the actual read from the repository
        Outboundorderheader order = repository.readById(id);

        // Post-Processing hook && Return.
        return readSinglePostProcess(order, args);
    }

    /**
     * Defines base communication between the <i>OutboundOrderHeaderService</i> and the <i>OutboundOrderHeaderRepository</i> for <b>update</b>
     * operations.  This method accommodates pre- and post- processing hooks such that extending classes can implement
     * custom business logic at any time during processing.
     *
     * @param outboundorderheader The Outboundorderheader object to be <b>updated</b>.
     * @param args                Any arguments extending class requires during pre-processing.
     * @return The <b>updated</b> Outboundorderheader object.
     */
    public final Outboundorderheader update(Outboundorderheader outboundorderheader, Object... args) {
        // Pre-Processing hook.
    	Outboundorderheader processed = updatePreProcess(outboundorderheader, args);

		if (args == null || args.length < 1 || !(args[0] instanceof String))
			throw new IllegalArgumentException("Insufficient parameters to create OutboundOrderHeader!");
		
		String username = (String) args[0];

		processed.setUpdatetimestamp(new Date());
		processed.setUpdateusername(username);
		processed.setUpdateprogram("OutboundOrderService.create()");

        // Perform the actual update.
        repository.update(outboundorderheader);

        // Trigger the creation of an OmsDownload if required.
        if (outboundorderheader.getStatus().equals(Enums.eOMSOrderStatus.C.toString()))
            downloadService.create(outboundorderheader, args);

        // Post-Processing hook && Return.
        return updatePostProcess(outboundorderheader, args);
    }

    /**
     * Defines base communication between the <i>OutboundOrderHeaderService</i> and the <i>OutboundOrderHeaderRepository</i> for <b>delete</b>
     * operations.  This method accommodates pre- and post- processing hooks such that extending classes can implement
     * custom business logic at any time during processing.
     *
     * @param outboundorderheader The Outboundorderheader object to be <b>deleted</b>.
     * @param args                Any arguments extending class requires during pre-processing.
     */
    public final void delete(Outboundorderheader outboundorderheader, Object... args) {
        // Pre-Processing hook.
        deletePreProcess(outboundorderheader, args);

        // Perform the actual delete from the Repository.
        repository.delete(outboundorderheader);
    }

    /**
     * Get next outbound Order Number.
     *
     * @param customerId Customer ID for order in question.
     * @return The next (system provided) Order Number.
     */
    public final String getNextOutboundOrderNumber(int customerId) {
        int nextNumber = sysRepository.get(customerId, Enums.eSystemValues.NEXT_OUTBOUND_ORDERNUMBER).getIntegervalue();

        return getNextOutboundOrderNumberPostProcess(Integer.toString(nextNumber), customerId);
    }

    /**
     * Get prefix for outbound order...
     *
     * @param customerId customer ID for order in question.
     * @return order prefix.
     */
    public final String getOutboundOrderPrefix(int customerId) {
        return sysRepository.get(customerId, Enums.eSystemValues.OUTBOUND_ORDERNUMBER_PREFIX).getStringvalue();
    }
}
