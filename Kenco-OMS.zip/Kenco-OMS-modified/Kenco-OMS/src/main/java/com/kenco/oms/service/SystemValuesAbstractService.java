package com.kenco.oms.service;

import com.kenco.oms.entity.Systemvalues;
import com.kenco.oms.repository.SystemValuesRepository;
import com.kenco.oms.utilities.Enums.eSystemValues;
import javax.persistence.EntityManager;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

/**
 * Class embodies the actual work for communicating with a
 * SystemValuesRepository. To implement custom business logic for any of the
 * provided operations, simply extend this class and enter your business logic
 * into the appropriate hook.
 *
 * @see com.kenco.oms.service.impl.GenericSystemValuesService
 */
public abstract class SystemValuesAbstractService implements PreProcessors<Systemvalues>, PostProcessors<Systemvalues> {

   private SystemValuesRepository repository;

   /**
    * Constructor.
    *
    * @param entityManager The EntityManager that this Service will need to use.
    */
   public SystemValuesAbstractService(EntityManager entityManager) {
      // repository = new SystemValuesRepository(entityManager);
      repository = SystemValuesRepository.getSystemValuesRepository(entityManager);
   }

   public Systemvalues get(int customerId, eSystemValues systemValueName) {
      return repository.get(customerId, systemValueName);
   }

   public String getStringValue(int customerId, eSystemValues systemValueName) {
      return repository.getStringValue(customerId, systemValueName);
   }

   public int getIntegerValue(int customerId, eSystemValues systemValueName) {
      return repository.getIntegerValue(customerId, systemValueName);
   }

   public boolean getBooleanValue(int customerId, eSystemValues systemValueName) {
      return repository.getBooleanValue(customerId, systemValueName);
   }

   /**
    * Defines base communication between the <i>SystemValuesService</i> and the
    * <i>SystemValuesRepository</i> for <b>create</b>
    * operations. This method accommodates pre- and post- processing hooks such
    * that extending classes can implement custom business logic at any time
    * during processing.
    *
    * @param systemValue The Systemvalues object to be <b>created</b>.
    * @param args Any arguments extending class requires during pre-processing.
    * @return The <b>persisted</b> Systemvalues object.
    */
   public Systemvalues create(Systemvalues systemValue, Object... args) {
      // Pre-Processing hook.
      createPreProcess(systemValue, args);

      // Perform the actual create from the Repository.
      //repository.create(systemValue);

      // Post-Processing hook && Return.
      return createPostProcess(systemValue, args);
   }

   /**
    * Defines base communication between the <i>SystemValuesService</i> and the
    * <i>SystemValuesRepository</i> for <b>read</b>
    * operations. This method accommodates pre- and post- processing hooks such
    * that extending classes can implement custom business logic at any time
    * during processing.
    *
    * @param customerId The Customer Id by which to delimit the read results.
    * @param args Any arguments extending class requires during pre-processing.
    * @return Typed List of Systemvalues retrieved from the <b>read</b>
    * operation.
    */
   public List<Systemvalues> read(int customerId, Object... args) {
      // Pre-Processing hook.
      readPreProcess(args);

      // Perform the actual read from the Repository.
      List<Systemvalues> systemValues = repository.list(customerId);

      // Post-Processing hook && Return.
      return readPostProcess(systemValues, args);
   }

   /**
    * Defines base communication between the <i>SystemValuesService</i> and the
    * <i>SystemValuesRepository</i> for <b>update</b>
    * operations. This method accommodates pre- and post- processing hooks such
    * that extending classes can implement custom business logic at any time
    * during processing.
    *
    * @param systemValue The Systemvalues object to be <b>updated</b>.
    * @param args Any arguments extending class requires during pre-processing.
    * @return The <b>updated</b> Systemvalues object.
    */
   public Systemvalues update(Systemvalues systemValue, Object... args) {
      // Pre-Processing hook.
      updatePreProcess(systemValue, args);

      // Perform the actual update.
      //repository.update(systemValue);

      // Post-Processing hook && Return.
      return updatePostProcess(systemValue, args);
   }

   /**
    * Defines base communication between the <i>SystemValuesService</i> and the
    * <i>SystemValuesRepository</i> for <b>delete</b>
    * operations. This method accommodates pre- and post- processing hooks such
    * that extending classes can implement custom business logic at any time
    * during processing.
    *
    * @param systemValue The TevendosystemValuet to be <b>deleted</b>.
    * @param args Any arguments extending class requires during pre-processing.
    */
   public void delete(Systemvalues systemValue, Object... args) {
      // Pre-Processing hook.
      deletePreProcess(systemValue, args);

      // Perform the actual delete from the Repository.
      //repository.delete(systemValue);

      // Post-Processing hook.
      deletePostProcess(systemValue, args);
   }
   
/**
 * Defines a read from OMS <i>Properties</i> file on a classpath to fill email Subject and Body 
 * @return <b>Map<String, String map></b> with email subject and body with place holders  
 * @throws FileNotFoundException
 * @throws IOException
 */
   public Map<String, String> getEmailSubjectBody() throws FileNotFoundException, IOException {
	   Properties props = new Properties();
	   props.load(this.getClass().getResourceAsStream("/oms.cfg"));

	   Map<String, String> map = new HashMap<String, String>();
	   map.put("subject", props.getProperty("email.subject"));
	   map.put("body", props.getProperty("email.body"));

	   return map;
   }
}
