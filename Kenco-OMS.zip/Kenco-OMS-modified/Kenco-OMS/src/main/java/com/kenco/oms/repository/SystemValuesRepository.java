package com.kenco.oms.repository;
import com.kenco.oms.entity.Systemvalues;
import com.kenco.oms.utilities.Enums.eSystemValueTypes;
import com.kenco.oms.utilities.Enums.eSystemValues;
import org.apache.log4j.Logger;
import org.eclipse.persistence.config.CacheUsage;
import org.eclipse.persistence.config.QueryHints;
import org.eclipse.persistence.config.QueryType;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Contains logic for communicating with the provided EntityManager for the Teams entity.
 *
 */
public final class SystemValuesRepository {
   private EntityManager em;
   private static Logger logger = Logger.getLogger(SystemValuesRepository.class);
   private static SystemValuesRepository sysval = null;

   private SystemValuesRepository(EntityManager entityManager) {
      this.em = entityManager;
   }

   public static SystemValuesRepository getSystemValuesRepository(EntityManager entityManager) {
      if (sysval == null) {
         sysval = new SystemValuesRepository(entityManager);
      }
      return sysval;
   }

   /**
    * Returns a Systemvalues entity for the specified Customer ID and Value Name.
    *
    * @param pCustomerId The CustomerId for system value in question.
    * @param pSystemValueName The SystemValueName for which the value needs retrieved
    * @return a SystemValue object
    * @throws IllegalStateException When any exception is thrown during the transaction that causes a rollback.
    */
   public synchronized Systemvalues get(int pCustomerId, eSystemValues pSystemValueName) {
      logger.info("Reading System Value for: Customer ID - " + pCustomerId + " || Value - " + pSystemValueName);
      EntityTransaction et = em.getTransaction();

      try {
         et.begin();

         String sql = "select s from Systemvalues s where s.customerId.id = :id and upper(s.valuename) = :systemvaluename";
         TypedQuery<Systemvalues> q = em.createQuery(sql, Systemvalues.class)
				 .setParameter("id", pCustomerId)
				 .setParameter("systemvaluename", pSystemValueName.toString());

         Systemvalues SysVal = q.getSingleResult();

         /**
          * DEV and TEST environments leverage the same DataSource.  As such, we are modifying the state of persistent
          * objects in multiple applications.  This is required to "sync" the state.
          */
		 em.refresh(SysVal);

         Systemvalues retSysVal = new Systemvalues().clone(SysVal);  // this is a clone before any updating - used to return to caller...

         // if an auto-incrementing system value, then increment and update the record...
         if (SysVal.getAutoincrement() != null && SysVal.getAutoincrement() == 1) {
            if (SysVal.getValuetype().equals(eSystemValueTypes.INTEGER.toString()) && SysVal.getIntegervalue() != null) {
               SysVal.setIntegervalue(SysVal.getIntegervalue() + 1);
            }
            if (SysVal.getValuetype().equals(eSystemValueTypes.DECIMAL.toString()) && SysVal.getDecimalvalue() != null) {
               SysVal.setDecimalvalue(SysVal.getDecimalvalue().add(new BigDecimal(1)));
            }
            em.merge(SysVal);
         }
         et.commit();

         logger.info("System Value read complete.");

         return retSysVal;
      } catch (Exception e) {
         et.rollback();
         logger.error("Error reading SystemValues: ", e);
         throw new IllegalStateException(e);
      }
   }

   public List<Systemvalues> list(int pCustomerId) {
      logger.info("Reading System valuess for: CustomerId - " + pCustomerId);

      String sql = "select t from Systemvalues t where t.customerId.id = :id and t.active = 1";
      Query query = em.createQuery(sql).setParameter("id", pCustomerId);

      List<Systemvalues> systemValues = new ArrayList<Systemvalues>();
      for (Object curObject : query.getResultList()) {
         if (curObject instanceof Systemvalues) {
            systemValues.add((Systemvalues) curObject);
         }
      }

      logger.info("Finished reading System valuess for: " + pCustomerId);
      return systemValues;
   }

   /**
    * Get a 'String ' system value...
    *
    * @param pCustomerId The CustomerId for system value in question.
    * @param pSystemValueName The SystemValueName for which the value needs
    * retrieved
    *
    * @return String value from systemvalues table.
    */
   public String getStringValue(int pCustomerId, eSystemValues pSystemValueName) {
      String val;
      Systemvalues sv = get(pCustomerId, pSystemValueName);
      if (sv != null) {
         val = sv.getStringvalue() != null ? sv.getStringvalue() : "";
      } else {
         val = "";
      }

      return val;
   }

   /**
    * Get a 'Integer ' system value...
    *
    * @param pCustomerId The CustomerId for system value in question.
    * @param pSystemValueName The SystemValueName for which the value needs
    * retrieved
    *
    * @return integer value from systemvalues table.
    */
   public int getIntegerValue(int pCustomerId, eSystemValues pSystemValueName) {
      int val;
      Systemvalues sv = get(pCustomerId, pSystemValueName);
      if (sv != null) {
         val = sv.getIntegervalue() != null ? sv.getIntegervalue() : 0;
      } else {
         val = 0;
      }

      return val;
   }

   /**
    * Get a 'Boolean ' system value...
    *
    * @param pCustomerId The CustomerId for system value in question.
    * @param pSystemValueName The SystemValueName for which the value needs
    * retrieved
    *
    * @return boolean value from systemvalues table.
    */
   public boolean getBooleanValue(int pCustomerId, eSystemValues pSystemValueName) {
      boolean val;
      Systemvalues sv = get(pCustomerId, pSystemValueName);
      if (sv != null) {
         val = (sv.getBooleanvalue() != null && sv.getBooleanvalue() == 1) ? true : false;
      } else {
         val = false;
      }

      return val;
   }
}
