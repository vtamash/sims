package com.kenco.oms.service;

import com.kenco.oms.entity.States;
import com.kenco.oms.repository.StatesRepository;

import javax.persistence.EntityManager;
import java.util.List;

/**
 * Class embodies the actual work for communicating with a StatesRepository.  To implement custom business logic for
 * any of the provided operations, simply extend this class and enter your business logic into the appropriate hook.
 *
 * @see com.kenco.oms.service.impl.GenericStatesService
 */
public abstract class StatesAbstractService implements PreProcessors<States>, PostProcessors<States> {
	private StatesRepository repository;

	/**
	 * Constructor.
	 *
	 * @param entityManager The EntityManager that this Service will need to use.
	 */
	public StatesAbstractService(EntityManager entityManager) {
		repository = new StatesRepository(entityManager);
	}

	/**
	 * Defines base communication between the <i>StatesService</i> and the <i>StatesRepository</i> for <b>read</b>
	 * operations.  This method accommodates pre- and post- processing hooks such that extending classes can implement
	 * custom business logic at any time during processing.
	 *
	 * @param args Any arguments extending class requires during pre-processing.
	 * @return Typed List of States retrieved from the <b>read</b> operation.
	 */
	public List<States> readAll(Object... args) {
		// Pre-Processing hook.
		readPreProcess(args);

		// Perform the actual read from the Repository.
		List<States> states = repository.list();

		// Post-Processing hook && Return.
		return readPostProcess(states, args);
	}

	/**
	 * Defines base communication between the <i>StatesService</i> and the <i>StatesRepository</i> for <b>read</b>
	 * operations.  This method accommodates pre- and post- processing hooks such that extending classes can implement
	 * custom business logic at any time during processing.
	 *
	 * @param id The ID (<i>Primary Key</i>) for the States entity to be retrieved.
	 * @param args Any arguments extending class requires during pre-processing.
	 * @return The States entity matching the provided ID (<i>Primary Key</i>).
	 */
	public States readById(int id, Object... args) {
		// Pre-Processing hook.
		readSinglePreProcess(args);

		// Perform the actual read from the Repository.
		States state = repository.get(id);

		// Post-Processing hook && Return.
		return readSinglePostProcess(state, args);
	}

	/**
	 * Defines base communication between the <i>StatesService</i> and the <i>StatesRepository</i> for <b>read</b>
	 * operations.  This method accommodates pre- and post- processing hooks such that extending classes can implement
	 * custom business logic at any time during processing.
	 *
	 * @param abbr The (<i>Officially Recognized</i>) abbreviation for the States entity to be retrieved.
	 * @param args Any arguments extending class requires during pre-processing.
	 * @return The States entity matching the provided (<i>Officially Recognized</i>) abbreviation.
	 */
	public States readByAbbr(String abbr, Object... args) {
		// Pre-Processing hook.
		readSinglePreProcess(args);

		// Perform the actual read from the Repository.
		States state = repository.get(abbr);

		// Post-Processing hook && Return.
		return readSinglePostProcess(state, args);
	}
}
