package com.kenco.oms.search;

import com.kenco.oms.utilities.Enums;

public final class InboundOrderSearchRequest extends SearchRequest {
	private String number;
	private String creator;
	private String vendor;
	private Enums.eOMSInboundOrderStatus status;

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public String getVendor() {
		return vendor;
	}

	public void setVendor(String vendor) {
		this.vendor = vendor;
	}

	public Enums.eOMSInboundOrderStatus getStatus() {
		return status;
	}

	public void setStatus(Enums.eOMSInboundOrderStatus status) {
		this.status = status;
	}
}
