/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kenco.oms.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name = "SKUDEPARTMENTS")
@XmlRootElement
@NamedQueries({
   @NamedQuery(name = "Skudepartments.findAll", query = "SELECT s FROM Skudepartments s"),
   @NamedQuery(name = "Skudepartments.findById", query = "SELECT s FROM Skudepartments s WHERE s.id = :id"),
   @NamedQuery(name = "Skudepartments.findByActive", query = "SELECT s FROM Skudepartments s WHERE s.active = :active"),
   @NamedQuery(name = "Skudepartments.findByDepartmentnumber", query = "SELECT s FROM Skudepartments s WHERE s.departmentnumber = :departmentnumber"),
   @NamedQuery(name = "Skudepartments.findByCreatetimestamp", query = "SELECT s FROM Skudepartments s WHERE s.createtimestamp = :createtimestamp"),
   @NamedQuery(name = "Skudepartments.findByCreateusername", query = "SELECT s FROM Skudepartments s WHERE s.createusername = :createusername"),
   @NamedQuery(name = "Skudepartments.findByCreateprogram", query = "SELECT s FROM Skudepartments s WHERE s.createprogram = :createprogram"),
   @NamedQuery(name = "Skudepartments.findByUpdatetimestamp", query = "SELECT s FROM Skudepartments s WHERE s.updatetimestamp = :updatetimestamp"),
   @NamedQuery(name = "Skudepartments.findByUpdateusername", query = "SELECT s FROM Skudepartments s WHERE s.updateusername = :updateusername"),
   @NamedQuery(name = "Skudepartments.findByUpdateprogram", query = "SELECT s FROM Skudepartments s WHERE s.updateprogram = :updateprogram")})
public class Skudepartments implements Serializable {

   private static final long serialVersionUID = 1L;
   @Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
   @Basic(optional = false)
   @Column(name = "ID")
   private Integer id;
   @Basic(optional = false)
   @NotNull
   @Column(name = "ACTIVE")
   private short active;
   @Basic(optional = false)
   @NotNull
   @Size(min = 1, max = 20)
   @Column(name = "DEPARTMENTNUMBER")
   private String departmentnumber;
   @Basic(optional = false)
   @NotNull
   @Column(name = "REQUIRETEAM")
   private short requireteam;
   @Basic(optional = false)
   @NotNull
   @Column(name = "CREATETIMESTAMP")
   @Temporal(TemporalType.TIMESTAMP)
   private Date createtimestamp;
   @Basic(optional = false)
   @NotNull
   @Size(min = 1, max = 10)
   @Column(name = "CREATEUSERNAME")
   private String createusername;
   @Basic(optional = false)
   @NotNull
   @Size(min = 1, max = 50)
   @Column(name = "CREATEPROGRAM")
   private String createprogram;
   @Column(name = "UPDATETIMESTAMP")
   @Temporal(TemporalType.TIMESTAMP)
   private Date updatetimestamp;
   @Basic(optional = false)
   @NotNull
   @Size(min = 1, max = 10)
   @Column(name = "UPDATEUSERNAME")
   private String updateusername;
   @Basic(optional = false)
   @NotNull
   @Size(min = 1, max = 50)
   @Column(name = "UPDATEPROGRAM")
   private String updateprogram;
   @JoinColumn(name = "CUSTOMER_ID", referencedColumnName = "ID")
   @ManyToOne(optional = false)
   private Customers customerId;

   public Skudepartments() {
   }

   public Skudepartments(Integer id) {
      this.id = id;
   }

   public Skudepartments(Integer id, short active, String departmentnumber, Date createtimestamp, String createusername, String createprogram, Date updatetimestamp, String updateusername, String updateprogram) {
      this.id = id;
      this.active = active;
      this.departmentnumber = departmentnumber;
      this.createtimestamp = createtimestamp;
      this.createusername = createusername;
      this.createprogram = createprogram;
      this.updatetimestamp = updatetimestamp;
      this.updateusername = updateusername;
      this.updateprogram = updateprogram;
   }

   public Integer getId() {
      return id;
   }

   public void setId(Integer id) {
      this.id = id;
   }

   public short getActive() {
      return active;
   }

   public void setActive(short active) {
      this.active = active;
   }

   public String getDepartmentnumber() {
      return departmentnumber;
   }

   public void setDepartmentnumber(String departmentnumber) {
      this.departmentnumber = departmentnumber;
   }

   public Date getCreatetimestamp() {
      return createtimestamp;
   }

   public void setCreatetimestamp(Date createtimestamp) {
      this.createtimestamp = createtimestamp;
   }

   public String getCreateusername() {
      return createusername;
   }

   public void setCreateusername(String createusername) {
      this.createusername = createusername;
   }

   public String getCreateprogram() {
      return createprogram;
   }

   public void setCreateprogram(String createprogram) {
      this.createprogram = createprogram;
   }

   public Date getUpdatetimestamp() {
      return updatetimestamp;
   }

   public void setUpdatetimestamp(Date updatetimestamp) {
      this.updatetimestamp = updatetimestamp;
   }

   public String getUpdateusername() {
      return updateusername;
   }

   public void setUpdateusername(String updateusername) {
      this.updateusername = updateusername;
   }

   public String getUpdateprogram() {
      return updateprogram;
   }

   public void setUpdateprogram(String updateprogram) {
      this.updateprogram = updateprogram;
   }

   public Customers getCustomerId() {
      return customerId;
   }

   public void setCustomerId(Customers customerId) {
      this.customerId = customerId;
   }

   public boolean isRequireteam() {
      return requireteam == 1 ? true : false;
   }

   public void setRequireteam(short requireteam) {
      this.requireteam = requireteam;
   }

   @Override
   public int hashCode() {
      int hash = 0;
      hash += (id != null ? id.hashCode() : 0);
      return hash;
   }

   @Override
   public boolean equals(Object object) {
      // TODO: Warning - this method won't work in the case the id fields are not set
      if (!(object instanceof Skudepartments)) {
         return false;
      }
      Skudepartments other = (Skudepartments) object;
      if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
         return false;
      }
      return true;
   }

   @Override
   public String toString() {
      return "com.kenco.oms.entity.Skudepartments[ id=" + id + " ]";
   }
}
