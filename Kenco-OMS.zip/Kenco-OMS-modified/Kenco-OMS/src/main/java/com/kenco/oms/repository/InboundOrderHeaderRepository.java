package com.kenco.oms.repository;

import com.kenco.oms.entity.Customers;
import com.kenco.oms.entity.Inboundorderdetail;
import com.kenco.oms.entity.Inboundorderheader;
import com.kenco.oms.search.InboundOrderSearchRequest;
import org.apache.log4j.Logger;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;
import javax.persistence.criteria.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class InboundOrderHeaderRepository {
	private static Logger logger = Logger.getLogger(InboundOrderHeaderRepository.class);

	private static final int MAX_PAGE_SIZE = 200;
	private static final int MAX_COMBO_SEARCH_SIZE = 500;

	private EntityManager em;

	/**
	 * Default constructor. This exists to accommodate any future Spring-backed projects that may require OMS.
	 */
	public InboundOrderHeaderRepository() {}

	/**
	 * Convenience constructor to pass in the EntityManager. This will (mostly) accommodate non-spring-backed implementations.
	 *
	 * @param entityManager The EntityManager to be used.
	 */
	public InboundOrderHeaderRepository(EntityManager entityManager) {
		this.em = entityManager;
	}

	/**
	 * Accessor for the EntityManager. This exists to accommodate any future Spring-backed projects that may require OMS.
	 *
	 * @param entityManager The EntityManager that this Repository will use.
	 */
	public void setEntityManager(EntityManager entityManager) {
		this.em = entityManager;
	}

	/**
	 * Partner method for our Paging Search (<i>readPage(...)</i>).  This method will determine the <b>total</b> number
	 * of results that match the provided <i>SearchRequest</i>.
	 *
	 * @param request The <i>SearchRequest</i> submitted by the User.
	 * @return The total number of results that match the provided <i>SearchRequest</i>.
	 */
	public long readSearchTotal(InboundOrderSearchRequest request) {
		CriteriaBuilder          builder     = em.getCriteriaBuilder();
		CriteriaQuery<Long>      query       = builder.createQuery(Long.class);
		Root<Inboundorderheader> orderHeader = query.from(Inboundorderheader.class);

		// Define what we are counting.
		query.select(builder.count(orderHeader));

		// Generate our predicates.
		List<Predicate> predicates = createSearchPredicates(builder, orderHeader, request);

		// Set WHERE clause.
		query.where(predicates.toArray(new Predicate[predicates.size()]));

		return em.createQuery(query)
				.getSingleResult();
	}

	/**
	 * Queries the InboundOrderHeader entity for Order Numbers that match the provided search term.  Search is
	 * performed with a <b>trailing</b> wildcard <b>only</b>.
	 *
	 * <b>Note</b>: The maximum search result-size for a combo box is specified as: <i>MAX_COMBO_SEARCH_SIZE</i>
	 *
	 * @param orderNumber The Order Number to match.
	 * @return Typed Collection holding each Order Number that matched the search term.
	 */
	public List<Map<String,Object>> searchOrderNumbers(String orderNumber, Customers customer) {
		String jpql = "SELECT o.ordernumber " +
		              "FROM Inboundorderheader o " +
				      "JOIN FETCH o.customerId c " +
				      "WHERE c.id = :customerId " +
                      "  AND o.status <> 'C' " +
				      "  AND UPPER(o.ordernumber) LIKE :orderNumber";

		Query query = em.createQuery(jpql)
				.setParameter("customerId", customer.getId())
				.setParameter("orderNumber", orderNumber.toUpperCase() + "%")
				.setFirstResult(0)
				.setMaxResults(MAX_COMBO_SEARCH_SIZE);

		List results = query.getResultList();

		List<Map<String,Object>> numbers = new ArrayList<Map<String,Object>>();
		for (int i = 0; i < results.size(); i++) {
			Object curObject = results.get(i);
			if (curObject instanceof String) {
				Map<String,Object> curNumber = new HashMap<String,Object>();
				curNumber.put("id",i);
				curNumber.put("customerId", customer.getId());
				curNumber.put("number", curObject);
				numbers.add(curNumber);
			}
		}
		return numbers;
	}

	/**
	 * Queries the InboundOrderHeader entity for Creators that match the provided search term.  Search is performed
	 * with a <b>trailing</b> wildcard <b>only</b>.
	 *
	 * <b>Note</b>: The maximum search result-size for a combo box is specified as: <i>MAX_COMBO_SEARCH_SIZE</i>
	 *
	 * @param name The Username to match.
	 * @return Typed Collection holding each Creators that matched the search term.
	 */
	public List<Map<String,Object>> searchCreators(String name, Customers customer) {
		String jpql = "SELECT DISTINCT o.createusername " +
				      "FROM Inboundorderheader o " +
				      "JOIN FETCH o.customerId c " +
				      "WHERE c.id = :customerId " +
				      "  AND UPPER(o.createusername) LIKE :name";

		Query query = em.createQuery(jpql)
				.setParameter("customerId", customer.getId())
				.setParameter("name", name.toUpperCase() + "%")
				.setFirstResult(0)
				.setMaxResults(MAX_COMBO_SEARCH_SIZE);

		List results = query.getResultList();

		List<Map<String,Object>> creators = new ArrayList<Map<String,Object>>();
		for (int i = 0; i < results.size(); i++) {
			Object curObject = results.get(i);
			if (curObject instanceof String) {
				Map<String,Object> curCreator = new HashMap<String,Object>();
				curCreator.put("id", i);
				curCreator.put("customerId", customer.getId());
				curCreator.put("name", curObject);
				creators.add(curCreator);
			}
		}
		return creators;
	}

	/**
	 * Queries the InboundOrderHeader entity for Vendors that match the provided search term.  Search is performed
	 * with a <b>trailing</b> wildcard <b>only</b>.
	 *
	 * <b>Note</b>: The maximum search result-size for a combo box is specified as: <i>MAX_COMBO_SEARCH_SIZE</i>
	 *
	 * @param name The Vendor's Name to match.
	 * @return Typed Collection holding each Creators that matched the search term.
	 */
	public List<Map<String,Object>> searchVendors(String name, Customers customer) {
		String jpql = "SELECT DISTINCT o.vendorname " +
				      "FROM Inboundorderheader o " +
				      "JOIN FETCH o.customerId c " +
				      "WHERE c.id = :customerId " +
				      "  AND UPPER(o.vendorname) LIKE :name";

		Query query = em.createQuery(jpql)
				.setParameter("customerId", customer.getId())
				.setParameter("name", name.toUpperCase() + "%")
				.setFirstResult(0)
				.setMaxResults(MAX_COMBO_SEARCH_SIZE);

		List results = query.getResultList();

		List<Map<String,Object>> vendors = new ArrayList<Map<String,Object>>();
		for (int i = 0; i < results.size(); i++) {
			Object curObject = results.get(i);
			if (curObject instanceof String) {
				Map<String,Object> curVendor = new HashMap<String,Object>();
				curVendor.put("id", i);
				curVendor.put("customerId", customer.getId());
				curVendor.put("name", curObject);
				vendors.add(curVendor);
			}
		}
		return vendors;
	}

	/**
	 * Persists the given Inboundorderheader entity.
	 *
	 * @param inboundorderheader Inboundorderheader entity to persist.
	 * @return The persisted Inboundorderheader entity.
	 */
	public Inboundorderheader create(Inboundorderheader inboundorderheader) {

		EntityTransaction et = em.getTransaction();
		et.begin();

		Inboundorderheader orn = em.merge(inboundorderheader);
		try { et.commit(); }
		catch (Exception e) { if (et.isActive()) et.rollback(); throw new IllegalStateException(e); }
		return orn;
	}

	/**
	 * Reads a single Inboundorderheader entity based on the provided Inbound Order number.
	 *
	 * @param orderId The Inbound Order ID for which the record is being requested.
	 * @return The Inboundorderheader entity read.
	 */
	public Inboundorderheader readById(int orderId) {
		logger.info("Reading Inboundorderheader for: Inboundorderheader Number - " + orderId);

		Query query = em.createQuery("SELECT o FROM Inboundorderheader o WHERE o.id = :orderId").setParameter("orderId", orderId);

		logger.info("Finished reading Inboundorderheader for: Inboundorderheader Number - " + orderId);

		return (Inboundorderheader) query.getSingleResult();
	}

	/**
	 * Reads a single Inboundorderheader entity based on the provided Inbound Order number.
	 *
	 * @param number The Inbound Order number for which the record is being requested.
	 * @return The Inboundorderheader entity read.
	 */
	public Inboundorderheader readByNumber(String number) {
		logger.info("Reading Inboundorderheader for: Inboundorderheader Number - " + number);

		Query query = em.createQuery("SELECT o FROM Inboundorderheader o WHERE TRIM(UPPER(o.ordernumber)) = :number").setParameter("number", number.trim().toUpperCase());

		logger.info("Finished reading Inboundorderheader for: Inboundorderheader Number - " + number);

		return (Inboundorderheader) query.getSingleResult();
	}

	/**
	 * Searches the InboundOrderHeader table for a <b>page</b> of results matching the provided <i>SearchRequest</i>.
	 *
	 * <b>Note</b>: Since not all of the search-able fields are required, we must dynamically build our query - at least
	 * the predicate portion thereof.  Therefore, this method is built using the JPA 2.x Criteria API.
	 *
	 * <b>Note</b>: Ordering is <b>not</b> assignable by the user.  It isn't that this functionality is impossible -
	 * quite the opposite - but it is (at the time of this writing) desired.
	 *
	 * @param request The <i>SearchRequest</i> submitted by the User.
	 * @return Typed Collection containing all InboundOrderHeader entities that matched the <i>SearchRequest</i>.
	 */
	public List<Inboundorderheader> readPage(InboundOrderSearchRequest request) {
		CriteriaBuilder                   builder     = em.getCriteriaBuilder();
		CriteriaQuery<Inboundorderheader> query       = builder.createQuery(Inboundorderheader.class);
		Root<Inboundorderheader>          orderHeader = query.from(Inboundorderheader.class);

		// Generate our predicates.
		List<Predicate> predicates = createSearchPredicates(builder, orderHeader, request);

		// Set WHERE clause.
		query.where(predicates.toArray(new Predicate[predicates.size()]));

		// Build ORDER BY clause.
		List<Order> ordersBy = new ArrayList<Order>();

		// Order By: Order Number
		ordersBy.add(builder.asc(orderHeader.<String>get("ordernumber")));

		// Set ORDER BY clause.
		query.orderBy(ordersBy);

		// Run the (Typed) Query and return.
		return em.createQuery(query)
				.setFirstResult(request.getStart())
				.setMaxResults(Math.min(MAX_PAGE_SIZE, request.getLimit()))
				.getResultList();
	}

	/**
	 * Saves the given Inboundorderheader entity.
	 *
	 * @param inboundorderheader The (<b>detached</b>Inutboundorderheader entity to save.
	 */
	public Inboundorderheader update(Inboundorderheader inboundorderheader) {
		EntityTransaction et = em.getTransaction();
		et.begin();

		Inboundorderheader order = em.merge(inboundorderheader);
		try { et.commit(); }
		catch (Exception e) { if (et.isActive()) et.rollback(); throw new IllegalStateException(e); }
		return order;
	}

	/**
	 * Deletes the given Inboundorderheader entity.
	 *
	 * @param inboundorderheader The (<b>detached</b>) Inboundorderheader entity to delete.
	 */
	public void delete(Inboundorderheader inboundorderheader) {
		EntityTransaction et = em.getTransaction();
		et.begin();
		try { 
			Inboundorderheader order = em.find(Inboundorderheader.class, inboundorderheader.getId());
			for (Inboundorderdetail detail : order.getInboundorderdetailCollection())
				detail.setInboundorderheaderId(null);
			order.getInboundorderdetailCollection().clear();
			order = em.merge(order);
			em.remove(order);
			et.commit(); }
		catch (Exception e) { 
			if (et.isActive()) 
				et.rollback(); 
			throw new IllegalStateException(e); 
		}
	}

	/**
	 * Our (paged) searches consist of two portions: 1.) Obtain a Collection of results that match the provided search
	 * criteria and 2.) Obtain a count of the <b>total</b> number of results that match the provided <i>SearchRequest</i>.
	 *
	 * Because of this, our Predicates must be built by two separate methods.  Therefore, that work is abstracted here,
	 * and any interested method may use it.
	 *
	 * @param builder The CriteriaBuilder that is being used to construct the query.
	 * @param orderHeader The Root of the Criteria to be queried that is being used (FROM clause).
	 * @param request The User-Provided Search Request.
	 * @return A (Typed) Collection of Predicates to be used in the query's WHERE clause.
	 */
	private List<Predicate> createSearchPredicates(CriteriaBuilder builder, Root<Inboundorderheader> orderHeader, InboundOrderSearchRequest request) {
		List<Predicate> predicates = new ArrayList<Predicate>();

		// Predicate: Customer (required)
		predicates.add(builder.equal(orderHeader.<Customers>get("customerId").<Integer>get("id"), request.getCustomer().getId()));

        // Predicate: Status (required).
		predicates.add(builder.and(builder.equal(orderHeader.<String>get("status"), request.getStatus().toString())));

		// Predicate: Order Number (optional).
		if (request.getNumber() != null && !request.getNumber().trim().isEmpty())
			predicates.add(builder.and(builder.equal(orderHeader.<String>get("ordernumber"), request.getNumber())));

		// Predicate: Vendor (optional).
		if (request.getVendor() != null && !request.getVendor().trim().isEmpty())
			predicates.add(builder.and(builder.equal(orderHeader.<String>get("vendor"), request.getVendor())));

		// Predicate: Creator (optional).
		if (request.getCreator() != null && !request.getCreator().trim().isEmpty())
			predicates.add(builder.and(builder.equal(orderHeader.<String>get("createusername"), request.getCreator())));

		return predicates;
	}
}
