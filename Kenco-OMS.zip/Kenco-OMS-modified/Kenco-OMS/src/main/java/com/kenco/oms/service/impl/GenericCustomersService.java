package com.kenco.oms.service.impl;

import com.kenco.oms.entity.Customers;
import com.kenco.oms.service.CustomersAbstractService;

import javax.persistence.EntityManager;
import java.util.List;

/**
 * Basic extension of the CustomersAbstractService.  This offers no additional business logic other than what is absolutely
 * enforced upon any extending class.  To implement custom business logic for any process, extend the CustomersAbstractService.
 * However, you may use this bean if the you need nothing more than <b>basic</b> CRUD functionality with no additional
 * business logic.
 *
 * @see com.kenco.oms.service.CustomersAbstractService
 */
public final class GenericCustomersService extends CustomersAbstractService {
	/**
	 * {@inheritDoc}
	 */
	public GenericCustomersService(EntityManager entityManager) {
		super(entityManager);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Customers createPreProcess(Customers customer, Object... args) {
		throw new UnsupportedOperationException("Customers Create Operation is Not Supported!");
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Customers updatePreProcess(Customers customer, Object... args) {
		throw new UnsupportedOperationException("Customers Update Operation is Not Supported!");
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Customers deletePreProcess(Customers customer, Object... args) {
		throw new UnsupportedOperationException("Customers Delete Operation is Not Supported!");
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Customers createPostProcess(Customers customer, Object... args) {
		throw new UnsupportedOperationException("Customers Create Operation is Not Supported!");
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public List<Customers> readPostProcess(List<Customers> customers, Object... args) {
		return customers;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Customers readSinglePostProcess(Customers customers, Object... args) {
		return customers;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Customers updatePostProcess(Customers customer, Object... args) {
		throw new UnsupportedOperationException("Customers Update Operation is Not Supported!");
	}
}
