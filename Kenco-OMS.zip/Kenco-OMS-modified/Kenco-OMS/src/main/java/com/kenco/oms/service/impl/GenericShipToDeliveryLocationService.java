package com.kenco.oms.service.impl;

import com.kenco.oms.entity.Shiptodeliverylocations;
import com.kenco.oms.service.ShipToDeliveryLocationsAbstractService;

import javax.persistence.EntityManager;
import java.util.List;

public final class GenericShipToDeliveryLocationService extends ShipToDeliveryLocationsAbstractService {
	/**
	 * {@inheritDoc}
	 */
	public GenericShipToDeliveryLocationService(EntityManager entityManager) {
		super(entityManager);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Shiptodeliverylocations createPreProcess(Shiptodeliverylocations shiptodeliverylocations, Object... args) {
		return shiptodeliverylocations;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Shiptodeliverylocations updatePreProcess(Shiptodeliverylocations shiptodeliverylocations, Object... args) {
		return shiptodeliverylocations;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Shiptodeliverylocations deletePreProcess(Shiptodeliverylocations shiptodeliverylocations, Object... args) {
		return shiptodeliverylocations;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Shiptodeliverylocations createPostProcess(Shiptodeliverylocations shiptodeliverylocations, Object... args) {
		return shiptodeliverylocations;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public List<Shiptodeliverylocations> readPostProcess(List<Shiptodeliverylocations> l, Object... args) {
		return l;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Shiptodeliverylocations readSinglePostProcess(Shiptodeliverylocations shiptodeliverylocations, Object... args) {
		return shiptodeliverylocations;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Shiptodeliverylocations updatePostProcess(Shiptodeliverylocations shiptodeliverylocations, Object... args) {
		return shiptodeliverylocations;
	}
}
