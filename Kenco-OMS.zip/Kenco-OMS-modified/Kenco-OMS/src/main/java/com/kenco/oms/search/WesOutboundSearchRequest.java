package com.kenco.oms.search;

import java.util.Date;

/**
 * Wrapper for a Search Request for the WesOutboundOrder entity.
 *
 */
public final class WesOutboundSearchRequest extends SearchRequest {
	private String prefix;
	private String door;
	private String load;
	private String number;
	private String shipTo;
	private String shipWith;
	private String status;
	private String type;
	private String zipcode;

	private Date act;
	private Date scd;

	public String getPrefix() {
		return prefix;
	}

	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}

	public String getDoor() {
		return door;
	}

	public void setDoor(String door) {
		this.door = door;
	}

	public String getLoad() {
		return load;
	}

	public void setLoad(String load) {
		this.load = load;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String getShipTo() {
		return shipTo;
	}

	public void setShipTo(String shipTo) {
		this.shipTo = shipTo;
	}

	public String getShipWith() {
		return shipWith;
	}

	public void setShipWith(String shipWith) {
		this.shipWith = shipWith;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	public Date getAct() {
		return act;
	}

	public void setAct(Date act) {
		this.act = act;
	}

	public Date getScd() {
		return scd;
	}

	public void setScd(Date scd) {
		this.scd = scd;
	}
}
