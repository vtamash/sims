package com.kenco.oms.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import java.util.Collection;
import java.util.Date;

@Entity
@Table(name = "BUSINESSUNITS")
@XmlRootElement
public class BusinessUnits {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID", nullable = false)
	private Integer id;

	@NotNull
	@Column(name = "ACTIVE", nullable = false)
	private short active;

	@NotNull
	@Size(min = 1, max = 20)
	@Column(name = "BUSINESSUNIT", nullable = false)
	private String businessunit;

	@NotNull
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATETIMESTAMP", nullable = false)
	private Date createtimestamp;

	@JsonIgnore
	@NotNull
	@Size(min = 1, max = 10)
	@Column(name = "CREATEUSERNAME", nullable = false)
	private String createusername;

	@JsonIgnore
	@NotNull
	@Size(min = 1, max = 50)
	@Column(name = "CREATEPROGRAM", nullable = false)
	private String createprogram;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPDATETIMESTAMP", insertable = false, updatable = false, nullable = false)
	private Date updatetimestamp;

	@JsonIgnore
	@NotNull
	@Size(min = 1, max = 10)
	@Column(name = "UPDATEUSERNAME", nullable = false)
	private String updateusername;

	@JsonIgnore
	@NotNull
	@Size(min = 1, max = 50)
	@Column(name = "UPDATEPROGRAM", nullable = false)
	private String updateprogram;

	@ManyToOne
	@JoinColumn(name = "CUSTOMER_ID", referencedColumnName = "ID")
	private Customers customer;

	@JsonIgnore
	@OneToMany(mappedBy = "businessunitId")
	private Collection<Outboundorderheader> outboundorderheaderCollection;

	@JsonIgnore
	@OneToMany(mappedBy = "businessunitId")
	private Collection<Tabledefaults> tabledefaultsCollection;

	public BusinessUnits() {}

	public BusinessUnits(Integer id) {
		this.id = id;
	}

	public BusinessUnits(Integer id, short active, String businessunit, String createusername, String createprogram, String updateusername, String updateprogram) {
		this.id = id;
		this.active = active;
		this.businessunit = businessunit;
		this.createusername = createusername;
		this.createprogram = createprogram;
		this.updateusername = updateusername;
		this.updateprogram = updateprogram;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public short getActive() {
		return active;
	}

	public void setActive(short active) {
		this.active = active;
	}

	public String getBusinessunit() {
		return businessunit;
	}

	public void setBusinessunit(String businessunit) {
		this.businessunit = businessunit;
	}

	public String getCreateusername() {
		return createusername;
	}

	public void setCreateusername(String createusername) {
		this.createusername = createusername;
	}

	public String getCreateprogram() {
		return createprogram;
	}

	public void setCreateprogram(String createprogram) {
		this.createprogram = createprogram;
	}

	public String getUpdateusername() {
		return updateusername;
	}

	public void setUpdateusername(String updateusername) {
		this.updateusername = updateusername;
	}

	public String getUpdateprogram() {
		return updateprogram;
	}

	public void setUpdateprogram(String updateprogram) {
		this.updateprogram = updateprogram;
	}

	@XmlTransient
	public Collection<Outboundorderheader> getOutboundorderheaderCollection() {
		return outboundorderheaderCollection;
	}

	public void setOutboundorderheaderCollection(Collection<Outboundorderheader> outboundorderheaderCollection) {
		this.outboundorderheaderCollection = outboundorderheaderCollection;
	}

	public Customers getCustomer() {
		return customer;
	}

	public void setCustomer(Customers customerId) {
		this.customer = customerId;
	}

	@Override
	public int hashCode() {
		int hash = 0;
		hash += (id != null ? id.hashCode() : 0);
		return hash;
	}

	@Override
	public boolean equals(Object object) {
		// TODO: Warning - this method won't work in the case the id fields are not set
		if (!(object instanceof BusinessUnits)) {
			return false;
		}
		BusinessUnits other = (BusinessUnits) object;
		if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return "com.kenco.oms.entity.Businessunits[ id=" + id + " ]";
	}

	public Date getCreatetimestamp() {
		return createtimestamp;
	}

	public void setCreatetimestamp(Date createtimestamp) {
		this.createtimestamp = createtimestamp;
	}

	public Date getUpdatetimestamp() {
		return updatetimestamp;
	}

	public void setUpdatetimestamp(Date updatetimestamp) {
		this.updatetimestamp = updatetimestamp;
	}

	@XmlTransient
	@JsonIgnore
	public Collection<Tabledefaults> getTabledefaultsCollection() {
		return tabledefaultsCollection;
	}

	public void setTabledefaultsCollection(Collection<Tabledefaults> tabledefaultsCollection) {
		this.tabledefaultsCollection = tabledefaultsCollection;
	}

}
