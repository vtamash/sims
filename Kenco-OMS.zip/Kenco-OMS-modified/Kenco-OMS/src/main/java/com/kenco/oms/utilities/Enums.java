package com.kenco.oms.utilities;

public class Enums {

   public enum eOMSInboundOrderStatus {
      P,
      C
   }

   public enum eOMSOrderStatus {
      P,
      C
   }

   public enum eOMSDownloadTransactionTypes {
      ORDH,
      ORDT,
      INTH,
      INTD
   }

   public enum eOMSDownloadStatuses {
      O, C
   }

   public enum eOMSDownloadOrderDetailTypes {
      D, I
   }

   public enum eOMSTableNames {
      OUTBOUNDORDERHEADER,
      INBOUNDORDERHEADER,
      OMSDOWNLOAD,
      OMSDOWNLOAD_ORDH,
      OMSDOWNLOAD_ORDT,
      OMSDOWNLOAD_INTH,
      OMSDOWNLOAD_INTD
   }

   public enum eOMSDOWNLOADColumnNames {
      WHSID,
      EXPIREDT
   }

   public enum eSystemValues {
      INBOUND_ORDERNUMBER_PREFIX,
      NEW_SKU_EMAIL_INBOUND,
      NEXT_DOCNO_DWNLOD,
      NEXT_OUTBOUND_ORDERNUMBER,
      NEXT_INBOUND_ORDERNUMBER,
      OUTBOUND_ORDERNUMBER_PREFIX
   }

   public enum eSystemValueTypes {
      STRING,
      INTEGER,
      DECIMAL,
      DATE,
      BOOLEAN
   }
}
