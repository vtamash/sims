package com.kenco.oms.entity;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Date;

@Entity
@Table(name = "INBOUNDORDERDETAIL")
@XmlRootElement
public class Inboundorderdetail {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID", nullable = false)
	private Integer id;

	@NotNull
	@Column(name = "LINE", nullable = false)
	private Short line;

	@NotNull
	@Size(min = 1, max = 30)
	@Column(name = "PRODUCTCODE", nullable = false)
	private String productcode;

	@NotNull
	@Size(min = 1, max = 30)
	@Column(name = "LOTID", nullable = false)
	private String lotid;

	@Column(name = "ORDERQUANTITY")
	private Short orderquantity;

	@NotNull
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATETIMESTAMP", nullable = false)
	private Date createtimestamp;

	@NotNull
	@Size(min = 1, max = 10)
	@Column(name = "CREATEUSERNAME", nullable = false)
	private String createusername;

	@NotNull
	@Size(min = 1, max = 50)
	@Column(name = "CREATEPROGRAM", nullable = false)
	private String createprogram;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPDATETIMESTAMP", insertable = false, updatable = false, nullable = false)
	private Date updatetimestamp;

	@NotNull
	@Size(min = 1, max = 10)
	@Column(name = "UPDATEUSERNAME", nullable = false)
	private String updateusername;

	@NotNull
	@Size(min = 1, max = 50)
	@Column(name = "UPDATEPROGRAM", nullable = false)
	private String updateprogram;

	@ManyToOne
	@JoinColumn(name = "INBOUNDORDERHEADER_ID", referencedColumnName = "ID")
	private Inboundorderheader inboundorderheaderId;

	public Inboundorderdetail() {
	}

	public Inboundorderdetail(Integer id) {
		this.id = id;
	}

	public Inboundorderdetail(Integer id, Short line, String productcode, String lotid, Date createtimestamp, String createusername, String createprogram, Date updatetimestamp, String updateusername, String updateprogram) {
		this.id = id;
		this.line = line;
		this.productcode = productcode;
		this.lotid = lotid;
		this.createtimestamp = createtimestamp;
		this.createusername = createusername;
		this.createprogram = createprogram;
		this.updatetimestamp = updatetimestamp;
		this.updateusername = updateusername;
		this.updateprogram = updateprogram;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Short getLine() {
		return line;
	}

	public void setLine(Short line) {
		this.line = line;
	}

	public String getProductcode() {
		return productcode;
	}

	public void setProductcode(String productcode) {
		this.productcode = productcode;
	}

	public String getLotid() {
		return lotid;
	}

	public void setLotid(String lotid) {
		this.lotid = lotid;
	}

	public Short getOrderquantity() {
		return orderquantity;
	}

	public void setOrderquantity(Short orderquantity) {
		this.orderquantity = orderquantity;
	}

	public Date getCreatetimestamp() {
		return createtimestamp;
	}

	public void setCreatetimestamp(Date createtimestamp) {
		this.createtimestamp = createtimestamp;
	}

	public String getCreateusername() {
		return createusername;
	}

	public void setCreateusername(String createusername) {
		this.createusername = createusername;
	}

	public String getCreateprogram() {
		return createprogram;
	}

	public void setCreateprogram(String createprogram) {
		this.createprogram = createprogram;
	}

	public Date getUpdatetimestamp() {
		return updatetimestamp;
	}

	public void setUpdatetimestamp(Date updatetimestamp) {
		this.updatetimestamp = updatetimestamp;
	}

	public String getUpdateusername() {
		return updateusername;
	}

	public void setUpdateusername(String updateusername) {
		this.updateusername = updateusername;
	}

	public String getUpdateprogram() {
		return updateprogram;
	}

	public void setUpdateprogram(String updateprogram) {
		this.updateprogram = updateprogram;
	}

	public Inboundorderheader getInboundorderheaderId() {
		return inboundorderheaderId;
	}

	public void setInboundorderheaderId(Inboundorderheader inboundorderheaderId) {
		this.inboundorderheaderId = inboundorderheaderId;
	}

	@Override
	public int hashCode() {
		int hash = 0;
		hash += (id != null ? id.hashCode() : 0);
		return hash;
	}

	@Override
	public boolean equals(Object object) {
		// TODO: Warning - this method won't work in the case the id fields are not set
		if (!(object instanceof Inboundorderdetail)) {
			return false;
		}
		Inboundorderdetail other = (Inboundorderdetail) object;
		if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return "com.kenco.oms.entity.Inboundorderdetail[ id=" + id + " ]";
	}
}
