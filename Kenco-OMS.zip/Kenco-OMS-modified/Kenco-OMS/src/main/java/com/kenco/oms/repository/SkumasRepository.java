package com.kenco.oms.repository;

import com.kenco.oms.entity.Customers;
import com.kenco.oms.entity.Skudepartments;
import com.kenco.oms.entity.Skumas;
import com.kenco.oms.service.impl.GenericSkuDepartmentsService;

import java.util.ArrayList;

import org.apache.log4j.Logger;

import javax.persistence.EntityManager;

import java.util.List;

import javax.persistence.Query;
import javax.persistence.TypedQuery;

/**
 * Contains logic for communicating with the provided EntityManager for the
 * Skumas entity.
 */
public final class SkumasRepository {

   private EntityManager entityManager;
   private static Logger logger = Logger.getLogger(SkumasRepository.class);

   private CustomersRepository repository;
   /**
    * Default constructor. This exists to accommodate any future Spring-backed
    * projects that may require OMS.
    */
   public SkumasRepository() {
   }

   /**
    * Convenience constructor to pass in the EntityManager. This will (mostly)
    * accommodate non-spring-backed implementations.
    *
    * @param entityManager The EntityManager to be used.
    */
   public SkumasRepository(EntityManager entityManager) {
      this.entityManager = entityManager;
      repository = new CustomersRepository(entityManager);
   }

   /**
    * Accessor for the EntityManager. This exists to accommodate any future
    * Spring-backed projects that may require OMS.
    *
    * @param entityManager The EntityManager that this Repository will use.
    */
   public void setEntityManager(EntityManager entityManager) {
      this.entityManager = entityManager;
   }

   /**
    * Accessor for the CustomerRepository. This exists to accommodate any future
    * Spring-backed projects that may require OMS.
    *
    * @param repository The CustomersRepository that this Repository will use.
    */
	public void setRepository(CustomersRepository repository) {
		this.repository = repository;
	}

   /**
    * Reads a collection of Skumas objects based on the provided SkuNumb and
    * LotID
    *
    * @param maxRecords = max number of records to retriev.
    * @param queryString = querystring to use on WHERE LIKE clause. Optional.
    *
    * @return Typed List of all associated Skumas records in the database.
    */
   public List<Skumas> list(int customerId, int maxRecords, String queryString) {
	  Customers customer = repository.readById(customerId);
	  String lib = customer.getDatalibrary();
	  if (this.entityManager.getProperties().get("tenant-id")==null || !this.entityManager.getProperties().get("tenant-id").equals(lib))
		  this.entityManager.setProperty("tenant-id",lib);

      return listByRestrictedDepartmentments(customerId, maxRecords, queryString);
//      logger.info("Reading Skumas for all SKUs");
//      String sql;
//      TypedQuery<Skumas> query;
//      if (queryString == null || queryString.trim().length() <= 0) {
//         sql = "select s from Skumas s";
//         query = entityManager.createQuery(sql, Skumas.class);
//      } else {
//         sql = "select s from Skumas s where upper(s.skunumb) like :skunumb";
//         query = entityManager.createQuery(sql, Skumas.class).setParameter("skunumb", queryString.toUpperCase() + "%");
//      }
//      query.setMaxResults(maxRecords);
//      List<Skumas> list = query.getResultList();
//      logger.info("Finished reading Skumas for all SKUs");
//      return list;
   }

   /**
    * Reads a collection of Skumas objects based on the provided SkuNumb and
    * LotID
    *
    * @param customerId = customer ID being processed
    * @param maxRecords = max number of records to retrieve
    * @param queryString = querystring to use on WHERE LIKE clause. Optional.
    *
    * @return Typed List of all associated Skumas records in the database
    * matching departments found in the skudepartments table.
    */
   private List<Skumas> listByRestrictedDepartmentments(int customerId, int maxRecords, String queryString) {
      logger.info("Starting listByRestrictedDeptartments()");

      // first get list of valid departments for the sku listing...
      List<String> departments = getDepartments(customerId);

      String sql;
      TypedQuery<Skumas> query;
      if (queryString == null || queryString.trim().length() <= 0) {
         if (departments.size() > 0) {
            sql = "select s from Skumas s where s.deptno in :departments";
            query = entityManager.createQuery(sql, Skumas.class).setParameter("departments", departments);
         } else {
            sql = "select s from Skumas s";
            query = entityManager.createQuery(sql, Skumas.class);
         }
      } else {
         if (departments.size() > 0) {
            sql = "select s from Skumas s where s.deptno in :departments and upper(s.skunumb) like :skunumb";
            query = entityManager.createQuery(sql, Skumas.class).setParameter("departments", departments).setParameter("skunumb", queryString.toUpperCase() + "%");
         } else {
            sql = "select s from Skumas s where upper(s.skunumb) like :skunumb";
            query = entityManager.createQuery(sql, Skumas.class).setParameter("skunumb", queryString.toUpperCase() + "%");
         }
      }
      query.setMaxResults(maxRecords);
      List<Skumas> list = query.getResultList();
      logger.info("Exiting listByRestrictedDeptartments()");
      return list;
   }

   /**
    * Reads a collection of Skumas objects based on the provided SkuNumb
    *
    * @param productCode The SKU wanted.
    *
    * @return Skumas object for ProductCode passed in parms.
    */
   public Skumas readSingle(int customerId, String productCode) {
      logger.info("Reading Skumas for:" + productCode);

	  Customers customer = repository.readById(customerId);
	  String lib = customer.getDatalibrary();
	  if (this.entityManager.getProperties().get("tenant-id")==null || !this.entityManager.getProperties().get("tenant-id").equals(lib))
		  this.entityManager.setProperty("tenant-id",lib);

	  String sql;
      Query qry;

      // first get list of valid departments for the sku listing...
      List<String> departments = getDepartments(customerId);

      Skumas sku;
      if (departments.size() > 0) {
         sql = "select s from Skumas s where upper(s.skunumb) = :skunumb and s.deptno in :departments";
         qry = entityManager.createQuery(sql).setParameter("skunumb", productCode.toUpperCase().trim()).setParameter("departments", departments);
      } else {
         sql = "select s from Skumas s where upper(s.skunumb) = :skunumb";
         qry = entityManager.createQuery(sql).setParameter("skunumb", productCode.toUpperCase().trim());
      }

      try {
         sku = (Skumas) qry.getSingleResult();
      } catch (Exception e) {
         sku = null;
      }

      logger.info("Finished reading Skumas for:" + productCode);
      return sku;
   }

   /**
    * Get list of departments valid for skus in the OMS
    *
    * @param customerId Customer ID for needed skus
    *
    * @return List object of valid departments
    */
   private List<String> getDepartments(int customerId) {
      List<Skudepartments> skudepts = new GenericSkuDepartmentsService(entityManager).readAll(customerId);
      List<String> departments = new ArrayList<String>();
      for (Skudepartments dept : skudepts) {
         departments.add(dept.getDepartmentnumber());
      }
      return departments;
   }
}
