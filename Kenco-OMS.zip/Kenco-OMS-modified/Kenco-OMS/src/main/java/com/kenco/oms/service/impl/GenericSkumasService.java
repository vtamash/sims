package com.kenco.oms.service.impl;

import com.kenco.oms.entity.Skumas;
import com.kenco.oms.service.SkuMasAbstractService;
import javax.persistence.EntityManager;
import java.util.List;

/**
 * Basic extension of the StatesAbstractService. This offers no additional
 * business logic other than what is absolutely enforced upon any extending
 * class. To implement custom business logic for any process, extend the
 * StatesAbstractService. However, you may use this bean if the you need nothing
 * more than <b>basic</b> CRUD functionality with no additional business logic.
 *
 * @see com.kenco.oms.service.StatesAbstractService
 */
public final class GenericSkumasService extends SkuMasAbstractService {

   public GenericSkumasService(EntityManager entityManager) {
      super(entityManager);
   }

   public List<Skumas> list(int customerId, int limit, String query, Object... args) {
      return super.list(customerId, limit, query);
   }

   public void createPreProcess(Skumas t, Object... args) {
   }

   public void readPreProcess(Object... args) {
   }

   public void readSinglePreProcess(Object... args) {
   }

   public void updatePreProcess(Object... args) {
   }

   public void deletePreProcess(Object... args) {
   }

   public Skumas createPostProcess(Skumas t, Object... args) {
      return t;
   }

   public List<Skumas> readPostProcess(List<Skumas> l, Object... args) {
      return l;
   }

   public Skumas readSinglePostProcess(Skumas t, Object... args) {
      return t;
   }

   public Skumas updatePostProcess(Skumas t, Object... args) {
      return t;
   }

   public void deletePostProcess(Skumas t, Object... args) {
   }
}
