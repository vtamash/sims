package com.kenco.oms.service.impl;

import com.kenco.oms.entity.Inboundorderheader;
import com.kenco.oms.service.InboundOrderAbstractService;
import com.kenco.oms.service.OmsDownloadAbstractService;
import javax.persistence.EntityManager;
import java.util.List;

public final class GenericInboundOrderService extends InboundOrderAbstractService {
	/**
	 * {@inheritDoc}
	 */
	public GenericInboundOrderService(EntityManager em) {
		super(em);
	}

	/**
	 * {@inheritDoc}
	 */
	public GenericInboundOrderService(EntityManager entityManager, OmsDownloadAbstractService service) {
		super(entityManager,service);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String getNextInboundOrderNumberPostProcess(String orderNumber, Object... args) {
		return orderNumber;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected Inboundorderheader createPreProcess(Inboundorderheader inboundorderheader, Object... args) {
		return inboundorderheader;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected Inboundorderheader updatePreProcess(Inboundorderheader inboundorderheader, Object... args) {
		return inboundorderheader;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected Inboundorderheader deletePreProcess(Inboundorderheader inboundorderheader, Object... args) {
		return inboundorderheader;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected Inboundorderheader createPostProcess(Inboundorderheader inboundorderheader, Object... args) {
		return inboundorderheader;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected List<Inboundorderheader> readPostProcess(List<Inboundorderheader> l, Object... args) {
		return l;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected Inboundorderheader readSinglePostProcess(Inboundorderheader inboundorderheader, Object... args) {
		return inboundorderheader;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected Inboundorderheader updatePostProcess(Inboundorderheader inboundorderheader, Object... args) {
		return inboundorderheader;
	}
}
