/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kenco.oms.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import org.eclipse.persistence.annotations.Multitenant;
import org.eclipse.persistence.annotations.TenantTableDiscriminator;
import org.eclipse.persistence.annotations.MultitenantType;
import org.eclipse.persistence.annotations.TenantTableDiscriminatorType;
import org.hibernate.annotations.Filter;
import org.hibernate.annotations.FilterDef;
import org.hibernate.annotations.Filters;
import org.hibernate.annotations.ParamDef;

@Entity
@Table(name = "SKUMAS")
@Multitenant(value=MultitenantType.TABLE_PER_TENANT)
@TenantTableDiscriminator(type=TenantTableDiscriminatorType.SCHEMA, contextProperty="tenant-id")
@FilterDef(name="tenantFilter", parameters=@ParamDef(name="tenantId", type="string"))
@Filters(@Filter(name="tenantFilter", condition="tenant_id=:tenantId"))
@XmlRootElement
@NamedQueries({@NamedQuery(name = "Skumas.findAll", query = "SELECT s FROM Skumas s"),
               @NamedQuery(name = "Skumas.findBySkunumb", query = "SELECT s FROM Skumas s WHERE s.skunumb = :skunumb"),
               @NamedQuery(name = "Skumas.findBySkutype", query = "SELECT s FROM Skumas s WHERE s.skutype = :skutype"),
               @NamedQuery(name = "Skumas.findByUnrlsflg", query = "SELECT s FROM Skumas s WHERE s.unrlsflg = :unrlsflg"),
               @NamedQuery(name = "Skumas.findByHoldcode", query = "SELECT s FROM Skumas s WHERE s.holdcode = :holdcode"),
               @NamedQuery(name = "Skumas.findByDesc20", query = "SELECT s FROM Skumas s WHERE s.desc20 = :desc20"),
               @NamedQuery(name = "Skumas.findByPltdescr", query = "SELECT s FROM Skumas s WHERE s.pltdescr = :pltdescr"),
               @NamedQuery(name = "Skumas.findByChrgcode", query = "SELECT s FROM Skumas s WHERE s.chrgcode = :chrgcode"),
               @NamedQuery(name = "Skumas.findByFrtclass", query = "SELECT s FROM Skumas s WHERE s.frtclass = :frtclass"),
               @NamedQuery(name = "Skumas.findByNmfc", query = "SELECT s FROM Skumas s WHERE s.nmfc = :nmfc"),
               @NamedQuery(name = "Skumas.findByDftzone", query = "SELECT s FROM Skumas s WHERE s.dftzone = :dftzone"),
               @NamedQuery(name = "Skumas.findByRstzone", query = "SELECT s FROM Skumas s WHERE s.rstzone = :rstzone"),
               @NamedQuery(name = "Skumas.findByAbcclass", query = "SELECT s FROM Skumas s WHERE s.abcclass = :abcclass"),
               @NamedQuery(name = "Skumas.findByPctfull", query = "SELECT s FROM Skumas s WHERE s.pctfull = :pctfull"),
               @NamedQuery(name = "Skumas.findByFpz", query = "SELECT s FROM Skumas s WHERE s.fpz = :fpz"),
               @NamedQuery(name = "Skumas.findByFwdzone", query = "SELECT s FROM Skumas s WHERE s.fwdzone = :fwdzone"),
               @NamedQuery(name = "Skumas.findByFpzqty", query = "SELECT s FROM Skumas s WHERE s.fpzqty = :fpzqty"),
               @NamedQuery(name = "Skumas.findByControl", query = "SELECT s FROM Skumas s WHERE s.control = :control"),
               @NamedQuery(name = "Skumas.findByWindow", query = "SELECT s FROM Skumas s WHERE s.window = :window"),
               @NamedQuery(name = "Skumas.findByShlflife", query = "SELECT s FROM Skumas s WHERE s.shlflife = :shlflife"),
               @NamedQuery(name = "Skumas.findByCrush", query = "SELECT s FROM Skumas s WHERE s.crush = :crush"),
               @NamedQuery(name = "Skumas.findByTie1", query = "SELECT s FROM Skumas s WHERE s.tie1 = :tie1"),
               @NamedQuery(name = "Skumas.findByTie2", query = "SELECT s FROM Skumas s WHERE s.tie2 = :tie2"),
               @NamedQuery(name = "Skumas.findByHigh", query = "SELECT s FROM Skumas s WHERE s.high = :high"),
               @NamedQuery(name = "Skumas.findByStack1", query = "SELECT s FROM Skumas s WHERE s.stack1 = :stack1"),
               @NamedQuery(name = "Skumas.findByStack2", query = "SELECT s FROM Skumas s WHERE s.stack2 = :stack2"),
               @NamedQuery(name = "Skumas.findByPyramid", query = "SELECT s FROM Skumas s WHERE s.pyramid = :pyramid"),
               @NamedQuery(name = "Skumas.findByStduom", query = "SELECT s FROM Skumas s WHERE s.stduom = :stduom"),
               @NamedQuery(name = "Skumas.findByHighuom", query = "SELECT s FROM Skumas s WHERE s.highuom = :highuom"),
               @NamedQuery(name = "Skumas.findByLowuom", query = "SELECT s FROM Skumas s WHERE s.lowuom = :lowuom"),
               @NamedQuery(name = "Skumas.findByBoluom", query = "SELECT s FROM Skumas s WHERE s.boluom = :boluom"),
               @NamedQuery(name = "Skumas.findByBolqty", query = "SELECT s FROM Skumas s WHERE s.bolqty = :bolqty"),
               @NamedQuery(name = "Skumas.findByAtchcod1", query = "SELECT s FROM Skumas s WHERE s.atchcod1 = :atchcod1"),
               @NamedQuery(name = "Skumas.findByAtchcod2", query = "SELECT s FROM Skumas s WHERE s.atchcod2 = :atchcod2"),
               @NamedQuery(name = "Skumas.findByAtchcod3", query = "SELECT s FROM Skumas s WHERE s.atchcod3 = :atchcod3"),
               @NamedQuery(name = "Skumas.findByAtchcod4", query = "SELECT s FROM Skumas s WHERE s.atchcod4 = :atchcod4"),
               @NamedQuery(name = "Skumas.findByPromobeg", query = "SELECT s FROM Skumas s WHERE s.promobeg = :promobeg"),
               @NamedQuery(name = "Skumas.findByPromoend", query = "SELECT s FROM Skumas s WHERE s.promoend = :promoend"),
               @NamedQuery(name = "Skumas.findByKit", query = "SELECT s FROM Skumas s WHERE s.kit = :kit"),
               @NamedQuery(name = "Skumas.findByVendorno", query = "SELECT s FROM Skumas s WHERE s.vendorno = :vendorno"),
               @NamedQuery(name = "Skumas.findByBusy", query = "SELECT s FROM Skumas s WHERE s.busy = :busy"),
               @NamedQuery(name = "Skumas.findByMtdhigh", query = "SELECT s FROM Skumas s WHERE s.mtdhigh = :mtdhigh"),
               @NamedQuery(name = "Skumas.findByMtdlow", query = "SELECT s FROM Skumas s WHERE s.mtdlow = :mtdlow"),
               @NamedQuery(name = "Skumas.findByMtdrecv", query = "SELECT s FROM Skumas s WHERE s.mtdrecv = :mtdrecv"),
               @NamedQuery(name = "Skumas.findByMtdship", query = "SELECT s FROM Skumas s WHERE s.mtdship = :mtdship"),
               @NamedQuery(name = "Skumas.findByMastpack", query = "SELECT s FROM Skumas s WHERE s.mastpack = :mastpack"),
               @NamedQuery(name = "Skumas.findByMpackqty", query = "SELECT s FROM Skumas s WHERE s.mpackqty = :mpackqty"),
               @NamedQuery(name = "Skumas.findByHostsku", query = "SELECT s FROM Skumas s WHERE s.hostsku = :hostsku"),
               @NamedQuery(name = "Skumas.findByUpc", query = "SELECT s FROM Skumas s WHERE s.upc = :upc"),
               @NamedQuery(name = "Skumas.findByRequnqscn", query = "SELECT s FROM Skumas s WHERE s.requnqscn = :requnqscn"),
               @NamedQuery(name = "Skumas.findByXref", query = "SELECT s FROM Skumas s WHERE s.xref = :xref"),
               @NamedQuery(name = "Skumas.findByReqsrlno", query = "SELECT s FROM Skumas s WHERE s.reqsrlno = :reqsrlno"),
               @NamedQuery(name = "Skumas.findByDeptno", query = "SELECT s FROM Skumas s WHERE s.deptno = :deptno"),
               @NamedQuery(name = "Skumas.findByParentsku", query = "SELECT s FROM Skumas s WHERE s.parentsku = :parentsku"),
               @NamedQuery(name = "Skumas.findByCritical", query = "SELECT s FROM Skumas s WHERE s.critical = :critical"),
               @NamedQuery(name = "Skumas.findByReqoutsrl", query = "SELECT s FROM Skumas s WHERE s.reqoutsrl = :reqoutsrl"),
               @NamedQuery(name = "Skumas.findByOrigin", query = "SELECT s FROM Skumas s WHERE s.origin = :origin"),
               @NamedQuery(name = "Skumas.findBySccid", query = "SELECT s FROM Skumas s WHERE s.sccid = :sccid"),
               @NamedQuery(name = "Skumas.findByTarewgt", query = "SELECT s FROM Skumas s WHERE s.tarewgt = :tarewgt"),
               @NamedQuery(name = "Skumas.findByMinqty", query = "SELECT s FROM Skumas s WHERE s.minqty = :minqty"),
               @NamedQuery(name = "Skumas.findByMaxqty", query = "SELECT s FROM Skumas s WHERE s.maxqty = :maxqty"),
               @NamedQuery(name = "Skumas.findByCcthres", query = "SELECT s FROM Skumas s WHERE s.ccthres = :ccthres"),
               @NamedQuery(name = "Skumas.findBySapnum", query = "SELECT s FROM Skumas s WHERE s.sapnum = :sapnum"),
               @NamedQuery(name = "Skumas.findByLayerpick", query = "SELECT s FROM Skumas s WHERE s.layerpick = :layerpick"),
               @NamedQuery(name = "Skumas.findByInzstamp", query = "SELECT s FROM Skumas s WHERE s.inzstamp = :inzstamp"),
               @NamedQuery(name = "Skumas.findByUpdstamp", query = "SELECT s FROM Skumas s WHERE s.updstamp = :updstamp"),
               @NamedQuery(name = "Skumas.findByProgram", query = "SELECT s FROM Skumas s WHERE s.program = :program"),
               @NamedQuery(name = "Skumas.findByUsername", query = "SELECT s FROM Skumas s WHERE s.username = :username")})
public class Skumas implements Serializable {
   private static final long serialVersionUID = 1L;

   @Id
   @Column(name = "SKUNUMB")
   private String skunumb;

   @Column(name = "SKUTYPE")
   private String skutype;

   @Column(name = "UNRLSFLG")
   private char unrlsflg;

   @Column(name = "HOLDCODE")
   private String holdcode;

   @Column(name = "CLASS")
   private String skuclass;

   @Column(name = "DESC20")
   private String desc20;

   @Column(name = "PLTDESCR")
   private String pltdescr;

   @Column(name = "CHRGCODE")
   private String chrgcode;

   @Column(name = "FRTCLASS")
   private String frtclass;

   @Column(name = "NMFC#")
   private String nmfc;

   @Column(name = "DFTZONE")
   private String dftzone;

   @Column(name = "RSTZONE")
   private char rstzone;

   @Column(name = "ABCCLASS")
   private char abcclass;

   @Column(name = "PCTFULL")
   private BigDecimal pctfull;

   @Column(name = "FPZ")
   private char fpz;

   @Column(name = "FWDZONE")
   private String fwdzone;

   @Column(name = "FPZQTY")
   private long fpzqty;

   @Column(name = "CONTROL")
   private char control;

   @Column(name = "WINDOW")
   private short window;

   @Column(name = "SHLFLIFE")
   private short shlflife;

   @Column(name = "CRUSH")
   private char crush;

   @Column(name = "TIE1")
   private short tie1;

   @Column(name = "TIE2")
   private short tie2;

   @Column(name = "HIGH")
   private short high;

   @Column(name = "STACK1")
   private short stack1;

   @Column(name = "STACK2")
   private BigDecimal stack2;

   @Column(name = "PYRAMID")
   private char pyramid;

   @Column(name = "STDUOM")
   private String stduom;

   @Column(name = "HIGHUOM")
   private String highuom;

   @Column(name = "LOWUOM")
   private String lowuom;

   @Column(name = "BOLUOM")
   private String boluom;

   @Column(name = "BOLQTY")
   private int bolqty;

   @Column(name = "ATCHCOD1")
   private String atchcod1;

   @Column(name = "ATCHCOD2")
   private String atchcod2;

   @Column(name = "ATCHCOD3")
   private String atchcod3;

   @Column(name = "ATCHCOD4")
   private String atchcod4;

   @Column(name = "PROMOBEG")
   @Temporal(TemporalType.DATE)
   private Date promobeg;

   @Column(name = "PROMOEND")
   @Temporal(TemporalType.DATE)
   private Date promoend;

   @Column(name = "KIT")
   private char kit;

   @Column(name = "VENDORNO")
   private String vendorno;

   @Column(name = "BUSY")
   private String busy;

   @Column(name = "MTDHIGH")
   private long mtdhigh;

   @Column(name = "MTDLOW")
   private long mtdlow;

   @Column(name = "MTDRECV")
   private long mtdrecv;

   @Column(name = "MTDSHIP")
   private long mtdship;

   @Column(name = "MASTPACK")
   private char mastpack;

   @Column(name = "MPACKQTY")
   private long mpackqty;

   @Column(name = "HOSTSKU")
   private String hostsku;

   @Column(name = "UPC")
   private String upc;

   @Column(name = "REQUNQSCN")
   private char requnqscn;

   @Column(name = "XREF")
   private String xref;

   @Column(name = "REQSRLNO")
   private char reqsrlno;

   @Column(name = "DEPTNO")
   private String deptno;

   @Column(name = "PARENTSKU")
   private String parentsku;

   @Column(name = "CRITICAL")
   private int critical;

   @Column(name = "REQOUTSRL")
   private char reqoutsrl;

   @Column(name = "ORIGIN")
   private String origin;

   @Column(name = "SCCID")
   private String sccid;

   @Column(name = "TAREWGT")
   private BigDecimal tarewgt;

   @Column(name = "MINQTY")
   private long minqty;

   @Column(name = "MAXQTY")
   private long maxqty;

   @Column(name = "CCTHRES")
   private long ccthres;

   @Column(name = "SAPNUM")
   private String sapnum;

   @Column(name = "LAYERPICK")
   private char layerpick;

   @Column(name = "INZSTAMP")
   private String inzstamp;

   @Column(name = "UPDSTAMP")
   private String updstamp;

   @Column(name = "PROGRAM")
   private String program;

   @Column(name = "USERNAME")
   private String username;

   @Transient
   private boolean requiresTeam;

   @ManyToOne()
   @JoinColumn(name = "DEPTNO", referencedColumnName = "DEPTNO", insertable=false, updatable=false)
   private Skudepartments skudepartmentsId;

   public Skumas() {
   }

   public String getSkunumb() {
      return skunumb;
   }

   public void setSkunumb(String skunumb) {
      this.skunumb = skunumb;
   }

   public String getSkutype() {
      return skutype;
   }

   public void setSkutype(String skutype) {
      this.skutype = skutype;
   }

   public char getUnrlsflg() {
      return unrlsflg;
   }

   public void setUnrlsflg(char unrlsflg) {
      this.unrlsflg = unrlsflg;
   }

   public String getHoldcode() {
      return holdcode;
   }

   public void setHoldcode(String holdcode) {
      this.holdcode = holdcode;
   }

   public String getDesc20() {
      return desc20;
   }

   public void setDesc20(String desc20) {
      this.desc20 = desc20;
   }

   public String getPltdescr() {
      return pltdescr;
   }

   public void setPltdescr(String pltdescr) {
      this.pltdescr = pltdescr;
   }

   public String getChrgcode() {
      return chrgcode;
   }

   public void setChrgcode(String chrgcode) {
      this.chrgcode = chrgcode;
   }

   public String getFrtclass() {
      return frtclass;
   }

   public void setFrtclass(String frtclass) {
      this.frtclass = frtclass;
   }

   public String getNmfc() {
      return nmfc;
   }

   public void setNmfc(String nmfc) {
      this.nmfc = nmfc;
   }

   public String getDftzone() {
      return dftzone;
   }

   public void setDftzone(String dftzone) {
      this.dftzone = dftzone;
   }

   public char getRstzone() {
      return rstzone;
   }

   public void setRstzone(char rstzone) {
      this.rstzone = rstzone;
   }

   public char getAbcclass() {
      return abcclass;
   }

   public void setAbcclass(char abcclass) {
      this.abcclass = abcclass;
   }

   public BigDecimal getPctfull() {
      return pctfull;
   }

   public void setPctfull(BigDecimal pctfull) {
      this.pctfull = pctfull;
   }

   public char getFpz() {
      return fpz;
   }

   public void setFpz(char fpz) {
      this.fpz = fpz;
   }

   public String getFwdzone() {
      return fwdzone;
   }

   public void setFwdzone(String fwdzone) {
      this.fwdzone = fwdzone;
   }

   public long getFpzqty() {
      return fpzqty;
   }

   public void setFpzqty(long fpzqty) {
      this.fpzqty = fpzqty;
   }

   public char getControl() {
      return control;
   }

   public void setControl(char control) {
      this.control = control;
   }

   public short getWindow() {
      return window;
   }

   public void setWindow(short window) {
      this.window = window;
   }

   public short getShlflife() {
      return shlflife;
   }

   public void setShlflife(short shlflife) {
      this.shlflife = shlflife;
   }

   public char getCrush() {
      return crush;
   }

   public void setCrush(char crush) {
      this.crush = crush;
   }

   public short getTie1() {
      return tie1;
   }

   public void setTie1(short tie1) {
      this.tie1 = tie1;
   }

   public short getTie2() {
      return tie2;
   }

   public void setTie2(short tie2) {
      this.tie2 = tie2;
   }

   public short getHigh() {
      return high;
   }

   public void setHigh(short high) {
      this.high = high;
   }

   public short getStack1() {
      return stack1;
   }

   public void setStack1(short stack1) {
      this.stack1 = stack1;
   }

   public BigDecimal getStack2() {
      return stack2;
   }

   public void setStack2(BigDecimal stack2) {
      this.stack2 = stack2;
   }

   public char getPyramid() {
      return pyramid;
   }

   public void setPyramid(char pyramid) {
      this.pyramid = pyramid;
   }

   public String getStduom() {
      return stduom;
   }

   public void setStduom(String stduom) {
      this.stduom = stduom;
   }

   public String getHighuom() {
      return highuom;
   }

   public void setHighuom(String highuom) {
      this.highuom = highuom;
   }

   public String getLowuom() {
      return lowuom;
   }

   public void setLowuom(String lowuom) {
      this.lowuom = lowuom;
   }

   public String getBoluom() {
      return boluom;
   }

   public void setBoluom(String boluom) {
      this.boluom = boluom;
   }

   public int getBolqty() {
      return bolqty;
   }

   public void setBolqty(int bolqty) {
      this.bolqty = bolqty;
   }

   public String getAtchcod1() {
      return atchcod1;
   }

   public void setAtchcod1(String atchcod1) {
      this.atchcod1 = atchcod1;
   }

   public String getAtchcod2() {
      return atchcod2;
   }

   public void setAtchcod2(String atchcod2) {
      this.atchcod2 = atchcod2;
   }

   public String getAtchcod3() {
      return atchcod3;
   }

   public void setAtchcod3(String atchcod3) {
      this.atchcod3 = atchcod3;
   }

   public String getAtchcod4() {
      return atchcod4;
   }

   public void setAtchcod4(String atchcod4) {
      this.atchcod4 = atchcod4;
   }

   public Date getPromobeg() {
      return promobeg;
   }

   public void setPromobeg(Date promobeg) {
      this.promobeg = promobeg;
   }

   public Date getPromoend() {
      return promoend;
   }

   public void setPromoend(Date promoend) {
      this.promoend = promoend;
   }

   public char getKit() {
      return kit;
   }

   public void setKit(char kit) {
      this.kit = kit;
   }

   public String getVendorno() {
      return vendorno;
   }

   public void setVendorno(String vendorno) {
      this.vendorno = vendorno;
   }

   public String getBusy() {
      return busy;
   }

   public void setBusy(String busy) {
      this.busy = busy;
   }

   public long getMtdhigh() {
      return mtdhigh;
   }

   public void setMtdhigh(long mtdhigh) {
      this.mtdhigh = mtdhigh;
   }

   public long getMtdlow() {
      return mtdlow;
   }

   public void setMtdlow(long mtdlow) {
      this.mtdlow = mtdlow;
   }

   public long getMtdrecv() {
      return mtdrecv;
   }

   public void setMtdrecv(long mtdrecv) {
      this.mtdrecv = mtdrecv;
   }

   public long getMtdship() {
      return mtdship;
   }

   public void setMtdship(long mtdship) {
      this.mtdship = mtdship;
   }

   public char getMastpack() {
      return mastpack;
   }

   public void setMastpack(char mastpack) {
      this.mastpack = mastpack;
   }

   public long getMpackqty() {
      return mpackqty;
   }

   public void setMpackqty(long mpackqty) {
      this.mpackqty = mpackqty;
   }

   public String getHostsku() {
      return hostsku;
   }

   public void setHostsku(String hostsku) {
      this.hostsku = hostsku;
   }

   public String getUpc() {
      return upc;
   }

   public void setUpc(String upc) {
      this.upc = upc;
   }

   public char getRequnqscn() {
      return requnqscn;
   }

   public void setRequnqscn(char requnqscn) {
      this.requnqscn = requnqscn;
   }

   public String getXref() {
      return xref;
   }

   public void setXref(String xref) {
      this.xref = xref;
   }

   public char getReqsrlno() {
      return reqsrlno;
   }

   public void setReqsrlno(char reqsrlno) {
      this.reqsrlno = reqsrlno;
   }

   public String getDeptno() {
      return deptno;
   }

   public void setDeptno(String deptno) {
      this.deptno = deptno;
   }

   public String getParentsku() {
      return parentsku;
   }

   public void setParentsku(String parentsku) {
      this.parentsku = parentsku;
   }

   public int getCritical() {
      return critical;
   }

   public void setCritical(int critical) {
      this.critical = critical;
   }

   public char getReqoutsrl() {
      return reqoutsrl;
   }

   public void setReqoutsrl(char reqoutsrl) {
      this.reqoutsrl = reqoutsrl;
   }

   public String getOrigin() {
      return origin;
   }

   public void setOrigin(String origin) {
      this.origin = origin;
   }

   public String getSccid() {
      return sccid;
   }

   public void setSccid(String sccid) {
      this.sccid = sccid;
   }

   public BigDecimal getTarewgt() {
      return tarewgt;
   }

   public void setTarewgt(BigDecimal tarewgt) {
      this.tarewgt = tarewgt;
   }

   public long getMinqty() {
      return minqty;
   }

   public void setMinqty(long minqty) {
      this.minqty = minqty;
   }

   public long getMaxqty() {
      return maxqty;
   }

   public void setMaxqty(long maxqty) {
      this.maxqty = maxqty;
   }

   public long getCcthres() {
      return ccthres;
   }

   public void setCcthres(long ccthres) {
      this.ccthres = ccthres;
   }

   public String getSapnum() {
      return sapnum;
   }

   public void setSapnum(String sapnum) {
      this.sapnum = sapnum;
   }

   public char getLayerpick() {
      return layerpick;
   }

   public void setLayerpick(char layerpick) {
      this.layerpick = layerpick;
   }

   public String getInzstamp() {
      return inzstamp;
   }

   public void setInzstamp(String inzstamp) {
      this.inzstamp = inzstamp;
   }

   public String getUpdstamp() {
      return updstamp;
   }

   public void setUpdstamp(String updstamp) {
      this.updstamp = updstamp;
   }

   public String getProgram() {
      return program;
   }

   public void setProgram(String program) {
      this.program = program;
   }

   public String getUsername() {
      return username;
   }

   public void setUsername(String username) {
      this.username = username;
   }

   public String getSkuclass() {
      return skuclass;
   }

   public void setSkuclass(String skuclass) {
      this.skuclass = skuclass;
   }

   public Skudepartments getSkudepartmentsId() {
      return skudepartmentsId;
   }

   public void setSkudepartmentsId(Skudepartments skudepartmentsId) {
      this.skudepartmentsId = skudepartmentsId;
   }

   public boolean isRequiresTeam() {
      return this.skudepartmentsId.isRequireteam();
   }

   public void setRequiresTeam(boolean requiresTeam) {
      // this.requiresTeam = skudepartmentsId.isRequireteam();
      // this.requiresTeam = requiresTeam;
   }
}
