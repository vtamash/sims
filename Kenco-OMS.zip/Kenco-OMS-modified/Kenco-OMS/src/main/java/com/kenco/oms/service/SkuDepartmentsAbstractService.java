package com.kenco.oms.service;

import com.kenco.oms.entity.Skudepartments;
import com.kenco.oms.repository.SkuDepartmentsRepository;

import javax.persistence.EntityManager;
import java.util.List;

/**
 * Class embodies the actual work for communicating with a
 * SkuDepartmentsRepository. To implement custom business logic for any of
 * the provided operations, simply extend this class and enter your business
 * logic into the appropriate hook.
 *
 */
public abstract class SkuDepartmentsAbstractService implements PreProcessors<Skudepartments>, PostProcessors<Skudepartments> {

   private SkuDepartmentsRepository repository;

   /**
    * Constructor.
    *
    * @param entityManager The EntityManager that this Service will need to use.
    */
   public SkuDepartmentsAbstractService(EntityManager entityManager) {
      repository = new SkuDepartmentsRepository(entityManager);
   }

   /**
    * Defines base communication between the <i>SkuDepartmentsService</i>
    * and the <i>SkuDepartmentsRepository</i> for <b>read</b>
    * operations. This method accommodates pre- and post- processing hooks such
    * that extending classes can implement custom business logic at any time
    * during processing.
    *
    * @param args Any arguments extending class requires during pre-processing.
    * @return Typed List of SkuDepartments retrieved from the <b>read</b>
    * operation.
    */
   public List<Skudepartments> readAll(int pCustomerId, Object... args) {
      // Pre-Processing hook.
      readPreProcess(args);

      // Perform the actual read from the Repository.
      List<Skudepartments> skudepts = repository.list(pCustomerId);

      // Post-Processing hook && Return.
      return readPostProcess(skudepts, args);
   }
}
