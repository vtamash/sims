/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kenco.oms.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name = "SYSTEMVALUES")
@XmlRootElement
@NamedQueries({
   @NamedQuery(name = "Systemvalues.findAll", query = "SELECT s FROM Systemvalues s"),
   @NamedQuery(name = "Systemvalues.findById", query = "SELECT s FROM Systemvalues s WHERE s.id = :id"),
   @NamedQuery(name = "Systemvalues.findByValuename", query = "SELECT s FROM Systemvalues s WHERE s.valuename = :valuename"),
   @NamedQuery(name = "Systemvalues.findByValuetype", query = "SELECT s FROM Systemvalues s WHERE s.valuetype = :valuetype"),
   @NamedQuery(name = "Systemvalues.findByStringvalue", query = "SELECT s FROM Systemvalues s WHERE s.stringvalue = :stringvalue"),
   @NamedQuery(name = "Systemvalues.findByIntegervalue", query = "SELECT s FROM Systemvalues s WHERE s.integervalue = :integervalue"),
   @NamedQuery(name = "Systemvalues.findByDecimalvalue", query = "SELECT s FROM Systemvalues s WHERE s.decimalvalue = :decimalvalue"),
   @NamedQuery(name = "Systemvalues.findByDatevalue", query = "SELECT s FROM Systemvalues s WHERE s.datevalue = :datevalue"),
   @NamedQuery(name = "Systemvalues.findByBooleanvalue", query = "SELECT s FROM Systemvalues s WHERE s.booleanvalue = :booleanvalue"),
   @NamedQuery(name = "Systemvalues.findByAutoincrement", query = "SELECT s FROM Systemvalues s WHERE s.autoincrement = :autoincrement"),
   @NamedQuery(name = "Systemvalues.findByLastupdated", query = "SELECT s FROM Systemvalues s WHERE s.lastupdated = :lastupdated")})
public class Systemvalues implements Serializable {
   private static final long serialVersionUID = 1L;
   @Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
   @Basic(optional = false)
   @Column(name = "ID")
   private Integer id;
   @Basic(optional = false)
   @NotNull
   @Size(min = 1, max = 50)
   @Column(name = "VALUENAME")
   private String valuename;
   @Basic(optional = false)
   @NotNull
   @Size(min = 1, max = 10)
   @Column(name = "VALUETYPE")
   private String valuetype;
   @Size(max = 100)
   @Column(name = "STRINGVALUE")
   private String stringvalue;
   @Column(name = "INTEGERVALUE")
   private Integer integervalue;
   // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
   @Column(name = "DECIMALVALUE")
   private BigDecimal decimalvalue;
   @Column(name = "DATEVALUE")
   @Temporal(TemporalType.DATE)
   private Date datevalue;
   @Column(name = "BOOLEANVALUE")
   private Short booleanvalue;
   @Column(name = "AUTOINCREMENT")
   private Short autoincrement;
   @Column(name = "LASTUPDATED")
   @Temporal(TemporalType.TIMESTAMP)
   private Date lastupdated;
   @JoinColumn(name = "CUSTOMER_ID", referencedColumnName = "ID")
   @ManyToOne(optional = false)
   private Customers customerId;

   public Systemvalues() {
   }

   public Systemvalues(Integer id) {
      this.id = id;
   }

   public Systemvalues(Integer id, String valuename, String valuetype, Date lastupdated) {
      this.id = id;
      this.valuename = valuename;
      this.valuetype = valuetype;
      this.lastupdated = lastupdated;
   }

   public Integer getId() {
      return id;
   }

   public void setId(Integer id) {
      this.id = id;
   }

   public String getValuename() {
      return valuename;
   }

   public void setValuename(String valuename) {
      this.valuename = valuename;
   }

   public String getValuetype() {
      return valuetype;
   }

   public void setValuetype(String valuetype) {
      this.valuetype = valuetype;
   }

   public String getStringvalue() {
      return stringvalue;
   }

   public void setStringvalue(String stringvalue) {
      this.stringvalue = stringvalue;
   }

   public Integer getIntegervalue() {
      return integervalue;
   }

   public void setIntegervalue(Integer integervalue) {
      this.integervalue = integervalue;
   }

   public BigDecimal getDecimalvalue() {
      return decimalvalue;
   }

   public void setDecimalvalue(BigDecimal decimalvalue) {
      this.decimalvalue = decimalvalue;
   }

   public Date getDatevalue() {
      return datevalue;
   }

   public void setDatevalue(Date datevalue) {
      this.datevalue = datevalue;
   }

   public Short getBooleanvalue() {
      return booleanvalue;
   }

   public void setBooleanvalue(Short booleanvalue) {
      this.booleanvalue = booleanvalue;
   }

   public Short getAutoincrement() {
      return autoincrement;
   }

   public void setAutoincrement(Short autoincrement) {
      this.autoincrement = autoincrement;
   }

   public Date getLastupdated() {
      return lastupdated;
   }

   public void setLastupdated(Date lastupdated) {
      this.lastupdated = lastupdated;
   }

   public Customers getCustomerId() {
      return customerId;
   }

   public void setCustomerId(Customers customerId) {
      this.customerId = customerId;
   }

   @Override
   public int hashCode() {
      int hash = 0;
      hash += (id != null ? id.hashCode() : 0);
      return hash;
   }

   @Override
   public boolean equals(Object object) {
      // TODO: Warning - this method won't work in the case the id fields are not set
      if (!(object instanceof Systemvalues)) {
         return false;
      }
      Systemvalues other = (Systemvalues) object;
      if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
         return false;
      }
      return true;
   }

   @Override
   public String toString() {
      return "com.kenco.oms.entity.Systemvalues[ id=" + id + " ]";
   }
   
   
   /**
    * @param pSystemValue = a SystemValue bean object.
    * @return new Systemvalue object.
    */
   public Systemvalues clone(Systemvalues pSystemValue) {
      Systemvalues systemValue = new Systemvalues();
      systemValue.setValuename(pSystemValue.getValuename());
      systemValue.setValuetype(pSystemValue.getValuetype());
      systemValue.setAutoincrement(pSystemValue.getAutoincrement());
      systemValue.setBooleanvalue(pSystemValue.getBooleanvalue());
      systemValue.setCustomerId(pSystemValue.getCustomerId());
      systemValue.setDatevalue(pSystemValue.getDatevalue());
      systemValue.setDecimalvalue(pSystemValue.getDecimalvalue());
      systemValue.setId(pSystemValue.getId());
      systemValue.setIntegervalue(pSystemValue.getIntegervalue());
      systemValue.setLastupdated(pSystemValue.getLastupdated());
      systemValue.setStringvalue(pSystemValue.getStringvalue());
      return systemValue;
   }
   
}
