package com.kenco.oms.repository;

import com.kenco.oms.entity.Customers;
import com.kenco.oms.entity.Outboundorderheader;
import com.kenco.oms.search.OutboundOrderSearchRequest;
import org.apache.log4j.Logger;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;
import javax.persistence.criteria.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Contains logic for communicating with the provided EntityManager for the Outboundorderheader entity.
 *
 */
public final class OutboundOrderHeaderRepository {
    private static Logger logger = Logger.getLogger(OutboundOrderHeaderRepository.class);

    private static final int MAX_PAGE_SIZE = 200;
    private static final int MAX_COMBO_SEARCH_SIZE = 500;

    private EntityManager em;

    /**
     * Default constructor. This exists to accommodate any future Spring-backed projects that may require OMS.
     */
    public OutboundOrderHeaderRepository() {
    }

    /**
     * Convenience constructor to pass in the EntityManager. This will (mostly) accommodate non-spring-backed implementations.
     *
     * @param entityManager The EntityManager to be used.
     */
    public OutboundOrderHeaderRepository(EntityManager entityManager) {
        this.em = entityManager;
    }

    /**
     * Accessor for the EntityManager. This exists to accommodate any future Spring-backed projects that may require OMS.
     *
     * @param entityManager The EntityManager that this Repository will use.
     */
    public void setEntityManager(EntityManager entityManager) {
        this.em = entityManager;
    }


    /**
     * Reads a single OutboundOrderHeader entity based on the provided Outbound Order number.
     *
     * @param number The Outbound Order number for which the record is being requested.
     * @return Outboundorderheader entity read
     */
    public Outboundorderheader readByNumber(String number) {
        logger.info("Reading Outboundorderheader for: Outboundorderheader Number - " + number);

        Query query = em.createQuery("select o from Outboundorderheader o where trim(upper(o.ordernumber)) = :number")
                .setParameter("number", number.trim().toUpperCase());

        logger.info("Finished reading Outboundorderheader for: Outboundorderheader Number - " + number);

        return (Outboundorderheader) query.getSingleResult();
    }

    /**
     * Partner method for our Paging Search (<i>readPage(...)</i>).  This method will determine the <b>total</b> number
     * of results that match the provided <i>SearchRequest</i>.
     *
     * @param request The <i>SearchRequest</i> submitted by the User.
     * @return The total number of results that match the provided <i>SearchRequest</i>.
     */
    public long readSearchTotal(OutboundOrderSearchRequest request) {
        CriteriaBuilder builder = em.getCriteriaBuilder();
        CriteriaQuery<Long> query = builder.createQuery(Long.class);
        Root<Outboundorderheader> orderHeader = query.from(Outboundorderheader.class);

        // Define what we are counting.
        query.select(builder.count(orderHeader));

        // Generate our predicates.
        List<Predicate> predicates = createSearchPredicates(builder, orderHeader, request);

        // Set WHERE clause.
        query.where(predicates.toArray(new Predicate[predicates.size()]));

        return em.createQuery(query)
                .getSingleResult();
    }

    /**
     * Queries the OutboundOrderHeader entity for Order Numbers that match the provided search term.  Search is
     * performed with a <b>trailing</b> wildcard <b>only</b>.
     * <p/>
     * <b>Note</b>: The maximum search result-size for a combo box is specified as: <i>MAX_COMBO_SEARCH_SIZE</i>
     *
     * @param orderNumber The Order Number to match.
     * @return Typed Collection holding each Order Number that matched the search term.
     */
    public List<Map<String, Object>> searchOrderNumbers(String orderNumber, Customers customer) {
        String jpql = "SELECT o.ordernumber " +
                "FROM Outboundorderheader o " +
                "JOIN FETCH o.customerId c " +
                "WHERE c.id = :customerId " +
                "  AND UPPER(o.ordernumber) LIKE :orderNumber";

        Query query = em.createQuery(jpql)
                .setParameter("customerId", customer.getId())
                .setParameter("orderNumber", orderNumber.toUpperCase() + "%")
                .setFirstResult(0)
                .setMaxResults(MAX_COMBO_SEARCH_SIZE);

        List results = query.getResultList();

        List<Map<String, Object>> numbers = new ArrayList<Map<String, Object>>();
        for (int i = 0; i < results.size(); i++) {
            Object curObject = results.get(i);
            if (curObject instanceof String) {
                Map<String, Object> curNumber = new HashMap<String, Object>();
                curNumber.put("id", i);
                curNumber.put("customerId", customer.getId());
                curNumber.put("number", curObject);
                numbers.add(curNumber);
            }
        }
        return numbers;
    }

    /**
     * Queries the OutboundOrderHeader entity for Creators that match the provided search term.  Search is performed
     * with a <b>trailing</b> wildcard <b>only</b>.
     * <p/>
     * <b>Note</b>: The maximum search result-size for a combo box is specified as: <i>MAX_COMBO_SEARCH_SIZE</i>
     *
     * @param name The Username to match.
     * @return Typed Collection holding each Creators that matched the search term.
     */
    public List<Map<String, Object>> searchCreators(String name, Customers customer) {
        String jpql = "SELECT DISTINCT o.createusername " +
                "FROM Outboundorderheader o " +
                "JOIN FETCH o.customerId c " +
                "WHERE c.id = :customerId " +
                "  AND UPPER(o.createusername) LIKE :name";

        Query query = em.createQuery(jpql)
                .setParameter("customerId", customer.getId())
                .setParameter("name", name.toUpperCase() + "%")
                .setFirstResult(0)
                .setMaxResults(MAX_COMBO_SEARCH_SIZE);

        List results = query.getResultList();

        List<Map<String, Object>> creators = new ArrayList<Map<String, Object>>();
        for (int i = 0; i < results.size(); i++) {
            Object curObject = results.get(i);
            if (curObject instanceof String) {
                Map<String, Object> curCreator = new HashMap<String, Object>();
                curCreator.put("id", i);
                curCreator.put("customerId", customer.getId());
                curCreator.put("name", curObject);
                creators.add(curCreator);
            }
        }
        return creators;
    }

    /**
     * Queries the OutboundOrderHeader entity for Ship-Tos that match the provided search term.  Search is performed
     * with a <b>trailing</b> wildcard <b>only</b>.
     * <p/>
     * <b>Note</b>: The maximum search result-size for a combo box is specified as: <i>MAX_COMBO_SEARCH_SIZE</i>
     *
     * @param name The Ship-To's Name to match.
     * @return Typed Collection holding each Creators that matched the search term.
     */
    public List<Map<String, Object>> searchShipTos(String name, Customers customer) {
        String jpql = "SELECT DISTINCT o.shiptoname " +
                "FROM Outboundorderheader o " +
                "JOIN FETCH o.customerId c " +
                "WHERE c.id = :customerId " +
                "  AND UPPER(o.shiptoname) LIKE :name";

        Query query = em.createQuery(jpql)
                .setParameter("customerId", customer.getId())
                .setParameter("name", name.toUpperCase() + "%")
                .setFirstResult(0)
                .setMaxResults(MAX_COMBO_SEARCH_SIZE);

        List results = query.getResultList();

        List<Map<String, Object>> shipTos = new ArrayList<Map<String, Object>>();
        for (int i = 0; i < results.size(); i++) {
            Object curObject = results.get(i);
            if (curObject instanceof String) {
                Map<String, Object> curShipTo = new HashMap<String, Object>();
                curShipTo.put("id", i);
                curShipTo.put("customerId", customer.getId());
                curShipTo.put("name", curObject);
                shipTos.add(curShipTo);
            }
        }
        return shipTos;
    }

    /**
     * Persists the given Outboundorderheader entity.
     *
     * @param outboundorderheader Outboundorderheader entity to persist.
     * @return The persisted Outboundorderheader entity.
     */
    public Outboundorderheader create(Outboundorderheader outboundorderheader) {
        EntityTransaction et = em.getTransaction();
        et.begin();

        Outboundorderheader orn = em.merge(outboundorderheader);
        try {
            et.commit();
        } catch (Exception e) {
            if (et.isActive()) et.rollback();
            throw new IllegalStateException(e);
        }

        return orn;
    }

    /**
     * Searches the OutboundOrderHeader table for a <b>page</b> of results matching the provided <i>SearchRequest</i>.
     * <p/>
     * <b>Note</b>: Since not all of the search-able fields are required, we must dynamically build our query - at least
     * the predicate portion thereof.  Therefore, this method is built using the JPA 2.x Criteria API.
     * <p/>
     * <b>Note</b>: Ordering is <b>not</b> assignable by the user.  It isn't that this functionality is impossible -
     * quite the opposite - but it is (at the time of this writing) desired.
     *
     * @param request The <i>SearchRequest</i> submitted by the User.
     * @return Typed Collection containing all OutboundOrderHeader entities that matched the <i>SearchRequest</i>.
     */
    public List<Outboundorderheader> readPage(OutboundOrderSearchRequest request) {
        CriteriaBuilder builder = em.getCriteriaBuilder();
        CriteriaQuery<Outboundorderheader> query = builder.createQuery(Outboundorderheader.class);
        Root<Outboundorderheader> orderHeader = query.from(Outboundorderheader.class);

        // Generate our predicates.
        List<Predicate> predicates = createSearchPredicates(builder, orderHeader, request);

        // Set WHERE clause.
        query.where(predicates.toArray(new Predicate[predicates.size()]));

        // Build ORDER BY clause.
        List<Order> ordersBy = new ArrayList<Order>();

        // Order By: Order Number
        ordersBy.add(builder.asc(orderHeader.<String>get("ordernumber")));

        // Set ORDER BY clause.
        query.orderBy(ordersBy);


        // Run the (Typed) Query and return.
        return em.createQuery(query)
                .setFirstResult(request.getStart())
                .setMaxResults(Math.min(MAX_PAGE_SIZE, request.getLimit()))
                .getResultList();
    }

    /**
     * Saves the given Outboundorderheader entity.
     *
     * @param outboundorderheader The (<b>detached</b>) Outboundorderheader entity to save.
     */
    public void update(Outboundorderheader outboundorderheader) {
        EntityTransaction et = em.getTransaction();
        et.begin();

        em.merge(outboundorderheader);
        try {
            et.commit();
        } catch (Exception e) {
            if (et.isActive()) et.rollback();
            throw new IllegalStateException(e);
        }
    }

    /**
     * Deletes the given Outboundorderheader entity.
     *
     * @param outboundorderheader The (<b>detached</b>) Outboundorderheader entity to delete.
     */
    public void delete(Outboundorderheader outboundorderheader) {
        EntityTransaction et = em.getTransaction();
        et.begin();

        em.remove(em.find(Outboundorderheader.class, outboundorderheader.getId()));
        try {
            et.commit();
        } catch (Exception e) {
            if (et.isActive()) et.rollback();
            throw new IllegalStateException(e);
        }
    }

    /**
     * Our (paged) searches consist of two portions: 1.) Obtain a Collection of results that match the provided search
     * criteria and 2.) Obtain a count of the <b>total</b> number of results that match the provided <i>SearchRequest</i>.
     * <p/>
     * Because of this, our Predicates must be built by two separate methods.  Therefore, that work is abstracted here,
     * and any interested method may use it.
     *
     * @param builder     The CriteriaBuilder that is being used to construct the query.
     * @param orderHeader The Root of the Criteria to be queried that is being used (FROM clause).
     * @param request     The User-Provided Search Request.
     * @return A (Typed) Collection of Predicates to be used in the query's WHERE clause.
     */
    private List<Predicate> createSearchPredicates(CriteriaBuilder builder, Root<Outboundorderheader> orderHeader, OutboundOrderSearchRequest request) {
        List<Predicate> predicates = new ArrayList<Predicate>();

        // Predicate: Customer (required)
        predicates.add(builder.equal(orderHeader.<Customers>get("customerId").<Integer>get("id"), request.getCustomer().getId()));

        // Predicate: Status (required).
		predicates.add(builder.and(builder.equal(orderHeader.<String>get("status"), request.getStatus().toString())));

        // Predicate: Order Number (optional).
        if (request.getNumber() != null && !request.getNumber().trim().isEmpty())
            predicates.add(builder.and(builder.equal(orderHeader.<String>get("ordernumber"), request.getNumber())));

        // Predicate: ShipTo (optional).
        if (request.getShipTo() != null && !request.getShipTo().trim().isEmpty())
            predicates.add(builder.and(builder.equal(orderHeader.<String>get("shiptoname"), request.getShipTo())));

        // Predicate: Creator (optional).
        if (request.getCreator() != null && !request.getCreator().trim().isEmpty())
            predicates.add(builder.and(builder.equal(orderHeader.<String>get("createusername"), request.getCreator())));

        return predicates;
    }

    /**
     * Reads a single OutboundOrderHeader entity based on the provided Outbound Order ID.
     *
     * @param id The Outbound Order ID for which the record is being requested.
     * @return Outboundorderheader entity read
     */
	public Outboundorderheader readById(int id) {
        logger.info("Reading Outboundorderheader for: Outboundorderheader ID - " + id);

        Query query = em.createQuery("select o from Outboundorderheader o where o.id = :id").setParameter("id", id);

        logger.info("Finished reading Outboundorderheader for: Outboundorderheader ID - " + id);

        return (Outboundorderheader) query.getSingleResult();
	}
}
