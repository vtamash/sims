package com.kenco.oms.repository;

import com.kenco.oms.entity.States;
import org.apache.log4j.Logger;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.util.ArrayList;
import java.util.List;

/**
 * Contains logic for communicating with the provided EntityManager for the States entity.
 *
 */
public class StatesRepository {
	private EntityManager entityManager;

	private static Logger logger = Logger.getLogger(StatesRepository.class);

	/**
	 * Default constructor.  This exists to accommodate any future Spring-backed projects that may require OMS.
	 */
	public StatesRepository() {}

	/**
	 * Convenience constructor to pass in the EntityManager.  This will (mostly) accommodate non-spring-backed implementations.
	 *
	 * @param entityManager The EntityManager to be used.
	 */
	public StatesRepository(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	/**
	 * Accessor for the EntityManager.  This exists to accommodate any future Spring-backed projects that may require OMS.
	 *
	 * @param entityManager The EntityManager that this Repository will use.
	 */
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	/**
	 * Reads all States entities.
	 *
	 * @return Typed List of States.
	 */
	public List<States> list() {
		logger.info("Reading all States.");

		Query query = entityManager.createQuery("select s from States s");

		List<States> states = new ArrayList<States>();
		for (Object curObject : query.getResultList())
			if (curObject instanceof States)
				states.add((States) curObject);

		logger.info("Finished reading all States.");
		return states;
	}

	/**
	 * Reads a single States entity based upon the provided ID (<i>Primary Key</i>).
	 *
	 * @param id The ID (<i>Primary Key</i>) of the States entity to be retrieved.
	 * @return The States entity matching the provided ID (<i>Primary Key</i>).
	 */
	public States get(int id) {
		logger.info("Reading States for: ID - " + id);

		States s = (States) entityManager.createQuery("SELECT s FROM States s WHERE s.id = :id")
				.setParameter("id",id)
				.getSingleResult();

		logger.info("Finished reading States for: ID - " + id);
		return s;
	}

	/**
	 * Reads a single States entity based upon the provided (<b>officially recognized</b>) abbreviation.
	 *
	 * @param abbr The (<b>officially recognized</b>) of the States entity to be retrieved.
	 * @return The States entity matching the provided (<b>officially recognized</b>) abbreviation.
	 */
	public States get(String abbr) {
		logger.info("Reading States for: State - " + abbr);

		States s = (States) entityManager.createQuery("SELECT s FROM States s WHERE state = :abbr")
				.setParameter("abbr",abbr)
				.getSingleResult();

		logger.info("Finished reading States for: State - " + abbr);
		return s;
	}
}
