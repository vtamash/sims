package com.kenco.oms.repository;

import com.kenco.oms.entity.Customers;
import com.kenco.oms.jdbc.model.Delimiter;
import com.kenco.oms.jdbc.model.WesOutboundOrder;
import com.kenco.oms.search.WesOutboundSearchRequest;
import com.kenco.oms.jdbc.util.WesOutboundOrderSqlHelper;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;

import javax.sql.DataSource;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class WesOutboundOrderRepository {
	private static final int MAX_PAGE_SIZE         = 200;
	private static final int MAX_COMBO_SEARCH_SIZE = 500;

	private JdbcTemplate template;

	/**
	 * Default constructor.
	 */
	public WesOutboundOrderRepository() {}

	/**
	 * Constructor.  Accepts JdbcTemplate as an argument.
	 *
	 * @param template The JdbcTemplate to use.
	 */
	public WesOutboundOrderRepository(JdbcTemplate template) {
		this.template = template;
	}

	/**
	 * Constructor.  Accepts a DataSource as an argument and creates a JdbcTemplate for use.
	 *
	 * @param dataSource The DataSource to use.
	 */
	public WesOutboundOrderRepository(DataSource dataSource) {
		this.template = new JdbcTemplate(dataSource);
	}

	/**
	 * Accessor for the JdbcTemplate.
	 *
	 * @param template The JdbcTemplate to use.
	 */
	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	/**
	 * Determines what the total search-result size is for UI Paging Functionality.
	 *
	 * @param request The Search Request object that the actual search is run with.
	 * @return The <b>total</b> number of rows in the result set - not the page-size.
	 */
	public Long getCount(final WesOutboundSearchRequest request) {
		// Get our SQL Helper.
		WesOutboundOrderSqlHelper helper = new WesOutboundOrderSqlHelper(request, MAX_PAGE_SIZE);

		// Create our PreparedStatementSetter.
		PreparedStatementSetter pss = new WesOutboundOrderPreparedStatementSetter(helper.getDelimiters());

		// Create our ResultSetExtractor.
		ResultSetExtractor<Long> rse = new ResultSetExtractor<Long>() {
			@Override
			public Long extractData(ResultSet rs) throws SQLException, DataAccessException {
				rs.next();
				return rs.getLong("rowCount");
			}
		};

		// Run the query.
		return template.query(helper.generateSqlCount(), pss, rse);
	}

	/**
	 * Queries the database for a <b>page</b> of Outbound Orders that match the provided search criteria.  All
	 * search criteria is optional, thus the SQL that is run is generated based on user input.
	 *
	 * <b>Note</b>: The <b>maximum</b> number of rows which a <b>page</b> may contain is: MAX_PAGE_SIZE
	 *
	 * <b>Note</b>: Because each customer runs their own "Database" (AS400 File) on the WES Server, we must determine which
	 * Database to query.  Therefore, caller must provide the relevant (<i>loaded</i>) Customers instance.
	 *
	 * @param request The search request.
	 * @return A typed collection containing a page of WesOutboundOrders.
	 */
	public List<WesOutboundOrder> readPage(final WesOutboundSearchRequest request) {
		WesOutboundOrderSqlHelper helper = new WesOutboundOrderSqlHelper(request, MAX_PAGE_SIZE);

		// The SQL Statement to run.
		String sql = helper.generateSqlQuery();

		// Create our PreparedStatementSetter.
		PreparedStatementSetter pss = new WesOutboundOrderPreparedStatementSetter(helper.getDelimiters());

		// Create our RowMapper.
		RowMapper<WesOutboundOrder> rm = new RowMapper<WesOutboundOrder>() {
			@Override
			public WesOutboundOrder mapRow(ResultSet rs, int rowNum) throws SQLException {
				WesOutboundOrder order = new WesOutboundOrder();
				order.setCustomerId(request.getCustomer().getId());
				order.setNumber(rs.getString("ORDERNO"));
				order.setLoad(rs.getString("LOADNO"));
				order.setShipTo(rs.getString("TNAME"));
				order.setScac(rs.getString("SCAC"));
				order.setDoor(rs.getString("DOOR"));
				order.setStatus(rs.getString("STATUS"));
				order.setType(rs.getString("ORDTYPE"));
				order.setZip(rs.getString("TZIP"));
				order.setActDate(rs.getString("ACTDDATE").equals("0001-01-01") ? null : rs.getDate("ACTDDATE"));
				order.setScdDate(rs.getString("SCDDDATE").equals("0001-01-01") ? null : rs.getDate("SCDDDATE"));
				return order;
			}
		};

		// Run the query.
		return template.query(sql, pss, rm);
	}

	/**
	 * Queries the WES Database for Order Numbers that match the provided search term.  Search is performed with a
	 * <b>trailing</b> wildcard <b>only</b>.
	 *
	 * <b>Note</b>: The maximum search result-size for a combo box is specified as: MAX_COMBO_SEARCH_SIZE
	 *
	 * <b>Note</b>: Because each customer runs their own "Database" (AS400 File) on the WES Server, we must determine which
	 * Database to query.  Therefore, caller must provide the relevant (<i>loaded</i>) Customers instance.
	 *
	 * @param number The Order Number to match.
	 * @param customer The Customer object for which we will delimit the search.
	 * @return Typed Collection holding each Order Number that matched the search term.
	 */
	public List<Map<String,Object>> searchOrderNumbers(final String number, final String prefix, final Customers customer) {
		// Validate our search term and kick out anything that is bogus.
		if (number == null || number.trim().isEmpty() || number.trim().length() < 3 || number.trim().length() > 15)
			throw new IllegalArgumentException("Invalid search term.");

		// The SQL Statement to run.
		String sql = "SELECT * " +
					 "FROM " + customer.getDatalibrary() + "/Ordhdr " +
					 "WHERE ORDERNO LIKE ? " +
                     "  AND ORDERNO LIKE ? " +
					 "FETCH FIRST " + MAX_COMBO_SEARCH_SIZE + " ROWS ONLY";

		// Create our PreparedStatementSetter.
		PreparedStatementSetter pss = new PreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
                ps.setString(1, "%" + prefix.trim().toUpperCase() + "%");
				ps.setString(2, number.trim().toUpperCase() + "%");
			}
		};

		// Create our RowMapper.
		RowMapper<Map<String,Object>> rm = new RowMapper<Map<String, Object>>() {
			@Override
			public Map<String, Object> mapRow(ResultSet rs, int rowNum) throws SQLException {
				Map<String,Object> row = new HashMap<>();
				row.put("id",         rowNum);
				row.put("customerId", customer.getId());
				row.put("number",     rs.getString("ORDERNO").trim());
				return row;
			}
		};

		// Run the query.
		return template.query(sql,pss,rm);
	}

	/**
	 * Queries the WES Database for Doors that match the provided search term.  Search is performed with a
	 * <b>trailing</b> wildcard <b>only</b>.
	 *
	 * <b>Note</b>: The maximum search result-size for a combo box is specified as: MAX_COMBO_SEARCH_SIZE
	 *
	 * <b>Note</b>: Because each customer runs their own "Database" (AS400 File) on the WES Server, we must determine which
	 * Database to query.  Therefore, caller must provide the relevant (<i>loaded</i>) Customers instance.
	 *
	 * @param door The Door to match.
	 * @param customer The Customer object for which we will delimit the search.
	 * @return Typed Collection holding each Door that matched the search term.
	 */
	public List<Map<String,Object>> searchDoors(final String door, final Customers customer) {
		// Validate our search term and kick out anything that is bogus.
		if (door == null || door.trim().isEmpty() || door.trim().length() > 3)
			throw new IllegalArgumentException("Invalid search term.");

		// The SQL Statement to run.
		String sql = "SELECT DISTINCT DOOR " +
					 "FROM " + customer.getDatalibrary() + "/Ordhdr " +
					 "WHERE DOOR LIKE ? " +
					 "FETCH FIRST " + MAX_COMBO_SEARCH_SIZE + " ROWS ONLY";

		// Create our PreparedStatementSetter.
		PreparedStatementSetter pss = new PreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setString(1,door.trim() + "%");
			}
		};

		// Create our RowMapper.
		RowMapper<Map<String,Object>> rm = new RowMapper<Map<String, Object>>() {
			@Override
			public Map<String, Object> mapRow(ResultSet rs, int rowNum) throws SQLException {
				Map<String,Object> row = new HashMap<>();
				row.put("id",         rowNum);
				row.put("customerId", customer.getId());
				row.put("door",       rs.getString("DOOR").trim());
				return row;
			}
		};

		// Run the query.
		return template.query(sql,pss,rm);
	}

	/**
	 * Queries the WES Database for SCACs that match the provided search term.  Search is performed with a
	 * <b>trailing</b> wildcard <b>only</b>.
	 *
	 * <b>Note</b>: The maximum search result-size for a combo box is specified as: MAX_COMBO_SEARCH_SIZE
	 *
	 * <b>Note</b>: Because each customer runs their own "Database" (AS400 File) on the WES Server, we must determine which
	 * Database to query.  Therefore, caller must provide the relevant (<i>loaded</i>) Customers instance.
	 *
	 * @param scac The SCAC to match.
	 * @param customer The Customer object for which we will delimit the search.
	 * @return Typed Collection holding each SCAC that matched the search term.
	 */
	public List<Map<String,Object>> searchScac(final String scac, final Customers customer) {
		// Validate our search term and kick out anything that is bogus.
		if (scac == null || scac.trim().isEmpty() || scac.trim().length() > 4)
			throw new IllegalArgumentException("Invalid search term.");

		// The SQL Statement to run.
		String sql = "SELECT DISTINCT SCAC " +
					 "FROM " + customer.getDatalibrary() + "/Ordhdr " +
					 "WHERE SCAC LIKE ? " +
					 "FETCH FIRST " + MAX_COMBO_SEARCH_SIZE + " ROWS ONLY";

		// Create our PreparedStatementSetter.
		PreparedStatementSetter pss = new PreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setString(1,scac.trim().toUpperCase() + "%");
			}
		};

		// Create our RowMapper.
		RowMapper<Map<String,Object>> rm = new RowMapper<Map<String, Object>>() {
			@Override
			public Map<String, Object> mapRow(ResultSet rs, int rowNum) throws SQLException {
				Map<String,Object> row = new HashMap<>();
				row.put("id",         rowNum);
				row.put("customerId", customer.getId());
				row.put("scac",       rs.getString("SCAC").trim());
				return row;
			}
		};

		// Run the query.
		return template.query(sql,pss,rm);
	}

	/**
	 * Queries the WES Database for Names that match the provided search term.  Search is performed with a
	 * <b>trailing</b> wildcard <b>only</b>.
	 *
	 * <b>Note</b>: The maximum search result-size for a combo box is specified as: MAX_COMBO_SEARCH_SIZE
	 *
	 * <b>Note</b>: Because each customer runs their own "Database" (AS400 File) on the WES Server, we must determine which
	 * Database to query.  Therefore, caller must provide the relevant (<i>loaded</i>) Customers instance.
	 *
	 * @param name The Name to match.
	 * @param customer The Customer object for which we will delimit the search.
	 * @return Typed Collection holding each Name that matched the search term.
	 */
	public List<Map<String,Object>> searchCustomerName(final String name, final Customers customer) {
		// Validate our search term and kick out anything that is bogus.
		if (name == null || name.trim().isEmpty() || name.trim().length() < 3 || name.trim().length() > 40)
			throw new IllegalArgumentException("Invalid search term.");

		// The SQL Statement to run.
		String sql = "SELECT DISTINCT TNAME " +
					 "FROM " + customer.getDatalibrary() + "/Ordhdr " +
					 "WHERE TNAME LIKE ? " +
					 "FETCH FIRST " + MAX_COMBO_SEARCH_SIZE + " ROWS ONLY";

		// Create our PreparedStatementSetter.
		PreparedStatementSetter pss = new PreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setString(1,name.trim().toUpperCase() + "%");
			}
		};

		// Create our RowMapper.
		RowMapper<Map<String,Object>> rm = new RowMapper<Map<String, Object>>() {
			@Override
			public Map<String, Object> mapRow(ResultSet rs, int rowNum) throws SQLException {
				Map<String,Object> row = new HashMap<>();
				row.put("id",         rowNum);
				row.put("customerId", customer.getId());
				row.put("name",       rs.getString("TNAME").trim());
				return row;
			}
		};

		// Run the query.
		return template.query(sql,pss,rm);
	}

	private class WesOutboundOrderPreparedStatementSetter implements PreparedStatementSetter {
		private final List<Delimiter> values;

		public WesOutboundOrderPreparedStatementSetter(List<Delimiter> values) {
			this.values = values;
		}

		@Override
		public void setValues(PreparedStatement ps) throws SQLException {
			for (int i = 0; i < values.size(); i++)
				ps.setString(i + 1, values.get(i).getValue());
		}
	}
}
