package com.kenco.oms.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import java.io.Serializable;
import java.util.Collection;
import java.util.Date;

@Entity
@Table(name = "OUTBOUNDORDERDETAIL")
@XmlRootElement
@JsonIgnoreProperties(ignoreUnknown = true)
@NamedQueries({
   @NamedQuery(name = "Outboundorderdetail.findAll", query = "SELECT o FROM Outboundorderdetail o"),
   @NamedQuery(name = "Outboundorderdetail.findById", query = "SELECT o FROM Outboundorderdetail o WHERE o.id = :id"),
   @NamedQuery(name = "Outboundorderdetail.findByLine", query = "SELECT o FROM Outboundorderdetail o WHERE o.line = :line"),
   @NamedQuery(name = "Outboundorderdetail.findByProductcode", query = "SELECT o FROM Outboundorderdetail o WHERE o.productcode = :productcode"),
   @NamedQuery(name = "Outboundorderdetail.findByOrderquantity", query = "SELECT o FROM Outboundorderdetail o WHERE o.orderquantity = :orderquantity"),
   @NamedQuery(name = "Outboundorderdetail.findByCreatetimestamp", query = "SELECT o FROM Outboundorderdetail o WHERE o.createtimestamp = :createtimestamp"),
   @NamedQuery(name = "Outboundorderdetail.findByCreateusername", query = "SELECT o FROM Outboundorderdetail o WHERE o.createusername = :createusername"),
   @NamedQuery(name = "Outboundorderdetail.findByCreateprogram", query = "SELECT o FROM Outboundorderdetail o WHERE o.createprogram = :createprogram"),
   @NamedQuery(name = "Outboundorderdetail.findByUpdatetimestamp", query = "SELECT o FROM Outboundorderdetail o WHERE o.updatetimestamp = :updatetimestamp"),
   @NamedQuery(name = "Outboundorderdetail.findByUpdateusername", query = "SELECT o FROM Outboundorderdetail o WHERE o.updateusername = :updateusername"),
   @NamedQuery(name = "Outboundorderdetail.findByUpdateprogram", query = "SELECT o FROM Outboundorderdetail o WHERE o.updateprogram = :updateprogram")})
public class Outboundorderdetail implements Serializable {
   private static final long serialVersionUID = 1L;
   @Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
   @Basic(optional = false)
   @Column(name = "ID")
   private Integer id;
   @Column(name = "LINE")
   private Short line;
   @Basic(optional = false)
   @NotNull
   @Size(min = 1, max = 30)
   @Column(name = "PRODUCTCODE")
   private String productcode;
   @Column(name = "ORDERQUANTITY")
   private Short orderquantity;
   @Basic(optional = false)
   @NotNull
   @Column(name = "CREATETIMESTAMP")
   @Temporal(TemporalType.TIMESTAMP)
   private Date createtimestamp;
   @Basic(optional = false)
   @NotNull
   @Size(min = 1, max = 10)
   @Column(name = "CREATEUSERNAME")
   private String createusername;
   @Basic(optional = false)
   @NotNull
   @Size(min = 1, max = 50)
   @Column(name = "CREATEPROGRAM")
   private String createprogram;
   @Column(name = "UPDATETIMESTAMP", insertable=false, updatable=false)
   @Temporal(TemporalType.TIMESTAMP)
   private Date updatetimestamp;
   @Basic(optional = false)
   @NotNull
   @Size(min = 1, max = 10)
   @Column(name = "UPDATEUSERNAME")
   private String updateusername;
   @Basic(optional = false)
   @NotNull
   @Size(min = 1, max = 50)
   @Column(name = "UPDATEPROGRAM")
   private String updateprogram;
   @JoinColumn(name = "OUTBOUNDORDERHEADER_ID", referencedColumnName = "ID")
   @ManyToOne
   private Outboundorderheader outboundorderheaderId;

   public Outboundorderdetail() {
   }

   public Outboundorderdetail(Integer id) {
      this.id = id;
   }

   public Outboundorderdetail(Integer id, String productcode, Date createtimestamp, String createusername, String createprogram, Date updatetimestamp, String updateusername, String updateprogram) {
      this.id = id;
      this.productcode = productcode;
      this.createtimestamp = createtimestamp;
      this.createusername = createusername;
      this.createprogram = createprogram;
      this.updatetimestamp = updatetimestamp;
      this.updateusername = updateusername;
      this.updateprogram = updateprogram;
   }

   public Integer getId() {
      return id;
   }

   public void setId(Integer id) {
      this.id = id;
   }

   public Short getLine() {
      return line;
   }

   public void setLine(Short line) {
      this.line = line;
   }

   public String getProductcode() {
      return productcode;
   }

   public void setProductcode(String productcode) {
      this.productcode = productcode;
   }

   public Short getOrderquantity() {
      return orderquantity;
   }

   public void setOrderquantity(Short orderquantity) {
      this.orderquantity = orderquantity;
   }

   public Date getCreatetimestamp() {
      return createtimestamp;
   }

   public void setCreatetimestamp(Date createtimestamp) {
      this.createtimestamp = createtimestamp;
   }

   public String getCreateusername() {
      return createusername;
   }

   public void setCreateusername(String createusername) {
      this.createusername = createusername;
   }

   public String getCreateprogram() {
      return createprogram;
   }

   public void setCreateprogram(String createprogram) {
      this.createprogram = createprogram;
   }

   public Date getUpdatetimestamp() {
      return updatetimestamp;
   }

   public void setUpdatetimestamp(Date updatetimestamp) {
      this.updatetimestamp = updatetimestamp;
   }

   public String getUpdateusername() {
      return updateusername;
   }

   public void setUpdateusername(String updateusername) {
      this.updateusername = updateusername;
   }

   public String getUpdateprogram() {
      return updateprogram;
   }

   public void setUpdateprogram(String updateprogram) {
      this.updateprogram = updateprogram;
   }

   public Outboundorderheader getOutboundorderheaderId() {
      return outboundorderheaderId;
   }

   public void setOutboundorderheaderId(Outboundorderheader outboundorderheaderId) {
      this.outboundorderheaderId = outboundorderheaderId;
   }

   @Override
   public int hashCode() {
      int hash = 0;
      hash += (id != null ? id.hashCode() : 0);
      return hash;
   }

   @Override
   public boolean equals(Object object) {
      // TODO: Warning - this method won't work in the case the id fields are not set
      if (!(object instanceof Outboundorderdetail)) {
         return false;
      }
      Outboundorderdetail other = (Outboundorderdetail) object;
      if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
         return false;
      }
      return true;
   }

   @Override
   public String toString() {
      return "com.kenco.oms.entity.Outboundorderdetail[ id=" + id + " ]";
   }
   
}
