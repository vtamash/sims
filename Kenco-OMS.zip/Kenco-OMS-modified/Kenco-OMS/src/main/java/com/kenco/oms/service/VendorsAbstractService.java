package com.kenco.oms.service;

import com.kenco.oms.entity.Vendors;
import com.kenco.oms.repository.VendorsRepository;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import java.util.Date;
import java.util.List;

/**
 * Class embodies the actual work for communicating with a VendorsRepository.  To implement custom business logic for
 * any of the provided operations, simply extend this class and enter your business logic into the appropriate hook.
 *
 * @see com.kenco.oms.service.impl.GenericVendorsService
 */
public abstract class VendorsAbstractService extends AbstractService<Vendors> {
	private VendorsRepository repository;

	/**
	 * Constructor.
	 *
	 * @param entityManager The EntityManager that this Service will need to use.
	 */
	public VendorsAbstractService(EntityManager entityManager) {
		repository = new VendorsRepository(entityManager);
	}

	/**
	 * Provides access to check if a Vendor Name is already taken or if it is available.
	 *
	 * @param name The String to check against the taken names.
	 * @return True if the name is taken, false if it is available.
	 */
	public boolean existsByName(String name) {
		try {
			repository.readByName(name);
			return true;
		} catch (NoResultException nre) {
			return false;
		}
	}

	/**
	 * Provides access to check if a Vendor Number is already taken or if it is available.
	 *
	 * @param number The String to check against the taken numbers.
	 * @return True if the number is taken, false if it is available.
	 */
	public boolean existsByNumber(String number) {
		try {
			repository.readByNumber(number);
			return true;
		} catch (NoResultException nre) {
			return false;
		}
	}

	/**
	 * Defines base communication between the <i>VendorsService</i> and the <i>VendorsRepository</i> for <b>create</b>
	 * operations.  This method accommodates pre- and post- processing hooks such that extending classes can implement
	 * custom business logic at any time during processing.
	 *
	 * @param vendor The Vendors object to be <b>created</b>.
	 * @param username The user performing the operation.
	 * @param args Any arguments extending class requires during pre-processing.
	 * @return The <b>persisted</b> Vendors object.
	 */
	public Vendors create(Vendors vendor, String username, Object... args) {
		// Pre-Processing hook.
		Vendors processed = createPreProcess(vendor, args);

		// Abstract business logic.
		processed.setCreatetimestamp(new Date());
		processed.setCreateusername(username);
		processed.setCreateprogram("VendorsService.create(...)");
		processed.setUpdateusername(username);
		processed.setUpdateprogram("VendorsService.create(...)");

		// Perform the actual create from the Repository.
		Vendors created = repository.create(vendor);

		// Post-Processing hook && Return.
		return createPostProcess(created, args);
	}

	/**
	 * Defines base communication between the <i>VendorsService</i> and the <i>VendorsRepository</i> for <b>read</b>
	 * operations.  This method accommodates pre- and post- processing hooks such that extending classes can implement
	 * custom business logic at any time during processing.
	 *
	 * @param customerId The Customer Id by which to delimit the read results.
	 * @param args Any arguments extending class requires during pre-processing.
	 * @return Typed List of Vendors retrieved from the <b>read</b> operation.
	 */
	public List<Vendors> read(int customerId, Object... args) {
		// Perform the actual read from the Repository.
		List<Vendors> vendors = repository.list(customerId);

		// Post-Processing hook && Return.
		return readPostProcess(vendors, args);
	}

	/**
	 * Defines base communication between the <i>VendorsService</i> and the <i>VendorsRepository</i> for <b>read</b>
	 * operations.  This method accommodates pre- and post- processing hooks such that extending classes can implement
	 * custom business logic at any time during processing.
	 *
	 * @param name The name of the Vendor to retrieve.
	 * @param args Any arguments extending class requires during pre-processing.
	 * @return Vendors entity that matches the provided Customer ID and Vendor Name.
	 */
	public Vendors readByName(String name, Object... args) {
		// Perform the actual read from the Repository.
		Vendors vendor = repository.readByName(name);

		// Post-Processing hook && Return.
		return readSinglePostProcess(vendor, args);
	}

	/**
	 * Defines base communication between the <i>VendorsService</i> and the <i>VendorsRepository</i> for <b>read</b>
	 * operations.  This method accommodates pre- and post- processing hooks such that extending classes can implement
	 * custom business logic at any time during processing.
	 *
	 * @param id The id (<i>primary key</i>) of the Vendors entity to retrieve.
	 * @param args Any arguments extending class requires during pre-processing.
	 * @return The Vendors entity for the given ID.
	 */
	public Vendors readById(int id, Object... args) {
		// Perform the actual read from the Repository.
		Vendors vendor = repository.readById(id);

		// Post-Processing hook && Return.
		return readSinglePostProcess(vendor, args);
	}

	/**
	 * Defines base communication between the <i>VendorsService</i> and the <i>VendorsRepository</i> for <b>update</b>
	 * operations.  This method accommodates pre- and post- processing hooks such that extending classes can implement
	 * custom business logic at any time during processing.
	 *
	 * @param vendor The Vendors object to be <b>updated</b>.
	 * @param username The user performing the operation.
	 * @param args Any arguments extending class requires during pre-processing.
	 * @return The <b>updated</b> Vendors object.
	 */
	public Vendors update(Vendors vendor, String username, Object... args) {
		// Pre-Processing hook.
		Vendors processed = updatePreProcess(vendor, args);

		// Abstract business logic.
		processed.setUpdateusername(username);
		processed.setUpdateprogram("VendorsService.update(...)");

		// Perform the actual update.
		Vendors updated = repository.update(processed);

		// Post-Processing hook && Return.
		return updatePostProcess(updated, args);
	}

	/**
	 * Defines base communication between the <i>VendorsService</i> and the <i>VendorsRepository</i> for <b>delete</b>
	 * operations.  This method accommodates pre- and post- processing hooks such that extending classes can implement
	 * custom business logic at any time during processing.
	 *
	 * @param vendor The Tevendorobject to be <b>deleted</b>.
	 * @param args Any arguments extending class requires during pre-processing.
	 */
	public void delete(Vendors vendor, Object... args) {
		// Pre-Processing hook.
		deletePreProcess(vendor, args);

		// Perform the actual delete from the Repository.
		repository.delete(vendor);
	}
}
