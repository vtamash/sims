package com.kenco.oms.service.impl;

import com.kenco.oms.jdbc.model.WesInboundOrder;
import com.kenco.oms.service.WesInboundOrderAbstractService;

import javax.sql.DataSource;
import java.util.List;

/**
 * Basic extension of the WesInboundOrderAbstractService.  This offers no additional business logic other than what
 * is absolutely enforced upon any extending class.  To implement custom business logic for any process, extend the
 * WesInboundOrderAbstractService.  However, you may use this bean if the you need nothing more than <b>basic</b>
 * CRUD functionality with no additional business logic.
 *
 * @see com.kenco.oms.service.WesInboundOrderAbstractService
 */
public final class GenericWesInboundOrderService extends WesInboundOrderAbstractService {
	/**
	 * {@inheritDoc}
	 */
	public GenericWesInboundOrderService(DataSource dataSource) {
		super(dataSource);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public WesInboundOrder createPostProcess(WesInboundOrder wesInboundOrder, Object... args) {
		return wesInboundOrder;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public List<WesInboundOrder> readPostProcess(List<WesInboundOrder> l, Object... args) {
		return l;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public WesInboundOrder readSinglePostProcess(WesInboundOrder wesInboundOrder, Object... args) {
		return wesInboundOrder;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public WesInboundOrder updatePostProcess(WesInboundOrder wesInboundOrder, Object... args) {
		return wesInboundOrder;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void deletePostProcess(WesInboundOrder wesInboundOrder, Object... args) {
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void createPreProcess(WesInboundOrder wesInboundOrder, Object... args) {
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void readPreProcess(Object... args) {
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void readSinglePreProcess(Object... args) {
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void updatePreProcess(Object... args) {
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void deletePreProcess(Object... args) {
	}
}
