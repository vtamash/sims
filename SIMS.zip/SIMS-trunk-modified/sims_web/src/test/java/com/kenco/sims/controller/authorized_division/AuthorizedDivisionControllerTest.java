package com.kenco.sims.controller.authorized_division;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.kenco.sims.dto.AuthorizedDivisionDTO;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.security.test.context.support.WithSecurityContextTestExecutionListener;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;
import org.springframework.test.context.support.DirtiesContextTestExecutionListener;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.test.context.transaction.TransactionalTestExecutionListener;
import org.springframework.test.context.web.ServletTestExecutionListener;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import static org.hamcrest.Matchers.hasSize;
import static org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers.springSecurity;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:test-rest-servlet.xml",
                                    "classpath:applicationContextTest.xml"})
@WebAppConfiguration
@TestExecutionListeners(listeners={ ServletTestExecutionListener.class,
                                    DependencyInjectionTestExecutionListener.class,
                                    DirtiesContextTestExecutionListener.class,
                                    TransactionalTestExecutionListener.class,
                                    WithSecurityContextTestExecutionListener.class})
@TransactionConfiguration(defaultRollback = true, transactionManager = "transactionManager")
@WithMockUser(username="stytestmed@kencogroup.com", authorities = {"STRYKER_SIMS_IT"})
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class AuthorizedDivisionControllerTest {

    @Autowired private WebApplicationContext wac;
    private MockMvc mockMvc;

    @Before public void setup() {
        mockMvc = MockMvcBuilders.webAppContextSetup(wac).apply(springSecurity()).build();
    }

    @Test
    public void read() throws Exception {
        this.mockMvc.perform(get("/user/109d4e9b-902b-4297-b58f-17eacf79f41d/division"))
                    .andDo(print())
                    .andExpect(status().isOk())
                    .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
                    .andExpect(jsonPath("$.[0].divisionId").value(21))
                    .andExpect(jsonPath("$.[0].userId").value("109d4e9b-902b-4297-b58f-17eacf79f41d"))
                    .andExpect(jsonPath("$.[0].id").value(104))
                    .andExpect(jsonPath("$.[0].username").value("VTAMASH   "))
                    .andExpect(jsonPath("$.[0].divisionName").value("CAN"))
                    .andExpect(jsonPath("$", hasSize(1)))
                    .andDo(print());

        this.mockMvc.perform(get("/user/0be465d8-2d5e-4a57-a6bb-1fc6362bb13e/division"))
                    .andDo(print())
                    .andExpect(status().isOk())
                    .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
                    .andExpect(jsonPath("$", hasSize(0)))
                    .andDo(print());
    }

    @Test
    public void write() throws Exception {
        AuthorizedDivisionDTO authorizedDivisionDTO = new AuthorizedDivisionDTO();
        authorizedDivisionDTO.setUserId("0be465d8-2d5e-4a57-a6bb-1fc6362bb13e");
        authorizedDivisionDTO.setDivisionId(21);
        ObjectMapper objectMapper = new ObjectMapper();
        ObjectWriter objectWriter = objectMapper.writer().withDefaultPrettyPrinter();
        String requestJson = objectWriter.writeValueAsString(authorizedDivisionDTO);

        this.mockMvc.perform(post("/user/691a8192-b1c9-4e49-b177-90660a999568/division")
                    .contentType(MediaType.APPLICATION_JSON).content(requestJson))
                    .andExpect(status().isOk())
                    .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
                    .andExpect(jsonPath("$.divisionId").value(21))
                    .andExpect(jsonPath("$.userId").value("691a8192-b1c9-4e49-b177-90660a999568"))
                    .andExpect(jsonPath("$.id").value(151))
                    .andExpect(jsonPath("$.username").value("SG00000004"))
                    .andExpect(jsonPath("$.divisionName").value("CAN"))
                    .andDo(print());


        AuthorizedDivisionDTO adDTO = new AuthorizedDivisionDTO();
        adDTO.setUserId("490cbe6e-7bfd-48ec-b81f-e100146c0895");
        adDTO.setDivisionId(1);
        ObjectMapper om = new ObjectMapper();
        ObjectWriter ow = om.writer().withDefaultPrettyPrinter();
        String rj = ow.writeValueAsString(adDTO);

        this.mockMvc.perform(post("/user/490cbe6e-7bfd-48ec-b81f-e100146c0895/division")
                    .contentType(MediaType.APPLICATION_JSON).content(rj))
                    .andExpect(status().isOk())
                    .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
                    .andExpect(jsonPath("$.divisionId").value(1))
                    .andExpect(jsonPath("$.userId").value("490cbe6e-7bfd-48ec-b81f-e100146c0895"))
                    .andExpect(jsonPath("$.id").value(152))
                    .andExpect(jsonPath("$.username").value("SLINDB    "))
                    .andExpect(jsonPath("$.divisionName").value("COM"))
                    .andDo(print());
    }

    @Test
    public void remove() throws Exception {
        this.mockMvc.perform(delete("/user/691a8192-b1c9-4e49-b177-90660a999568/division/150"))
                    .andExpect(status().isOk())
                    .andDo(print());
    }
}
