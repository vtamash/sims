package com.kenco.sims.controller.authorized_rdc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.kenco.sims.dto.AuthorizedRdcDTO;
import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.security.test.context.support.WithSecurityContextTestExecutionListener;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;
import org.springframework.test.context.support.DirtiesContextTestExecutionListener;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.test.context.transaction.TransactionalTestExecutionListener;
import org.springframework.test.context.web.ServletTestExecutionListener;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import static org.hamcrest.Matchers.hasSize;
import static org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers.springSecurity;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:test-rest-servlet.xml",
        "classpath:applicationContextTest.xml"})
@WebAppConfiguration
@TestExecutionListeners(listeners={ ServletTestExecutionListener.class,
        DependencyInjectionTestExecutionListener.class,
        DirtiesContextTestExecutionListener.class,
        TransactionalTestExecutionListener.class,
        WithSecurityContextTestExecutionListener.class})
@TransactionConfiguration(defaultRollback = true, transactionManager = "transactionManager")
@WithMockUser(username="stytestmed@kencogroup.com", authorities = {"STRYKER_SIMS_IT"})
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class AuthorizedRdcControllerTest {
    @Autowired
    private WebApplicationContext wac;
    private MockMvc mockMvc;

    @Before
    public void setup() {
        mockMvc = MockMvcBuilders.webAppContextSetup(wac).apply(springSecurity()).build();
    }

    @Test
    public void read() throws Exception {
        this.mockMvc.perform(get("/rdc.sjson"))
                    .andDo(print())
                    .andExpect(status().isOk())
                    .andExpect(content().contentType("application/vnd.sencha+json"))
                    .andExpect(jsonPath("$.success").value(true))
                    .andExpect(jsonPath("$.results[0].id").value(1))
                    .andExpect(jsonPath("$.results[0].rdcId").value("KZOO"))
                    .andExpect(jsonPath("$.results[0].name").value("RDC STRYKER KZOO TEST 0086"))
                    .andExpect(jsonPath("$.results[0].address").value("3550 MIDLINK DRIVE"))
                    .andExpect(jsonPath("$.results[0].city").value("KALAMAZOO"))
                    .andExpect(jsonPath("$.results[0].state").value("MI"))
                    .andExpect(jsonPath("$.results[0].zipcode").value("49002"))
                    .andExpect(jsonPath("$.results[1].id").value(2))
                    .andExpect(jsonPath("$.results[1].rdcId").value("CHA"))
                    .andExpect(jsonPath("$.results[1].name").value("RDC STRYKER CHATT TEST 0086"))
                    .andExpect(jsonPath("$.results[1].address").value("6170 ENTERPRISE PARK DRIVE"))
                    .andExpect(jsonPath("$.results[1].city").value("CHATTANOOGA"))
                    .andExpect(jsonPath("$.results[1].state").value("TN"))
                    .andExpect(jsonPath("$.results[1].zipcode").value("37416"))
                    .andExpect(jsonPath("$.results[2].id").value(3))
                    .andExpect(jsonPath("$.results[2].rdcId").value("DAL"))
                    .andExpect(jsonPath("$.results[2].name").value("RDC STRYKER DALLAS TEST 0086"))
                    .andExpect(jsonPath("$.results[2].address").value("2060 LUNA ROAD SUITE 100"))
                    .andExpect(jsonPath("$.results[2].city").value("CARROLLTON"))
                    .andExpect(jsonPath("$.results[2].state").value("TX"))
                    .andExpect(jsonPath("$.results[2].zipcode").value("75006"))
                    .andExpect(jsonPath("$.results", hasSize(3)));

        this.mockMvc.perform(get("/user/109d4e9b-902b-4297-b58f-17eacf79f41d/rdc"))
                    .andDo(print())
                    .andExpect(status().isOk())
                    .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
                    .andExpect(jsonPath("$.[0].rdcId").value(1))
                    .andExpect(jsonPath("$.[0].userId").value("109d4e9b-902b-4297-b58f-17eacf79f41d"))
                    .andExpect(jsonPath("$.[0].id").value(79))
                    .andExpect(jsonPath("$.[0].username").value("VTAMASH   "))
                    .andExpect(jsonPath("$.[0].rdcName").value("RDC STRYKER KZOO TEST 0086"))
                    .andExpect(jsonPath("$.[1].rdcId").value(2))
                    .andExpect(jsonPath("$.[1].userId").value("109d4e9b-902b-4297-b58f-17eacf79f41d"))
                    .andExpect(jsonPath("$.[1].id").value(77))
                    .andExpect(jsonPath("$.[1].username").value("VTAMASH   "))
                    .andExpect(jsonPath("$.[1].rdcName").value("RDC STRYKER CHATT TEST 0086"))
                    .andExpect(jsonPath("$.[2].rdcId").value(3))
                    .andExpect(jsonPath("$.[2].userId").value("109d4e9b-902b-4297-b58f-17eacf79f41d"))
                    .andExpect(jsonPath("$.[2].id").value(78))
                    .andExpect(jsonPath("$.[2].username").value("VTAMASH   "))
                    .andExpect(jsonPath("$.[2].rdcName").value("RDC STRYKER DALLAS TEST 0086"))
                    .andExpect(jsonPath("$", hasSize(3)))
                    .andDo(print());
    }

    @Test
    public void write() throws Exception {
        AuthorizedRdcDTO authorizedRdcDTO = new AuthorizedRdcDTO();
        authorizedRdcDTO.setUserId("0be465d8-2d5e-4a57-a6bb-1fc6362bb13e");
        authorizedRdcDTO.setRdcId(3);
        ObjectMapper objectMapper = new ObjectMapper();
        ObjectWriter objectWriter = objectMapper.writer().withDefaultPrettyPrinter();
        String requestJson = objectWriter.writeValueAsString(authorizedRdcDTO);

        this.mockMvc.perform(post("/user/0be465d8-2d5e-4a57-a6bb-1fc6362bb13e/rdc")
                .contentType(MediaType.APPLICATION_JSON).content(requestJson))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(jsonPath("$.rdcId").value(3))
                .andExpect(jsonPath("$.userId").value("0be465d8-2d5e-4a57-a6bb-1fc6362bb13e"))
                .andExpect(jsonPath("$.id").value(148))
                .andExpect(jsonPath("$.username").value("MK00000004"))
                .andExpect(jsonPath("$.rdcName").value("RDC STRYKER DALLAS TEST 0086"));
    }

    @Test
    public void wzRead() throws Exception {
        this.mockMvc.perform(get("/user/0be465d8-2d5e-4a57-a6bb-1fc6362bb13e"))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(jsonPath("$.id").value("0be465d8-2d5e-4a57-a6bb-1fc6362bb13e"))
                .andExpect(jsonPath("$.email").value("test101@test.com"))
                .andExpect(jsonPath("$.phone").value("5555555555"))
                .andExpect(jsonPath("$.firstName").value("Mike"))
                .andExpect(jsonPath("$.lastName").value("Keith"))
                .andExpect(jsonPath("$.userName").value("MK00000004"))
                .andExpect(jsonPath("$.roleId").value(1))
                .andExpect(jsonPath("$.homeRdcId").value(1))
                .andExpect(jsonPath("$.enabled").value(true))
                .andExpect(jsonPath("$.salesRepId").value(Matchers.nullValue()))
                .andDo(print());

        this.mockMvc.perform(get("/user/0be465d8-2d5e-4a57-a6bb-1fc6362bb13e/rdc"))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(jsonPath("$.[0].rdcId").value(3))
                .andExpect(jsonPath("$.[0].userId").value("0be465d8-2d5e-4a57-a6bb-1fc6362bb13e"))
                .andExpect(jsonPath("$.[0].id").value(148))
                .andExpect(jsonPath("$.[0].username").value("MK00000004"))
                .andExpect(jsonPath("$.[0].rdcName").value("RDC STRYKER DALLAS TEST 0086"))
                .andExpect(jsonPath("$", hasSize(1)))
                .andDo(print());
    }

    @Test
    public void zapDelete() throws Exception {
        this.mockMvc.perform(delete("/user/0be465d8-2d5e-4a57-a6bb-1fc6362bb13e/rdc/148"))
                .andExpect(status().isOk())
                .andDo(print());
    }
}
