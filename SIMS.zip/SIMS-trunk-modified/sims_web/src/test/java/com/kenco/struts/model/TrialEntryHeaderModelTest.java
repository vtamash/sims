package com.kenco.struts.model;

public class TrialEntryHeaderModelTest {
}
