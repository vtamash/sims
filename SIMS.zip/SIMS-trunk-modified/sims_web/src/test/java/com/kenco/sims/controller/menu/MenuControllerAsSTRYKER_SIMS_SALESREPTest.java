package com.kenco.sims.controller.menu;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.security.test.context.support.WithSecurityContextTestExecutionListener;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;
import org.springframework.test.context.support.DirtiesContextTestExecutionListener;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.test.context.transaction.TransactionalTestExecutionListener;
import org.springframework.test.context.web.ServletTestExecutionListener;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import static org.hamcrest.Matchers.hasSize;
import static org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers.springSecurity;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:test-rest-servlet.xml",
                                    "classpath:applicationContextTest.xml"})
@WebAppConfiguration
@TestExecutionListeners(listeners={ ServletTestExecutionListener.class,
                                    DependencyInjectionTestExecutionListener.class,
                                    DirtiesContextTestExecutionListener.class,
                                    TransactionalTestExecutionListener.class,
                                    WithSecurityContextTestExecutionListener.class})
@TransactionConfiguration(defaultRollback = true, transactionManager = "transactionManager")
@WithMockUser(username="stytestmed@kencogroup.com", authorities = {"STRYKER_SIMS_SALESREP"})
public class MenuControllerAsSTRYKER_SIMS_SALESREPTest {

    @Autowired private WebApplicationContext wac;
    private MockMvc mockMvc;

    @Before public void setup() {
        mockMvc = MockMvcBuilders.webAppContextSetup(wac).apply(springSecurity()).build();
    }

    @Test
    public void read() throws Exception {
        this.mockMvc.perform(get("/menu"))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(jsonPath("$.[0].name").value("Request Transfer"))
                .andExpect(jsonPath("$.[0].action").value("trialentryheader"))
                .andExpect(jsonPath("$.[1].name").value("Active Requests"))
                .andExpect(jsonPath("$.[1].action").value("trialentrysearch"))
                .andExpect(jsonPath("$.[2].name").value("Requests History"))
                .andExpect(jsonPath("$.[2].action").value("trialentryhistory"))
                .andExpect(jsonPath("$.[3].name").value("Inventory"))
                .andExpect(jsonPath("$.[3].action").value("salesrepinventory"))
                .andExpect(jsonPath("$", hasSize(4)))
                .andDo(print());
    }
}
