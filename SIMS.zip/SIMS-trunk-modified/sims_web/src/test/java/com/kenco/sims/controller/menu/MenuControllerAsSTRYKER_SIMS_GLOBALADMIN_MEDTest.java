package com.kenco.sims.controller.menu;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.security.test.context.support.WithSecurityContextTestExecutionListener;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;
import org.springframework.test.context.support.DirtiesContextTestExecutionListener;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.test.context.transaction.TransactionalTestExecutionListener;
import org.springframework.test.context.web.ServletTestExecutionListener;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import static org.hamcrest.Matchers.hasSize;
import static org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers.springSecurity;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:test-rest-servlet.xml",
                                    "classpath:applicationContextTest.xml"})
@WebAppConfiguration
@TestExecutionListeners(listeners={ ServletTestExecutionListener.class,
                                    DependencyInjectionTestExecutionListener.class,
                                    DirtiesContextTestExecutionListener.class,
                                    TransactionalTestExecutionListener.class,
                                    WithSecurityContextTestExecutionListener.class})
@TransactionConfiguration(defaultRollback = true, transactionManager = "transactionManager")
@WithMockUser(username="stytestmed@kencogroup.com", authorities = {"STRYKER_SIMS_GLOBALADMIN_MED"})
public class MenuControllerAsSTRYKER_SIMS_GLOBALADMIN_MEDTest {

    @Autowired private WebApplicationContext wac;
    private MockMvc mockMvc;

    @Before public void setup() {
        mockMvc = MockMvcBuilders.webAppContextSetup(wac).apply(springSecurity()).build();
    }

    @Test
    public void read() throws Exception {
        this.mockMvc.perform(get("/menu"))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(jsonPath("$.[0].name").value("Inquiry/Lookup"))
                .andExpect(jsonPath("$.[0].children[0].name").value("History Lookup"))
                .andExpect(jsonPath("$.[0].children[0].children[0].name").value("Transfer History"))
                .andExpect(jsonPath("$.[0].children[0].children[0].action").value("stytransferhistory.do"))
                .andExpect(jsonPath("$.[0].children[1].name").value("Inventory Lookup"))
                .andExpect(jsonPath("$.[0].children[1].children[0].name").value("Inventory Inquiry"))
                .andExpect(jsonPath("$.[0].children[1].children[0].action").value("styinventoryinquiry.do"))
                .andExpect(jsonPath("$.[0].children[1].children[1].name").value("Inventory Inquiry by Serial"))
                .andExpect(jsonPath("$.[0].children[1].children[1].action").value("styinventoryinquiryserial.do"))
                .andExpect(jsonPath("$.[0].children[1].children", hasSize(2)))
                .andExpect(jsonPath("$.[0].children[2].name").value("Order Inquiry"))
                .andExpect(jsonPath("$.[0].children[2].action").value("orderinquiryaction.do"))
                .andExpect(jsonPath("$.[0].children", hasSize(3)))
                .andExpect(jsonPath("$.[1].name").value("Stryker Global"))
                .andExpect(jsonPath("$.[1].children[0].name").value("Inquiry"))
                .andExpect(jsonPath("$.[1].children[0].children[0].name").value("Order Inquiry"))
                .andExpect(jsonPath("$.[1].children[0].children[0].action").value("omsorderinquiry.do"))
                .andExpect(jsonPath("$.[1].children[0].children[1].name").value("Inventory Inquiry"))
                .andExpect(jsonPath("$.[1].children[0].children[1].action").value("omsinventoryinquiry.do"))
                .andExpect(jsonPath("$.[1].children[0].children", hasSize(2)))
                .andExpect(jsonPath("$.[1].children[1].name").value("Maintenance"))
                .andExpect(jsonPath("$.[1].children[1].children[0].name").value("Teams Maintenance"))
                .andExpect(jsonPath("$.[1].children[1].children[0].action").value("omsteammaint.do"))
                .andExpect(jsonPath("$.[1].children[1].children[1].name").value("Vendor Maintenance"))
                .andExpect(jsonPath("$.[1].children[1].children[1].action").value("omsvendormaint.do"))
                .andExpect(jsonPath("$.[1].children[1].children[2].name").value("Ship-To Customer Maintenance"))
                .andExpect(jsonPath("$.[1].children[1].children[2].action").value("omsshiptocustomermaint.do"))
                .andExpect(jsonPath("$.[1].children[1].children[3].name").value("Delivery Location Maintenance"))
                .andExpect(jsonPath("$.[1].children[1].children[3].action").value("omsdeliverylocationmaint.do"))
                .andExpect(jsonPath("$.[1].children[1].children", hasSize(4)))
                .andExpect(jsonPath("$.[1].children[2].name").value("Transfers"))
                .andExpect(jsonPath("$.[1].children[2].children[0].name").value("Request Parts from Kenco"))
                .andExpect(jsonPath("$.[1].children[2].children[0].action").value("omsoutboundordermaint.do"))
                .andExpect(jsonPath("$.[1].children[2].children", hasSize(1)))
                .andExpect(jsonPath("$.[1].children", hasSize(3)))
                .andExpect(jsonPath("$.[2].name").value("Help"))
                .andExpect(jsonPath("$.[2].children[0].name").value("Stryker User Manual"))
                .andExpect(jsonPath("$.[2].children[0].action").value("styhelpmanual.do"))
                .andExpect(jsonPath("$.[2].children", hasSize(1)))
                .andDo(print());
    }
}
