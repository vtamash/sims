//package com.kenco.sims.oms.action;
//
//import servletunit.struts.MockStrutsTestCase;
//
//public class InboundOrderActionTest extends MockStrutsTestCase {
//
//	public InboundOrderActionTest(String testName) {
//		super(testName);
//	}
//
//	public void setUp() throws Exception {
//		super.setUp();
//		setInitParameter("validating","false");
//	}
//
//	public void testSuccessfulLogin() {
//		addRequestParameter("username","struts");
//		addRequestParameter("password","apache");
//
//		setRequestPathInfo("/LoginAction");
//		actionPerform();
//
//		verifyForward("success");
//		verifyForwardPath("/jsp/Success.jsp");
//		assertEquals("struts",getSession().getAttribute("authentication"));
//		verifyNoActionErrors();
//	}
//
//	public void testFailedLogin() {
//		addRequestParameter("username","struts");
//		addRequestParameter("password","name");
//
//		setRequestPathInfo("/LoginAction");
//		actionPerform();
//
//		verifyForward("failure");
//		verifyForwardPath("/jsp/Login.jsp");
//		verifyInputForward();
//		verifyActionErrors(new String[] {"error.password.mismatch"});
//		assertNull(getSession().getAttribute("authentication"));
//
//		addRequestParameter("username","apache");
//		addRequestParameter("password","struts");
//
//		setRequestPathInfo("/LoginAction");
//		actionPerform();
//
//		verifyForward("failure");
//		verifyForwardPath("/jsp/Login.jsp");
//		verifyInputForward();
//		assertNull(getSession().getAttribute("authentication"));
//
//		addRequestParameter("username","");
//		addRequestParameter("password","");
//
//		setRequestPathInfo("/LoginAction");
//		actionPerform();
//
//		verifyForward("failure");
//		verifyForwardPath("/jsp/Login.jsp");
//		verifyInputForward();
//	}
//
//	public static void main(String[] args) {
//		junit.textui.TestRunner.run(InboundOrderActionTest.class);
//	}
//}
