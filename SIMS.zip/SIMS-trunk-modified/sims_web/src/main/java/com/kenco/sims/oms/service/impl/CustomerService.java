package com.kenco.sims.oms.service.impl;

import com.kenco.oms.entity.Customers;
import com.kenco.oms.service.CustomersAbstractService;
import com.kenco.sims.oms.domain.CustomerStub;
import com.kenco.struts.utilities.InitServlet;

import javax.persistence.EntityManager;
import java.util.List;

/**
 * SIMS Implementation of the <i>CustomersAbstractService</i>.  Business logic relating to the <i>Customers</i>
 * entity and specific to SIMS is located here.
 *
 * @see com.kenco.sims.oms.domain.CustomerStub
 * @see com.kenco.oms.service.CustomersAbstractService
 */
public final class CustomerService extends CustomersAbstractService {
	private static final EntityManager entityManager = InitServlet.getEntityManagerFactory().createEntityManager();

	/**
	 * Constructs a <i>CustomersService</i>.
	 */
	public CustomerService() {
		super(entityManager);
	}

	/**
	 * SIMS Implementation of the <i>CustomersAbstractService</i>.  The <b>create</b> process requires one argument
	 * to be passed in for processing: A <i>CustomerStub</i> object which will be used to construct the
	 * <i>Customers</i> entity.
	 *
	 * @param customer The <i>Customers</i> entity that is being created.
	 * @param args     Array of size one (1) containing a <i>CustomerStub</i> object which is to be used to
	 *                 create the <i>Customers</i> entity.
	 * @return The processed <i>Customers</i> entity.
	 */
	@Override
	protected Customers createPreProcess(Customers customer, Object... args) {
		if (args == null || args.length != 1)
			throw new UnsupportedOperationException("The <b>create</b> method requires arguments to be passed in.");
		else if (args[0] == null || !(args[0] instanceof CustomerStub))
			throw new IllegalArgumentException("Invalid argument(s) passed to the <b>create</b> method.");

		CustomerStub stub = (CustomerStub) args[0];
		customer.setActive(stub.getActive());
		customer.setUpdateprogram("SIMS: CustomerService.create(...)");
		return customer;
	}

	/**
	 * SIMS Implementation of the <i>CustomersAbstractService</i>.  The <b>update</b> process requires one argument
	 * to be passed in for processing: A <i>CustomerStub</i> object which will be used to update the
	 * <i>Customers</i> entity.
	 *
	 * @param customer The <i>Customers</i> entity that is being updated.
	 * @param args     Array of size one (1) containing a <i>CustomerStub</i> object which is to be used to update the
	 *                 <i>Customers</i> entity.
	 * @return The processed <i>Customers</i> entity.
	 */
	@Override
	protected Customers updatePreProcess(Customers customer, Object... args) {
		if (args == null || args.length != 1)
			throw new UnsupportedOperationException("The <b>update</b> method requires arguments to be passed in.");
		else if (args[0] == null || !(args[0] instanceof CustomerStub))
			throw new IllegalArgumentException("Invalid argument(s) passed to the <b>update</b> method.");

		CustomerStub stub = (CustomerStub) args[0];
		customer.setActive(stub.getActive());
		customer.setUpdateprogram("SIMS: CustomersService.update(...)");
		return customer;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected Customers deletePreProcess(Customers customer, Object... args) {
		customer.setUpdateprogram("SIMS: CustomersService.update(...)");
		return customer;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected Customers createPostProcess(Customers customer, Object... args) {
		return customer;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected List<Customers> readPostProcess(List<Customers> customers, Object... args) {
		return customers;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected Customers readSinglePostProcess(Customers customer, Object... args) {
		return customer;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected Customers updatePostProcess(Customers customer, Object... args) {
		return customer;
	}
}
