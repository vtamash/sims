package com.kenco.sims.oms.action;

import com.kenco.oms.entity.Skumas;
import com.kenco.oms.service.impl.GenericSkumasService;
import com.kenco.struts.formbeans.WMSFormBean;
import com.kenco.struts.utilities.InitServlet;
import com.kenco.struts.utilities.PojoMapper;
import json.org.JSONArray;
import json.org.JSONObject;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class SkumasAction extends Action {

   static Logger logger = LoggerFactory.getLogger(SkumasAction.class);
   private final static String SUCCESS = "success";

   public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
      WMSFormBean wfb = (WMSFormBean) form;
      logger.info("USER: " + wfb.getUser() + " Starting execute() method");

      String action = request.getParameter("action");

      if (action == null) {
         wfb.resetJavascriptIncludes("appJrtest.js"); // Use append after this.
         logger.info("USER: " + wfb.getUser() + " Exiting execute() method");
         return mapping.findForward(SUCCESS);
      }

      PrintWriter out = response.getWriter();
      JSONObject jo = new JSONObject();
      GenericSkumasService sku = new GenericSkumasService(InitServlet.getEntityManagerFactory().createEntityManager());
      if (request.getMethod().equals("GET")) {
         if (action.equals("read")) {
            List<Skumas> list = new ArrayList<Skumas>();
            try {
               list = sku.read(wfb.getOmsDefaultCustomerId(), Integer.parseInt(wfb.getLimit()), wfb.getQuery());
               String jsonString = PojoMapper.toJson(list, true);
               JSONArray ja = new JSONArray(jsonString);
               if (!list.isEmpty()) {
                  jo.put("message", ja.length() + " records found.");
                  jo.put("results", ja);
                  jo.put("success", true);
               } else {
                  jo.put("total", 0);
                  jo.put("message", "No records found.");
                  jo.put("success", false);
               }

            } catch (Exception e) {
               jo.put("total", 0);
               jo.put("message", "Error searching for Skumas records.");
               jo.put("success", false);
            }

         } else {
            jo.put("total", 0);
            jo.put("message", "No read action detected.");
            jo.put("success", false);
         }
      } //-END- if (request.getMethod().equals("GET"))

      out.print(jo.toString());
      out.flush();
      out.close();

      logger.info("USER: " + wfb.getUser() + " Exiting execute() method");
      return null;
   }
}
