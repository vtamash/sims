package com.kenco.sims.oms.service.impl;

import com.kenco.oms.entity.Inboundorderdetail;
import com.kenco.oms.entity.Inboundorderheader;
import com.kenco.oms.entity.Vendors;
import com.kenco.oms.service.InboundOrderAbstractService;
import com.kenco.oms.service.impl.GenericBusinessUnitsService;
import com.kenco.oms.service.impl.GenericCustomersService;
import com.kenco.oms.service.impl.GenericStatesService;
import com.kenco.oms.service.impl.GenericVendorsService;
import com.kenco.oms.utilities.Enums;
import com.kenco.sims.oms.domain.InboundOrderStub;

import javax.persistence.EntityManager;
import java.util.Date;
import java.util.List;

/**
 * SIMS Implementation
 * SIMS Implementation of the <i>InboundOrderAbstractService</i>.
 *
 * @see com.kenco.oms.service.InboundOrderAbstractService
 * @see com.kenco.oms.service.OmsDownloadAbstractService
 * @see com.kenco.sims.oms.service.impl.OmsDownloadService
 */
public final class InboundOrderService extends InboundOrderAbstractService {
	private final GenericCustomersService     cService;
	private final GenericVendorsService       vService;
	private final GenericStatesService        sService;
	private final GenericBusinessUnitsService bService;

	/**
	 * Constructs an <i>InboundOrderService</i> with the provided <i>EntityManager</i> and <i>OmsDownloadService</i>.
	 * This services uses the provided <i>OmsDownloadService</i> for the triggered OmsDownload creation process.
	 *
	 * @see com.kenco.oms.service.InboundOrderAbstractService
	 * @see com.kenco.oms.service.OmsDownloadAbstractService
	 * @see com.kenco.sims.oms.service.impl.OmsDownloadService
	 */
	public InboundOrderService(EntityManager em, OmsDownloadService downloadService) {
		super(em, downloadService);

		cService = new GenericCustomersService(em);
		vService = new GenericVendorsService(em);
		sService = new GenericStatesService(em);
		bService = new GenericBusinessUnitsService(em);
	}

	/**
	 * <i>Completes</i> the given order by changing its status to "Complete."
	 *
	 * <b>Note</b>: This action will trigger an OmsDownload to be created.
	 *
	 * @see com.kenco.oms.utilities.Enums.eOMSOrderStatus
	 * @see com.kenco.sims.oms.service.impl.OmsDownloadService
	 * @see com.kenco.oms.service.InboundOrderAbstractService
	 */
	public void completeOrder(Inboundorderheader order, String username) {
		order.setStatus(Enums.eOMSOrderStatus.C.toString());
		order.setUpdateprogram("InboundOrderModel.setOrderComplete");
		update(order, username);
	}

	/**
	 * SIMS Business logic to add an OrderDetail.
	 *
	 * <b>Note</b>: This should probably be abstracted at some point.
	 */
	public Inboundorderdetail addOrderDetail(Inboundorderheader order, Inboundorderdetail detail, String username) {
		detail.setCreatetimestamp(new Date());
		detail.setCreateusername(username);
		detail.setCreateprogram("InboundOrderService.addOrderDetail");
		detail.setUpdateprogram("InboundOrderService.updateOrderDetail");
		detail.setUpdateusername(username);

		detail.setInboundorderheaderId(order);
		order.getInboundorderdetailCollection().add(detail);

		update(order, username);

		return detail;
	}

	/**
	 * SIMS Business logic to update an OrderDetail.
	 *
	 * <b>Note</b>: This should probably be abstracted at some point.
	 */
	public Inboundorderdetail updateOrderDetail(Inboundorderheader order, Inboundorderdetail detail, String username) {
		for (Inboundorderdetail curDetail : order.getInboundorderdetailCollection())
			if (curDetail.getId().equals(detail.getId())) {
				curDetail.setProductcode(detail.getProductcode());
				curDetail.setOrderquantity(detail.getOrderquantity());
				curDetail.setLotid(detail.getLotid());
				curDetail.setUpdateprogram("InboundOrderService.updateOrderDetail");
				curDetail.setUpdateusername(username);
				break;
			}

		update(order, username);

		return detail;
	}

	/**
	 * SIMS Business logic to delete an OrderDetail.
	 *
	 * <b>Note</b>: This should probably be abstracted at some point.
	 */
	public void removeOrderDetail(Inboundorderheader order, Inboundorderdetail detail, String username) {
		for (Inboundorderdetail curDetail : order.getInboundorderdetailCollection())
			if (curDetail.getId().equals(detail.getId())) {
				curDetail.setInboundorderheaderId(null);
				order.getInboundorderdetailCollection().remove(curDetail);
				break;
			}

		update(order, username);
	}

	/**
	 * SIMS Implementation: Prepends SIMS Specific prefix to the "next" order number.
	 */
	@Override
	public String getNextInboundOrderNumberPostProcess(String orderNumber, Object... args) {
		return getInboundOrderPrefix((Integer) args[0]).trim() + orderNumber;
	}

	/**
	 * SIMS Implementation: The <b>create</b> process requires and <i>InboundOrderStub</i>, which will be used to create
	 * the <i>InboundOrderHeader</i>,to be passed in as an argument.
	 *
	 * @throws IllegalArgumentException If the mandated argument is not passed in.
	 * @return The (properly configured, but not yet persisted) <i>InboundOrderHeader</i>.
	 */
	@Override
	protected Inboundorderheader createPreProcess(Inboundorderheader order, Object... args) {
		if (args == null || args.length < 1 || !(args[0] instanceof InboundOrderStub))
			throw new IllegalArgumentException("Insufficient parameters to create InboundOrderHeader!");

		InboundOrderStub stub = (InboundOrderStub) args[0];
		order.setCustomerId(cService.readById(stub.getCustomerId()));
		order.setBusinessunitId(bService.readById(stub.getBusinessUnitId()));

		order.setOrdernumber(getNextInboundOrderNumber(stub.getCustomerId()));

		order.setStatus(Enums.eOMSOrderStatus.P.toString());
		order.setScac(stub.getScac());
		order.setTrailernumber(stub.getTrailer());
		order.setReceipttype(stub.getReceiptType());
		order.setScheduledarrivaldate(stub.getScheduledShipDate());

		// Vendor
		Vendors vendor = getVendor(stub);
		order.setVendorId(vendor.getId() == null ? null : vendor);
		order.setVendoraddress1(stub.getVendorAddress1());
		order.setVendorname(vendor.getName());
		order.setVendornumber(vendor.getVendornumber());
		order.setVendoraddress1(vendor.getAddress1());
		order.setVendorcity(vendor.getCity());
		order.setVendorstate(vendor.getState());
		order.setVendorzip(vendor.getZipcode());

		return order;
	}

	/**
	 * SIMS Implementation:
	 * <b>Note</b>: Caller may pass an <i>InboundOrderStub</i> as the <b>first</b> argument in the argument array to have it used
	 * to update the <i>InboundOrderHeader</i>.
	 *
	 * <b>Note</b>: Caller may pass
	 * The <b>update</b> process is called from two (2) locations:
	 * 1.) From <i>completeOrder(...)</i>.
	 * 2.) From <i>update(...)</i>.
	 *
	 * In the case of an <i>update(...)</i> being called, in order to properly process, you <b>must</b> pass in an
	 * InboundOrderStub - which will be used to update the InboundOrderHeader - as the first argument.
	 */
	@Override
	protected Inboundorderheader updatePreProcess(Inboundorderheader order, Object... args) {
		// This should be true every time <i>service.update(...)</i> is called.
		if (args != null && args.length > 0 && args[0] instanceof InboundOrderStub) {
			InboundOrderStub stub = (InboundOrderStub) args[0];

			order.setCustomerId(cService.readById(stub.getCustomerId()));
			order.setBusinessunitId(bService.readById(stub.getBusinessUnitId()));

			order.setStatus(Enums.eOMSOrderStatus.P.toString());
			order.setScheduledarrivaldate(stub.getScheduledShipDate());
			order.setScac(stub.getScac());
			order.setTrailernumber(stub.getTrailer());
			order.setReceipttype(stub.getReceiptType());

			// Vendor
			Vendors vendor = getVendor(stub);
			order.setVendorId(vendor.getId() == null ? null : vendor);
			order.setVendoraddress1(stub.getVendorAddress1());
			order.setVendorname(vendor.getName());
			order.setVendornumber(vendor.getVendornumber());
			order.setVendoraddress1(vendor.getAddress1());
			order.setVendorcity(vendor.getCity());
			order.setVendorstate(vendor.getState());
			order.setVendorzip(vendor.getZipcode());
		}

		return order;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected Inboundorderheader deletePreProcess(Inboundorderheader inboundorderheader, Object... os) {
		return inboundorderheader;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected Inboundorderheader createPostProcess(Inboundorderheader inboundorderheader, Object... args) {
		return inboundorderheader;
	}

	/**
	 * {@inheritDoc}
	 */
   @Override
   protected List<Inboundorderheader> readPostProcess(List<Inboundorderheader> list, Object... args) {
      return list;
   }

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected Inboundorderheader readSinglePostProcess(Inboundorderheader inboundorderheader, Object... args) {
		return inboundorderheader;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected Inboundorderheader updatePostProcess(Inboundorderheader order, Object... args) {
		return order;
	}

	/**
	 * Apparently, we allow users to set <i>Vendor</i> information for when they want to chose a <i>Vendor</i> that
	 * isn't in the <i>Vendor</i> table.  Unsure why we can't allow them to insert a record since we are inserting a
	 * <i>de facto</i> <i>Vendor</i> at this point.
	 */
	private Vendors getVendor(InboundOrderStub stub) {
		if (stub.getVendorId() == null) {
			Vendors vendor = new Vendors();
			vendor.setName(stub.getVendorName());
			vendor.setAddress1(stub.getVendorAddress1());
			vendor.setCity(stub.getVendorCity());
			vendor.setState(sService.readById(stub.getVendorStateId()));
			vendor.setZipcode(stub.getVendorZip());
			return vendor;
		}

		return vService.readById(stub.getVendorId());
	}
}
