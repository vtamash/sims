package com.kenco.sims.dto;

import com.kenco.sims.entity.AuthorizedDivision;

import javax.validation.constraints.NotNull;

/**
 * Web representation of a {@code AuthorizedDivision} entity.
 *
 * @see com.kenco.sims.entity.AuthorizedDivision
 */
public class AuthorizedDivisionDTO {
    @NotNull(message = "must have a value.")
    private Integer divisionId;

    @NotNull(message = "must have a value.")
    private String userId;

    private Integer id;
    private String username;
    private String divisionName;

    public AuthorizedDivisionDTO() {}

    public AuthorizedDivisionDTO(AuthorizedDivision authorizedDivision) {
        id           = authorizedDivision.getId();
        divisionId   = authorizedDivision.getDivision().getId();
        userId       = authorizedDivision.getUser().getId().toString();
        username     = authorizedDivision.getUser().getUsername();
        divisionName = authorizedDivision.getDivision().getName();
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getDivisionId() {
        return divisionId;
    }

    public void setDivisionId(Integer divisionId) {
        this.divisionId = divisionId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getDivisionName() {
        return divisionName;
    }

    public void setDivisionName(String divisionName) {
        this.divisionName = divisionName;
    }
}
