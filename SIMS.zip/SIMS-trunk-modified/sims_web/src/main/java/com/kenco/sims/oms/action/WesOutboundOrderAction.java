package com.kenco.sims.oms.action;

import com.kenco.oms.entity.Customers;
import com.kenco.oms.jdbc.model.WesOutboundOrder;
import com.kenco.oms.search.WesOutboundSearchRequest;
import com.kenco.oms.service.impl.GenericCustomersService;
import com.kenco.oms.service.impl.GenericSystemValuesService;
import com.kenco.oms.service.impl.GenericWesOutboundOrderService;
import com.kenco.oms.utilities.Enums;
import com.kenco.sims.oms.view.JsonView;
import com.kenco.struts.formbeans.WMSFormBean;
import com.kenco.struts.utilities.InitServlet;
import com.kenco.struts.utilities.PojoMapper;
import json.org.JSONArray;
import json.org.JSONObject;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.util.Date;
import java.util.List;
import java.util.Map;

public class WesOutboundOrderAction extends Action {
    private static final Logger logger = LoggerFactory.getLogger(WesOutboundOrderAction.class);

    /**
     * Access point for and controls of the flow for each inbound (OrderHeader-releated) request.
     */
    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
        WMSFormBean wfb = (WMSFormBean) form;

        logger.info("USER: " + wfb.getUser() + " Starting execute() method");

        // Setup our Business Services.
        final GenericWesOutboundOrderService service = new GenericWesOutboundOrderService(InitServlet.getDataSource());
        final GenericCustomersService cService = new GenericCustomersService(InitServlet.getEntityManagerFactory().createEntityManager());
        final GenericSystemValuesService vService = new GenericSystemValuesService(InitServlet.getEntityManagerFactory().createEntityManager());

        // Route the request.
        JsonView view;
        try {
            String action = request.getParameter("action");

            // Render the page.
            if (action == null)
                throw new IllegalArgumentException("Invalid Action.");

                // Order Search.
            else if (request.getMethod().equals("GET") && action.equals("search"))
                view = searchOrders(request, service, cService, vService);

                // Search by Order Number.
            else if (request.getMethod().equals("GET") && action.equals("searchByNumber"))
                view = new JsonView<>(searchByOrderNumber(request, service, cService, vService));

                // Search by Door.
            else if (request.getMethod().equals("GET") && action.equals("searchByDoor"))
                view = new JsonView<>(searchByDoor(request, service, cService));

                // Search by SCAC.
            else if (request.getMethod().equals("GET") && action.equals("searchByScac"))
                view = new JsonView<>(searchByScac(request, service, cService));

                // Search by Ship-To.
            else if (request.getMethod().equals("GET") && action.equals("searchByShipTo"))
                view = new JsonView<>(searchByShipTo(request, service, cService));

                // Catch-all for sanity.
            else
                throw new IllegalArgumentException("Invalid Action.");
        } catch (Exception e) {
            // Log the error.
            logger.error("Error processing WesOutboundOrderAction request: ", e);

            // Respond to the call negatively for user-feedback.
            view = new JsonView("There was an error proccessing this request.");
        }

        PrintWriter out = response.getWriter();
        out.print(PojoMapper.toJson(view, true));
        out.flush();
        out.close();

        logger.info("USER: " + wfb.getUser() + " Exiting execute() method");
        return null;
    }

    /**
     * Performs the primary search and returns a Collection (page) of results that match the provided search criteria.
     */
    private JsonView<WesOutboundOrder> searchOrders(HttpServletRequest request, GenericWesOutboundOrderService service, GenericCustomersService cService, GenericSystemValuesService vService) throws Exception {
        WesOutboundSearchRequest search = marshallRequest(request, vService, cService.readById(Integer.parseInt(request.getParameter("customerId"))));

        return new JsonView<>(service.readPage(search), service.readSearchTotal(search));
    }

    /**
     * Performs a search of all WesOutboundOrders based on the Order Number.
     */
    private List<Map<String, Object>> searchByOrderNumber(HttpServletRequest request, GenericWesOutboundOrderService service, GenericCustomersService cService, GenericSystemValuesService vService) throws Exception {
        // Read the Customers entity.
        Customers customer = cService.readById(parseCustomerNumberFilter(request));

        // Read and return our entities.
        return service.searchByOrderNumbers(request.getParameter("orderNumber"), vService.get(customer.getId(), Enums.eSystemValues.OUTBOUND_ORDERNUMBER_PREFIX).getStringvalue(), customer);
    }

    /**
     * Performs a search of all WesOutboundOrders based on the Door.
     */
    private List<Map<String, Object>> searchByDoor(HttpServletRequest request, GenericWesOutboundOrderService service, GenericCustomersService cService) throws Exception {
        // Parse out the Customer Id.
        Integer customerId = parseCustomerNumberFilter(request);

        // Read and return our entities.
        return service.searchByDoor(request.getParameter("door"), cService.readById(customerId));
    }

    /**
     * Performs a search of all WesOutboundOrders based on the SCAC.
     */
    private List<Map<String, Object>> searchByScac(HttpServletRequest request, GenericWesOutboundOrderService service, GenericCustomersService cService) throws Exception {
        // Parse out the Customer Id.
        Integer customerId = parseCustomerNumberFilter(request);

        // Read and return our entities.
        return service.searchByScac(request.getParameter("scac"), cService.readById(customerId));
    }

    /**
     * Performs a search of all WesOutboundOrders based on the Ship-To.
     */
    private List<Map<String, Object>> searchByShipTo(HttpServletRequest request, GenericWesOutboundOrderService service, GenericCustomersService cService) throws Exception {
        // Parse out the Customer Id.
        Integer customerId = parseCustomerNumberFilter(request);

        // Read and return our entities.
        return service.searchByCustomerName(request.getParameter("shipTo"), cService.readById(customerId));
    }

    /**
     * Marshalls a SearchRequest.
     */
    private WesOutboundSearchRequest marshallRequest(HttpServletRequest request, GenericSystemValuesService vService, Customers customer) throws Exception {
        WesOutboundSearchRequest search = new WesOutboundSearchRequest();
        search.setPrefix(vService.get(customer.getId(), Enums.eSystemValues.OUTBOUND_ORDERNUMBER_PREFIX).getStringvalue());

        search.setLimit(request.getParameter("limit").trim().isEmpty() ? null : Integer.parseInt(request.getParameter("limit")));
        search.setPage(request.getParameter("page").trim().isEmpty() ? null : Short.parseShort(request.getParameter("page")));
        search.setStart(request.getParameter("start").trim().isEmpty() ? null : Short.parseShort(request.getParameter("start")));

        search.setCustomer(customer);
        search.setDoor(request.getParameter("door").trim().isEmpty() ? null : request.getParameter("door"));
        search.setLoad(request.getParameter("load").trim().isEmpty() ? null : request.getParameter("load"));
        search.setNumber(request.getParameter("orderNumber").trim().isEmpty() ? null : request.getParameter("orderNumber"));
        search.setScac(request.getParameter("scac").trim().isEmpty() ? null : request.getParameter("scac"));
        search.setShipTo(request.getParameter("shipTo").trim().isEmpty() ? null : request.getParameter("shipTo"));
        search.setStatus(request.getParameter("status").trim().isEmpty() ? null : request.getParameter("status"));
        search.setType(request.getParameter("type").trim().isEmpty() ? null : request.getParameter("type"));
        search.setZipcode(request.getParameter("zipCode").trim().isEmpty() ? null : request.getParameter("zipCode"));

        Long m1 = request.getParameter("scd").trim().isEmpty() ? null : Long.parseLong(request.getParameter("scd").trim());
        search.setScd(m1 == null ? null : new Date(m1));

        Long m2 = request.getParameter("act").trim().isEmpty() ? null : Long.parseLong(request.getParameter("act").trim());
        search.setAct(m2 == null ? null : new Date(m2));
        return search;
    }

    /**
     * Parses the "Filter" sent with the request to determine for which Customer to search.
     */
    private Integer parseCustomerNumberFilter(HttpServletRequest request) throws Exception {
        // Parse the filter.
        JSONObject filter = (JSONObject) new JSONArray(request.getParameter("filter")).get(0);

        // Sanity check our filter.
        if (!filter.has("property") || filter.get("property") == null || !((String) filter.get("property")).equalsIgnoreCase("customerId"))
            throw new IllegalArgumentException("Invalid Search Filter - Customer ID must be present.");

        if (!filter.has("value") || filter.get("value") == null || ((String) filter.get("value")).trim().isEmpty())
            throw new IllegalArgumentException("Invalid Search Filter - Customer ID must be present.");

        return Integer.parseInt((String) filter.get("value"));
    }
}
