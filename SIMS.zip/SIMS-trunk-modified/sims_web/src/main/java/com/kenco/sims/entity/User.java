package com.kenco.sims.entity;

import javax.persistence.*;
import java.util.*;

/**
 * SIMS user account entity.
 * <p/>
 * User account entities are created and maintained within the KIMS Application.  However, not all
 * user account data is required by (or even provided to) SIMS at account creation.  This entity
 * describes the entirety of a user entity as far as the SIMS application is concerned.
 * <p/>
 * Only use one.
 *
 * @see com.kenco.api.security.domain.KencoUser
 */
@Entity
//@DiscriminatorColumn(name = "ROLE")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@Table(schema = "SIMS_SYS", name = "USERS")
public class User {
    @Id
    @Column(nullable = false, length = 36)
    private String id;

    @Column(name = "USERID", nullable = false, unique = true, length = 128)
    private String username;

    @Column(name = "PHONE", length = 10)
    private String phone;

    @Column(name = "EMAIL", nullable = false, unique = true, length = 128)
    private String email;

    @Column(name = "FNAME", nullable = false, length = 64)
    private String firstName;

    @Column(name = "LNAME", nullable = false, length = 64)
    private String lastName;

    @Column(name = "ENABLED", nullable = false)
    private boolean enabled;

    @Column(name = "CREATEDBY", nullable = false, length = 128)
    private String creator;

    @Column(name = "UPDATEDBY", nullable = false, length = 128)
    private String modifier;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATED", nullable = false)
    private Date createDate = new Date();

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "UPDATED", insertable = false, updatable = false)
    private Date updateDate;

    @ManyToOne
    @JoinColumn(name = "HOMERDC_ID", referencedColumnName = "ID")
    private Rdc homeRdc;

    @ManyToOne(optional = false)
    @JoinColumn(name = "ROLE_ID", referencedColumnName = "ID", nullable = false)
    private Role role;

    @OneToMany(mappedBy = "user", fetch = FetchType.EAGER)
    private Set<AuthorizedDivision> divisions;

    @OneToMany(mappedBy = "user", fetch = FetchType.EAGER)
    private Set<AuthorizedRdc> rdcs;

    @Override
    public String toString() {
        return getId().toString();
    }

    @Override
    public boolean equals(Object obj) {
        return obj instanceof User &&
                getId().equals(((User) obj).getId());
    }

    @Override
    public int hashCode() {
        return getId().hashCode();
    }

    public UUID getId() {
        return UUID.fromString(id);
    }

    public void setId(UUID id) {
        this.id = id.toString();
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public String getModifier() {
        return modifier;
    }

    public void setModifier(String modifier) {
        this.modifier = modifier;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    protected void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public Rdc getHomeRdc() {
        return homeRdc;
    }

    public void setHomeRdc(Rdc homeRdc) {
        this.homeRdc = homeRdc;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public Set<AuthorizedDivision> getDivisions() {
        return Collections.unmodifiableSet(divisions);
    }

    protected void setDivisions(Set<AuthorizedDivision> divisions) {
        this.divisions = divisions;
    }

    public Set<AuthorizedRdc> getRdcs() {
        return Collections.unmodifiableSet(rdcs);
    }

    protected void setRdcs(Set<AuthorizedRdc> rdcs) {
        this.rdcs = rdcs;
    }
}
