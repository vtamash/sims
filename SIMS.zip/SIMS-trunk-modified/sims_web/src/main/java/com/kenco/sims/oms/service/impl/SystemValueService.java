package com.kenco.sims.oms.service.impl;

import com.kenco.oms.entity.Systemvalues;
import com.kenco.oms.service.SystemValuesAbstractService;
import com.kenco.oms.utilities.Enums;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.persistence.EntityManager;
import java.util.List;

public class SystemValueService extends SystemValuesAbstractService {
   private static Logger logger = LoggerFactory.getLogger(SystemValueService.class);

   // constructor...
   public SystemValueService(EntityManager em) {
      super(em);
   }

   @Override
   public String getStringValue(int customerId, Enums.eSystemValues systemValueName) {
      return super.getStringValue(customerId, systemValueName);
   }

   @Override
   public int getIntegerValue(int customerId, Enums.eSystemValues systemValueName) {
      return super.getIntegerValue(customerId, systemValueName);
   }

   @Override
   public boolean getBooleanValue(int customerId, Enums.eSystemValues systemValueName) {
      return super.getBooleanValue(customerId, systemValueName);
   }

   @Override
   public void createPreProcess(Systemvalues t, Object... os) {
   }

   @Override
   public void readPreProcess(Object... os) {
   }

   @Override
   public void readSinglePreProcess(Object... os) {
   }

   @Override
   public void updatePreProcess(Object... os) {
   }

   @Override
   public void deletePreProcess(Object... os) {
   }

   @Override
   public Systemvalues createPostProcess(Systemvalues t, Object... args) {
      return t;
   }

   @Override
   public List<Systemvalues> readPostProcess(List<Systemvalues> list, Object... args) {
      return list;
   }

   @Override
   public Systemvalues readSinglePostProcess(Systemvalues t, Object... args) {
      return t;
   }

   @Override
   public Systemvalues updatePostProcess(Systemvalues t, Object... args) {
      return t;
   }

   @Override
   public void deletePostProcess(Systemvalues t, Object... args) {
   }
}
