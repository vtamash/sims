package com.kenco.sims.domain.search.impl;

import com.kenco.sims.domain.search.SearchRequest;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class SalesorderheaderSearchRequest extends SearchRequest {
    private String status;
    private String salesRepID;
    private String ownerCode;
    private String email;
    private String phone;
    private String phoneExtension;
    private String rdcid;
    private String rDCName;
    private Integer rDCMasterKey;
    private String orderType;
    private Date scheduledDateFrom;
    private Date scheduledDateTo;
    private String deliveryDateReason;
    private Boolean scheduleOnDate;
    private Boolean scheduleNoLaterThanDate;
    private Boolean scheduleASAPDate;
    private Date scheduledTimeFrom;
    private Date scheduledTimeTo;
    private Date scheduledTimeEndFrom;
    private Date scheduledTimeEndTo;
    private Date pickupDateFrom;
    private Date pickupDateTo;
    private String pickupDateReason;
    private Date pickupTimeFrom;
    private Date pickupTimeTo;
    private Boolean pickupDateTBD;
    private String customerID;
    private String customerName;
    private Boolean newCustomer;
    private String address;
    private String city;
    private String state;
    private String zipCode;
    private String contact;
    private String contactPhone;
    private String contactPhoneExtension;
    private String contactEmail;
    private String specialInstructions;
    private Boolean liftGate;
    private Boolean dock;
    private Boolean tractorTrailer;
    private Date emailedFrom;
    private Date emailedTo;
    private Date createdFrom;
    private Date createdTo;
    private Date updatedFrom;
    private Date updatedTo;
    private String userName;
    private String programName;
    private String department;
    private Boolean loaner;
    private String legalNotice;
    private String legalAcknowledgement;

    private Boolean hasAttachment;
    private Integer deliveryTypeId;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getSalesRepID() {
        return salesRepID;
    }

    public void setSalesRepID(String salesRepID) {
        this.salesRepID = salesRepID;
    }

    public String getOwnerCode() {
        return ownerCode;
    }

    public void setOwnerCode(String ownerCode) {
        this.ownerCode = ownerCode;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPhoneExtension() {
        return phoneExtension;
    }

    public void setPhoneExtension(String phoneExtension) {
        this.phoneExtension = phoneExtension;
    }

    public String getRdcid() {
        return rdcid;
    }

    public void setRdcid(String rdcid) {
        this.rdcid = rdcid;
    }

    public String getrDCName() {
        return rDCName;
    }

    public void setrDCName(String rDCName) {
        this.rDCName = rDCName;
    }

    public Integer getrDCMasterKey() {
        return rDCMasterKey;
    }

    public void setrDCMasterKey(Integer rDCMasterKey) {
        this.rDCMasterKey = rDCMasterKey;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public Date getScheduledDateFrom() {
        return scheduledDateFrom;
    }

    public void setScheduledDateFrom(Date scheduledDateFrom) {
        this.scheduledDateFrom = scheduledDateFrom;
    }

    public Date getScheduledDateTo() {
        return scheduledDateTo;
    }

    public void setScheduledDateTo(Date scheduledDateTo) {
        this.scheduledDateTo = scheduledDateTo;
    }

    public String getDeliveryDateReason() {
        return deliveryDateReason;
    }

    public void setDeliveryDateReason(String deliveryDateReason) {
        this.deliveryDateReason = deliveryDateReason;
    }

    public Boolean getScheduleOnDate() {
        return scheduleOnDate;
    }

    public void setScheduleOnDate(Boolean scheduleOnDate) {
        this.scheduleOnDate = scheduleOnDate;
    }

    public Boolean getScheduleNoLaterThanDate() {
        return scheduleNoLaterThanDate;
    }

    public void setScheduleNoLaterThanDate(Boolean scheduleNoLaterThanDate) {
        this.scheduleNoLaterThanDate = scheduleNoLaterThanDate;
    }

    public Boolean getScheduleASAPDate() {
        return scheduleASAPDate;
    }

    public void setScheduleASAPDate(Boolean scheduleASAPDate) {
        this.scheduleASAPDate = scheduleASAPDate;
    }

    public Date getScheduledTimeFrom() {
        return scheduledTimeFrom;
    }

    public void setScheduledTimeFrom(Date scheduledTimeFrom) {
        this.scheduledTimeFrom = scheduledTimeFrom;
    }

    public Date getScheduledTimeTo() {
        return scheduledTimeTo;
    }

    public void setScheduledTimeTo(Date scheduledTimeTo) {
        this.scheduledTimeTo = scheduledTimeTo;
    }

    public Date getScheduledTimeEndFrom() {
        return scheduledTimeEndFrom;
    }

    public void setScheduledTimeEndFrom(Date scheduledTimeEndFrom) {
        this.scheduledTimeEndFrom = scheduledTimeEndFrom;
    }

    public Date getScheduledTimeEndTo() {
        return scheduledTimeEndTo;
    }

    public void setScheduledTimeEndTo(Date scheduledTimeEndTo) {
        this.scheduledTimeEndTo = scheduledTimeEndTo;
    }

    public Date getPickupDateFrom() {
        return pickupDateFrom;
    }

    public void setPickupDateFrom(Date pickupDateFrom) {
        this.pickupDateFrom = pickupDateFrom;
    }

    public Date getPickupDateTo() {
        return pickupDateTo;
    }

    public void setPickupDateTo(Date pickupDateTo) {
        this.pickupDateTo = pickupDateTo;
    }

    public String getPickupDateReason() {
        return pickupDateReason;
    }

    public void setPickupDateReason(String pickupDateReason) {
        this.pickupDateReason = pickupDateReason;
    }

    public Date getPickupTimeFrom() {
        return pickupTimeFrom;
    }

    public void setPickupTimeFrom(Date pickupTimeFrom) {
        this.pickupTimeFrom = pickupTimeFrom;
    }

    public Date getPickupTimeTo() {
        return pickupTimeTo;
    }

    public void setPickupTimeTo(Date pickupTimeTo) {
        this.pickupTimeTo = pickupTimeTo;
    }

    public Boolean getPickupDateTBD() {
        return pickupDateTBD;
    }

    public void setPickupDateTBD(Boolean pickupDateTBD) {
        this.pickupDateTBD = pickupDateTBD;
    }

    public String getCustomerID() {
        return customerID;
    }

    public void setCustomerID(String customerID) {
        this.customerID = customerID;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public Boolean getNewCustomer() {
        return newCustomer;
    }

    public void setNewCustomer(Boolean newCustomer) {
        this.newCustomer = newCustomer;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getContactPhone() {
        return contactPhone;
    }

    public void setContactPhone(String contactPhone) {
        this.contactPhone = contactPhone;
    }

    public String getContactPhoneExtension() {
        return contactPhoneExtension;
    }

    public void setContactPhoneExtension(String contactPhoneExtension) {
        this.contactPhoneExtension = contactPhoneExtension;
    }

    public String getContactEmail() {
        return contactEmail;
    }

    public void setContactEmail(String contactEmail) {
        this.contactEmail = contactEmail;
    }

    public String getSpecialInstructions() {
        return specialInstructions;
    }

    public void setSpecialInstructions(String specialInstructions) {
        this.specialInstructions = specialInstructions;
    }

    public Boolean getLiftGate() {
        return liftGate;
    }

    public void setLiftGate(Boolean liftGate) {
        this.liftGate = liftGate;
    }

    public Boolean getDock() {
        return dock;
    }

    public void setDock(Boolean dock) {
        this.dock = dock;
    }

    public Boolean getTractorTrailer() {
        return tractorTrailer;
    }

    public void setTractorTrailer(Boolean tractorTrailer) {
        this.tractorTrailer = tractorTrailer;
    }

    public Date getEmailedFrom() {
        return emailedFrom;
    }

    public void setEmailedFrom(Date emailedFrom) {
        this.emailedFrom = emailedFrom;
    }

    public Date getEmailedTo() {
        return emailedTo;
    }

    public void setEmailedTo(Date emailedTo) {
        this.emailedTo = emailedTo;
    }

    public Date getCreatedFrom() {
        return createdFrom;
    }

    public void setCreatedFrom(Date createdFrom) {
        this.createdFrom = createdFrom;
    }

    public Date getCreatedTo() {
        return createdTo;
    }

    public void setCreatedTo(Date createdTo) {
        this.createdTo = createdTo;
    }

    public Date getUpdatedFrom() {
        return updatedFrom;
    }

    public void setUpdatedFrom(Date updatedFrom) {
        this.updatedFrom = updatedFrom;
    }

    public Date getUpdatedTo() {
        return updatedTo;
    }

    public void setUpdatedTo(Date updatedTo) {
        this.updatedTo = updatedTo;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getProgramName() {
        return programName;
    }

    public void setProgramName(String programName) {
        this.programName = programName;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public Boolean getLoaner() {
        return loaner;
    }

    public void setLoaner(Boolean loaner) {
        this.loaner = loaner;
    }

    public String getLegalNotice() {
        return legalNotice;
    }

    public void setLegalNotice(String legalNotice) {
        this.legalNotice = legalNotice;
    }

    public String getLegalAcknowledgement() {
        return legalAcknowledgement;
    }

    public void setLegalAcknowledgement(String legalAcknowledgement) {
        this.legalAcknowledgement = legalAcknowledgement;
    }

    public Boolean getHasAttachment() {
        return hasAttachment;
    }

    public void setHasAttachment(Boolean hasAttachment) {
        this.hasAttachment = hasAttachment;
    }

    public Integer getDeliveryTypeId() {
        return deliveryTypeId;
    }

    public void setDeliveryTypeId(Integer deliveryTypeId) {
        this.deliveryTypeId = deliveryTypeId;
    }

    @Override
    protected Map<String, Object> getSearchPredicates() {
        Map<String, Object> predicates = new HashMap<>();

        predicates.put("status", status);
        predicates.put("salesRepID", salesRepID);
        predicates.put("ownerCode", ownerCode);
        predicates.put("email", email);
        predicates.put("phone", phone);
        predicates.put("phoneExtension", phoneExtension);
        predicates.put("rdcid", rdcid);
        predicates.put("rDCName", rDCName);
        predicates.put("rDCMasterKey", rDCMasterKey);
        predicates.put("orderType", orderType);
        predicates.put("scheduledDateFrom", scheduledDateFrom);
        predicates.put("scheduledDateTo", scheduledDateTo);
        predicates.put("deliveryDateReason", deliveryDateReason);
        predicates.put("scheduleOnDate", scheduleOnDate);
        predicates.put("scheduleNoLaterThanDate", scheduleNoLaterThanDate);
        predicates.put("scheduleASAPDate", scheduleASAPDate);
        predicates.put("scheduledTimeFrom", scheduledTimeFrom);
        predicates.put("scheduledTimeTo", scheduledTimeTo);
        predicates.put("scheduledTimeEndFrom", scheduledTimeEndFrom);
        predicates.put("scheduledTimeEndTo", scheduledTimeEndTo);
        predicates.put("pickupDateFrom", pickupDateFrom);
        predicates.put("pickupDateTo", pickupDateTo);
        predicates.put("pickupDateReason", pickupDateReason);
        predicates.put("pickupTimeFrom", pickupTimeFrom);
        predicates.put("pickupTimeTo", pickupTimeTo);
        predicates.put("pickupDateTBD", pickupDateTBD);
        predicates.put("customerID", customerID);
        predicates.put("customerName", customerName);
        predicates.put("newCustomer", newCustomer);
        predicates.put("address", address);
        predicates.put("city", city);
        predicates.put("state", state);
        predicates.put("zipCode", zipCode);
        predicates.put("contact", contact);
        predicates.put("contactPhone", contactPhone);
        predicates.put("contactPhoneExtension", contactPhoneExtension);
        predicates.put("contactEmail", contactEmail);
        predicates.put("specialInstructions", specialInstructions);
        predicates.put("liftGate", liftGate);
        predicates.put("dock", dock);
        predicates.put("tractorTrailer", tractorTrailer);
        predicates.put("emailedFrom", emailedFrom);
        predicates.put("emailedTo", emailedTo);
        predicates.put("createdFrom", createdFrom);
        predicates.put("createdFrom", createdFrom);
        predicates.put("updatedFrom", updatedFrom);
        predicates.put("updatedTo", updatedTo);
        predicates.put("userName", userName);
        predicates.put("programName", programName);
        predicates.put("department", department);
        predicates.put("loaner", loaner);
        predicates.put("legalNotice", legalNotice);
        predicates.put("legalAcknowledgement", legalAcknowledgement);
        predicates.put("hasAttachment", hasAttachment);
        predicates.put("deliveryTypeId", deliveryTypeId);

        return predicates;
    }
}
