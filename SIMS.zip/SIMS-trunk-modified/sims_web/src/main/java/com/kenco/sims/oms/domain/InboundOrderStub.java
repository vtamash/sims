package com.kenco.sims.oms.domain;

import java.util.Date;

public class InboundOrderStub {
	private Integer customerId;
	private Integer businessUnitId;
	private String number;
	private String scac;
	private String trailer;
	private String receiptType;
	private Date scheduledShipDate;
	private Integer vendorId;
	private String vendorName;
	private String vendorAddress1;
	private String vendorCity;
	private Integer vendorStateId;
	private String vendorZip;

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String getScac() {
		return scac;
	}

	public void setScac(String scac) {
		this.scac = scac;
	}

	public String getTrailer() {
		return trailer;
	}

	public void setTrailer(String trailer) {
		this.trailer = trailer;
	}

	public String getReceiptType() {
		return receiptType;
	}

	public void setReceiptType(String receiptType) {
		this.receiptType = receiptType;
	}

	public Date getScheduledShipDate() {
		return scheduledShipDate;
	}

	public void setScheduledShipDate(Date scheduledShipDate) {
		this.scheduledShipDate = scheduledShipDate;
	}

	public Integer getBusinessUnitId() {
		return businessUnitId;
	}

	public void setBusinessUnitId(Integer businessUnitId) {
		this.businessUnitId = businessUnitId;
	}

	public Integer getVendorId() {
		return vendorId;
	}

	public void setVendorId(Integer vendorId) {
		this.vendorId = vendorId;
	}

	public String getVendorName() {
		return vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

	public String getVendorAddress1() {
		return vendorAddress1;
	}

	public void setVendorAddress1(String vendorAddress1) {
		this.vendorAddress1 = vendorAddress1;
	}

	public String getVendorCity() {
		return vendorCity;
	}

	public void setVendorCity(String vendorCity) {
		this.vendorCity = vendorCity;
	}

	public Integer getVendorStateId() {
		return vendorStateId;
	}

	public void setVendorStateId(Integer vendorStateId) {
		this.vendorStateId = vendorStateId;
	}

	public String getVendorZip() {
		return vendorZip;
	}

	public void setVendorZip(String vendorZip) {
		this.vendorZip = vendorZip;
	}
}
