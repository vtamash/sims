package com.kenco.sims.oms.action;

import com.kenco.oms.entity.States;
import com.kenco.oms.service.impl.GenericStatesService;
import com.kenco.sims.oms.view.JsonView;
import com.kenco.struts.formbeans.WMSFormBean;
import com.kenco.struts.utilities.InitServlet;
import com.kenco.struts.utilities.PojoMapper;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.util.Collections;
import java.util.List;

public class StatesAction extends Action {
	private static final Logger logger = LoggerFactory.getLogger(StatesAction.class);

	/**
	 * Access point for and controls of the flow for each inbound (States-related) request.
	 */
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		WMSFormBean wfb = (WMSFormBean) form;

		logger.info("USER: " + wfb.getUser() + " Starting execute() method");

		// Setup our Business Services.
		final GenericStatesService service = new GenericStatesService(InitServlet.getEntityManagerFactory().createEntityManager());

		JsonView<States> view = null;
		try {
			String action = request.getParameter("action");
			if (action == null)
				return null;
			else if (request.getMethod().equals("GET") && action.equals("read"))
				view = new JsonView<States>(readStates(request,service));
		} catch (Exception e) {
			// Log the error.
			logger.error("Error processing States-Action request: ", e);

			// Respond to the call negatively for user-feedback.
			view = new JsonView<States>("There was an error proccessing this request.");
		}

		PrintWriter out = response.getWriter();
		out.print(PojoMapper.toJson(view, true));
		out.flush();
		out.close();

		logger.info("USER: " + wfb.getUser() + " Exiting execute() method");
		return null;
	}

	/**
	 * Performs a READ operation on the StatesService and returns a collection of States entities.  This method will also
	 * detect if there is an <i>id</i> set on the inbound request (to load only a single States entity) and return a
	 * typed Collection with only the single States entity requested (if it exists).
	 */
	private List<States> readStates(HttpServletRequest request, GenericStatesService service) {
		String id = request.getParameter("id");
		if (id != null)
			return Collections.singletonList(service.readById(Integer.parseInt(id)));
		else
			return service.readAll();
	}
}
