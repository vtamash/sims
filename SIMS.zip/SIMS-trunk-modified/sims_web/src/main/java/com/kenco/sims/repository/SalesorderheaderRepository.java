package com.kenco.sims.repository;

import com.kenco.sims.domain.search.impl.SalesorderheaderSearchRequest;
import com.kenco.struts.wmsio.tables.Salesorderheader;

import java.util.List;

/**
 * Specifies behavior for interaction with the {@code Salesorderheader} entity.
 *
 * @see Salesorderheader
 * @see PagingRepository
 * @see com.kenco.sims.repository.jpa.SalesorderheaderJpaRepository
 */
public interface SalesorderheaderRepository extends PagingRepository<Salesorderheader, SalesorderheaderSearchRequest> {
    /**
     * Persists the given {@code Salesorderheader} entity.
     *
     * @param soh The transient {@code Salesorderheader} entity to be persisted.
     * @return The persisted {@code Salesorderheader} entity.
     */
    Salesorderheader create(Salesorderheader soh);

    /**
     * Retrieves the {@code Salesorderheader} entity for the given Primary Key.
     *
     * @param salesOrderHeaderKey The Primary Key of the {@code Salesorderheader} entity to be retrieved.
     * @return The persistent {@code Salesorderheader} for the given Primary Key.
     * @throws javax.persistence.NoResultException When no result is found for the given {@code salesOrderHeaderKey}.
     * @throws javax.persistence.NonUniqueResultException When multiple results are found for the given {@code salesOrderHeaderKey}.
     */
    Salesorderheader readBySalesOrderHeaderKey(int salesOrderHeaderKey);

    /**
     * Retrieves a single page of {@code Salesorderheader} entities for the given {@code SearchRequest}.
     *
     * @return A {@code List} containing a the desired page of {@code Salesorderheader} entity results.
     */
    List<Salesorderheader> read(SalesorderheaderSearchRequest request);

    /**
     * Retrieves a single page of Incomplete Request {@code Salesorderheader} entities for the given {@code SearchRequest}
     *
     * @return A {@code List} containing a the desired page of {@code Salesorderheader} entity results.
     */
    List<Salesorderheader> findAllIncompletes(SalesorderheaderSearchRequest request);

    /**
     * Updates the persistent context for the given user to the given state.
     *
     * @param soh The state to which the persistent context should be updated.
     */
    void update(Salesorderheader soh);

    /**
     * Updates the persistent context for the given user to the given state.
     *
     * @param soh The state to which the persistent context should be updated.
     */
    void updateTransfers(Salesorderheader soh);

    /**
     * Retrieves the total number of Incomplete entities matching the predicates in the given {@code SearchReqeust}.
     *
     * @param request The {@code SearchRequest} containing the predicates to apply to this findAllIncompletes Operation.
     * @return The total number of entities which match the predicates contained within the given {@code SearchRequest}.
     */
    long getAllIncompletesCount(SalesorderheaderSearchRequest request);

    boolean isGenerated(int salesOrderHeaderKey);
}
