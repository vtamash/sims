package com.kenco.sims.oms.view;

import java.util.Collections;
import java.util.List;

public class JsonView<T> {
	private boolean success;
	private String message;
	private List<T> results;
	private Long total;

	public JsonView() {}

	public JsonView(String message) {
		this.message = message;
		this.success = false;
	}

	public JsonView(List<T> results) {
		this.results = results;
		this.success = true;
	}

	public JsonView(List<T> results, long total) {
		this.results = results;
		this.success = true;
		this.total   = total;
	}

	public JsonView(T t) {
		this.results = Collections.singletonList(t);
		this.success = true;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public List<T> getResults() {
		return results;
	}

	public void setResults(List<T> results) {
		this.results = results;
	}

	public Long getTotal() {
		return total;
	}

	public void setTotal(long total) {
		this.total = total;
	}
}
