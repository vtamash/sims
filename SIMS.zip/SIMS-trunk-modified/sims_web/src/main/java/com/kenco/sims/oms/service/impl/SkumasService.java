package com.kenco.sims.oms.service.impl;

import com.kenco.oms.entity.Skumas;
import com.kenco.oms.service.SkuMasAbstractService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.persistence.EntityManager;
import java.util.List;

public class SkumasService extends SkuMasAbstractService {

   private static Logger logger = LoggerFactory.getLogger(SkumasService.class);

   // constructor...
   public SkumasService(EntityManager em) {
      super(em);
   }

   @Override
   public void readPreProcess(Object... os) {
   }

   @Override
   public void updatePreProcess(Object... os) {
   }

   @Override
   public void deletePreProcess(Object... os) {
   }

   @Override
   public void readSinglePreProcess(Object... os) {
   }

   @Override
   public void createPreProcess(Skumas t, Object... os) {
   }

   @Override
   public Skumas createPostProcess(Skumas t, Object... args) {
      return t;
   }

   @Override
   public List<Skumas> readPostProcess(List<Skumas> list, Object... args) {
      return list;
   }

   @Override
   public Skumas readSinglePostProcess(Skumas t, Object... args) {
      return t;
   }

   @Override
   public Skumas updatePostProcess(Skumas t, Object... args) {
     return t;
   }

   @Override
   public void deletePostProcess(Skumas t, Object... args) {
   }
}
