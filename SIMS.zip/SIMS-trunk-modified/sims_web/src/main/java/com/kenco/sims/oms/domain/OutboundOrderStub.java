package com.kenco.sims.oms.domain;

import java.util.Date;

public class OutboundOrderStub {
    private Integer customerId;
    private Integer businessUnitId;

    private String number;
    private Date scheduledShipDate;
    private Date scheduledShipTime;

    private Integer shipToCustomerId;
    private String shipToCustomerName;
    private String shipToCustomerAddress;
    private String shipToCustomerCity;
    private Integer shipToCustomerStateId;
    private String shipToCustomerZip;
	private String ordertype;
	private String routed;
	private String scac;
	private String freightterms;
	private Integer deliveryId;
	private String deliveryName;
    
//	   Date scheduleddeparturedate;
//	   Date scheduleddeparturetime;

    public OutboundOrderStub() {
    }

    public Integer getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Integer customerId) {
        this.customerId = customerId;
    }

    public Integer getBusinessUnitId() {
        return businessUnitId;
    }

    public void setBusinessUnitId(Integer businessUnitId) {
        this.businessUnitId = businessUnitId;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public Date getScheduledShipDate() {
        return scheduledShipDate;
    }

    public void setScheduledShipDate(Date scheduledShipDate) {
        this.scheduledShipDate = scheduledShipDate;
    }

    public Integer getShipToCustomerId() {
        return shipToCustomerId;
    }

    public void setShipToCustomerId(Integer shipToCustomerId) {
        this.shipToCustomerId = shipToCustomerId;
    }

    public String getShipToCustomerAddress() {
        return shipToCustomerAddress;
    }

    public void setShipToCustomerAddress(String shipToCustomerAddress) {
        this.shipToCustomerAddress = shipToCustomerAddress;
    }

    public String getShipToCustomerCity() {
        return shipToCustomerCity;
    }

    public void setShipToCustomerCity(String shipToCustomerCity) {
        this.shipToCustomerCity = shipToCustomerCity;
    }

    public Integer getShipToCustomerStateId() {
        return shipToCustomerStateId;
    }

    public void setShipToCustomerStateId(Integer shipToCustomerStateId) {
        this.shipToCustomerStateId = shipToCustomerStateId;
    }

    public String getShipToCustomerZip() {
        return shipToCustomerZip;
    }

    public void setShipToCustomerZip(String shipToCustomerZip) {
        this.shipToCustomerZip = shipToCustomerZip;
    }

	public String getShipToCustomerName() {
		return shipToCustomerName;
	}

	public void setShipToCustomerName(String shipToCustomerName) {
		this.shipToCustomerName = shipToCustomerName;
	}

	public String getOrdertype() {
		return ordertype;
	}

	public void setOrdertype(String ordertype) {
		this.ordertype = ordertype;
	}

	public String getRouted() {
		return routed;
	}

	public void setRouted(String routed) {
		this.routed = routed;
	}

	public String getScac() {
		return scac;
	}

	public void setScac(String scac) {
		this.scac = scac;
	}

	public String getFreightterms() {
		return freightterms;
	}

	public void setFreightterms(String freightterms) {
		this.freightterms = freightterms;
	}

	public Date getScheduledShipTime() {
		return scheduledShipTime;
	}

	public void setScheduledShipTime(Date scheduledShipTime) {
		this.scheduledShipTime = scheduledShipTime;
	}

	public Integer getDeliveryId() {
		return deliveryId;
	}

	public void setDeliveryId(Integer deliveryId) {
		this.deliveryId = deliveryId;
	}

	public String getDeliveryName() {
		return deliveryName;
	}

	public void setDeliveryName(String deliveryName) {
		this.deliveryName = deliveryName;
	}
}
