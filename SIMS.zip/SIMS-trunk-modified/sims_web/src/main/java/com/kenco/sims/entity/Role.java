package com.kenco.sims.entity;

import javax.persistence.*;

/**
 * Represents a single role that may be assigned to a user for security purposes.
 */
@Entity
@Table(schema = "SIMS_SYS", name = "Roles")
public class Role {
    /**
     * Primary Key.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    /**
     * Name by which this is known.
     */
    @Column(name = "ROLE", nullable = false, length = 64)
    private String name;

    /**
     * The name of the application to which this applies.
     */
    @Column(name = "SYSTEMNAME", nullable = false, length = 64)
    private String systemName = "SIMS";

    /**
     * The name of the application to which this applies.
     */
    @Column(name = "SEQUENCE", nullable = false)
    private int sequence;

    @Override
    public boolean equals(Object obj) {
        return obj instanceof Role &&
                getId().equals(((Role) obj).getId());
    }

    @Override
    public int hashCode() {
        return getId().hashCode();
    }

    @Override
    public String toString() {
        return getId().toString();
    }

    public Integer getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSystemName() {
        return systemName;
    }

    protected void setSystemName(String systemName) {
        this.systemName = systemName;
    }

    public int getSequence() {
        return sequence;
    }

    public void setSequence(int sequence) {
        this.sequence = sequence;
    }
}
