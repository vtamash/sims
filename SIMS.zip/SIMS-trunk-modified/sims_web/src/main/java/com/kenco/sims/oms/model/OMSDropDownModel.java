package com.kenco.sims.oms.model;

import com.kenco.struts.utilities.InitServlet;
import com.thoughtworks.paranamer.BytecodeReadingParanamer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Type;
import java.util.*;

public class OMSDropDownModel {

   static Logger logger = LoggerFactory.getLogger(OMSDropDownModel.class);

   @SuppressWarnings("unchecked")
   public List<Object> getDropDownList(Integer pCustomerId, Map<String, String[]> params) throws ClassNotFoundException, NoSuchMethodException, SecurityException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {

      String serviceName = ((String[]) params.get("action"))[0];
      Class<?> clazz = Class.forName((serviceName.indexOf(".") < 0 ? "com.kenco.oms.service.impl." : "") + serviceName);

      Method method = null;
      BytecodeReadingParanamer brp = new BytecodeReadingParanamer();

      Method[] methods = clazz.getMethods();
      String[] parameterNames = null;

      for (Method m : methods)
         if (m.getName().startsWith("read") || m.getName().startsWith("list")) {
        	 
        	 if ( (	m.getReturnType().isAssignableFrom(Collection.class) || 
        			m.getReturnType().isAssignableFrom(List.class) || 
        			m.getReturnType().isAssignableFrom(Set.class) ) && 
        			!m.getReturnType().equals(java.lang.Object.class) ) {
        	     parameterNames = brp.lookupParameterNames(m);
        	     boolean isIt = true;
        	     for (String param : parameterNames) {
        	    	 if (!params.containsKey(param)) {
            	    	 if (param.equals("customerId") || param.equals("args"))
            	    		 continue;
        	    		 isIt = false;
        	    		 break;
        	    	 }
        	     }
        	     if (isIt) {
                     method = m;
                     break;
        	     }
        	 }
         }

      if (method == null)
         throw new NoSuchMethodException();

      EntityManagerFactory emf = InitServlet.getEntityManagerFactory();
      EntityManager em = emf.createEntityManager();
      
      Type[] types = method.getGenericParameterTypes();
      int length = parameterNames.length;
      List<Object> parameters = new ArrayList<Object>();
      for (int i = 0; i < length; i++) {
         if (parameterNames[i].equals("customerId") && params.get(parameterNames[i]) == null)
        	parameters.add(pCustomerId);
         else if (params.get(parameterNames[i]) != null) {
            String param = params.get(parameterNames[i])[0];
            if (param != null && !param.isEmpty()) {
               if (types[i].equals(int.class) || types[i].equals(Integer.class))
                  parameters.add(Integer.parseInt(param));
               else if (types[i].equals(boolean.class) || types[i].equals(Boolean.class))
            	  parameters.add(Boolean.parseBoolean(param));
               else if (types[i].equals(String.class))
                  parameters.add(param);
            } else
               parameters.add(null);
         } else if (types[i].equals(Object[].class))
            parameters.add(new Object[]{null});
         else
            parameters.add(null);
      }

      final Constructor<?> constractor = (Constructor<?>) clazz.getConstructors()[0];

      Object service = constractor.newInstance(em);

      List<Object> list = (List<Object>) method.invoke(service, parameters.toArray());

      return list;
   }
}
