package com.kenco.sims.oms.action;

import com.kenco.oms.entity.Wmsoutboundorderstatuses;
import com.kenco.oms.service.impl.GenericWmsOutboundOrderStatusService;
import com.kenco.sims.oms.view.JsonView;
import com.kenco.struts.formbeans.WMSFormBean;
import com.kenco.struts.utilities.InitServlet;
import com.kenco.struts.utilities.PojoMapper;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.util.List;

public class OutboundOrderStatusAction extends Action {
	private static final Logger logger = LoggerFactory.getLogger(OutboundOrderStatusAction.class);

	/**
	 * Access point for and controls of the flow for each inbound (Wmsoutboundorderstatuses-related) request.
	 */
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		WMSFormBean wfb = (WMSFormBean) form;

		logger.info("USER: " + wfb.getUser() + " Starting execute() method");

		// Setup our Business Services.
		final GenericWmsOutboundOrderStatusService service = new GenericWmsOutboundOrderStatusService(InitServlet.getEntityManagerFactory().createEntityManager());

		JsonView view = null;
		try {
			String action = request.getParameter("action");

			// Render the page.
			if (action == null)
				throw new IllegalArgumentException("Invalid Action.");

			// Create request.
			else if (request.getMethod().equals("POST") && action.equals("create"))
				throw new IllegalArgumentException("Invalid Action.");

			// Read (all) request.
			else if (request.getMethod().equals("GET") && action.equals("read"))
				view = new JsonView<Wmsoutboundorderstatuses>(read(service, wfb));

			// Update request.
			else if (request.getMethod().equals("POST") && action.equals("update"))
				throw new IllegalArgumentException("Invalid Action.");

			// Delete request.
			else if (request.getMethod().equals("POST") && action.equals("delete"))
				throw new IllegalArgumentException("Invalid Action.");
		} catch (Exception e) {
			// Log the error.
			logger.error("Error processing Wmsoutboundorderstatuses-Action request: ", e);

			// Respond to the call negatively for user-feedback.
			view = new JsonView("There was an error proccessing this request.");
		}

		PrintWriter out = response.getWriter();
		out.print(PojoMapper.toJson(view, true));
		out.flush();
		out.close();

		logger.info("USER: " + wfb.getUser() + " Exiting execute() method");
		return null;
	}

	/**
	 * Performs a READ operation on the WmsOutboundOrderStatusService and returns a collection of Wmsoutboundorderstatuses entities
	 * Marshalled into JSON.
	 */
	private List<Wmsoutboundorderstatuses> read(GenericWmsOutboundOrderStatusService service, WMSFormBean wfb) throws Exception {
		return service.read(wfb.getOmsDefaultCustomerId());
	}
}
