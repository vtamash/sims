package com.kenco.sims.oms.domain;

/**
 * We don't have the full Customers entity on an inbound Create or Update request.  Instead, we are only given the
 * Customers ID value.  For this reason, we can't outright instantiate a Customers object.  Instead, we create one
 * of these (thin) wrappers to use during the Un-Marshalling process and instantiate a BusinessUnit object once
 * we can load up the relevant Customers entity.
 */
public class BusinessUnitStub {
	private Integer id;
	private Integer customerId;
	private Short active;
	private String name;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public Short getActive() {
		return active;
	}

	public void setActive(Short active) {
		this.active = active;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
