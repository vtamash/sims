package com.kenco.sims.oms.service.impl;

import com.kenco.oms.entity.*;
import com.kenco.oms.service.OmsDownloadAbstractService;
import com.kenco.oms.utilities.Enums;

import javax.persistence.EntityManager;
import java.util.Date;
import java.util.List;

/**
 * SIMS Implementation of the OmsDownloadAbstractService.  This class will handle the format of an OmsDownload when
 * creation is triggered.  Per documentation, OmsDownload creation is triggered automatically from an <i>update</i>
 * operation for the <i>InboundOrderHeader</i> and <i>OutboundOrderHeader</i> entities (Setting status to complete).
 *
 * @see com.kenco.oms.service.InboundOrderAbstractService
 * @see com.kenco.oms.service.OutboundOrderAbstractService
 */
public final class OmsDownloadService extends OmsDownloadAbstractService {
    /**
     * {@inheritDoc}
     */
    public OmsDownloadService(EntityManager em) {
        super(em);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected String generateOutboundHeaderDataString(Outboundorderheader order, String whsid) {
        StringBuilder sb = new StringBuilder();
        sb.append(pad("0000000", 7, false, true)); // DOCNO
        sb.append(pad(whsid, 6, false, true)); // WHSID
        sb.append(pad(dateFormat.format(new Date()), 8, false, true)); // TRNDAT
        sb.append(pad(timeFormat.format(new Date()), 6, false, true)); // TRNTIM
        sb.append(pad(Enums.eOMSDownloadTransactionTypes.ORDH.toString(), 4, false, true)); // TRNTYP
        sb.append(pad("", 5, false, true)); // CUSTNO
        sb.append(pad(order.getOrdernumber(), 15, false, true));  // ORDERNO
        sb.append(pad("", 15, false, true)); // PONO
        sb.append(pad(order.getOrdertype(), 2, false, true)); // ORDTYPE
        sb.append(pad(order.getFreightterms(), 3, false, true)); // FRTTRM
        sb.append(pad(order.getScac(), 4, false, true)); // SCAC
        sb.append(pad(dateFormat.format(order.getScheduleddeparturedate()), 8, false, true)); // SCDDEPDT
        sb.append(pad(timeFormat.format(order.getScheduleddeparturetime()), 6, false, true)); // SCDDEPTM
        sb.append(pad("", 8, false, true)); // SCDDLVDT
        sb.append(pad("", 6, false, true)); // SCDDLVTM
        sb.append(pad(order.getShiptocustomerId().getShiptocustomernumber(), 10, false, true)); // SHPTOCUS
        sb.append(pad(order.getShiptocustomerId().getShiptocustomernumber(), 10, false, true)); // SLDTOCUS
        sb.append(pad("", 6, false, true)); // TOWHS
        sb.append(pad(order.getShiptoname(), 40, false, true)); // NAME
        sb.append(pad(order.getShiptoaddress1() == null ? "" : order.getShiptoaddress1(), 40, false, true)); // ADDRESS1
        sb.append(pad(order.getShiptoaddress2() == null ? "" : order.getShiptoaddress2(), 40, false, true)); // ADDRESS2
        sb.append(pad(order.getShiptoaddress3() == null ? "" : order.getShiptoaddress3(), 40, false, true)); // ADDRESS3
        sb.append(pad(order.getShiptocity(), 30, false, true)); // CITY
        sb.append(pad(order.getShiptostateId().getState(), 2, false, true)); // STATE
        sb.append(pad(order.getShiptozip(), 6, false, true)); // ZIP
        sb.append(pad("", 4, false, true)); // ZIP4
        sb.append(pad("", 8, true, false)); // RESVPRTY
        sb.append(pad("", 5, true, false)); // STOPSEQN
        sb.append(pad("", 35, false, true)); //SHIPMENT
        sb.append(pad("", 3, false, true)); //CSR
        sb.append(pad("", 20, false, true)); //MSTBILL
        sb.append(pad("", 10, false, true)); //POOLNO
        sb.append(pad("", 5, false, true)); //FILLER
        sb.append(pad("", 2, false, true)); //DSTCHNL
        sb.append(pad("", 15, false, true)); //HOSTORDNO
        sb.append(pad("", 10, false, true)); //TOTAMT
        sb.append(pad("", 10, false, true)); //PHONE1
        sb.append(pad("", 10, false, true)); //PHONE2
        sb.append(pad("", 2, false, true)); //DLVCOD
        sb.append(pad("", 2, false, true)); //CODMTHD
        sb.append(pad("00000000", 8, false, true)); // CODAMT
        sb.append(pad("", 5, false, true)); // ROUTID
        sb.append(pad("", 10, false, true)); // LOADNO
        sb.append(pad("000000000", 9, false, true)); // ORDWGT
        sb.append(pad("", 10, false, true)); //CNTRYCOD
        sb.append(pad("", 8, false, true)); //CNCLDAT
        sb.append(pad("", 8, false, true)); //BEGSHPDT
        sb.append(pad("", 8, false, true)); //ENDSHPDT
        sb.append(pad("", 8, false, true)); //BEGDLVDT
        sb.append(pad("", 8, false, true)); //ENDDLVDT
        sb.append(pad("", 10, false, true)); //DEPTNO
        sb.append(pad("", 10, false, true)); //STORENO
        sb.append(pad("", 20, false, true)); //STORENAME
        sb.append(pad("", 5, false, true)); //POTYPE
        sb.append(pad("", 6, false, true)); //LNKSEQNUM
        sb.append(pad("", 15, false, true)); //REFLNKNUM
        sb.append(pad("", 1, false, true)); //PLTEXCHG
        sb.append(pad("", 2, false, true)); //PLTTYP
        sb.append(pad("", 15, false, true)); //DEANUM
        sb.append(pad("", 35, false, true)); //PONO35
        sb.append(pad("", 1, false, true)); //PROCCODE
        sb.append(pad("", 20, false, true)); //DISTCTR
        sb.append(pad("", 30, false, true)); //REPNAME
        sb.append(pad("", 15, false, true)); //REPPHONE
        sb.append(pad("", 10, false, true)); //VENDNO
        sb.append(pad("", 15, false, true)); //WRKORD
        sb.append(pad("", 8, false, true)); //WRKORDDUE
        sb.append(pad("", 10, false, true)); //SALESGRP
        sb.append(pad("", 1, false, true)); //CODTYPE
        sb.append(pad("", 3, false, true)); //SPCHLD
        sb.append(pad("", 10, false, true)); //SHIPWITH
        sb.append(pad("", 5, false, true)); //ORDSTS
        sb.append(pad("", 10, false, true)); //ACCTNO
        sb.append(pad("", 40, false, true)); //REPEMAIL
        sb.append(pad("", 20, false, true)); //GLNUM
        sb.append(pad("", 3, false, true)); //SDROUT
        sb.append(pad("", 130, false, true)); //FILLER
        return sb.toString();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected String generateOutboundDetailDataString(Outboundorderdetail detail, String whsid) {
        Skumas sku = skuService.read(detail.getOutboundorderheaderId().getCustomerId().getId(), detail.getProductcode());

        StringBuilder sb = new StringBuilder();
        sb.append(pad("0000000", 7, false, true)); // DOCNO
        sb.append(pad(whsid, 6, false, true)); // WHSID
        sb.append(pad(dateFormat.format(new Date()), 8, false, true)); // TRNDAT
        sb.append(pad(timeFormat.format(new Date()), 6, false, true)); // TRNTIM
        sb.append(pad(Enums.eOMSDownloadTransactionTypes.ORDT.toString(), 4, false, true)); // TRNTYP
        sb.append(pad("", 5, false, true)); //CUSTNO
        sb.append(pad(detail.getOutboundorderheaderId().getOrdernumber(), 15, false, true)); // ORDERNO
        sb.append(pad(detail.getLine().toString(), 3, true, false)); // LINE
        sb.append(pad(Enums.eOMSDownloadOrderDetailTypes.D.toString(), 1, false, true)); // TYPE
        sb.append(pad(detail.getProductcode(), 18, false, true)); // SKUNUMB
        sb.append(pad("", 12, false, true)); // LOTID
        sb.append(pad("", 5, false, true)); //HOLDCODE
        sb.append(pad(detail.getOrderquantity().toString(), 11, true, false)); // ORDQTY
        sb.append(pad(sku != null && sku.getStduom() != null ? sku.getStduom() : "", 5, false, true)); // UOM
        sb.append(pad("", 72, false, true)); //DESC
        sb.append(pad("", 1, false, true)); //LOTLMT
        sb.append(pad("", 18, false, true)); //CUSPN
        sb.append(pad("000000", 6, false, true)); //VALUE
        sb.append(pad("00000000000", 11, false, true)); //REQQTY
        sb.append(pad("", 10, false, true)); //LININS
        sb.append(pad("", 2, false, true)); //PUFLAG
        sb.append(pad("", 2, false, true)); //HDRTYPE
        sb.append(pad("000", 3, false, true)); //LOTSEQ
        sb.append(pad("000000000", 9, false, true)); //WEIGHT
        sb.append(pad("", 10, false, true)); //CLASS
        sb.append(pad("", 6, false, true)); //HOSTLINE
        sb.append(pad("", 9, true, false)); //VALUE2
        sb.append(pad("00000", 5, false, true)); //HOSTCUBE
        sb.append(pad("", 14, false, true)); //UPC
        sb.append(pad("", 10, false, true)); //STORENO
        sb.append(pad("", 2, false, true)); //NDCQUAL
        sb.append(pad("", 15, false, true)); //NDCNUM
        sb.append(pad("", 15, false, true)); //TARIFCOD
        sb.append(pad("", 50, false, true)); //CNTRYORIG
        sb.append(pad("", 24, false, true)); //FILLER
        return sb.toString();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected String generateOutboundNoteDataString(Outboundordernotes note, String whsid) {
        StringBuilder sb = new StringBuilder();
        sb.append(pad("0000000", 7, false, true)); // DOCNO
        sb.append(pad(whsid, 6, false, true)); // WHSID
        sb.append(pad(dateFormat.format(new Date()), 8, false, true)); // TRNDAT
        sb.append(pad(timeFormat.format(new Date()), 6, false, true)); // TRNTIM
        sb.append(pad(Enums.eOMSDownloadTransactionTypes.ORDT.toString(), 4, false, true)); // TRNTYP
        sb.append(pad("", 5, false, true)); //CUSTNO
        sb.append(pad(note.getOutboundorderheaderId().getOrdernumber(), 15, false, true)); // ORDERNO
        sb.append(pad("000", 3, false, true)); // LINE
        sb.append(pad(Enums.eOMSDownloadOrderDetailTypes.I.toString(), 1, false, true)); // TYPE
        sb.append(pad("", 18, false, true)); // SKUNUMB
        sb.append(pad("", 12, false, true)); // LOTID
        sb.append(pad("", 5, false, true)); //HOLDCODE
        sb.append(pad("00000000000", 11, false, true)); // ORDQTY
        sb.append(pad("", 5, false, true)); // UOM
        if (note.getNotetype().equals("LOTRESV") && note.getQuantity() > 0)
            sb.append(pad(note.getNote().trim() + ", Qty: " + note.getQuantity(), 72, false, true)); //DESC  with Lot Qty
        else
            sb.append(pad(note.getNote(), 72, false, true)); //DESC
        sb.append(pad("", 1, false, true)); //LOTLMT
        sb.append(pad("", 18, false, true)); //CUSPN
        sb.append(pad("000000", 6, false, true)); //VALUE
        sb.append(pad("00000000000", 11, false, true)); //REQQTY
        sb.append(pad("", 10, false, true)); //LININS
        sb.append(pad("", 2, false, true)); //PUFLAG
        sb.append(pad("", 2, false, true)); //HDRTYPE
        sb.append(pad("000", 3, false, true)); //LOTSEQ
        sb.append(pad("000000000", 9, false, true)); //WEIGHT
        sb.append(pad("", 10, false, true)); //CLASS
        sb.append(pad("", 6, false, true)); //HOSTLINE
        sb.append(pad("", 9, false, true)); //VALUE2
        sb.append(pad("00000", 5, false, true)); //HOSTCUBE
        sb.append(pad("", 14, false, true)); //UPC
        sb.append(pad("", 10, false, true)); //STORENO
        sb.append(pad("", 2, false, true)); //NDCQUAL
        sb.append(pad("", 15, false, true)); //NDCNUM
        sb.append(pad("", 15, false, true)); //TARIFCOD
        sb.append(pad("", 50, false, true)); //CNTRYORIG
        sb.append(pad("", 24, false, true)); //FILLER
        return sb.toString();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected String generateInboundHeaderDataString(Inboundorderheader order, String whsid) {
        StringBuilder sb = new StringBuilder();
        sb.append(pad("0000000", 7, false, true)); // DOCNO
        sb.append(pad(whsid, 6, false, true)); // WHSID
        sb.append(pad(dateFormat.format(new Date()), 8, false, true)); // TRNDAT
        sb.append(pad(timeFormat.format(new Date()), 6, false, true)); // TRNTIM
        sb.append(pad(Enums.eOMSDownloadTransactionTypes.INTH.toString(), 4, false, true)); // TRNTYP
        sb.append(pad("", 5, false, true)); // CUSTNO
        sb.append(pad(order.getOrdernumber(), 15, false, true)); // ORDERNO
        sb.append(pad(order.getScac(), 4, false, true)); // SCAC
        sb.append(pad(order.getTrailernumber(), 15, false, true)); // TRLRNO
        sb.append(pad("", 15, false, true)); // SEALNO
        sb.append(pad(dateFormat.format(new Date()), 8, false, true)); // SCDADATE
        sb.append(pad(order.getVendornumber(), 10, false, true)); // VENDNO
        sb.append(pad(order.getVendorname(), 40, false, true)); // NAME
        sb.append(pad(order.getVendoraddress1() == null ? "" : order.getVendoraddress1(), 40, false, true)); // ADDR1
        sb.append(pad(order.getVendoraddress2() == null ? "" : order.getVendoraddress2(), 40, false, true)); // ADDR2
        sb.append(pad(order.getVendoraddress3() == null ? "" : order.getVendoraddress3(), 40, false, true)); // ADDR3
        sb.append(pad(order.getVendorcity(), 30, false, true)); // CITY
        sb.append(pad(order.getVendorstate().getState(), 2, false, true)); // STATE
        sb.append(pad(order.getVendorzip(), 9, false, true)); // ZIP
        sb.append(pad("", 4, false, true)); // ZIP4
        sb.append(pad("00000000", 8, false, true)); // GROSSWGT
        sb.append(pad("", 15, false, true)); // PONO
        sb.append(pad("", 10, false, true)); // FRMWHSID
        return sb.toString();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected String generateInboundDetailDataString(Inboundorderdetail detail, String whsid) {
        Skumas sku = skuService.read(detail.getInboundorderheaderId().getCustomerId().getId(), detail.getProductcode());
        String expireDt = tableDefaultRepo.getValue(detail.getInboundorderheaderId().getCustomerId().getId(), detail.getInboundorderheaderId().getBusinessunitId().getId(), Enums.eOMSTableNames.OMSDOWNLOAD_INTD.toString(), Enums.eOMSDOWNLOADColumnNames.EXPIREDT.toString());

        StringBuilder sb = new StringBuilder();
        sb.append(pad("0000000", 7, false, true)); // DOCNO
        sb.append(pad(whsid, 6, false, true)); // WHSID
        sb.append(pad(dateFormat.format(new Date()), 8, false, true)); // TRNDAT
        sb.append(pad(timeFormat.format(new Date()), 6, false, true)); // TRNTIM
        sb.append(pad(Enums.eOMSDownloadTransactionTypes.INTD.toString(), 4, false, true)); // TRNTYP
        sb.append(pad("", 5, false, true)); // CUSTNO
        sb.append(pad(detail.getInboundorderheaderId().getOrdernumber(), 15, false, true)); // ORDERNO
        sb.append(pad(detail.getLine().toString(), 3, true, false)); // LINE
        sb.append(pad(detail.getProductcode(), 18, false, true)); // SKUNUMB
        sb.append(pad(detail.getLotid(), 12, false, true)); // LOTID
        sb.append(pad(sku != null && sku.getStduom() != null ? sku.getStduom() : "", 2, false, true)); // UOM
        sb.append(pad(detail.getOrderquantity().toString(), 11, true, false)); // ORDQTY
        sb.append(pad(expireDt, 8, false, true)); // EXPIREDT
        sb.append(pad("", 15, false, true)); // PONO
        sb.append(pad("00000000", 8, false, true)); // PRODDATE
        sb.append(pad("", 10, false, true)); // FRMWHSID

        return sb.toString();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Omsdownload createPreProcess(Omsdownload omsdownload, Object... args) {
        omsdownload.setCreateprogram("SIMS: OmsDownloadService.create(...)");
        return omsdownload;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Omsdownload updatePreProcess(Omsdownload omsdownload, Object... args) {
        omsdownload.setUpdateprogram("SIMS: OmsDownloadService.update(...)");
        return omsdownload;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Omsdownload deletePreProcess(Omsdownload omsdownload, Object... args) {
        return omsdownload;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Omsdownload createPostProcess(Omsdownload omsdownload, Object... args) {
        return omsdownload;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public List<Omsdownload> readPostProcess(List<Omsdownload> l, Object... args) {
        return l;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Omsdownload readSinglePostProcess(Omsdownload omsdownload, Object... args) {
        return omsdownload;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Omsdownload updatePostProcess(Omsdownload omsdownload, Object... args) {
        return omsdownload;
    }

    /**
     * Pad passed string with leading zeros or trailing blanks according to parms
     *
     * @param str       String to pad
     * @param len       Total length the string field should be once padding is done
     * @param padZeros  pad right side with zeros
     * @param padBlanks pad left side with blanks
     * @return Padded String.
     */
    private String pad(String str, int len, boolean padZeros, boolean padBlanks) {
        StringBuilder sb = new StringBuilder();
        str = str.trim();
        if (padZeros) {
            for (int i = 0; i < len - str.length(); i++) {
                sb.append("0");
            }
            str = sb.toString().concat(str);
        } else if (padBlanks) {
            for (int i = 0; i < len - str.length(); i++) {
                sb.append(" ");
            }
            str = str.concat(sb.toString());
        }

        return str;
    }
}
