package com.kenco.sims.dto;

import com.kenco.sims.entity.MenuItem;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Represents a single {@code MenuItem}.
 *
 * This is useful for transmitting one or more {@code MenuItem} entities in a flat structure rather than as a full,
 * hierarchical format that they are naturally in.
 *
 * If / When the menu-related objects are persisted within a database rather than XML, we can entirely remove this as
 * the object relations will be handled by JPA.
 */
@XmlRootElement(name = "MenuItem")
@XmlAccessorType(XmlAccessType.FIELD)
public class MenuItemDTO implements Serializable {
    private static final long serialVersionUID = 3119362316534757909L;

    @XmlAttribute(required = true)
    private String id;

    @XmlAttribute(required = true)
    private int sequence;

    @XmlAttribute(required = true)
    private String name;

    @XmlAttribute
    private String action;

    @XmlAttribute
    private String iconName;

    private List<MenuItemDTO> children = new ArrayList<>();

    public MenuItemDTO() {}

    public MenuItemDTO(MenuItem menuItem) {
        id       = menuItem.getId().toString();
        sequence = menuItem.getSequence();
        name     = menuItem.getName();
        action   = menuItem.getAction();
        iconName = menuItem.getIconName();
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getSequence() {
        return sequence;
    }

    public void setSequence(int sequence) {
        this.sequence = sequence;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getIconName() {
        return iconName;
    }

    public void setIconName(String iconName) {
        this.iconName = iconName;
    }

    public List<MenuItemDTO> getChildren() {
        return children;
    }

    public void setChildren(List<MenuItemDTO> children) {
        this.children = children;
    }

    public void addChild(MenuItemDTO child) {
        children.add(child);
    }
}
