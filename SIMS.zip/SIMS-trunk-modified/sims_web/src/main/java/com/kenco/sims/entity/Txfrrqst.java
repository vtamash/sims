package com.kenco.sims.entity;

import com.kenco.struts.wmsio.tables.Salesorderheader;

import javax.persistence.*;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;

@Entity
@Table(name = "TXFRRQST")
@XmlRootElement
public class Txfrrqst  implements Serializable {
    private static final long serialVersionUID = 1L;

    private String txfrrqstid;
    private String shipwithno;
    private String status;
    private String ordertype;
    private String skunumb;
    private String lotid;
    private String serialno;
    private String tocustid;
    private Date scddeldate;
    private String delvreason;
    private Date delwdwdate;
    private Date actdeldate;
    private Date enddate;
    private String pickuprsn;
    private String salesman;
    private String tour;
    private String ordcontact;
    private String repid;
    private String region;
    private String territory;
    private String delvprof;
    private String shpcontact;
    private int cube;
    private String noreprqd;
    private String origin;
    private String cancelrsn;
    private String cancelby;
    private String origintype;
    private String desttype;
    private Timestamp inzstamp;
    private Timestamp updstamp;
    private String program;
    private String username;
    private List<Salesorderheader> salesorderheaders;

    @Id
    @Column(name = "TXFRRQSTID")
    public String getTxfrrqstid() {
        return txfrrqstid;
    }

    public void setTxfrrqstid(String txfrrqstid) {
        this.txfrrqstid = txfrrqstid;
    }

    @Column(name = "SHIPWITHNO")
    @Basic
    public String getShipwithno() {
        return shipwithno;
    }

    public void setShipwithno(String shipwithno) {
        this.shipwithno = shipwithno;
    }

    @Column(name = "STATUS")
    @Basic
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Column(name = "ORDERTYPE")
    @Basic
    public String getOrdertype() {
        return ordertype;
    }

    public void setOrdertype(String ordertype) {
        this.ordertype = ordertype;
    }

    @Column(name = "SKUNUMB")
    @Basic
    public String getSkunumb() {
        return skunumb;
    }

    public void setSkunumb(String skunumb) {
        this.skunumb = skunumb;
    }

    @Column(name = "LOTID")
    @Basic
    public String getLotid() {
        return lotid;
    }

    public void setLotid(String lotid) {
        this.lotid = lotid;
    }

    @Column(name = "SERIALNO")
    @Basic
    public String getSerialno() {
        return serialno;
    }

    public void setSerialno(String serialno) {
        this.serialno = serialno;
    }

    @Column(name = "TOCUSTID")
    @Basic
    public String getTocustid() {
        return tocustid;
    }

    public void setTocustid(String tocustid) {
        this.tocustid = tocustid;
    }

    @Column(name = "SCDDELDATE")
    @Basic
    public Date getScddeldate() {
        return scddeldate;
    }

    public void setScddeldate(Date scddeldate) {
        this.scddeldate = scddeldate;
    }

    @Column(name = "DELVREASON")
    @Basic
    public String getDelvreason() {
        return delvreason;
    }

    public void setDelvreason(String delvreason) {
        this.delvreason = delvreason;
    }

    @Column(name = "DELWDWDATE")
    @Basic
    public Date getDelwdwdate() {
        return delwdwdate;
    }

    public void setDelwdwdate(Date delwdwdate) {
        this.delwdwdate = delwdwdate;
    }

    @Column(name = "ACTDELDATE")
    @Basic
    public Date getActdeldate() {
        return actdeldate;
    }

    public void setActdeldate(Date actdeldate) {
        this.actdeldate = actdeldate;
    }

    @Column(name = "ENDDATE")
    @Basic
    public Date getEnddate() {
        return enddate;
    }

    public void setEnddate(Date enddate) {
        this.enddate = enddate;
    }

    @Column(name = "PICKUPRSN")
    @Basic
    public String getPickuprsn() {
        return pickuprsn;
    }

    public void setPickuprsn(String pickuprsn) {
        this.pickuprsn = pickuprsn;
    }

    @Column(name = "SALESMAN")
    @Basic
    public String getSalesman() {
        return salesman;
    }

    public void setSalesman(String salesman) {
        this.salesman = salesman;
    }

    @Column(name = "TOUR")
    @Basic
    public String getTour() {
        return tour;
    }

    public void setTour(String tour) {
        this.tour = tour;
    }

    @Column(name = "ORDCONTACT")
    @Basic
    public String getOrdcontact() {
        return ordcontact;
    }

    public void setOrdcontact(String ordcontact) {
        this.ordcontact = ordcontact;
    }

    @Column(name = "REPID")
    @Basic
    public String getRepid() {
        return repid;
    }

    public void setRepid(String repid) {
        this.repid = repid;
    }

    @Column(name = "REGION")
    @Basic
    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    @Column(name = "TERRITORY")
    @Basic
    public String getTerritory() {
        return territory;
    }

    public void setTerritory(String territory) {
        this.territory = territory;
    }

    @Column(name = "DELVPROF")
    @Basic
    public String getDelvprof() {
        return delvprof;
    }

    public void setDelvprof(String delvprof) {
        this.delvprof = delvprof;
    }

    @Column(name = "SHPCONTACT")
    @Basic
    public String getShpcontact() {
        return shpcontact;
    }

    public void setShpcontact(String shpcontact) {
        this.shpcontact = shpcontact;
    }

    @Column(name = "CUBE")
    @Basic
    public int getCube() {
        return cube;
    }

    public void setCube(int cube) {
        this.cube = cube;
    }

    @Column(name = "NOREPRQD")
    @Basic
    public String getNoreprqd() {
        return noreprqd;
    }

    public void setNoreprqd(String noreprqd) {
        this.noreprqd = noreprqd;
    }

    @Column(name = "ORIGIN")
    @Basic
    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    @Column(name = "CANCELRSN")
    @Basic
    public String getCancelrsn() {
        return cancelrsn;
    }

    public void setCancelrsn(String cancelrsn) {
        this.cancelrsn = cancelrsn;
    }

    @Column(name = "CANCELBY")
    @Basic
    public String getCancelby() {
        return cancelby;
    }

    public void setCancelby(String cancelby) {
        this.cancelby = cancelby;
    }

    @Column(name = "ORIGINTYPE")
    @Basic
    public String getOrigintype() {
        return origintype;
    }

    public void setOrigintype(String origintype) {
        this.origintype = origintype;
    }

    @Column(name = "DESTTYPE")
    @Basic
    public String getDesttype() {
        return desttype;
    }

    public void setDesttype(String desttype) {
        this.desttype = desttype;
    }

    @Column(name = "INZSTAMP")
    @Basic
    public Timestamp getInzstamp() {
        return inzstamp;
    }

    public void setInzstamp(Timestamp inzstamp) {
        this.inzstamp = inzstamp;
    }

    @Column(name = "UPDSTAMP")
    @Basic
    public Timestamp getUpdstamp() {
        return updstamp;
    }

    public void setUpdstamp(Timestamp updstamp) {
        this.updstamp = updstamp;
    }

    @Column(name = "PROGRAM")
    @Basic
    public String getProgram() {
        return program;
    }

    public void setProgram(String program) {
        this.program = program;
    }

    @Column(name = "USERNAME")
    @Basic
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

/*
    @ManyToMany(mappedBy = "txfrrqsts")
    @JoinTable( name="TXRQSTDTL",
                joinColumns={@JoinColumn(name="TXFRRQSTID", referencedColumnName="SHIPWITHNO")},
                inverseJoinColumns={@JoinColumn(name="SALESID", referencedColumnName="SALESORDERHEADERKEY")})
*/
    @Transient
    public List<Salesorderheader> getSalesorderheaders() {
        return salesorderheaders;
    }

    public void setSalesorderheaders(List<Salesorderheader> salesorderheaders) {
        this.salesorderheaders = salesorderheaders;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Txfrrqst txfrrqst = (Txfrrqst) o;

        if (cube != txfrrqst.cube) return false;
        if (actdeldate != null ? !actdeldate.equals(txfrrqst.actdeldate) : txfrrqst.actdeldate != null) return false;
        if (cancelby != null ? !cancelby.equals(txfrrqst.cancelby) : txfrrqst.cancelby != null) return false;
        if (cancelrsn != null ? !cancelrsn.equals(txfrrqst.cancelrsn) : txfrrqst.cancelrsn != null) return false;
        if (delvprof != null ? !delvprof.equals(txfrrqst.delvprof) : txfrrqst.delvprof != null) return false;
        if (delvreason != null ? !delvreason.equals(txfrrqst.delvreason) : txfrrqst.delvreason != null) return false;
        if (delwdwdate != null ? !delwdwdate.equals(txfrrqst.delwdwdate) : txfrrqst.delwdwdate != null) return false;
        if (desttype != null ? !desttype.equals(txfrrqst.desttype) : txfrrqst.desttype != null) return false;
        if (enddate != null ? !enddate.equals(txfrrqst.enddate) : txfrrqst.enddate != null) return false;
        if (inzstamp != null ? !inzstamp.equals(txfrrqst.inzstamp) : txfrrqst.inzstamp != null) return false;
        if (lotid != null ? !lotid.equals(txfrrqst.lotid) : txfrrqst.lotid != null) return false;
        if (noreprqd != null ? !noreprqd.equals(txfrrqst.noreprqd) : txfrrqst.noreprqd != null) return false;
        if (ordcontact != null ? !ordcontact.equals(txfrrqst.ordcontact) : txfrrqst.ordcontact != null) return false;
        if (ordertype != null ? !ordertype.equals(txfrrqst.ordertype) : txfrrqst.ordertype != null) return false;
        if (origin != null ? !origin.equals(txfrrqst.origin) : txfrrqst.origin != null) return false;
        if (origintype != null ? !origintype.equals(txfrrqst.origintype) : txfrrqst.origintype != null) return false;
        if (pickuprsn != null ? !pickuprsn.equals(txfrrqst.pickuprsn) : txfrrqst.pickuprsn != null) return false;
        if (program != null ? !program.equals(txfrrqst.program) : txfrrqst.program != null) return false;
        if (region != null ? !region.equals(txfrrqst.region) : txfrrqst.region != null) return false;
        if (repid != null ? !repid.equals(txfrrqst.repid) : txfrrqst.repid != null) return false;
        if (salesman != null ? !salesman.equals(txfrrqst.salesman) : txfrrqst.salesman != null) return false;
        if (scddeldate != null ? !scddeldate.equals(txfrrqst.scddeldate) : txfrrqst.scddeldate != null) return false;
        if (serialno != null ? !serialno.equals(txfrrqst.serialno) : txfrrqst.serialno != null) return false;
        if (shipwithno != null ? !shipwithno.equals(txfrrqst.shipwithno) : txfrrqst.shipwithno != null) return false;
        if (shpcontact != null ? !shpcontact.equals(txfrrqst.shpcontact) : txfrrqst.shpcontact != null) return false;
        if (skunumb != null ? !skunumb.equals(txfrrqst.skunumb) : txfrrqst.skunumb != null) return false;
        if (status != null ? !status.equals(txfrrqst.status) : txfrrqst.status != null) return false;
        if (territory != null ? !territory.equals(txfrrqst.territory) : txfrrqst.territory != null) return false;
        if (tocustid != null ? !tocustid.equals(txfrrqst.tocustid) : txfrrqst.tocustid != null) return false;
        if (tour != null ? !tour.equals(txfrrqst.tour) : txfrrqst.tour != null) return false;
        if (txfrrqstid != null ? !txfrrqstid.equals(txfrrqst.txfrrqstid) : txfrrqst.txfrrqstid != null) return false;
        if (updstamp != null ? !updstamp.equals(txfrrqst.updstamp) : txfrrqst.updstamp != null) return false;
        if (username != null ? !username.equals(txfrrqst.username) : txfrrqst.username != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = txfrrqstid != null ? txfrrqstid.hashCode() : 0;
        result = 31 * result + (shipwithno != null ? shipwithno.hashCode() : 0);
        result = 31 * result + (status != null ? status.hashCode() : 0);
        result = 31 * result + (ordertype != null ? ordertype.hashCode() : 0);
        result = 31 * result + (skunumb != null ? skunumb.hashCode() : 0);
        result = 31 * result + (lotid != null ? lotid.hashCode() : 0);
        result = 31 * result + (serialno != null ? serialno.hashCode() : 0);
        result = 31 * result + (tocustid != null ? tocustid.hashCode() : 0);
        result = 31 * result + (scddeldate != null ? scddeldate.hashCode() : 0);
        result = 31 * result + (delvreason != null ? delvreason.hashCode() : 0);
        result = 31 * result + (delwdwdate != null ? delwdwdate.hashCode() : 0);
        result = 31 * result + (actdeldate != null ? actdeldate.hashCode() : 0);
        result = 31 * result + (enddate != null ? enddate.hashCode() : 0);
        result = 31 * result + (pickuprsn != null ? pickuprsn.hashCode() : 0);
        result = 31 * result + (salesman != null ? salesman.hashCode() : 0);
        result = 31 * result + (tour != null ? tour.hashCode() : 0);
        result = 31 * result + (ordcontact != null ? ordcontact.hashCode() : 0);
        result = 31 * result + (repid != null ? repid.hashCode() : 0);
        result = 31 * result + (region != null ? region.hashCode() : 0);
        result = 31 * result + (territory != null ? territory.hashCode() : 0);
        result = 31 * result + (delvprof != null ? delvprof.hashCode() : 0);
        result = 31 * result + (shpcontact != null ? shpcontact.hashCode() : 0);
        result = 31 * result + cube;
        result = 31 * result + (noreprqd != null ? noreprqd.hashCode() : 0);
        result = 31 * result + (origin != null ? origin.hashCode() : 0);
        result = 31 * result + (cancelrsn != null ? cancelrsn.hashCode() : 0);
        result = 31 * result + (cancelby != null ? cancelby.hashCode() : 0);
        result = 31 * result + (origintype != null ? origintype.hashCode() : 0);
        result = 31 * result + (desttype != null ? desttype.hashCode() : 0);
        result = 31 * result + (inzstamp != null ? inzstamp.hashCode() : 0);
        result = 31 * result + (updstamp != null ? updstamp.hashCode() : 0);
        result = 31 * result + (program != null ? program.hashCode() : 0);
        result = 31 * result + (username != null ? username.hashCode() : 0);
        return result;
    }
}
