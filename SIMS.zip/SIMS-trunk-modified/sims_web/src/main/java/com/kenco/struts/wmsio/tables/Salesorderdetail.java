package com.kenco.struts.wmsio.tables;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name = "salesorderdetail")
public class Salesorderdetail implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SalesOrderDetailKey")
    private Integer salesOrderDetailKey;
    @Basic(optional = false)
    @Column(name = "SalesOrderHeaderKey")
    private int salesOrderHeaderKey;
    @Column(name = "SerialNumber")
    private String serialNumber;
    @Column(name = "ProductType")
    private String productType;
    @Column(name = "ProductCode")
    private String productCode;
    @Column(name = "ProductVariation")
    private String productVariation;
    @Basic(optional = false)
    @Column(name = "ProductDescription")
    private String productDescription;
    @Basic(optional = false)
    @Column(name = "OrderQuantity")
    private int orderQuantity;
    @Basic(optional = false)
    @Column(name = "Surface")
    private String surface;
    @Basic(optional = false)
    @Column(name = "SurfaceDescription")
    private String surfaceDescription;
    @Column(name = "SurfaceSerialNumber")
    private String surfaceSerialNumber;
    @Column(name = "SpecialInstructions")
    private String specialInstructions;
    @Basic(optional = false)
    @Column(name = "Created")
    @Temporal(TemporalType.TIMESTAMP)
    private Date created;
    @Basic(optional = false)
    @Column(name = "Updated", insertable = false, updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date updated;
    @Basic(optional = false)
    @Column(name = "UserName")
    private String userName;
    @Basic(optional = false)
    @Column(name = "ProgramName")
    private String programName;
    @Basic(optional = false)
    @Column(name = "SalesOpportunity")
    private BigDecimal salesOpportunity;
    @Basic(optional = false)
    @Column(name = "PurchaseOrderNumber")
    private String purchaseOrderNumber;

    public Integer getSalesOrderDetailKey() {
        return salesOrderDetailKey;
    }

    public void setSalesOrderDetailKey(Integer salesOrderDetailKey) {
        this.salesOrderDetailKey = salesOrderDetailKey;
    }

    public int getSalesOrderHeaderKey() {
        return salesOrderHeaderKey;
    }

    public void setSalesOrderHeaderKey(int salesOrderHeaderKey) {
        this.salesOrderHeaderKey = salesOrderHeaderKey;
    }

    public String getSerialNumber() {
        return serialNumber;
    }

    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getProductVariation() {
        return productVariation;
    }

    public void setProductVariation(String productVariation) {
        this.productVariation = productVariation;
    }

    public String getProductDescription() {
        return productDescription;
    }

    public void setProductDescription(String productDescription) {
        this.productDescription = productDescription;
    }

    public int getOrderQuantity() {
        return orderQuantity;
    }

    public void setOrderQuantity(int orderQuantity) {
        this.orderQuantity = orderQuantity;
    }

    public String getSurface() {
        return surface;
    }

    public void setSurface(String surface) {
        this.surface = surface;
    }

    public String getSurfaceDescription() {
        return surfaceDescription;
    }

    public void setSurfaceDescription(String surfaceDescription) {
        this.surfaceDescription = surfaceDescription;
    }

    public String getSurfaceSerialNumber() {
        return surfaceSerialNumber;
    }

    public void setSurfaceSerialNumber(String surfaceSerialNumber) {
        this.surfaceSerialNumber = surfaceSerialNumber;
    }

    public String getSpecialInstructions() {
        return specialInstructions;
    }

    public void setSpecialInstructions(String specialInstructions) {
        this.specialInstructions = specialInstructions;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public Date getUpdated() {
        return updated;
    }

    protected void setUpdated(Date updated) {
        this.updated = updated;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getProgramName() {
        return programName;
    }

    public void setProgramName(String programName) {
        this.programName = programName;
    }

    public BigDecimal getSalesOpportunity() {
        return salesOpportunity;
    }

    public void setSalesOpportunity(BigDecimal salesOpportunity) {
        this.salesOpportunity = salesOpportunity;
    }

    public String getPurchaseOrderNumber() {
        return purchaseOrderNumber;
    }

    public void setPurchaseOrderNumber(String purchaseOrderNumber) {
        this.purchaseOrderNumber = purchaseOrderNumber;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (salesOrderDetailKey != null ? salesOrderDetailKey.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Salesorderdetail)) {
            return false;
        }
        Salesorderdetail other = (Salesorderdetail) object;
        if ((this.salesOrderDetailKey == null && other.salesOrderDetailKey != null) || (this.salesOrderDetailKey != null && !this.salesOrderDetailKey.equals(other.salesOrderDetailKey))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.kenco.struts.wmsio.tables.Salesorderdetail[salesOrderDetailKey=" + salesOrderDetailKey + "]";
    }

}
