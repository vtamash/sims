package com.kenco.struts.wmsio.tables;

import com.kenco.sims.entity.Txfrrqst;
import com.kenco.sims.entity.Txrqstdtl;
import javax.persistence.*;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.util.*;

@Entity
@Table(name = "salesorderheader")
@XmlRootElement
public class Salesorderheader implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SalesOrderHeaderKey")
    private Integer salesOrderHeaderKey;
    @Column(name = "Status")
    private String status;
    @Basic(optional = false)
    @Column(name = "SalesRepID")
    private String salesRepID;
    @Column(name = "OwnerCode")
    private String ownerCode;
    @Basic(optional = false)
    @Column(name = "Email")
    private String email;
    @Basic(optional = false)
    @Column(name = "Phone")
    private String phone;
    @Column(name = "PhoneExtension")
    private String phoneExtension;
    @Column(name = "RDCID")
    private String rdcid;
    @Column(name = "RDCName")
    private String rDCName;
    @Column(name = "RDCMasterKey")
    private Integer rDCMasterKey;
    @Basic(optional = false)
    @Column(name = "OrderType")
    private String orderType;
    @Column(name = "ScheduledDate")
    @Temporal(TemporalType.DATE)
    private Date scheduledDate;
    @Column(name = "DeliveryDateReason")
    private String deliveryDateReason;
    @Column(name = "ScheduleOnDate")
    private Boolean scheduleOnDate;
    @Column(name = "ScheduleNoLaterThanDate")
    private Boolean scheduleNoLaterThanDate;
    @Column(name = "ScheduleASAPDate")
    private Boolean scheduleASAPDate;
    @Column(name = "ScheduledTime")
    @Temporal(TemporalType.TIME)
    private Date scheduledTime;
    @Column(name = "ScheduledTimeEnd")
    @Temporal(TemporalType.TIME)
    private Date scheduledTimeEnd;
    @Column(name = "PickupDate")
    @Temporal(TemporalType.DATE)
    private Date pickupDate;
    @Column(name = "PickupDateReason")
    private String pickupDateReason;
    @Column(name = "PickupTime")
    @Temporal(TemporalType.TIME)
    private Date pickupTime;
    @Column(name = "PickupDateTBD")
    private Boolean pickupDateTBD;
    @Column(name = "CustomerID")
    private String customerID;
    @Column(name = "CustomerName")
    private String customerName;
    @Column(name = "NewCustomer")
    private Boolean newCustomer;
    @Column(name = "Address")
    private String address;
    @Column(name = "City")
    private String city;
    @Column(name = "State")
    private String state;
    @Column(name = "ZipCode")
    private String zipCode;
    @Column(name = "Contact")
    private String contact;
    @Column(name = "ContactPhone")
    private String contactPhone;
    @Column(name = "ContactPhoneExtension")
    private String contactPhoneExtension;
    @Column(name = "ContactEmail")
    private String contactEmail;
    @Column(name = "SpecialInstructions")
    private String specialInstructions;
    @Column(name = "LiftGate")
    private Boolean liftGate;
    @Column(name = "Dock")
    private Boolean dock;
    @Column(name = "TractorTrailer")
    private Boolean tractorTrailer;
    @Column(name = "Emailed")
    @Temporal(TemporalType.TIMESTAMP)
    private Date emailed;
    @Basic(optional = false)
    @Column(name = "Created")
    @Temporal(TemporalType.TIMESTAMP)
    private Date created;
    @Basic(optional = false)
    @Column(name = "Updated", insertable = false, updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date updated;
    @Basic(optional = false)
    @Column(name = "UserName")
    private String userName;
    @Basic(optional = false)
    @Column(name = "ProgramName")
    private String programName;
    @Basic(optional = false)
    @Column(name = "Department")
    private String department;
    @Basic(optional = false)
    @Column(name = "Loaner")
    private Boolean loaner;
    @Basic(optional = false)
    @Column(name = "LegalNotice")
    private String legalNotice;
    @Basic(optional = false)
    @Column(name = "LegalAcknowledgement")
    private String legalAcknowledgement;

    @Column(name = "SHORTTRUCK_ID")
    private Integer shortTruckOptionId;

    @Column(name = "lockeduser")
    private String lockedUser;

    @Column(name = "lockedstamp")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lockedDate;

    @Transient
    private List<Txfrrqst> txfrrqsts;

    @OneToMany(mappedBy = "salesorderheader", fetch = FetchType.EAGER, cascade = CascadeType.REFRESH)
    private List<Txrqstdtl> txrqstdtls;

    public Salesorderheader() {}

    public Salesorderheader(Integer salesOrderHeaderKey) {
        this.salesOrderHeaderKey = salesOrderHeaderKey;
    }

    public Salesorderheader(Integer salesOrderHeaderKey, String salesRepID, String email, String phone, String orderType, Date created, Date updated, String userName, String programName) {
        this.salesOrderHeaderKey = salesOrderHeaderKey;
        this.salesRepID = salesRepID;
        this.email = email;
        this.phone = phone;
        this.orderType = orderType;
        this.created = created;
        this.updated = updated;
        this.userName = userName;
        this.programName = programName;
    }

    public Integer getSalesOrderHeaderKey() {
        return salesOrderHeaderKey;
    }

    public void setSalesOrderHeaderKey(Integer salesOrderHeaderKey) {
        this.salesOrderHeaderKey = salesOrderHeaderKey;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getSalesRepID() {
        return salesRepID;
    }

    public void setSalesRepID(String salesRepID) {
        this.salesRepID = salesRepID;
    }

    public String getOwnerCode() {
        return ownerCode;
    }

    public void setOwnerCode(String ownerCode) {
        this.ownerCode = ownerCode;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPhoneExtension() {
        return phoneExtension;
    }

    public void setPhoneExtension(String phoneExtension) {
        this.phoneExtension = phoneExtension;
    }

    public String getRdcid() {
        return rdcid;
    }

    public void setRdcid(String rdcid) {
        this.rdcid = rdcid;
    }

    public String getRDCName() {
        return rDCName;
    }

    public void setRDCName(String rDCName) {
        this.rDCName = rDCName;
    }

    public Integer getRDCMasterKey() {
        return rDCMasterKey;
    }

    public void setRDCMasterKey(Integer rDCMasterKey) {
        this.rDCMasterKey = rDCMasterKey;
    }

    public String getOrderType() {
        return orderType.trim();
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType.trim();
    }

    public Date getScheduledDate() {
        return scheduledDate;
    }

    public void setScheduledDate(Date scheduledDate) {
        this.scheduledDate = scheduledDate;
    }

    public String getDeliveryDateReason() {
        return deliveryDateReason;
    }

    public void setDeliveryDateReason(String deliveryDateReason) {
        this.deliveryDateReason = deliveryDateReason;
    }

    public Boolean getScheduleOnDate() {
        return scheduleOnDate;
    }

    public void setScheduleOnDate(Boolean scheduleOnDate) {
        this.scheduleOnDate = scheduleOnDate;
    }

    public Boolean getScheduleNoLaterThanDate() {
        return scheduleNoLaterThanDate;
    }

    public void setScheduleNoLaterThanDate(Boolean scheduleNoLaterThanDate) {
        this.scheduleNoLaterThanDate = scheduleNoLaterThanDate;
    }

    public Boolean getScheduleASAPDate() {
        return scheduleASAPDate;
    }

    public void setScheduleASAPDate(Boolean scheduleASAPDate) {
        this.scheduleASAPDate = scheduleASAPDate;
    }

    public Date getScheduledTime() {
        return scheduledTime;
    }

    public void setScheduledTime(Date scheduledTime) {
        this.scheduledTime = scheduledTime;
    }

    public Date getScheduledTimeEnd() {
        return scheduledTimeEnd;
    }

    public void setScheduledTimeEnd(Date scheduledTimeEnd) {
        this.scheduledTimeEnd = scheduledTimeEnd;
    }

    public Date getPickupDate() {
        return pickupDate;
    }

    public String getPickupDateReason() {
        return pickupDateReason;
    }

    public void setPickupDateReason(String pickupDateReason) {
        this.pickupDateReason = pickupDateReason;
    }

    public void setPickupDate(Date pickupDate) {
        this.pickupDate = pickupDate;
    }

    public Date getPickupTime() {
        return pickupTime;
    }

    public void setPickupTime(Date pickupTime) {
        this.pickupTime = pickupTime;
    }

    public Boolean getPickupDateTBD() {
        return pickupDateTBD;
    }

    public void setPickupDateTBD(Boolean pickupDateTBD) {
        this.pickupDateTBD = pickupDateTBD;
    }

    public String getCustomerID() {
        return customerID;
    }

    public void setCustomerID(String customerID) {
        this.customerID = customerID;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public Boolean getNewCustomer() {
        return newCustomer;
    }

    public void setNewCustomer(Boolean newCustomer) {
        this.newCustomer = newCustomer;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getContactPhone() {
        return contactPhone;
    }

    public void setContactPhone(String contactPhone) {
        this.contactPhone = contactPhone;
    }

    public String getContactPhoneExtension() {
        return contactPhoneExtension;
    }

    public void setContactPhoneExtension(String contactPhoneExtension) {
        this.contactPhoneExtension = contactPhoneExtension;
    }

    public String getContactEmail() {
        return contactEmail;
    }

    public void setContactEmail(String contactEmail) {
        this.contactEmail = contactEmail;
    }

    public String getSpecialInstructions() {
        return specialInstructions;
    }

    public void setSpecialInstructions(String specialInstructions) {
        this.specialInstructions = specialInstructions;
    }

    public Boolean getLiftGate() {
        return liftGate;
    }

    public void setLiftGate(Boolean liftGate) {
        this.liftGate = liftGate;
    }

    public Boolean getDock() {
        return dock;
    }

    public void setDock(Boolean dock) {
        this.dock = dock;
    }

    public Boolean getTractorTrailer() {
        return tractorTrailer;
    }

    public void setTractorTrailer(Boolean tractorTrailer) {
        this.tractorTrailer = tractorTrailer;
    }

    public Date getEmailed() {
        return emailed;
    }

    public void setEmailed(Date emailed) {
        this.emailed = emailed;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public Date getUpdated() {
        return updated;
    }

    protected void setUpdated(Date updated) {
        this.updated = updated;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getProgramName() {
        return programName;
    }

    public void setProgramName(String programName) {
        this.programName = programName;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public Boolean getLoaner() {
        return loaner;
    }

    public void setLoaner(Boolean loaner) {
        this.loaner = loaner;
    }

    public String getLegalNotice() {
        return legalNotice;
    }

    public void setLegalNotice(String legalNotice) {
        this.legalNotice = legalNotice;
    }

    public String getLegalAcknowledgement() {
        return legalAcknowledgement;
    }

    public void setLegalAcknowledgement(String legalAcknowledgement) {
        this.legalAcknowledgement = legalAcknowledgement;
    }

    public List<Txfrrqst> getTxfrrqsts() {
        return txfrrqsts;
    }

    public void setTxfrrqsts(List<Txfrrqst> txfrrqsts) {
        this.txfrrqsts = txfrrqsts;
    }

    public List<Txrqstdtl> getTxrqstdtls() {
        return txrqstdtls;
    }

    public void setTxrqstdtls(List<Txrqstdtl> txrqstdtls) {
        this.txrqstdtls = txrqstdtls;
    }

    public String getLockedUser() {
        return lockedUser;
    }

    public void setLockedUser(String lockedUser) {
        this.lockedUser = lockedUser;
    }

    public Date getLockedDate() {
        return lockedDate;
    }

    public void setLockedDate(Date lockedDate) {
        this.lockedDate = lockedDate;
    }

    public Integer getShortTruckOptionId() {
        return shortTruckOptionId;
    }

    public void setShortTruckOptionId(Integer shortTruckOptionId) {
        this.shortTruckOptionId = shortTruckOptionId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (salesOrderHeaderKey != null ? salesOrderHeaderKey.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Salesorderheader)) {
            return false;
        }
        Salesorderheader other = (Salesorderheader) object;
        if ((this.salesOrderHeaderKey == null && other.salesOrderHeaderKey != null) || (this.salesOrderHeaderKey != null && !this.salesOrderHeaderKey.equals(other.salesOrderHeaderKey))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.kenco.struts.wmsio.tables.Salesorderheader[ salesOrderHeaderKey=" + salesOrderHeaderKey + " ]";
    }
}
