package com.kenco.sims.domain;

public enum UserFunction {
    CANCELTRANSFER,
    OVERRIDEPICKUPDATE,
    SELECTNOREPREQUESTNEEDED,
    PLANCANADAREQUESTS,
    REP_IMPERSONATION
}
