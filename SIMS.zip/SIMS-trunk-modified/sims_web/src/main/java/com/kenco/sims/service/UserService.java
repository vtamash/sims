package com.kenco.sims.service;

import com.kenco.api.integration.domain.KencoClientCredential;
import com.kenco.api.security.domain.KencoUser;
import com.kenco.api.security.domain.UnAuthorizedKencoUser;
import com.kenco.api.security.service.KencoUserService;
import com.kenco.sims.domain.SIMSKencoUser;
import com.kenco.sims.domain.search.SearchResponse;
import com.kenco.sims.domain.search.impl.UserSearchRequest;
import com.kenco.sims.dto.UserDTO;
import com.kenco.sims.entity.User;
import com.kenco.sims.repository.RoleRepository;
import com.kenco.sims.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Business service for interactions with the {@code User} entity.
 *
 * Note: JSR-303 Bean Validation occurs automatically before any Spring-Managed Controllers receive the request.
 * The service tier is reserved for non-standard validations.
 *
 * @see com.kenco.sims.domain.search.impl.UserSearchRequest
 */
@Service
public class UserService implements KencoUserService, UserDetailsService {
    private static final Logger logger = LoggerFactory.getLogger(UserService.class);

    @Value("${app.context}")
    private String contextPath;

    @Autowired private UserRepository repository;
    @Autowired private RoleRepository roleRepository;

    /**
     * {@inheritDoc}
     */
    @Override
    public KencoUser retrieveKencoUser(String username) {
        logger.info(String.format("Authorizing Login Request for [%s]", username));
        User user;
        try {
            user = repository.readByEmail(username);
            logger.info(String.format("User [%s] Successfully Retrieved; Constructing User Details.", user));
        } catch (Exception e) {
            user = new User();
            logger.info(String.format("Error Retrieving Username [%s]; Denying Access.", username), e);
        }

        return (!user.isEnabled() || user.getRole() == null) ?
                new UnAuthorizedKencoUser(username) :
                new SIMSKencoUser(user);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void consumeAccessRequestMessage(KencoClientCredential credential) {
        logger.info("JMS Access Request Initiated.");
        if (!credential.getApplication().getSlug().equalsIgnoreCase(contextPath)) {
            logger.info(String.format("JMS Access Request; Ignoring Access Request for Client [%s: %s]", credential.getApplication().getSlug(), credential.getApplication().getName()));
        } else {
            logger.info(String.format("JMS Access Request; Creating User for Kenco User Account [%s]", credential.getAccount().getId()));
            User user = new User();
            user.setId(credential.getAccount().getId());
            user.setEmail(credential.getAccount().getUsername().toLowerCase());
            user.setUsername(generateUserName(credential).toUpperCase());
            user.setPhone(credential.getAccount().getProfile().getPhone());
            user.setFirstName(credential.getAccount().getProfile().getFirstName());
            user.setLastName(credential.getAccount().getProfile().getLastName());
            user.setCreator("System-JMS");
            user.setModifier("System-JMS");

            logger.info(String.format("JMS Access Request; User [%s] Built; Persisting.", user));
            repository.create(user);
        }
    }

    /**
     * Reads and fully initializes the {@code User} entity associated with the given {@code email}.
     *
     * @param email The email address for the {@code User} to be retrieved.
     * @return The fully initialized {@code User} entity.
     */
    @Transactional(readOnly = true)
    public User readFullyInitializedByEmail(String email) {
        logger.info(String.format("Service Request; Retrieving User For Email [%s].", email));
        final User user = repository.readByEmail(email);

        logger.info(String.format("Service Request; User [%s] Successfully Retrieved.", user));
        return user;
    }

    /**
     * Performs a search on the {@code User} entity with the given {@code SearchRequest}.
     *
     * @param request The {@code SearchRequest} containing the predicates for this search.
     * @return A {@code SearchResponse} instance containing the results and meta data for the response.
     */
    @Transactional(readOnly = true)
    public SearchResponse<UserDTO> search(UserSearchRequest request) {
        logger.info(String.format("Service Request; User Search Request; [%s]", request));
        final List<UserDTO> results = new ArrayList<>();
        for(User user: repository.read(request))
            results.add(new UserDTO(user));

        logger.trace(String.format("Service Request; User Search Request; [%s] User Results Found.", results.size()));
        long total = repository.getSearchTotal(request);

        logger.info(String.format("Service Request; [%s] of [%s] User Search Results Successfully Retrieved.", total, results.size()));
        return new SearchResponse<>(total, results);
    }

    /**
     * Updates the persistent {@code User} to the state contained within the given {@code UserDTO}.
     *
     * @param dto The {@code UserDTO} holding the state to which the persistent {@code User} entity should be updated.
     */
    @Transactional
    public void update(UserDTO dto) {
        logger.info(String.format("Service Request; User [%s] Update; Retrieving Persistent User.", dto.getId()));
        final User user = repository.readById(UUID.fromString(dto.getId()));

        if (dto.isEnabled() && dto.getHomeRdcId() == null && user.getRole()!=null && user.getRole().getName().equals("STRYKER_SIMS_SALESREP"))
            throw new IllegalStateException("Enabled STRYKER_SIMS_SALESREP must have a Home RDC Assigned to them.");

        logger.trace(String.format("Service Request; User [%s] Update; User Retrieved; Updating Values.", dto.getId()));
        user.setEnabled(dto.isEnabled());
        user.setModifier(SecurityContextHolder.getContext().getAuthentication().getName());
        user.setRole(roleRepository.readById(dto.getRoleId()));

        logger.info(String.format("Service Request; User [%s] Update; Values Updated; Persisting.", dto.getId()));
        repository.update(user);
    }

    /**
     * Generated User ID Values follow the following pattern:
     *
     * [First Initial][Last Initial][Left-Padded Local-User Row Count]
     */
    private String generateUserName(KencoClientCredential credential) {
        final String firstName    = credential.getAccount().getProfile().getFirstName().toUpperCase(),
                     firstInitial = firstName.substring(0,1),
                     lastName     = credential.getAccount().getProfile().getLastName().toUpperCase(),
                     lastInitial  = lastName.substring(0,1);

        String count = ((Long) repository.getSearchTotal(new UserSearchRequest(firstInitial + lastInitial))).toString();
        while (count.length() < 8)
            count = "0" + count;

        return firstInitial + lastInitial + count;
    }

    /**
     * Locates the user based on the username. In the actual implementation, the search may possibly be case
     * insensitive, or case insensitive depending on how the implementation instance is configured. In this case, the
     * <code>UserDetails</code> object that comes back may have a username that is of a different case than what was
     * actually requested..
     *
     * @param username the username identifying the user whose data is required.
     * @return a fully populated user record (never <code>null</code>)
     * @throws UsernameNotFoundException if the user could not be found or the user has no GrantedAuthority
     */
    @Override
    public KencoUser loadUserByUsername(String username) throws UsernameNotFoundException {
        return retrieveKencoUser(username);
    }
}
