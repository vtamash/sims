package com.kenco.sims.dto;

import com.kenco.sims.entity.Division;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Web representation of a {@code Division} entity.
 *
 * @see com.kenco.sims.entity.Division
 */
@XmlRootElement(name = "Division")
@XmlAccessorType(XmlAccessType.FIELD)
public class DivisionDTO {
    @XmlAttribute
    private Integer id;

    @XmlAttribute
    @NotNull(message = "must have a value.")
    @Length(min = 3, max = 64, message = "must be between 3 and 64 characters in length.")
    private String name;

    @XmlAttribute
    @NotNull(message = "must have a value.")
    @Length(min = 3, max = 64, message = "must be between 3 and 64 characters in length.")
    private String description;

    @XmlAttribute
    @NotNull(message = "must have a value.")
    @Length(min = 6, max = 128, message = "must be between 6 and 128 characters in length.")
    @Email(message = "must be a valid email address. (email@example.com)")
    private String email;

    @XmlAttribute
    @NotNull(message = "must have a value.")
    private boolean useSideTables;

    public DivisionDTO() {}

    public DivisionDTO(Division division) {
        id            = division.getId();
        name          = division.getName();
        description   = division.getDescription();
        email         = division.getEmail();
        useSideTables = division.isUseSideTables();
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public boolean isUseSideTables() {
        return useSideTables;
    }

    public void setUseSideTables(boolean useSideTables) {
        this.useSideTables = useSideTables;
    }
}
