package com.kenco.sims.repository;

import com.kenco.sims.domain.search.impl.SalesorderdetailSearchRequest;
import com.kenco.struts.wmsio.tables.Salesorderdetail;
import java.util.List;

public interface SalesorderdetailRepository extends PagingRepository<Salesorderdetail, SalesorderdetailSearchRequest> {
    Salesorderdetail create(Salesorderdetail soh);

    Salesorderdetail readBySalesOrderDetailKey(int salesOrderDetailKey);

    List<Salesorderdetail> findBySalesOrderHeaderKey(int salesOrderHeaderKey);

    List<Salesorderdetail> read(SalesorderdetailSearchRequest request);

    void update(Salesorderdetail soh);
}
