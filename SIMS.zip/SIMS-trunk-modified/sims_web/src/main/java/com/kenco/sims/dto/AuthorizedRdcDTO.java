package com.kenco.sims.dto;

import com.kenco.sims.entity.AuthorizedRdc;

import javax.validation.constraints.NotNull;

/**
 * Web representation of a {@code AuthorizedDivision} entity.
 *
 * @see com.kenco.sims.entity.AuthorizedRdc
 */
public class AuthorizedRdcDTO {
    @NotNull(message = "must have a value.")
    private Integer rdcId;

    @NotNull(message = "must have a value.")
    private String userId;

    private Integer id;
    private String username;
    private String rdcName;

    public AuthorizedRdcDTO() {}

    public AuthorizedRdcDTO(AuthorizedRdc rdc) {
        id       = rdc.getId();
        rdcId    = rdc.getRdc().getId();
        rdcName  = rdc.getRdc().getName();
        userId   = rdc.getUser().getId().toString();
        username = rdc.getUser().getUsername();
    }

    public Integer getRdcId() {
        return rdcId;
    }

    public void setRdcId(Integer rdcId) {
        this.rdcId = rdcId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getRdcName() {
        return rdcName;
    }

    public void setRdcName(String rdcName) {
        this.rdcName = rdcName;
    }
}
