package com.kenco.sims.oms.action;

import com.kenco.oms.entity.Vendors;
import com.kenco.oms.service.VendorsAbstractService;
import com.kenco.sims.oms.domain.VendorStub;
import com.kenco.sims.oms.service.impl.VendorsService;
import com.kenco.sims.oms.view.JsonView;
import com.kenco.struts.formbeans.WMSFormBean;
import com.kenco.struts.utilities.PojoMapper;
import json.org.JSONObject;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class VendorsAction extends Action {
	private static final Logger logger = LoggerFactory.getLogger(VendorsAction.class);

	private static final String SUCCESS = "success";

	/**
	 * Access point for and controls of the flow for each inbound (Vendors-related) request.
	 */
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		WMSFormBean wfb = (WMSFormBean) form;

		logger.info("USER: " + wfb.getUser() + " Starting execute() method");

		// Setup our Business Services.
		final VendorsService service  = new VendorsService();

		JsonView view = null;
		try {
			String action = request.getParameter("action");

			// Render the page.
			if (action == null)
				return renderStrut(request, wfb, mapping);

			// Create request.
			else if (request.getMethod().equals("POST") && action.equals("create"))
				view = new JsonView<Vendors>(create(request,wfb,service));

			// Read (all) request.
			else if (request.getMethod().equals("GET") && action.equals("read"))
				view = new JsonView<Vendors>(read(service, wfb));

			// Update request.
			else if (request.getMethod().equals("POST") && action.equals("update"))
				view = new JsonView<Vendors>(update(request, wfb, service));

			// Delete request.
			else if (request.getMethod().equals("POST") && action.equals("delete"))
				delete(request, service);

			// Unicity check - Name.
			else if (request.getMethod().equals("GET") && action.equals("checkName"))
				view = new JsonView<Map<String,Object>>(checkNameUnicity(service, request.getParameter("id"), request.getParameter("name")));

			// Unicity check - Number.
			else if (request.getMethod().equals("GET") && action.equals("checkNumber"))
				view = new JsonView<Map<String,Object>>(checkNumberUnicity(service, request.getParameter("id"), request.getParameter("number")));
		} catch (Exception e) {
			// Log the error.
			logger.error("Error processing Vendors-Action request: ", e);

			// Respond to the call negatively for user-feedback.
			view = new JsonView<Vendors>("There was an error proccessing this request.");
		}

		PrintWriter out = response.getWriter();
		out.print(PojoMapper.toJson(view, true));
		out.flush();
		out.close();

		logger.info("USER: " + wfb.getUser() + " Exiting execute() method");
		return null;
	}

	/**
	 * Performs a CREATE Operation on the provided Vendors object.
	 *
	 * !!This action is secured!!
	 */
	private Vendors create(HttpServletRequest request, WMSFormBean wfb, VendorsAbstractService service) throws Exception {
		return service.create(new Vendors(), wfb.getUser(), unmarshallStub(request));
	}

	/**
	 * Performs a READ operation on the VendorsService and returns a collection of Vendors entities Marshalled into JSON.
	 */
	private List<Vendors> read(VendorsAbstractService service, WMSFormBean wfb) throws Exception {
		return service.read(wfb.getOmsDefaultCustomerId());
	}

	/**
	 * Performs an UPDATE operation on the provided Vendors entity.
	 *
	 * !!This action is secured!!
	 */
	private Vendors update(HttpServletRequest request, WMSFormBean wfb, VendorsAbstractService service) throws Exception {
		return service.update(new Vendors(), wfb.getUser(), unmarshallStub(request));
	}

	/**
	 * Performs a DELETE operation on the provided Vendors entity.
	 *
	 * !!This action is secured!!
	 */
	private void delete(HttpServletRequest request, VendorsAbstractService service) throws Exception {
		// Retrieve the Vendors entity.
		Vendors vendor = service.readById(Integer.parseInt(request.getParameter("id")));

		// Perform our delete operation.
		service.delete(vendor);
	}

	/**
	 * If the ID (<i>Primary Key</i>) is, in any way, absent, this method performs a simple unicity check.  However,
	 * if there is an ID present, then we must compare the <b>name</b> for the entity belonging to the ID.  If they are
	 * the same, then we exempt the unicity check since it already owns the <b>name</b>.  However, if the <b>name</b>
	 * is different, we must still perform a simple unicity check.
	 */
	private Map<String,Object> checkNameUnicity(VendorsAbstractService service, String id, String name) {
		Map<String,Object> isUnique = new HashMap<String,Object>();

		if (id == null || id.trim().isEmpty() || id.trim().equalsIgnoreCase("null"))
			isUnique.put("unique", !service.existsByName(name));
		else
			isUnique.put("unique", service.readById(Integer.parseInt(id)).getName().equalsIgnoreCase(name.trim())
									|| !service.existsByName(name));

		return isUnique;
	}

	/**
	 * If the ID (<i>Primary Key</i>) is, in any way, absent, this method performs a simple unicity check.  However,
	 * if there is an ID present, then we must compare the <b>number</b> for the entity belonging to the ID.  If they are
	 * the same, then we exempt the unicity check since it already owns the <b>number</b>.  However, if the <b>number</b>
	 * is different, we must still perform a simple unicity check.
	 */
	private Map<String,Object> checkNumberUnicity(VendorsAbstractService service, String id, String number) {
		Map<String,Object> isUnique = new HashMap<String,Object>();

		if (id == null || id.trim().isEmpty() || id.trim().equalsIgnoreCase("null"))
			isUnique.put("unique", !service.existsByNumber(number));
		else
			isUnique.put("unique", service.readById(Integer.parseInt(id)).getVendornumber().equalsIgnoreCase(number.trim())
									|| !service.existsByNumber(number));

		return isUnique;
	}

	/**
	 * Forwards the caller to the proper JSP for interaction with Vendors.
	 *
	 * !!This action is secured!!
	 */
	private ActionForward renderStrut(HttpServletRequest request, WMSFormBean wfb, ActionMapping mapping) {
		wfb.resetJavascriptIncludes("appVendor.js"); // This gets used first.
		// wfb.appendJavascriptIncludes(); // This is what we need to use to add other JS to our jsp.
		logger.info("USER: " + wfb.getUser() + " Exiting execute() method");
		return mapping.findForward(SUCCESS);
	}

	/**
	 * Un-Marshalls a JSON String into a VendorStub object.
	 */
	private VendorStub unmarshallStub(HttpServletRequest request) throws Exception {
		JSONObject json   = new JSONObject(parseReader(request));
		JSONObject record = (JSONObject) json.get("records");

		VendorStub vendor = new VendorStub();
		vendor.setId(record.get("id") == JSONObject.NULL ? null : (Integer) record.get("id"));
		vendor.setCustomerId((Integer) record.get("customerId"));
		vendor.setActive((Boolean) record.get("active") ? (short) 1 : (short) 0);
		vendor.setName((String) record.get("name"));
		vendor.setNumber((String) record.get("number"));
		vendor.setAddress1((String) record.get("address1"));
		vendor.setAddress2((String) record.get("address2"));
		vendor.setAddress3((String) record.get("address3"));
		vendor.setCity((String) record.get("city"));
		vendor.setStateId((Integer) record.get("stateId"));
		vendor.setZip((String) record.get("zip"));
		return vendor;
	}

	/**
	 * Parses the HttpServletRequest's reader to get any POST Parameters that are present.
	 */
	private String parseReader(HttpServletRequest request) throws Exception {
		StringBuilder builder = new StringBuilder();

		BufferedReader reader = request.getReader();
		for (String curLine = reader.readLine(); curLine != null; curLine = reader.readLine())
			builder.append(curLine);

		return builder.toString();
	}
}
