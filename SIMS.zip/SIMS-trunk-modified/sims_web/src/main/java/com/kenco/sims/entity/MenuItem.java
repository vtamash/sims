package com.kenco.sims.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.xml.bind.annotation.*;
import java.util.*;

/**
 * Represents a single, assignable menu option with which a user may interact.
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class MenuItem {
    /**
     * Primary Key.
     */
    @XmlAttribute
    private UUID id;

    /**
     * Parent Entity's Primary Key.
     */
    @XmlAttribute
    private UUID parentId;

    /**
     * Denotes the order of appearance within the parent.
     */
    @XmlAttribute
    private int sequence;

    /**
     * Display Name.
     */
    @XmlAttribute
    private String name;

    /**
     * Struts Action to be taken.
     */
    @XmlAttribute
    private String action;

    /**
     * Name of the icon image file.
     */
    @XmlAttribute
    private String iconName;

    /**
     * The {@code Role} entities which have access to this {@code MenuItem}.
     */
    @JsonIgnore
    @XmlTransient
    private Set<Role> roles = new HashSet<>();

    /**
     * The {@code SimsUserFunction} entities which have access to this {@code MenuItem} if specified.
     */
    @JsonIgnore
    @XmlTransient
    private Map<String, Set<SimsUserFunction>> simsUserFunctions = new HashMap<>();

    @Override
    public boolean equals(Object obj) {
        return obj instanceof MenuItem &&
                getId().equals(((MenuItem) obj).getId());
    }

    @Override
    public int hashCode() {
        return getId().hashCode();
    }

    @Override
    public String toString() {
        return getId().toString();
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public UUID getParentId() {
        return parentId;
    }

    public void setParentId(UUID parentId) {
        this.parentId = parentId;
    }

    public int getSequence() {
        return sequence;
    }

    public void setSequence(int weight) {
        this.sequence = weight;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getIconName() {
        return iconName;
    }

    public void setIconName(String iconName) {
        this.iconName = iconName;
    }

    public Set<Role> getRoles() {
        return Collections.unmodifiableSet(roles);
    }

    protected void setRoles(Set<Role> roles) {
        this.roles = roles;
    }

    public void addRole(Role role) {
        roles.add(role);
    }

    public Map<String, Set<SimsUserFunction>> getSimsUserFunctions() {
        return simsUserFunctions;
    }

    protected void setSimsUserFunctions(Map<String, Set<SimsUserFunction>> simsUserFunctions) {
        this.simsUserFunctions = simsUserFunctions;
    }

    public void addSimsUserFunction(String role, SimsUserFunction simsUserFunction) {
        if (this.simsUserFunctions.get(role)==null)
            this.simsUserFunctions.put(role,new HashSet<SimsUserFunction>());
        this.simsUserFunctions.get(role).add(simsUserFunction);
    }
}
