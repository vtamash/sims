package com.kenco.sims.oms.action;

import com.kenco.oms.entity.Customers;
import com.kenco.oms.entity.Inboundorderdetail;
import com.kenco.oms.entity.Inboundorderheader;
import com.kenco.oms.search.InboundOrderSearchRequest;
import com.kenco.oms.service.impl.GenericCustomersService;
import com.kenco.oms.utilities.Enums;
import com.kenco.sims.oms.domain.InboundOrderStub;
import com.kenco.sims.oms.service.impl.InboundOrderService;
import com.kenco.sims.oms.service.impl.OmsDownloadService;
import com.kenco.sims.oms.service.impl.SystemValueService;
import com.kenco.sims.oms.view.JsonView;
import com.kenco.struts.formbeans.WMSFormBean;
import com.kenco.struts.utilities.InitServlet;
import com.kenco.struts.utilities.KencoEmailManager;
import com.kenco.struts.utilities.PojoMapper;
import json.org.JSONArray;
import json.org.JSONObject;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.context.SecurityContextHolder;

import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class InboundOrderAction extends Action {
	private static Logger logger = LoggerFactory.getLogger(InboundOrderAction.class);
	private final static String SUCCESS = "success";

	/**
	 * Access point for and controls of the flow for each inbound (InboundOrder-releated) request.
	 */
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		WMSFormBean wfb = (WMSFormBean) form;

		logger.info("USER: " + wfb.getUser() + " Starting execute() method");

		// Setup our Business Services.
		final GenericCustomersService cService = new GenericCustomersService(InitServlet.getEntityManagerFactory().createEntityManager());
		final SystemValueService      sService = new SystemValueService(InitServlet.getEntityManagerFactory().createEntityManager());
		final OmsDownloadService      dService = new OmsDownloadService(InitServlet.getEntityManagerFactory().createEntityManager());
		final InboundOrderService     service  = new InboundOrderService(InitServlet.getEntityManagerFactory().createEntityManager(), dService);

		JsonView<?> view;
		try {
			String action = request.getParameter("action");
			String bean   = request.getParameter("bean");

			// Render the page.
			if (action == null)
				return renderStrut(request, wfb, mapping);

			// Read Order Details.
			else if (request.getMethod().equals("GET") && action.equals("read") && bean != null && bean.equals("detail"))
				view = readDetails(request, service);

			// Send Product-Request email.
			else if (request.getMethod().equals("GET") && action.equals("product"))
				view = requestProduct(request, wfb, sService);

			// Order Search.
			else if (request.getMethod().equals("GET") && action.equals("search"))
				view = searchOrders(request, service, cService);

			// Search Order Numbers.
			else if (request.getMethod().equals("GET") && action.equals("searchNumbers"))
				view = new JsonView<>(searchOrderNumbers(request, service, cService));

			// Search Creators.
			else if (request.getMethod().equals("GET") && action.equals("searchCreators"))
				view = new JsonView<>(searchCreators(request, service, cService));

			// Search Ship-Tos.
			else if (request.getMethod().equals("GET") && action.equals("searchVendors"))
				view = new JsonView<>(searchVendors(request, service, cService));

			// Create / Update Order Header.
			else if (request.getMethod().equals("POST") && action.equals("update") && bean != null && bean.equals("header"))
				view = routeOrderHeaderRequest(request, wfb, service);

			// Delete Order Header.
			else if (request.getMethod().equals("POST") && action.equals("delete") && bean != null && bean.equals("header"))
				view = deleteOrderHeader(request, service);

			// Create / Update Order Detail.
			else if (request.getMethod().equals("POST") && action.equals("update") && bean != null && bean.equals("detail"))
				view = routeOrderDetailRequest(request, wfb, service);

			// Remove Order Detail.
			else if (request.getMethod().equals("POST") && action.equals("delete") && bean != null && bean.equals("detail"))
				view = removeOrderDetail(request, wfb, service);

			// Complete Order.
			else if (request.getMethod().equals("POST") && action.equals("complete"))
				view = completeOrder(request, service, wfb);

			// Catch-all for sanity.
			else
				throw new IllegalArgumentException("Invalid Action.");
		} catch (IllegalStateException ise) {
			logger.warn("Exception caught and handled:", ise);

			view = new JsonView(ise.getMessage());
		} catch (IllegalArgumentException iae) {
			logger.warn("Exception caught and handled:", iae);

			view = new JsonView(iae.getMessage());
		} catch (Exception e) {
			logger.error("Unexpected error encountered and handled:", e);

			view = new JsonView("There was an error processing this request.");
		}

		PrintWriter out = response.getWriter();
		out.print(PojoMapper.toJson(view, true));
		out.flush();
		out.close();

		logger.info("USER: " + wfb.getUser() + " Exiting execute() method");
		return null;
	}

	/**
	 * Forwards the caller to the proper JSP for interaction with Inbound Orders.
	 * <p/>
	 * !!This action is secured!!
	 */
	private ActionForward renderStrut(HttpServletRequest request, WMSFormBean wfb, ActionMapping mapping) {
		wfb.resetJavascriptIncludes("appInboundOrders.js"); // Use append after this.
		logger.info("USER: " + wfb.getUser() + " Exiting execute() method");
		return mapping.findForward(SUCCESS);
	}

	/**
	 * Reads the InboundOrderHeader entity for the provided ID (<b>Primary Key</b>) and returns its associated Collection
	 * of InboundOrderDetail entities.
	 *
	 * !!This action is secured!!
	 */
	private JsonView<Inboundorderdetail> readDetails(HttpServletRequest request, InboundOrderService service) {
		Inboundorderheader order = service.readById(Integer.parseInt(request.getParameter("inboundorderheaderId")));
		return new JsonView<>(order.getInboundorderdetailCollection());
	}

	/**
	 * Sends an email for a <i>Product Request</i>.
	 *
	 * !!This action is secured!!
	 */
	private JsonView requestProduct(HttpServletRequest request, WMSFormBean wfb, SystemValueService sService) throws Exception {
		Map<String, String> email   = sService.getEmailSubjectBody();
		KencoEmailManager   manager = new KencoEmailManager();

		String message = "";
		message += String.format(email.get("body"),
				                 wfb.getUser(),
				                 request.getParameter("product").toUpperCase(),
                                 SecurityContextHolder.getContext().getAuthentication().getName(),
				                 wfb.getEmail());
		message += "<br/><br/>";
		message += request.getParameter("message");

		Properties appWide   = (Properties) request.getSession().getServletContext().getAttribute("application_scope");
		String     recipient = sService.getStringValue(1, Enums.eSystemValues.NEW_SKU_EMAIL_INBOUND);
		manager.sendHTML(email.get("subject"),
		                 message,
		                 appWide.getProperty("emailsender"),
		                 new ArrayList<>(Collections.singletonList(recipient)),
		                 null);

		JsonView jsonView = new JsonView();
		jsonView.setSuccess(true);
		jsonView.setTotal(1);
		jsonView.setMessage("New Product Request email was sent.");
		return jsonView;
	}

	/**
	 * Updates the InboundOrderHeader that matches the provided ID (<b>Primary Key</b>) to have a status of "Complete."
	 *
	 * <b>Note</b>: This action will trigger an OmsDownload to be created.
	 *
	 * !!This action is secured!!
	 *
	 * @see com.kenco.oms.utilities.Enums.eOMSOrderStatus
	 * @see com.kenco.sims.oms.service.impl.OmsDownloadService
	 * @see com.kenco.oms.service.InboundOrderAbstractService
	 */
	private JsonView<Inboundorderheader> completeOrder(HttpServletRequest request, InboundOrderService service, WMSFormBean wfb) {
		Inboundorderheader order = service.readById(Integer.parseInt(request.getParameter("id")));
		order.setStatus(Enums.eOMSOrderStatus.C.toString());
		order.setUpdateprogram("InboundOrderModel.setOrderComplete");

		service.update(order, wfb.getUser());

		return new JsonView<>(order);
	}

	/**
	 * Apparently, both <i>CREATE</i> <b>and</b> <i>UPDATE</i> requests come in on the same URL.  We programatically
	 * determine which type of request we are dealing with based on the inbound <i>OrderNumber</i>.  Let's hope that
	 * this continues to work.  For the record - I didn't make this.  This is an attempt to clean things up a bit
	 * for read-ability and maintain-ability.  I don't have enough time to fix the frontend for now, so...good luck.
	 *
	 * !!This action is secured!!
	 */
	private JsonView<Inboundorderheader> routeOrderHeaderRequest(HttpServletRequest request, WMSFormBean wfb, InboundOrderService service) {
		String orderNumber = request.getParameter("orderNumber");
		if (orderNumber == null || orderNumber.trim().isEmpty() || orderNumber.equals("XXXXXXXX"))
			return createOrderHeader(request, wfb, service);
		else
			return updateOrderHeader(request, wfb, service);
	}

	/**
	 * Creates a new InboundOrderHeader after marshalling an InboundOrderStub.  Business logic resides in the
	 * InboundOrderService's Pre-Process method.
	 *
	 * !!This action is secured!!
	 *
	 * @see com.kenco.sims.oms.service.impl.InboundOrderService
	 */
	private JsonView<Inboundorderheader> createOrderHeader(HttpServletRequest request, WMSFormBean wfb, InboundOrderService service) {
		Inboundorderheader order = new Inboundorderheader();
		InboundOrderStub   stub  = marshallStub(request);

		return new JsonView<>(service.create(order, wfb.getUser(), stub));
	}

	/**
	 * Updates an InboundOrderHeader after Marshalling an InboundOrderStub.  Business logic resides in the InboundOrderService's
	 * Pre-Process method.
	 *
	 * !!This action is secured!!
	 *
	 * @see com.kenco.sims.oms.service.impl.InboundOrderService
	 */
	private JsonView<Inboundorderheader> updateOrderHeader(HttpServletRequest request, WMSFormBean wfb, InboundOrderService service) {
		Inboundorderheader order = service.readByName(request.getParameter("orderNumber"));
		InboundOrderStub   stub  = marshallStub(request);

		return new JsonView<>(service.update(order, wfb.getUser(), stub));
	}

	/**
	 * Deletes the InboundOrderHeader entity for the user-submitted ID.
	 *
	 * @throws IllegalArgumentException When the OrderHeader's ID cannot be parsed from the request.
	 */
	private JsonView deleteOrderHeader(HttpServletRequest request, InboundOrderService service) {
		try { service.delete(service.readById(Integer.parseInt(request.getParameter("id")))); }
		catch (NumberFormatException e) { throw new IllegalArgumentException("Order Header ID must be both present and numeric.", e); }

		JsonView view = new JsonView();
		view.setSuccess(true);
		return view;
	}

	/**
	 * The request to <b>CREATE</b> or <b>UDATE</b> an <i>InboundOrderDetail</i> entity is one and the same.  Therefore,
	 * we must find out - programatically - which operation the user is attempting to perform and then route it to the
	 * correct code.
	 *
	 * !!This action is secured!!
	 */
	private JsonView routeOrderDetailRequest(HttpServletRequest request, WMSFormBean wfb, InboundOrderService service) throws Exception {
		Inboundorderdetail detail = marshallOrderDetail(request);
		Inboundorderheader order  = service.readById(detail.getInboundorderheaderId().getId());

		return detail.getId() == null || detail.getId() == 0 ?
				createOrderDetail(order, detail, wfb, service) :
				updateOrderDetail(order, detail, wfb, service);
	}

	/**
	 * Creates an InboundOrderDetail for the user-submitted InboundOrderHeader.
	 *
	 * !!This action is secured!!
	 */
	private JsonView createOrderDetail(Inboundorderheader order, Inboundorderdetail detail, WMSFormBean wfb, InboundOrderService service) {
		service.addOrderDetail(order, detail, wfb.getUser());

		JsonView view = new JsonView();
		view.setSuccess(true);
		return view;
	}

	/**
	 * Updates an InboundOrderDetail for the user-submitted InboundOrderHeader.
	 *
	 * !!This action is secured!!
	 */
	private JsonView updateOrderDetail(Inboundorderheader order, Inboundorderdetail detail, WMSFormBean wfb, InboundOrderService service) {
		service.updateOrderDetail(order, detail, wfb.getUser());

		JsonView view = new JsonView();
		view.setSuccess(true);
		return view;
	}

	/**
	 * Removes an InboundOrderDetail for the user-submitted InboundOrderHeader.
	 *
	 * !!This action is secured!!
	 */
	private JsonView removeOrderDetail(HttpServletRequest request, WMSFormBean wfb, InboundOrderService service) throws Exception {
		Inboundorderdetail detail = marshallOrderDetail(request);
		Inboundorderheader order  = service.readById(detail.getInboundorderheaderId().getId());

		service.removeOrderDetail(order, detail, wfb.getUser());

		JsonView view = new JsonView();
		view.setSuccess(true);
		return view;
	}

	/**
	 * Performs the primary search and returns a Collection (page) of results that match the provided <i>SearchRequest</i>.
	 *
	 * !!This action is secured!!
	 */
	private JsonView<Inboundorderheader> searchOrders(HttpServletRequest request, InboundOrderService service, GenericCustomersService cService) throws Exception {
		InboundOrderSearchRequest search = marshallRequest(request, cService.readById(Integer.parseInt(request.getParameter("customerId"))));

		return new JsonView<>(service.readPage(search), service.readSearchTotal(search));
	}

	/**
	 * Performs a search of all InboundOrderHeaders based on the Order Number.
	 */
	private List<Map<String, Object>> searchOrderNumbers(HttpServletRequest request, InboundOrderService service, GenericCustomersService cService) throws Exception {
		// Parse out the Customer Id.
		Integer customerId = parseCustomerNumberFilter(request);

		// Read and return our entities.
		return service.searchOrderNumbers(request.getParameter("orderNumber"), cService.readById(customerId));
	}

	/**
	 * Performs a search of all InboundOrderHeaders based on the CreatedUserName.
	 */
	private List<Map<String, Object>> searchCreators(HttpServletRequest request, InboundOrderService service, GenericCustomersService cService) throws Exception {
		// Parse out the Customer Id.
		Integer customerId = parseCustomerNumberFilter(request);

		// Read and return our entities.
		return service.searchCreators(request.getParameter("creator"), cService.readById(customerId));
	}

	/**
	 * Performs a search of all InboundOrderHeaders based on the Ship-To Name.
	 */
	private List<Map<String, Object>> searchVendors(HttpServletRequest request, InboundOrderService service, GenericCustomersService cService) throws Exception {
		// Parse out the Customer Id.
		Integer customerId = parseCustomerNumberFilter(request);

		// Read and return our entities.
		return service.searchVendors(request.getParameter("name"), cService.readById(customerId));
	}

	/**
	 * Marshalls an InboundOrderStub.
	 */
	private InboundOrderStub marshallStub(HttpServletRequest request) {
		InboundOrderStub stub = new InboundOrderStub();

		stub.setNumber(request.getParameter("orderNumber"));

		// Customer (required).
		try { stub.setCustomerId(Integer.parseInt(request.getParameter("customerId"))); }
		catch (NumberFormatException e) { throw new IllegalArgumentException("Customer ID Must be both present and numeric."); }

		// Business Unit (required).
		try { stub.setBusinessUnitId(Integer.parseInt(request.getParameter("businessUnitId"))); }
		catch (NumberFormatException e) { throw new IllegalArgumentException("Business Unit ID Must be both present and numeric."); }

		// State (required).
		try { stub.setVendorStateId(Integer.parseInt(request.getParameter("state"))); }
		catch (NumberFormatException e) { throw new IllegalArgumentException("State ID Must be both present and numeric."); }

		// Scheduled Ship Date (required).
        Boolean noCheck = ( request.getParameter("noCheck")!=null && !request.getParameter("noCheck").isEmpty() && request.getParameter("noCheck").toLowerCase().equals("true") );
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
            Date date = sdf.parse(request.getParameter("sheduledShipDate"));
            if (!noCheck && date.compareTo(sdf.parse(sdf.format(new Date())))<0)
                throw new IllegalArgumentException("Scheduled Date must be later or equal than today's date.");
            stub.setScheduledShipDate(date);
        } catch (ParseException e) {
            throw new IllegalArgumentException("Scheduled Date must be presented and properly formatted (MM/DD/YYYY).");
        }

		String vendor = request.getParameter("vendor"); // Apparently, this could be either the ID or the Name.
		stub.setVendorId(vendor   == null || vendor.trim().isEmpty() || !vendor.matches("\\d+") ? null : Integer.parseInt(vendor));
		stub.setVendorName(vendor == null || vendor.trim().isEmpty() ||  vendor.matches("\\d+") ? null : vendor.toUpperCase());

		String address = request.getParameter("address");
		stub.setVendorAddress1(address == null || address.trim().isEmpty() ? null : address);

		String city = request.getParameter("city");
		stub.setVendorCity(city == null || city.trim().isEmpty() ? null : city);

		String zip = request.getParameter("zip");
		stub.setVendorZip(zip == null || zip.trim().isEmpty() ? null : zip);

		String scac = request.getParameter("scac");
		stub.setScac(scac == null || scac.trim().isEmpty() ? null : scac);

		String receiptType = request.getParameter("receiptType");
		stub.setReceiptType(receiptType == null || receiptType.trim().isEmpty() ? null : receiptType);

		String trailer = request.getParameter("trailer");
		stub.setTrailer(trailer == null || trailer.trim().isEmpty() ? null : trailer);

		return stub;
	}

	/**
	 * Marshalls a SearchRequest.
	 */
	private InboundOrderSearchRequest marshallRequest(HttpServletRequest request, Customers customer) throws Exception {
		InboundOrderSearchRequest search = new InboundOrderSearchRequest();
		search.setLimit(request.getParameter("limit").trim().isEmpty() ? null : Integer.parseInt(request.getParameter("limit")));
		search.setPage(request.getParameter("page").trim().isEmpty() ? null : Short.parseShort(request.getParameter("page")));
		search.setStart(request.getParameter("start").trim().isEmpty() ? null : Short.parseShort(request.getParameter("start")));

		search.setCustomer(customer);
		search.setNumber(request.getParameter("orderNumber").trim().isEmpty() ? null : request.getParameter("orderNumber"));
		search.setVendor(request.getParameter("vendor").trim().isEmpty() ? null : request.getParameter("vendor"));
		search.setCreator(request.getParameter("creator").trim().isEmpty() ? null : request.getParameter("creator"));

		return search;
	}

	/**
	 * Lifted exactly as it was.  I have neither the time nor the ability to test this right now, so - out of fear - I
	 * decided not to change this one at all because I'm not entirely certain of the syntax of the inbound request.
	 */
	private Inboundorderdetail marshallOrderDetail(HttpServletRequest request) throws Exception {
		ServletInputStream content = request.getInputStream();
		BufferedReader postBufferedReader = new BufferedReader(new InputStreamReader(content));
		StringBuilder records = new StringBuilder();
		String postline;
		while ((postline = postBufferedReader.readLine()) != null)
			records.append(postline);

		JSONObject jRecords = new JSONObject(records.toString());

		return (Inboundorderdetail) PojoMapper.fromJson((jRecords.get("records")).toString(), Inboundorderdetail.class);
	}

	/**
	 * Parses the "Filter" sent with the request to determine for which Customer to search.
	 */
	private Integer parseCustomerNumberFilter(HttpServletRequest request) throws Exception {
		// Parse the filter.
		JSONObject filter = (JSONObject) new JSONArray(request.getParameter("filter")).get(0);

		// Sanity check our filter.
		if (!filter.has("property") || filter.get("property") == null || !((String) filter.get("property")).equalsIgnoreCase("customerId"))
			throw new IllegalArgumentException("Invalid Search Filter - Customer ID must be present.");

		if (!filter.has("value") || filter.get("value") == null || ((String) filter.get("value")).trim().isEmpty())
			throw new IllegalArgumentException("Invalid Search Filter - Customer ID must be present.");

		return Integer.parseInt((String) filter.get("value"));
	}
}
