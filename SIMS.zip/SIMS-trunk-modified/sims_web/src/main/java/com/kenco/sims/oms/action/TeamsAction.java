package com.kenco.sims.oms.action;

import com.kenco.oms.entity.Teams;
import com.kenco.oms.search.TeamsSearchRequest;
import com.kenco.oms.service.TeamsAbstractService;
import com.kenco.sims.oms.domain.TeamStub;
import com.kenco.sims.oms.service.impl.TeamsService;
import com.kenco.sims.oms.view.JsonView;
import com.kenco.struts.formbeans.WMSFormBean;
import com.kenco.struts.utilities.PojoMapper;
import json.org.JSONObject;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

public class TeamsAction extends Action {
	private static final Logger logger = LoggerFactory.getLogger(TeamsAction.class);

	private final static String SUCCESS = "success";

	/**
	 * Access point for and controls of the flow for each inbound (Teams-related) request.
	 */
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		WMSFormBean wfb = (WMSFormBean) form;

		logger.info("USER: " + wfb.getUser() + " Starting execute() method");

		// Setup our Business Services.
		final TeamsAbstractService service = new TeamsService();

		JsonView view = null;
		try {
			String action = request.getParameter("action");

			// Render the page.
			if (action == null)
				return renderStrut(request, wfb, mapping);

			// Create request.
			else if (request.getMethod().equals("POST") && action.equals("create"))
				view = new JsonView<Teams>(create(request, wfb, service));

			// Search request.
			else if (request.getMethod().equals("GET") && action.equals("search"))
				view = search(request, service);

			// Update request.
			else if (request.getMethod().equals("POST") && action.equals("update"))
				view = new JsonView<Teams>(update(request, wfb, service));

			// Delete request.
			else if (request.getMethod().equals("POST") && action.equals("delete"))
				delete(request,wfb,service);

			// Unicity check - Name.
			else if (request.getMethod().equals("GET") && action.equals("checkName"))
				view = new JsonView<Map<String,Object>>(checkNameUnicity(service, request.getParameter("id"), request.getParameter("name")));
		} catch (IllegalArgumentException iae) {
			// Log the error.
			logger.error("Expected error caught and handled in TeamsAction: ", iae);

			// Respond to the call negatively for user-feedback.
			view = new JsonView<Teams>(iae.getMessage());
		} catch (Exception e) {
			// Log the error.
			logger.error("Unexpected error caught and handled in TeamsAction: ", e);

			// Respond to the call negatively for user-feedback.
			view = new JsonView<Teams>("There was an error processing this request.");
		}

		PrintWriter out = response.getWriter();
		out.print(PojoMapper.toJson(view, true));
		out.flush();
		out.close();

		logger.info("USER: " + wfb.getUser() + " Exiting execute() method");
		return null;
	}

	/**
	 * Forwards the caller to the proper JSP for interaction with Teams.
	 *
	 * !!This is a secured action!!
	 */
	private ActionForward renderStrut(HttpServletRequest request, WMSFormBean wfb, ActionMapping mapping) {
		wfb.resetJavascriptIncludes("appTeam.js"); // This gets used first.
		// wfb.appendJavascriptIncludes(); // This is what we need to use to add other JS to our jsp.
		logger.info("USER: " + wfb.getUser() + " Exiting execute() method");
		return mapping.findForward(SUCCESS);
	}

	/**
	 * Performs a CREATE Operation on the provided Teams object.
	 *
	 * !!This is a secured action!!
	 */
	private Teams create(HttpServletRequest request, WMSFormBean wfb, TeamsAbstractService service) throws Exception {
		return service.create(new Teams(), wfb.getUser(), unmarshallStub(request));
	}

	/**
	 * Performs a READ operation on the TeamsService and returns a collection of Teams entities Marshalled into JSON.
	 */
	private JsonView<Teams> search(HttpServletRequest request, TeamsAbstractService service) {
		TeamsSearchRequest search = unmarshallSearchRequest(request);

		return new JsonView<Teams>(service.search(search), service.readSearchTotal(search));
	}

	/**
	 * Performs an UPDATE operation on the provided Teams entity.
	 *
	 * !!This is a secured action!!
	 */
	private Teams update(HttpServletRequest request, WMSFormBean wfb, TeamsAbstractService service) throws Exception {
		TeamStub stub = unmarshallStub(request);
		Teams    team = service.readById(stub.getId());

		return service.update(team, wfb.getUser(), stub);
	}

	/**
	 * Performs a DELETE operation on the provided Teams entity.
	 *
	 * !!This is a secured action!!
	 */
	private void delete(HttpServletRequest request, WMSFormBean wfb, TeamsAbstractService service) {
		Teams team = service.readById(Integer.parseInt(request.getParameter("id")));

		service.delete(team, wfb.getUser());
	}

	/**
	 * If the ID (<i>Primary Key</i>) is, in any way, absent, this method performs a simple unicity check.  However,
	 * if there is an ID present, then we must compare the <b>name</b> for the entity belonging to the ID.  If they are
	 * the same, then we exempt the unicity check since it already owns the <b>name</b>.  However, if the <b>name</b>
	 * is different, we must still perform a simple unicity check.
	 */
	private Map<String,Object> checkNameUnicity(TeamsAbstractService service, String id, String name) {
		Map<String,Object> isUnique = new HashMap<String,Object>();

		if (id == null || id.trim().isEmpty() || id.trim().equalsIgnoreCase("null"))
			isUnique.put("unique", !service.existsByName(name));
		else
			isUnique.put("unique", service.readById(Integer.parseInt(id)).getTeam().equalsIgnoreCase(name.trim())
									|| !service.existsByName(name));

		return isUnique;
	}

	/**
	 * Un-Marshalls a JSON String into a TeamStub object.
	 */
	private TeamStub unmarshallStub(HttpServletRequest request) throws Exception {
		JSONObject json   = new JSONObject(parseReader(request));
		JSONObject record = (JSONObject) json.get("records");

		TeamStub team = new TeamStub();
		team.setId(record.get("id") == JSONObject.NULL ? null : (Integer) record.get("id"));
		team.setCustomerId((Integer) record.get("customerId"));
		team.setActive((Boolean) record.get("active") ? (short) 1 : (short) 0);
		team.setName((String) record.get("team"));
		return team;
	}

	/**
	 * Un-Marshalls a <i>TeamsSearchRequest</i> from the provided <i>HttpServletRequest</i>.  This should be used to
	 * perform search operations with the <i>TeamsService</i>.
	 */
	private TeamsSearchRequest unmarshallSearchRequest(HttpServletRequest request) {
		TeamsSearchRequest search = new TeamsSearchRequest();

		try { search.setPage(Short.parseShort(request.getParameter("page"))); }
		catch (NumberFormatException e) { throw new IllegalArgumentException("Page Parameter is required and must be numeric.", e); }

		try { search.setStart(Short.parseShort(request.getParameter("start"))); }
		catch (NumberFormatException e) { throw new IllegalArgumentException("Start Parameter is required and must be numeric.", e); }

		try { search.setLimit(Integer.parseInt(request.getParameter("limit"))); }
		catch (NumberFormatException e) { throw new IllegalArgumentException("Limit Parameter is required and must be numeric.", e); }

		try { search.setCustomerId(Integer.parseInt(request.getParameter("customerId"))); }
		catch (NumberFormatException e) { throw new IllegalArgumentException("Customer Id Parameter is required and must be numeric.", e); }

		String name = request.getParameter("name");
		search.setName(name == null || name.trim().isEmpty() ? null : name);

		String active = request.getParameter("active");
		search.setActive(active == null || active.trim().isEmpty() || !active.matches("\\d+") ? null : Integer.parseInt(active) == 1);

		String creator = request.getParameter("creator");
		search.setCreator(creator == null || creator.trim().isEmpty() ? null : creator.trim());

		String updater = request.getParameter("updater");
		search.setUpdater(updater == null || updater.trim().isEmpty() ? null : updater.trim());

		return search;
	}

	/**
	 * Parses the HttpServletRequest's reader to get any POST Parameters that are present.
	 */
	private String parseReader(HttpServletRequest request) throws Exception {
		StringBuilder builder = new StringBuilder();

		BufferedReader reader = request.getReader();
		for (String curLine = reader.readLine(); curLine != null; curLine = reader.readLine())
			builder.append(curLine);

		return builder.toString();
	}
}
