package com.kenco.sims.entity;

import java.io.Serializable;

public class TxrqstdtlPK implements Serializable {
    private static final long serialVersionUID = 49153L;

    private String txfrrqstId;

    private String salesId;

    public String getTxfrrqstId() {
        return txfrrqstId;
    }

    public void setTxfrrqstId(String txfrrqstId) {
        this.txfrrqstId = txfrrqstId;
    }

    public String getSalesId() {
        return salesId;
    }

    public void setSalesId(String salesId) {
        this.salesId = salesId;
    }
}
