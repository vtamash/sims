package com.kenco.struts.utilities;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.Properties;

public class PersistenceManager {

  private static Logger logger = LoggerFactory.getLogger(PersistenceManager.class);
  private static final PersistenceManager singleton = new PersistenceManager();
  protected EntityManagerFactory emf;

  public static PersistenceManager getInstance() {
    return singleton;
  }

  public PersistenceManager() {
  }

  /**
   * *
   *
   * @return @throws Exception
   */
  public EntityManagerFactory getEntityManagerFactory() throws Exception {

    if (emf == null) {
      logger.info("EntityManagerFactory is null....creating one.");

      Properties appWide = (Properties) InitServlet.getContext().getAttribute("application_scope");
      String PU = "sims_PU_" + appWide.getProperty("environment").toUpperCase().trim();

      // I know it's seems stupid but it will make sense to overcome NullPointerException working with HotSwap Java plugin ;-)
      try {
          this.emf = Persistence.createEntityManagerFactory(PU);
      } catch (NullPointerException e) {
          this.emf = Persistence.createEntityManagerFactory(PU);
      }

      logger.info("Created EntityManagerFactory for environment " + PU + ".");
    }

    return emf;
  }

  public void closeEntityManagerFactory() {
    if (emf != null) {
      emf.close();
      emf = null;
    }
  }
}
