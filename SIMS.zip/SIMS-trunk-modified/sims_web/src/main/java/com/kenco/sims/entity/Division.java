package com.kenco.sims.entity;

import com.kenco.sims.dto.DivisionDTO;
import javax.persistence.*;

/**
 * Persistent Entity;
 *
 * Represents a single division that can be assigned to a {@code User}.  {@code Division} entities represent a subset
 * of {@code User} entities within the a corporate organization - in this case, Stryker.
 *
 * @see com.kenco.sims.entity.User
 */
@Entity
@Table(schema = "SIMS_SYS", name = "DIVISIONS")
public class Division {
    /**
     * Primary Key;
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    /**
     * The name by which this is known.
     */
    @Column(name = "DIVISION", unique = true, nullable = false, length = 64)
    private String name;

    /**
     * A brief textual description of this {@code Division}.
     */
    @Column(name="DESCRIPTION", length=64)
    private String description;

    /**
     * Primary email address for contact.
     */
    @Column(name="EMAILADDRESS", length=128)
    private String email;

    /**
     * Whether or not this {@code Division} uses side-loaded integration data.
     */
    @Column(name="USESIDETABLES", nullable=false)
    private boolean useSideTables;

    public Division() {}

    public Division(DivisionDTO dto) {
        this.id = dto.getId();
        this.name = dto.getName();
        this.description = dto.getDescription();
        this.email = dto.getEmail();
    }

    @Override
    public String toString() {
        return getId().toString();
    }

    @Override
    public boolean equals(Object obj) {
        return obj instanceof Division &&
               getId().equals(((Division) obj).getId());
    }

    @Override
    public int hashCode() {
        return getId().hashCode();
    }

    public Integer getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public boolean isUseSideTables() {
        return useSideTables;
    }

    public void setUseSideTables(boolean useSideTables) {
        this.useSideTables = useSideTables;
    }
}