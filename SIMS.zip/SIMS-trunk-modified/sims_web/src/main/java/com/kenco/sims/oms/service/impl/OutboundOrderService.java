package com.kenco.sims.oms.service.impl;

import com.kenco.oms.entity.*;
import com.kenco.oms.service.OutboundOrderAbstractService;
import com.kenco.oms.service.impl.*;
import com.kenco.oms.utilities.Enums;
import com.kenco.sims.oms.domain.OutboundOrderStub;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.persistence.EntityManager;
import java.util.*;

/**
 * SIMS Implementation
 * SIMS Implementation of the <i>OutboundOrderAbstractService</i>.
 *
 * @see com.kenco.oms.service.OutboundOrderAbstractService
 * @see com.kenco.oms.service.OmsDownloadAbstractService
 * @see com.kenco.sims.oms.service.impl.OmsDownloadService
 */
public final class OutboundOrderService extends OutboundOrderAbstractService {
    private static Logger logger = LoggerFactory.getLogger(OutboundOrderService.class);

    private final GenericCustomersService cService;
	private final GenericShiptoCustomersService scService;
	private final GenericStatesService sService;
	private final GenericBusinessUnitsService bService;
	private final GenericShipToDeliveryLocationService dService;

	private class NoteComparator implements Comparator<Outboundordernotes> {
		@Override
		public int compare(Outboundordernotes note1, Outboundordernotes note2) {
			if(note1.getOutboundorderdetailId().getLine() < note2.getOutboundorderdetailId().getLine()) return -1;
			if(note1.getOutboundorderdetailId().getLine() == note2.getOutboundorderdetailId().getLine()) return 0;
			return 1;
		}
	}
	
    /**
     * Constructs an <i>OutboundOrderService</i> with the provided <i>EntityManager</i> and <i>OmsDownloadService</i>.
     * This services uses the provided <i>OmsDownloadService</i> for the triggered OmsDownload creation process.
     *
     * @see com.kenco.oms.service.OutboundOrderAbstractService
     * @see com.kenco.oms.service.OmsDownloadAbstractService
     * @see com.kenco.sims.oms.service.impl.OmsDownloadService
     */
    public OutboundOrderService(EntityManager em, OmsDownloadService downloadService) {
        super(em, downloadService);

		cService = new GenericCustomersService(em);
		scService = new GenericShiptoCustomersService(em);
		sService = new GenericStatesService(em);
		bService = new GenericBusinessUnitsService(em);
		dService = new GenericShipToDeliveryLocationService(em);
    }

    /**
     * SIMS Implementation: Prepends SIMS Specific prefix to the "next" order number.
     */
    @Override
    public String getNextOutboundOrderNumberPostProcess(String orderNumber, Object... args) {
        return getOutboundOrderPrefix((Integer) args[0]).trim() + orderNumber;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Outboundorderheader createPreProcess(Outboundorderheader order, Object... args) {

		if (args == null || args.length < 2 || !(args[1] instanceof OutboundOrderStub))
			throw new IllegalArgumentException("Insufficient parameters to create OutboundOrderHeader!");

		OutboundOrderStub stub = (OutboundOrderStub) args[1];

		order.setCustomerId(cService.readById(stub.getCustomerId()));
		order.setBusinessunitId(bService.readById(stub.getBusinessUnitId()));

		order.setOrdernumber(getNextOutboundOrderNumber(stub.getCustomerId()));
		order.setOrdertype(stub.getOrdertype());
		order.setRouted(stub.getRouted());
		order.setScac(stub.getScac());
		order.setFreightterms(stub.getFreightterms());
		order.setStatus(Enums.eOMSOrderStatus.P.toString());
		order.setScheduleddeparturedate(stub.getScheduledShipDate());
		order.setScheduleddeparturetime(stub.getScheduledShipTime());

		// Ship-to Customer
		Shiptocustomers shipto = getShiptocustomer(stub);
		order.setShiptocustomerId(shipto.getId()==null? null: shipto);
		order.setShiptoaddress1(shipto.getAddress1());
		order.setShiptoaddress2(shipto.getAddress2());
		order.setShiptoaddress3(shipto.getAddress3());
		order.setShiptocity(shipto.getCity());
		order.setShiptoname(shipto.getName());
		order.setShiptonumber(shipto.getShiptocustomernumber());
		order.setShiptostateId(shipto.getState());
		order.setShiptozip(shipto.getZipcode());

		return order;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Outboundorderheader updatePreProcess(Outboundorderheader order, Object... args) {
		if (args == null || args.length < 1 || !(args[0] instanceof String))
			throw new IllegalArgumentException("Insufficient parameters to create OutboundOrderHeader!");
		
		String username = (String) args[0];

		if (args == null || args.length < 2 || !(args[1] instanceof OutboundOrderStub) && args[1]!=null)
			throw new IllegalArgumentException("Insufficient parameters to update OutboundOrderHeader!");

		if (args[1]==null)
			return order;

		OutboundOrderStub stub = (OutboundOrderStub) args[1];
		
		order.setCustomerId(cService.readById(stub.getCustomerId()));
		order.setBusinessunitId(bService.readById(stub.getBusinessUnitId()));

		order.setOrdernumber(stub.getNumber());
		order.setOrdertype(stub.getOrdertype());
		order.setRouted(stub.getRouted());
		order.setScac(stub.getScac());
		order.setFreightterms(stub.getFreightterms());
		order.setStatus(Enums.eOMSOrderStatus.P.toString());
		order.setScheduleddeparturedate(stub.getScheduledShipDate());
		order.setScheduleddeparturetime(stub.getScheduledShipTime());

		// Ship-to Customer
		Shiptocustomers shipto = getShiptocustomer(stub);
		order.setShiptocustomerId(shipto.getId()==null? null: shipto);
		order.setShiptoaddress1(shipto.getAddress1());
		order.setShiptoaddress2(shipto.getAddress2());
		order.setShiptoaddress3(shipto.getAddress3());
		order.setShiptocity(shipto.getCity());
		order.setShiptoname(shipto.getName());
		order.setShiptonumber(shipto.getShiptocustomernumber());
		order.setShiptostateId(shipto.getState());
		order.setShiptozip(shipto.getZipcode());

		for (Outboundordernotes outboundordernote : order.getOutboundordernotesCollection()) {
			if (outboundordernote.getSequence()==(short)1 && outboundordernote.getNotetype().equals("DELVLOCT")) {
				Shiptodeliverylocations shiptodeliverylocation = getShiptoDeliveryLocation(stub);

				outboundordernote.setNote("Delivery Location : "+shiptodeliverylocation.getDeliverylocation());
				
				outboundordernote.setUpdateprogram("OutboundOrderService.updatePostProcess()");
				outboundordernote.setUpdatetimestamp(new Date());
				outboundordernote.setUpdateusername(username);

				break;
			}
		}
		
		return order;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Outboundorderheader deletePreProcess(Outboundorderheader outboundorderheader, Object... args) {
        return outboundorderheader;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Outboundorderheader createPostProcess(Outboundorderheader order, Object... args) {
		if (args == null || args.length < 1 || !(args[0] instanceof String))
			throw new IllegalArgumentException("Insufficient parameters to create OutboundOrderHeader!");
		
		String username = (String) args[0];

		if (args == null || args.length < 2 || !(args[1] instanceof OutboundOrderStub))
			throw new IllegalArgumentException("Insufficient parameters to create OutboundOrderHeader!");

		OutboundOrderStub stub = (OutboundOrderStub) args[1];

		Shiptodeliverylocations shiptodeliverylocation = getShiptoDeliveryLocation(stub);
		Outboundordernotes outboundordernote = new Outboundordernotes();
		outboundordernote.setOutboundorderheaderId(order);
		outboundordernote.setNotetype("DELVLOCT");
		outboundordernote.setNote("Delivery Location : "+shiptodeliverylocation.getDeliverylocation());
		outboundordernote.setSequence((short) 1);
		outboundordernote.setCreateprogram("OutboundOrderService.createPostProcess()");
		outboundordernote.setCreatetimestamp(new Date());
		outboundordernote.setCreateusername(username);
		outboundordernote.setUpdateprogram("OutboundOrderService.createPostProcess()");
		outboundordernote.setUpdatetimestamp(new Date());
		outboundordernote.setUpdateusername(username);

		order.getOutboundordernotesCollection().add(outboundordernote);
		
		order = update(order, username, null);

        return order;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public List<Outboundorderheader> readPostProcess(List<Outboundorderheader> list, Object... args) {
        return list;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Outboundorderheader readSinglePostProcess(Outboundorderheader t, Object... args) {
        return t;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Outboundorderheader updatePostProcess(Outboundorderheader order, Object... args) {
        return order;
    }

	/**
	 * Apparently, we allow users to set <i>Vendor</i> information for when they want to chose a <i>Vendor</i> that
	 * isn't in the <i>Vendor</i> table.  Unsure why we can't allow them to insert a record since we are inserting a
	 * <i>de facto</i> <i>Vendor</i> at this point.
	 */
	private Shiptocustomers getShiptocustomer(OutboundOrderStub stub) {
		if (stub.getShipToCustomerId() == null) {
			Shiptocustomers shiptocustomer = new Shiptocustomers();
			shiptocustomer.setName(stub.getShipToCustomerName());
			shiptocustomer.setAddress1(stub.getShipToCustomerAddress());
			shiptocustomer.setCity(stub.getShipToCustomerCity());
			shiptocustomer.setState(sService.readById(stub.getShipToCustomerStateId()));
			shiptocustomer.setZipcode(stub.getShipToCustomerZip());
			return shiptocustomer;
		}

		return scService.readById(stub.getShipToCustomerId());
	}

	/**
	 * Apparently, we allow users to set <i>Vendor</i> information for when they want to chose a <i>Vendor</i> that
	 * isn't in the <i>Vendor</i> table.  Unsure why we can't allow them to insert a record since we are inserting a
	 * <i>de facto</i> <i>Vendor</i> at this point.
	 */
	private Shiptodeliverylocations getShiptoDeliveryLocation(OutboundOrderStub stub) {
		if (stub.getDeliveryId() == null) {
			Shiptodeliverylocations shiptodeliverylocation = new Shiptodeliverylocations();
			shiptodeliverylocation.setDeliverylocation(stub.getDeliveryName());
			return shiptodeliverylocation;
		}

		return dService.readById(stub.getDeliveryId());
	}

	/**
	 * SIMS Business logic to add an OrderDetail.
	 *
	 * <b>Note</b>: This should probably be abstracted at some point.
	 */
	public Outboundorderdetail addOrderDetail(Outboundorderheader order, Outboundorderdetail detail, Collection<Outboundordernotes> notes, String username) {
		detail.setCreatetimestamp(new Date());
		detail.setCreateusername(username);
		detail.setCreateprogram("OutboundOrderService.addOrderDetail");
		detail.setUpdateprogram("OutboundOrderService.updateOrderDetail");
		detail.setUpdateusername(username);

		detail.setOutboundorderheaderId(order);

		for (Outboundordernotes note : notes) {
			note.setCreatetimestamp(new Date());
			note.setCreateusername(username);
			note.setCreateprogram("OutboundOrderService.addOrderDetail");
			note.setUpdateprogram("OutboundOrderService.updateOrderDetail");
			note.setUpdateusername(username);
		}

		order.getOutboundorderdetailCollection().add(detail);
		
		order = update(order, username, null);
		
		for (Outboundorderdetail dtl : order.getOutboundorderdetailCollection())
			if (dtl.getLine()==detail.getLine() && dtl.getProductcode().equals(detail.getProductcode())) {
				detail = dtl;
				break;
			}

		short i = 0;
		for (Outboundordernotes note : order.getOutboundordernotesCollection())
			if (note.getSequence()<1000 && note.getSequence()>i) i = note.getSequence();

		for (Outboundordernotes note : notes) {
			note.setOutboundorderdetailId(detail);
			note.setOutboundorderheaderId(order);
			note.setSequence(++i);
		}
		
		detail.getOutboundordernotesCollection().addAll(notes);
		order.getOutboundordernotesCollection().addAll(notes);

		update(order, username, null);

		return detail;
	}

	/**
	 * SIMS Business logic to update an OrderDetail.
	 *
	 * <b>Note</b>: This should probably be abstracted at some point.
	 */
	public Outboundorderdetail updateOrderDetail(Outboundorderheader order, Outboundorderdetail detail, Collection<Outboundordernotes> notes, String username) {
		Map<Integer, Object> map = new HashMap<Integer, Object>();
		for (Outboundordernotes note : notes)
			map.put(note.getId(), note);

		for (Outboundorderdetail curDetail : order.getOutboundorderdetailCollection()) {
			if (curDetail.getId().equals(detail.getId())) {
				curDetail.setProductcode(detail.getProductcode());
				curDetail.setOrderquantity(detail.getOrderquantity());
//				curDetail.setLotid(detail.getLotid());
				curDetail.setUpdateprogram("OutboundOrderService.updateOrderDetail");
				curDetail.setUpdateusername(username);

				Collection<Outboundordernotes> rNotes = new ArrayList<Outboundordernotes>();

				if (map.isEmpty()) {
					if (curDetail.getOutboundordernotesCollection()!=null) {
						for (Outboundordernotes note : curDetail.getOutboundordernotesCollection()) {
							note.setOutboundorderdetailId(null);
							note.setOutboundorderheaderId(null);
							rNotes.add(note);
						}
						curDetail.getOutboundordernotesCollection().clear();
						order.getOutboundordernotesCollection().removeAll(rNotes);
					}
				} else {
					if (curDetail.getOutboundordernotesCollection()==null)
						curDetail.setOutboundordernotesCollection(new ArrayList<Outboundordernotes>());
					if (curDetail.getOutboundordernotesCollection().isEmpty()) {
						for (Outboundordernotes note : notes) {
							note.setCreateprogram("OutboundOrderService.updateOrderDetail");
							note.setCreatetimestamp(new Date());
							note.setCreateusername(username);
							note.setUpdateprogram("OutboundOrderService.updateOrderDetail");
							note.setUpdateusername(username);
							note.setOutboundorderdetailId(curDetail);
							note.setOutboundorderheaderId(order);

							curDetail.getOutboundordernotesCollection().add(note);
							order.getOutboundordernotesCollection().add(note);
						}
					} else {
						for (Outboundordernotes note : curDetail.getOutboundordernotesCollection()) {
							if (map.get(note.getId())!=null) {
								note.setUpdateprogram("OutboundOrderService.updateOrderDetail");
								note.setUpdateusername(username);
								note.setNote(((Outboundordernotes)map.get(note.getId())).getNote());
								note.setNotetype(((Outboundordernotes)map.get(note.getId())).getNotetype());
								note.setQuantity(((Outboundordernotes)map.get(note.getId())).getQuantity());
								note.setSequence(((Outboundordernotes)map.get(note.getId())).getSequence());
							} else 
								rNotes.add(note);
						}
						curDetail.getOutboundordernotesCollection().removeAll(rNotes);
						order.getOutboundordernotesCollection().removeAll(rNotes);
						map.clear();
						for (Outboundordernotes note : curDetail.getOutboundordernotesCollection())
							map.put(note.getId(), note);
						for (Outboundordernotes note : notes)
							if (map.get(note.getId())==null) {
								note.setCreateprogram("OutboundOrderService.updateOrderDetail");
								note.setCreatetimestamp(new Date());
								note.setCreateusername(username);
								note.setUpdateprogram("OutboundOrderService.updateOrderDetail");
								note.setUpdateusername(username);
								note.setOutboundorderdetailId(curDetail);
								note.setOutboundorderheaderId(order);

								curDetail.getOutboundordernotesCollection().add(note);
								order.getOutboundordernotesCollection().add(note);
							}
					}
				}
				break;
			}
		}

		Comparator<Outboundordernotes> comparator = new NoteComparator();
		List<Outboundordernotes> noteList = new ArrayList<Outboundordernotes>();
		for (Outboundordernotes note : order.getOutboundordernotesCollection())
			if (note.getOutboundorderdetailId()!=null)
				noteList.add(note);
		Collections.sort(noteList, comparator);
		short i = 1;
		map.clear();
		for (Outboundordernotes note : noteList)
			map.put(note.getId(), ++i);
		
		for (Outboundordernotes note : order.getOutboundordernotesCollection())
			if (note.getOutboundorderdetailId()!=null)
				note.setSequence((Short)map.get(note.getId()));
		
		update(order, username, null);

		return detail;
	}

	/**
	 * SIMS Business logic to add an OrderNote.
	 *
	 * <b>Note</b>: This should probably be abstracted at some point.
	 */
	public Outboundordernotes addOrderNote(Outboundorderheader order, Outboundordernotes note, String username) {
		note.setCreatetimestamp(new Date());
		note.setCreateusername(username);
		note.setCreateprogram("OutboundOrderService.addOrderNote");
		note.setUpdateprogram("OutboundOrderService.updateOrderNote");
		note.setUpdateusername(username);

		if (note.getOutboundorderdetailId()!=null && (note.getOutboundorderdetailId().getId()==null || note.getOutboundorderdetailId().getId()==0))
			note.setOutboundorderdetailId(null);
			
		note.setOutboundorderheaderId(order);
		order.getOutboundordernotesCollection().add(note);

		update(order, username, null);

		return note;
	}

	/**
	 * SIMS Business logic to update an OrderNote.
	 *
	 * <b>Note</b>: This should probably be abstracted at some point.
	 */
	public Outboundordernotes updateOrderNote(Outboundorderheader order, Outboundordernotes note, String username) {
		for (Outboundordernotes curNote : order.getOutboundordernotesCollection())
			if (curNote.getId().equals(note.getId())) {
				curNote.setNote(note.getNote());
				curNote.setNotetype(note.getNotetype());
				curNote.setQuantity(note.getQuantity());
				curNote.setUpdateprogram("OutboundOrderService.updateOrderNote");
				curNote.setUpdateusername(username);
				break;
			}

		update(order, username, null);

		return note;
	}

	public void removeOrderDetail(Outboundorderheader order, Outboundorderdetail detail, String username) {
		Collection<Outboundordernotes> removeNotes = new ArrayList<Outboundordernotes>();
		for (Outboundorderdetail curDetail : order.getOutboundorderdetailCollection()) {
			if (curDetail.getId().equals(detail.getId())) {
				for (Outboundordernotes note : curDetail.getOutboundordernotesCollection()) {
					note.setOutboundorderdetailId(null);
					note.setOutboundorderheaderId(null);
					removeNotes.add(note);
				}
				curDetail.getOutboundordernotesCollection().clear();
				break;
			}
		}
		order.getOutboundordernotesCollection().removeAll(removeNotes);

		TreeMap<Short, Short> dMap = new TreeMap<Short, Short>();

		for (Outboundorderdetail curDetail : order.getOutboundorderdetailCollection())
			if (curDetail.getId().equals(detail.getId())) {
				curDetail.setOutboundorderheaderId(null);
				detail = curDetail;
			} else
				dMap.put(curDetail.getLine(), (short) 0);

		order.getOutboundorderdetailCollection().remove(detail);

		short i = 0;
		for (short key : dMap.keySet()) dMap.put(key, ++i);
		for (Outboundorderdetail curDetail : order.getOutboundorderdetailCollection())
			curDetail.setLine(dMap.get(curDetail.getLine()));

		Comparator<Outboundordernotes> comparator = new NoteComparator();
		List<Outboundordernotes> noteList = new ArrayList<Outboundordernotes>();
		for (Outboundordernotes note : order.getOutboundordernotesCollection())
			if (note.getOutboundorderdetailId()!=null)
				noteList.add(note);
		Collections.sort(noteList, comparator);
		i = 1;
		Map<Integer, Short> map = new HashMap<Integer, Short>();
		for (Outboundordernotes note : noteList)
			map.put(note.getId(), ++i);
		
		for (Outboundordernotes note : order.getOutboundordernotesCollection())
			if (note.getOutboundorderdetailId()!=null)
				note.setSequence(map.get(note.getId()));

		update(order, username, null);
	}

	/**
	 * SIMS Business logic to delete an OrderNote.
	 *
	 * <b>Note</b>: This should probably be abstracted at some point.
	 */
	public void deleteOrderNote(Outboundorderheader order, Outboundordernotes note, String username) {
		Outboundorderdetail detail = note.getOutboundorderdetailId();
		note.setOutboundorderdetailId(null);
		note.setOutboundorderheaderId(null);

		order.getOutboundordernotesCollection().remove(note);
		if (detail.getOutboundordernotesCollection()!=null)
			detail.getOutboundordernotesCollection().remove(note);

		update(order, username, null);
	}
}
