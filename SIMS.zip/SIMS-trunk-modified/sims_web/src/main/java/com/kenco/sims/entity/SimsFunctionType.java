package com.kenco.sims.entity;

public enum SimsFunctionType {
    USER,
    DIVISION
}
