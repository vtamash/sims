package com.kenco.sims.oms.action;

import com.kenco.oms.entity.Customers;
import com.kenco.oms.jdbc.model.WesInboundOrder;
import com.kenco.oms.search.WesInboundSearchRequest;
import com.kenco.oms.service.impl.GenericCustomersService;
import com.kenco.oms.service.impl.GenericSystemValuesService;
import com.kenco.oms.service.impl.GenericWesInboundOrderService;
import com.kenco.oms.utilities.Enums;
import com.kenco.sims.oms.view.JsonView;
import com.kenco.struts.formbeans.WMSFormBean;
import com.kenco.struts.utilities.InitServlet;
import com.kenco.struts.utilities.PojoMapper;
import json.org.JSONArray;
import json.org.JSONObject;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.util.Date;
import java.util.List;
import java.util.Map;

public class WesInboundOrderAction extends Action {
    private static final Logger logger = LoggerFactory.getLogger(WesInboundOrderAction.class);

    /**
     * Access point for and controls of the flow for each inbound (OrderHeader-releated) request.
     */
    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
        WMSFormBean wfb = (WMSFormBean) form;

        logger.info("USER: " + wfb.getUser() + " Starting execute() method");

        // Setup our Business Services.
        final GenericWesInboundOrderService service = new GenericWesInboundOrderService(InitServlet.getDataSource());
        final GenericCustomersService cService = new GenericCustomersService(InitServlet.getEntityManagerFactory().createEntityManager());
        final GenericSystemValuesService vService = new GenericSystemValuesService(InitServlet.getEntityManagerFactory().createEntityManager());

        // Route the request.
        JsonView view;
        try {
            String action = request.getParameter("action");

            // Render the page.
            if (action == null)
                throw new IllegalArgumentException("Invalid Action.");

                // Order Search.
            else if (request.getMethod().equals("GET") && action.equals("search"))
                view = searchOrders(request, service, cService, vService);

                // Search by Order Number.
            else if (request.getMethod().equals("GET") && action.equals("searchByNumber"))
                view = new JsonView<>(searchByOrderNumber(request, service, cService, vService));

                // Search by SCAC.
            else if (request.getMethod().equals("GET") && action.equals("searchByScac"))
                view = new JsonView<>(searchByScac(request, service, cService));

                // Search by Vendor.
            else if (request.getMethod().equals("GET") && action.equals("searchByVendor"))
                view = new JsonView<>(searchByVendor(request, service, cService));

                // Catch-all for sanity.
            else
                throw new IllegalArgumentException("Invalid Action.");
        } catch (Exception e) {
            // Log the error.
            logger.error("Error processing WesInboundOrderAction-Action request: ", e);

            // Respond to the call negatively for user-feedback.
            view = new JsonView("There was an error proccessing this request.");
        }

        PrintWriter out = response.getWriter();
        out.print(PojoMapper.toJson(view, true));
        out.flush();
        out.close();

        logger.info("USER: " + wfb.getUser() + " Exiting execute() method");
        return null;
    }

    /**
     * Performs the primary search and returns a Collection (page) of results that match the provided search criteria.
     */
    private JsonView<WesInboundOrder> searchOrders(HttpServletRequest request, GenericWesInboundOrderService service, GenericCustomersService cService, GenericSystemValuesService vService) throws Exception {
        WesInboundSearchRequest search = marshallRequest(request, vService, cService.readById(Integer.parseInt(request.getParameter("customerId"))));

        return new JsonView<>(service.readPage(search), service.readSearchTotal(search));
    }

    /**
     * Performs a search of all WesInboundOrders based on the Order Number.
     */
    private List<Map<String, Object>> searchByOrderNumber(HttpServletRequest request, GenericWesInboundOrderService service, GenericCustomersService cService, GenericSystemValuesService vService) throws Exception {
        // Read the Customers entity.
        Customers customer = cService.readById(parseCustomerNumberFilter(request));

        // Read and return our entities.
        return service.searchByOrderNumbers(request.getParameter("orderNumber"), vService.get(customer.getId(), Enums.eSystemValues.INBOUND_ORDERNUMBER_PREFIX).getStringvalue(), customer);
    }

    /**
     * Performs a search of all WesInboundOrders based on the SCAC.
     */
    private List<Map<String, Object>> searchByScac(HttpServletRequest request, GenericWesInboundOrderService service, GenericCustomersService cService) throws Exception {
        // Parse out the Customer Id.
        Integer customerId = parseCustomerNumberFilter(request);

        // Read and return our entities.
        return service.searchByScac(request.getParameter("scac"), cService.readById(customerId));
    }

    /**
     * Performs a search of all WesInboundOrders based on the Vendor.
     */
    private List<Map<String, Object>> searchByVendor(HttpServletRequest request, GenericWesInboundOrderService service, GenericCustomersService cService) throws Exception {
        // Parse out the Customer Id.
        Integer customerId = parseCustomerNumberFilter(request);

        // Read and return our entities.
        return service.searchByCustomerName(request.getParameter("vendor"), cService.readById(customerId));
    }

    /**
     * Marshalls a SearchRequest.
     */
    private WesInboundSearchRequest marshallRequest(HttpServletRequest request, GenericSystemValuesService vService, Customers customer) throws Exception {
        WesInboundSearchRequest search = new WesInboundSearchRequest();
        search.setPrefix(vService.get(customer.getId(), Enums.eSystemValues.INBOUND_ORDERNUMBER_PREFIX).getStringvalue());

        search.setLimit(request.getParameter("limit").trim().isEmpty() ? null : Integer.parseInt(request.getParameter("limit")));
        search.setPage(request.getParameter("page").trim().isEmpty() ? null : Short.parseShort(request.getParameter("page")));
        search.setStart(request.getParameter("start").trim().isEmpty() ? null : Short.parseShort(request.getParameter("start")));

        search.setCustomer(customer);
        search.setNumber(request.getParameter("orderNumber").trim().isEmpty() ? null : request.getParameter("orderNumber"));
        search.setScac(request.getParameter("scac").trim().isEmpty() ? null : request.getParameter("scac"));
        search.setVendor(request.getParameter("vendor").trim().isEmpty() ? null : request.getParameter("vendor"));
        search.setStatus(request.getParameter("status").trim().isEmpty() ? null : request.getParameter("status"));
        search.setType(request.getParameter("type").trim().isEmpty() ? null : request.getParameter("type"));

        Long m1 = request.getParameter("scd").trim().isEmpty() ? null : Long.parseLong(request.getParameter("scd").trim());
        search.setScdDate(m1 == null ? null : new Date(m1));

        Long m2 = request.getParameter("act").trim().isEmpty() ? null : Long.parseLong(request.getParameter("act").trim());
        search.setActDate(m2 == null ? null : new Date(m2));
        return search;
    }

    /**
     * Parses the "Filter" sent with the request to determine for which Customer to search.
     */
    private Integer parseCustomerNumberFilter(HttpServletRequest request) throws Exception {
        // Parse the filter.
        JSONObject filter = (JSONObject) new JSONArray(request.getParameter("filter")).get(0);

        // Sanity check our filter.
        if (!filter.has("property") || filter.get("property") == null || !((String) filter.get("property")).equalsIgnoreCase("customerId"))
            throw new IllegalArgumentException("Invalid Search Filter - Customer ID must be present.");

        if (!filter.has("value") || filter.get("value") == null || ((String) filter.get("value")).trim().isEmpty())
            throw new IllegalArgumentException("Invalid Search Filter - Customer ID must be present.");

        return Integer.parseInt((String) filter.get("value"));
    }
}
