package com.kenco.sims.oms.action;

import com.kenco.oms.entity.Teams;
import com.kenco.sims.oms.view.JsonView;
import com.kenco.struts.formbeans.WMSFormBean;
import com.kenco.struts.utilities.PojoMapper;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;

public class OrderInquiryAction extends Action {
	private static final Logger logger = LoggerFactory.getLogger(OrderInquiryAction.class);

	private final static String SUCCESS = "success";

	/**
	 * Access point for and controls of the flow for each inbound (OrderInquiry-related) request.
	 */
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		WMSFormBean wfb = (WMSFormBean) form;

		logger.info("USER: " + wfb.getUser() + " Starting execute() method");

		JsonView view = null;
		try {
			String action = request.getParameter("action");

			// Render the page.
			if (action == null)
				return renderStrut(wfb, mapping);
		} catch (Exception e) {
			// Log the error.
			logger.error("Error processing Teams-Action request: ", e);

			// Respond to the call negatively for user-feedback.
			view = new JsonView<Teams>("There was an error proccessing this request.");
		}

		PrintWriter out = response.getWriter();
		out.print(PojoMapper.toJson(view, true));
		out.flush();
		out.close();

		logger.info("USER: " + wfb.getUser() + " Exiting execute() method");
		return null;
	}

	/**
	 * Forwards the caller to the proper JSP for interaction with OrderInquiry.
	 */
	private ActionForward renderStrut(WMSFormBean wfb, ActionMapping mapping) {
		wfb.resetJavascriptIncludes("appOrderInquiry.js"); // This gets used first.
		// wfb.appendJavascriptIncludes(); // This is what we need to use to add other JS to our jsp.
		logger.info("USER: " + wfb.getUser() + " Exiting execute() method");
		return mapping.findForward(SUCCESS);
	}
}
