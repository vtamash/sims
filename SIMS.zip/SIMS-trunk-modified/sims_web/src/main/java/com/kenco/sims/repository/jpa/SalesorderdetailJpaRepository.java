package com.kenco.sims.repository.jpa;

import com.kenco.sims.domain.search.impl.SalesorderdetailSearchRequest;
import com.kenco.sims.repository.SalesorderdetailRepository;
import com.kenco.struts.wmsio.tables.Salesorderdetail;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;

@Repository
public class SalesorderdetailJpaRepository implements SalesorderdetailRepository {
    private static final Logger logger = LoggerFactory.getLogger(SalesorderdetailJpaRepository.class);

    private EntityManager entityManager;

    @Override
    @Transactional
    public Salesorderdetail create(Salesorderdetail soh) {
        logger.trace(String.format("Data Request; Creating Salesorderdetail [%s]; Persisting.", soh));
        entityManager.persist(soh);

        logger.info(String.format("Data Request; Salesorderdetail Successfully Created [%s].", soh));
        return soh;
    }

    @Override
    @Transactional(readOnly = true)
    public Salesorderdetail readBySalesOrderDetailKey(int salesOrderDetailKey) {
        logger.trace(String.format("Data Request; Retrieving Salesorderdetail [%s]; Building Criteria Query For Request.", salesOrderDetailKey));
        CriteriaBuilder     builder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Salesorderdetail> query   = builder.createQuery(Salesorderdetail.class);

        logger.trace(String.format("Data Request; Retrieving Salesorderdetail [%s]; Criteria Query Built; Setting Root.", salesOrderDetailKey));
        Root<Salesorderdetail> root = query.from(Salesorderdetail.class);

        logger.trace(String.format("Data Request; Retrieving Salesorderdetail [%s]; Root Set; Setting Predicates.", salesOrderDetailKey));
        query.where(builder.equal(root.<Integer>get("salesOrderDetailKey"), salesOrderDetailKey));

        logger.trace(String.format("Data Request; Retrieving Salesorderdetail [%s]; Predicates Set; Executing Query.", salesOrderDetailKey));
        Salesorderdetail entity = entityManager.createQuery(query).getSingleResult();

        logger.info(String.format("Data Request; Salesorderdetail [%s] Successfully Retrieved.", entity));
        return entity;
    }

    @Override
    @Transactional(readOnly = true)
    public List<Salesorderdetail> findBySalesOrderHeaderKey(int salesOrderHeaderKey) {
        logger.trace(String.format("Data Request; Retrieving Salesorderdetail [%s]; Building Criteria Query For Request.", salesOrderHeaderKey));
        CriteriaBuilder     builder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Salesorderdetail> query   = builder.createQuery(Salesorderdetail.class);

        logger.trace(String.format("Data Request; Retrieving Salesorderdetail [%s]; Criteria Query Built; Setting Root.", salesOrderHeaderKey));
        Root<Salesorderdetail> root = query.from(Salesorderdetail.class);

        logger.trace(String.format("Data Request; Retrieving Salesorderdetail [%s]; Root Set; Setting Predicates.", salesOrderHeaderKey));
        query.where(builder.equal(root.<Integer>get("salesOrderHeaderKey"), salesOrderHeaderKey));

        logger.trace(String.format("Data Request; Retrieving Salesorderdetail [%s]; Predicates Set; Executing Query.", salesOrderHeaderKey));
        List<Salesorderdetail> results = entityManager.createQuery(query).getResultList();

        if (results!=null && results.size()>0)
            for (Salesorderdetail detail : results)
                entityManager.refresh(detail);

        logger.info(String.format("Data Request; Salesorderdetail [%s] Successfully Retrieved.", results));
        return results;
    }

    @Override
    @Transactional(readOnly = true)
    public List<Salesorderdetail> read(SalesorderdetailSearchRequest request) {
        logger.trace(String.format("Data Request; Salesorderdetail Search Request; Building Criteria Query: " + request));
        CriteriaBuilder     builder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Salesorderdetail> query   = builder.createQuery(Salesorderdetail.class);

        logger.trace("Data Request; Salesorderdetail Search Request; Criteria Query Built; Setting Root.");
        Root<Salesorderdetail> root = query.from(Salesorderdetail.class);

        logger.trace("Data Request; Salesorderdetail Search Request; Root Set; Setting Predicates.");
        query.where(getPredicates(builder, null, root, request));

        logger.trace("Data Request; Salesorderdetail Search Request; Predicates Set; Setting Order.");
        query.orderBy(builder.desc(root.<Integer>get("salesOrderHeaderKey")));

        logger.trace("Data Request; Salesorderdetail Search Request; Order Set; Executing Query.");
        List<Salesorderdetail> results = entityManager.createQuery(query).setFirstResult(request.getStart())
                                                                         .setMaxResults(request.getLimit())
                                                                         .getResultList();

        logger.info(String.format("Data Request; [%s] Salesorderdetails Successfully Retrieved for Request: [%s]", results.size(), request));
        return results;
    }

    @Transactional(readOnly = true)
    public long getSearchTotal(SalesorderdetailSearchRequest request) {
        logger.trace(String.format("Data Request; Counting Salesorderdetail Search Total; Building Criteria Query: [%s] ", request));
        CriteriaBuilder     builder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Long> query   = builder.createQuery(Long.class);

        logger.trace("Data Request; Counting Salesorderdetail Search Total; Criteria Query Built; Setting Root.");
        Root<Salesorderdetail> root = query.from(Salesorderdetail.class);

        logger.trace("Data Request; Counting Salesorderdetail Search Total; Root Set; Setting Aggregation.");
        query.select(builder.count(root));

        logger.trace("Data Request; Counting Salesorderdetail Search Total; Aggregation Set; Setting Predicates.");
        query.where(getPredicates(builder, null, root, request));

        logger.trace("Data Request; Counting Salesorderdetail Search Total; Predicates Set; Executing Query.");
        long count = entityManager.createQuery(query).getSingleResult();

        logger.info(String.format("Data Request; [%s] Total Salesorderdetails Found for Search Request: [%s]", count, request));
        return count;
    }

    @Override
    @Transactional
    @PreAuthorize("hasRole('STRYKER_SIMS_SUPERUSER') and hasPermission(#user, 'write')")
    public void update(Salesorderdetail sod) {
        logger.trace(String.format("Data Request; Updating Salesorderdetail [%s]; Merging.", sod));
        entityManager.merge(sod);
        logger.info(String.format("Data Request; Salesorderdetail Successfully Updated [%s].", sod));
    }

    public Predicate[] getPredicates(CriteriaBuilder builder, CriteriaQuery<?> query, Root<Salesorderdetail> root, SalesorderdetailSearchRequest request) {
        final List<Predicate> predicates = new ArrayList<>();

        final String serialNumber = request.getSerialNumber();
        if (serialNumber != null && !serialNumber.trim().isEmpty())
            predicates.add(builder.equal(builder.upper(root.<String>get("serialNumber")), serialNumber.trim().toUpperCase()));

        final String productType = request.getProductType();
        if (productType != null && !productType.trim().isEmpty())
            predicates.add(builder.equal(builder.upper(root.<String>get("productType")), productType.trim().toUpperCase()));

        final String productCode = request.getProductCode();
        if (productCode != null && !productCode.trim().isEmpty())
            predicates.add(builder.like(builder.upper(root.<String>get("productCode")), String.format("%%%s%%", productCode.trim().toUpperCase())));

        final String productVariation = request.getProductVariation();
        if (productVariation != null && !productVariation.trim().isEmpty())
            predicates.add(builder.like(builder.upper(root.<String>get("productVariation")), String.format("%%%s%%", productVariation.trim().toUpperCase())));

        final String productDescription = request.getProductDescription();
        if (productDescription != null && !productDescription.trim().isEmpty())
            predicates.add(builder.like(builder.upper(root.<String>get("productDescription")), String.format("%%%s%%", productDescription.trim().toUpperCase())));

        final String surface = request.getSurface();
        if (surface != null && !surface.trim().isEmpty())
            predicates.add(builder.like(builder.upper(root.<String>get("surface")), String.format("%%%s%%", surface.trim().toUpperCase())));

        final String surfaceDescription = request.getSurfaceDescription();
        if (surfaceDescription != null && !surfaceDescription.trim().isEmpty())
            predicates.add(builder.equal(builder.upper(root.<String>get("surfaceDescription")), surfaceDescription.trim().toUpperCase()));

        final String surfaceSerialNumber = request.getSurfaceSerialNumber();
        if (surfaceSerialNumber != null && !surfaceSerialNumber.trim().isEmpty())
            predicates.add(builder.like(builder.upper(root.<String>get("surfaceSerialNumber")), String.format("%%%s%%", surfaceSerialNumber.trim().toUpperCase())));

        final String specialInstructions = request.getSpecialInstructions();
        if (specialInstructions != null && !specialInstructions.trim().isEmpty())
            predicates.add(builder.like(builder.upper(root.<String>get("specialInstructions")), String.format("%%%s%%", specialInstructions.trim().toUpperCase())));

        return predicates.toArray(new Predicate[predicates.size()]);
    }

    public EntityManager getEntityManager() {
        return entityManager;
    }

    public void setEntityManager(EntityManager entityManager) {
        this.entityManager = entityManager;
    }
}
