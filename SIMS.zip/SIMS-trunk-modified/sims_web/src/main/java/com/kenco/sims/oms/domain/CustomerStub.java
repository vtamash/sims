package com.kenco.sims.oms.domain;

public class CustomerStub {
	private Integer id;
	private short active;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public short getActive() {
		return active;
	}

	public void setActive(short active) {
		this.active = active;
	}
}
