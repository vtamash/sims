package com.kenco.struts.utilities;

import com.kenco.sims.repository.jpa.SalesorderdetailJpaRepository;
import com.kenco.sims.repository.jpa.SalesorderheaderJpaRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.naming.InitialContext;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class InitServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private static final Logger logger = LoggerFactory.getLogger(InitServlet.class);

    private static DataSource dataSource;
    private static EntityManagerFactory emf;
    private static ServletContext servletContext;
    private static String stySndRcvLib;
    private static String stySharedLib;
    private static String chkCgiLib;
    private static String styFileLib;

    public void init() {
        logger.info("STARTING SERVLET ENGINE.");
        final String realPath = getServletContext().getRealPath("/").replace('\\', '/');

        logger.info("SERVLET ENGINE RUNNING AT: " + realPath);
        final String cfgFile =
                getInitParameter("initservlet").replace('\\', '/') + getServletContext().getContextPath() + ".cfg";

        logger.info("STARTUP CONFIGURATION FILE IS LOCATED AT: " + cfgFile);
        final Properties propFile = new Properties();
        try { propFile.load(new FileInputStream(cfgFile)); }
        catch (IOException ex) { logger.info("STARTUP: FAILURE - Startup configuration file not found!", ex); }

        propFile.setProperty("webserverPath", realPath);

        logger.info("WEB APPLICATION IS: " + propFile.getProperty("webroot"));
        getServletContext().setAttribute("application_scope", propFile);

        servletContext = getServletContext();

        // load properties that need to be available application wide...
        final Properties appWide = (Properties) getServletContext().getAttribute("application_scope");
        stySndRcvLib = appWide.getProperty("stysndrcvlib");
        stySharedLib = appWide.getProperty("stysharedlib");
        chkCgiLib    = appWide.getProperty("chkcgilib");
        styFileLib   = appWide.getProperty("styfilelib");

        try {
            final String environment = appWide.getProperty("environment").toUpperCase().trim();
            dataSource = (DataSource) new InitialContext().lookup("java:comp/env/jdbc/DB2_JPA_STY_" + environment);

            final PersistenceManager pm = PersistenceManager.getInstance();
            emf = pm.getEntityManagerFactory();

            final EntityManager entityManager = emf.createEntityManager();
            ((SalesorderdetailJpaRepository)            SpringContextHolder.getBean("salesorderdetailJpaRepository")).setEntityManager(entityManager);
            ((SalesorderheaderJpaRepository)            SpringContextHolder.getBean("salesorderheaderJpaRepository")).setEntityManager(entityManager);
        } catch (Exception ex) {
            logger.error("***************** INITSERVLET ERROR **********************");
            logger.error("Fatal exception at startup!",ex);
            logger.error("***************** INITSERVLET ERROR **********************");
        }
    }

    public void doGet(HttpServletRequest req, HttpServletResponse res) {}

    public static ServletContext getContext() {
        return servletContext;
    }

    public static EntityManagerFactory getEntityManagerFactory() {
        return emf;
    }

    public static EntityManagerFactory getSalesEntityManagerFactory() {
        return emf;
    }

    public static String getStySndRcvLib() {
        return stySndRcvLib;
    }

    public static String getStySharedLib() {
        return stySharedLib;
    }

    public static String getChkCgiLib() {
        return chkCgiLib;
    }

    public static String getStyFileLib() {
        return styFileLib;
    }

    public static DataSource getDataSource() {
        return dataSource;
    }
}
