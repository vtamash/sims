package com.kenco.struts.utilities;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.TypeFactory;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Collection;

public class PojoMapper {

    private static ObjectMapper m = new ObjectMapper();
    private static TypeFactory tf = TypeFactory.defaultInstance();

    public static <T> Object fromJson(String jsonAsString, Class<T> pojoClass) throws IOException {
    	Object object = null;

    	if (pojoClass.isAssignableFrom(Collection.class)) {
    		@SuppressWarnings("unchecked")
			Class<? extends Collection<?>> pojoCollection = (Class<? extends Collection<?>>) pojoClass;
			object = m.readValue(jsonAsString, tf.constructCollectionType(pojoCollection, pojoCollection.getComponentType()));
    	} else {
    		object = m.readValue(jsonAsString, pojoClass);
    	}
    	
        return object;
    }

    public static <T> Object fromJson(FileReader fr, Class<T> pojoClass) throws IOException {
    	Object object = null;

    	if (pojoClass.isAssignableFrom(Collection.class)) {
    		@SuppressWarnings("unchecked")
			Class<? extends Collection<?>> pojoCollection = (Class<? extends Collection<?>>) pojoClass;
			object = m.readValue(fr, tf.constructCollectionType(pojoCollection, pojoCollection.getComponentType()));
    	} else {
    		object = m.readValue(fr, pojoClass);
    	}
    	
        return object;
    }

    public static String toJson(Object pojo, boolean prettyPrint) throws IOException {
        return m.writeValueAsString(pojo);
    }

    public static void toJson(Object pojo, FileWriter fw, boolean prettyPrint) throws IOException {
        m.writeValue(fw, pojo);
    }
}