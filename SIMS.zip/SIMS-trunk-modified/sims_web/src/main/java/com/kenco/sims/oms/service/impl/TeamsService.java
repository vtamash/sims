package com.kenco.sims.oms.service.impl;

import com.kenco.oms.entity.Teams;
import com.kenco.oms.search.TeamsSearchRequest;
import com.kenco.oms.service.CustomersAbstractService;
import com.kenco.oms.service.TeamsAbstractService;
import com.kenco.oms.service.impl.GenericCustomersService;
import com.kenco.sims.oms.domain.TeamStub;
import com.kenco.struts.utilities.InitServlet;

import javax.persistence.EntityManager;
import java.util.List;

/**
 * SIMS Implementation of the <i>TeamsAbstractService</i>.  Business logic relating to the <i>Teams</i> entity and
 * specific to SIMS is located here.
 *
 * @see com.kenco.sims.oms.domain.TeamStub
 * @see com.kenco.oms.service.TeamsAbstractService
 * @see com.kenco.oms.service.CustomersAbstractService
 */
public final class TeamsService extends TeamsAbstractService {
	private static final EntityManager entityManager = InitServlet.getEntityManagerFactory().createEntityManager();

	private final CustomersAbstractService cService;

	/**
	 * Constructs a <i>TeamsService</i> along with the required <i>CustomersService</i> that it will need for processing.
	 */
	public TeamsService() {
		super(entityManager);

		cService = new GenericCustomersService(entityManager);
	}

	/**
	 * SIMS Implementation of the <i>TeamsAbstractService</i>.  The <b>create</b> process requires one argument to be
	 * passed in for processing: A <i>TeamStub</i> object which will be used to construct the <i>Teams</i> entity.
	 *
	 * @param teams The <i>Teams</i> entity that is being created.
	 * @param args Array of size one (1) containing a <i>TeamStub</i> object which is to be used to create the
	 *             <i>Teams</i> entity.
	 * @return The processed <i>Teams</i> entity.
	 */
	@Override
	protected Teams createPreProcess(Teams teams, Object... args) {
		if (args == null || args.length != 1)
			throw new UnsupportedOperationException("The <b>create</b> method requires arguments to be passed in.");
		else if (args[0] == null || !(args[0] instanceof TeamStub))
			throw new IllegalArgumentException("Invalid argument(s) passed to the <b>create</b> method.");

		TeamStub stub = (TeamStub) args[0];
		teams.setTeam(stub.getName());
		teams.setActive(stub.getActive());
		teams.setCustomerId(cService.readById(stub.getCustomerId()));
		return teams;
	}

	/**
	 * SIMS Implementation of the <i>TeamsAbstractService</i>.  The <b>update</b> process requires one argument to be
	 * passed in for processing: A <i>TeamStub</i> object which will be used to update the <i>Teams</i> entity.
	 *
	 * @param teams The <i>Teams</i> entity that is being updated.
	 * @param args Array of size one (1) containing a <i>TeamStub</i> object which is to be used to update the
	 *             <i>Teams</i> entity.
	 * @return The processed <i>Teams</i> entity.
	 */
	@Override
	protected Teams updatePreProcess(Teams teams, Object... args) {
		if (args == null || args.length != 1)
			throw new UnsupportedOperationException("The <b>update</b> method requires arguments to be passed in.");
		else if (args[0] == null || !(args[0] instanceof TeamStub))
			throw new IllegalArgumentException("Invalid argument(s) passed to the <b>update</b> method.");

		TeamStub stub = (TeamStub) args[0];
		teams.setTeam(stub.getName());
		teams.setActive(stub.getActive());
		teams.setCustomerId(cService.readById(stub.getCustomerId()));
		return teams;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected Teams deletePreProcess(Teams teams, Object... args) {
		return teams;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected Teams createPostProcess(Teams teams, Object... args) {
		return teams;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected List<Teams> readPostProcess(List<Teams> l, Object... args) {
		return l;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected Teams readSinglePostProcess(Teams teams, Object... args) {
		return teams;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected Teams updatePostProcess(Teams teams, Object... args) {
		return teams;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected TeamsSearchRequest searchPreProcess(TeamsSearchRequest teamsSearchRequest, Object... args) {
		return teamsSearchRequest;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected List<Teams> searchPostProcessing(List<Teams> results, Object... args) {
		return results;
	}
}
