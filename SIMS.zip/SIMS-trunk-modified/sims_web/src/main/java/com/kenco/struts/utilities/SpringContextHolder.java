package com.kenco.struts.utilities;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.security.access.hierarchicalroles.RoleHierarchy;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;

public class SpringContextHolder implements ApplicationContextAware {
    private static ApplicationContext CONTEXT;
    private static RoleHierarchy ROLE_HIERARCHY;

    @Override
    public void setApplicationContext(final ApplicationContext applicationContext) throws BeansException {
        CONTEXT        = applicationContext;
        ROLE_HIERARCHY = (RoleHierarchy) applicationContext.getBean("roleHierarchy");
    }

    public static Object getBean(final String beanName) {
        return CONTEXT.getBean(beanName);
    }

    public static boolean hasRole(final String roleName) {
        return ROLE_HIERARCHY
                .getReachableGrantedAuthorities(SecurityContextHolder.getContext().getAuthentication().getAuthorities())
                .contains(new SimpleGrantedAuthority(roleName));
    }
}
