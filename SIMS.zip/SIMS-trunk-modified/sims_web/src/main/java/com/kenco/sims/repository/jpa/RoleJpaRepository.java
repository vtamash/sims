package com.kenco.sims.repository.jpa;

import com.kenco.sims.entity.Role;
import com.kenco.sims.repository.RoleRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import java.util.List;

/**
 * Sole point-of-access for interaction with {@code User} entities.
 *
 * @see com.kenco.sims.repository.RoleRepository
 */
@Repository
public class RoleJpaRepository implements RoleRepository {
    private static final Logger logger = LoggerFactory.getLogger(RoleJpaRepository.class);

    @PersistenceContext
    private EntityManager entityManager;

    /**
     * {@inheritDoc}
     */
    @Override
    @Transactional(readOnly = true)
    public List<Role> read() {
        logger.trace("Data Request; Retrieving All Roles; Building Criteria Query For Request.");
        CriteriaBuilder     builder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Role> query   = builder.createQuery(Role.class);

        logger.trace("Data Request; Retrieving All Roles; Criteria Query Built; Setting Root.");
        Root<Role> root = query.from(Role.class);

        query.orderBy(builder.asc(root.<Integer>get("sequence")));

        logger.trace("Data Request; Retrieving All Roles; Root Set; Executing Query.");
        List<Role> results = entityManager.createQuery(query).getResultList();

        logger.info(String.format("Data Request; [%s] Roles Successfully Retrieved.", results.size()));
        return results;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @Transactional(readOnly = true)
    public Role readById(int id) {
        logger.trace(String.format("Data Request; Retrieving Role [%s]; Building Criteria Query For Request.", id));
        CriteriaBuilder     builder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Role> query   = builder.createQuery(Role.class);

        logger.trace(String.format("Data Request; Retrieving Role [%s]; Criteria Query Built; Setting Root.", id));
        Root<Role> root = query.from(Role.class);

        logger.trace(String.format("Data Request; Retrieving Role [%s]; Root Set; Setting Predicates.", id));
        query.where(builder.equal(root.<String>get("id"), id));

        logger.trace(String.format("Data Request; Retrieving Role [%s]; Predicates Set; Executing Query.", id));
        Role entity = entityManager.createQuery(query)
                .getSingleResult();

        logger.info(String.format("Data Request; Role [%s] Successfully Retrieved.", entity));
        return entity;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @Transactional(readOnly = true)
    public Role readByName(String name) {
        logger.trace(String.format("Data Request; Retrieving Role [%s]; Building Criteria Query For Request.", name));
        CriteriaBuilder     builder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Role> query   = builder.createQuery(Role.class);

        logger.trace(String.format("Data Request; Retrieving Role [%s]; Criteria Query Built; Setting Root.", name));
        Root<Role> root = query.from(Role.class);

        logger.trace(String.format("Data Request; Retrieving Role [%s]; Root Set; Setting Predicates.", name));
        query.where(builder.equal(builder.upper(root.<String>get("name")), name.toUpperCase()));

        logger.trace(String.format("Data Request; Retrieving Role [%s]; Predicates Set; Executing Query.", name));
        Role entity = entityManager.createQuery(query)
                .getSingleResult();

        logger.info(String.format("Data Request; Role [%s] Successfully Retrieved.", entity));
        return entity;
    }
}
