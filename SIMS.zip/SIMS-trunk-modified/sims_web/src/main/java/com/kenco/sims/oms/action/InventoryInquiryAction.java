package com.kenco.sims.oms.action;

import com.kenco.oms.entity.Customers;
import com.kenco.oms.entity.Inboundorderdetail;
import com.kenco.oms.entity.Omsinventoryinquiry;
import com.kenco.oms.search.OmsInventoryInquirySearchRequest;
import com.kenco.oms.service.impl.GenericCustomersService;
import com.kenco.oms.service.impl.GenericOmsInventoryInquiryService;
import com.kenco.sims.oms.view.JsonView;
import com.kenco.struts.formbeans.WMSFormBean;
import com.kenco.struts.utilities.InitServlet;
import com.kenco.struts.utilities.PojoMapper;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.util.List;

public class InventoryInquiryAction extends Action {

    static Logger logger = LoggerFactory.getLogger(OMSDropDownAction.class);
    private final static String SUCCESS = "success";

    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
            WMSFormBean wfb = (WMSFormBean) form;

            logger.info("USER: " + wfb.getUser() + " Starting execute() method");

            String action = request.getParameter("action");

            if (action == null)
            	return renderStrut(wfb, mapping);

            PrintWriter out = response.getWriter();
        	  
            JsonView<?> jsonView = null;
            String jsonString = null;

            String customerIdStr = request.getParameter("customerId");
            int customerId = 0;
            if (customerIdStr!=null) {
        		try {
        			customerId = Integer.parseInt(customerIdStr);
        		} catch (Exception e) {
        			logger.error("Error parsing Customer ID.");
        		}
            } else
            	logger.warn("Customer ID has not been passed from the Client Side.");

    		EntityManagerFactory emf = InitServlet.getEntityManagerFactory();

/*    		Customers customer = (new GenericCustomersService(emf.createEntityManager())).readById(customerId==0?wfb.getOmsDefaultCustomerId():customerId);
    		Map<String, Object> emProperties = new HashMap<String, Object>(); 
    		emProperties.put("tenant-id", customer.getDatalibrary());        			 

    		EntityManager em = emf.createEntityManager(emProperties);
*/
    		EntityManager em = emf.createEntityManager();
    		
    		Customers customer = (new GenericCustomersService(emf.createEntityManager())).readById(customerId==0?wfb.getOmsDefaultCustomerId():customerId);

    		em.setProperty("tenant-id", customer.getDatalibrary());
    		GenericOmsInventoryInquiryService giis = new GenericOmsInventoryInquiryService(em);

            if (request.getMethod().equals("GET")) {
                if (action.equals("search")) {
                    String skunumb = request.getParameter("skunumb");
                    String lotid = request.getParameter("lotid");
                    String deptno = request.getParameter("deptno");
                    String holdcode = request.getParameter("holdcode");
                    String hasholdcodeStr = request.getParameter("hasholdcode");
                    String startStr = request.getParameter("start");
                    String limitStr = request.getParameter("limit");
                    
                    short start = 0;
					int limit = 0;
                    boolean hasholdcode = false;
                    try { 
                        start = Short.parseShort(startStr);
                        limit = Integer.parseInt(limitStr);
                        hasholdcode = Boolean.parseBoolean(hasholdcodeStr);

            			try {
            				OmsInventoryInquirySearchRequest searchRequest = new OmsInventoryInquirySearchRequest();
            				searchRequest.setSkunumb(skunumb);
            				searchRequest.setLotid(lotid);
            				searchRequest.setDeptno(deptno);
            				searchRequest.setHoldcode(holdcode);
            				searchRequest.setHasholdcode(hasholdcode);
            				searchRequest.setStart(start);
            				searchRequest.setLimit(limit);
            				long total = giis.readSearchTotal(customerId==0?wfb.getOmsDefaultCustomerId():customerId, searchRequest);
            				List<Omsinventoryinquiry> list = giis.readSearch(customerId==0?wfb.getOmsDefaultCustomerId():customerId, searchRequest);
            				jsonView = new JsonView<Omsinventoryinquiry>(list);
            				jsonView.setTotal(total);
            				jsonView.setMessage("Records were successfully retrieved.");
            			} catch (Exception e) {
            				jsonView = new JsonView<Inboundorderdetail>("Error retrieving Inventory Inquiry.");
            			}
                    } catch(Exception e) {
        				jsonView = new JsonView<Inboundorderdetail>("Error parsing page parameters.");
                    }
            	}
            }
            jsonString = PojoMapper.toJson(jsonView, true);

            logger.info("DropDownArray: " + jsonString);
            out.print(jsonString);
            out.flush();
            out.close();
            
            return null;
        }

        private ActionForward renderStrut(WMSFormBean wfb, ActionMapping mapping) {
            wfb.resetJavascriptIncludes("appInventoryInquiry.js");
            logger.info("USER: " + wfb.getUser() + " Exiting execute() method");
            return mapping.findForward(SUCCESS);
        }
}
