package com.kenco.sims.repository;

import com.kenco.sims.entity.Role;

import java.util.List;

/**
 * Specifies behavior for interaction with the {@code Role} entity.
 */
public interface RoleRepository {
    /**
     * Retrieves all {@code Role} entities.
     *
     * @return A typed {@code List} of all {@code Role} entities.  Ordering is implementation specific.
     */
    List<Role> read();

    /**
     * Retrieves the {@code Role} entity for the given Primary Key.
     *
     * @param id The Primary Key for the {@code Role} entity to be retrieved.
     * @return The {@code Role} entity matching the given Primary Key.
     * throws javax.persistence.NoResultException when no {@code Role} entity can be found for the given Primary Key.
     * throws javax.persistence.NonUniqueResultException when more than one {@code Role} entity is found for the given
     * Primary Key.
     */
    Role readById(int id);

    /**
     * Retrieves the {@code Role} entity for the given {@code name}.
     *
     * @param name The name of the {@code Role} entity to be retrieved.
     * @return The persistent {@code Role} entity for the given {@code name}.
     * throws javax.persistence.NoResultException when no {@code Role} entity can be found for the given {@code name}.
     * throws javax.persistence.NonUniqueResultException when more than one {@code Role} entity is found for the given {@code name}
     */
    Role readByName(String name);
}
