package com.kenco.sims.entity;

import javax.persistence.*;

/**
 * A table entity representing a remote distribution center.
 * One or more of these can be assigned to users in the USERAUTHORIZEDRDCS table.
 */
@Entity
@Table(schema = "SIMS_SYS", name = "RDCS")
public class Rdc {
    /**
     * Primary Key.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    /**
     * EDI Process Identifier.
     */
    @Column(name="RDCID", nullable=false, length=8)
    private String rdcId;

    /**
     * Stryker's JD Edwards Primary Key.
     */
    @Column(name="JDEID", nullable=false, length=16)
    private String jdeId;

    /**
     * The schema where data is kept.
     */
    @Column(name="LIBRARY", nullable=false, length=64)
    private String library;

    /**
     * Name by which this is known.
     */
    @Column(name="NAME", nullable=false, length=64)
    private String name;

    /**
     * Primary email contact.
     */
    @Column(name = "EMAIL", nullable = false, length = 64)
    private String email;

    /**
     * Street address for this.
     */
    @Column(name="ADDRESS", nullable=false, length=64)
    private String address;

    /**
     * City where this is located.
     */
    @Column(name="CITY", nullable=false, length=64)
    private String city;

    /**
     * State (Two-Character abbreviation) where this is located.
     */
    @Column(name="STATE", nullable=false, length=64)
    private String state;

    /**
     * Zip code for where this is located.
     */
    @Column(name="ZIP", nullable=false, length=8)
    private String zipCode;

    @Column(name="PHONE", nullable=true, length=64)
    private String phone;

    @Override
    public String toString() {
        return this.getId().toString();
    }

    @Override
    public int hashCode() {
        return this.getId().hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        return obj instanceof Rdc && ((Rdc) obj).getId().equals(this.getId());
    }


    public Integer getId() {
        return this.id;
    }
    public void setId(int id) {
        this.id = id;
    }

    public String getRdcId() {
        return this.rdcId;
    }
    public void setRdcId(String rdcId) {
        this.rdcId = rdcId;
    }

    public String getLibrary() {
        return this.library;
    }
    public void setLibrary(String library) {
        this.library = library;
    }

    public String getName() {
        return this.name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }

    public String getAddress() {
        return this.address;
    }
    public void setAddress(String address) {
        this.address = address;
    }

    public String getCity() {
        return this.city;
    }
    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return this.state;
    }
    public void setState(String state) {
        this.state = state;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getJdeId() {
        return this.jdeId;
    }
    public void setJdeId(String jdeId) {
        this.jdeId = jdeId;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}
