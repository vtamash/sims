package com.kenco.struts.utilities;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import java.util.Date;
import java.util.List;
import java.util.Properties;

public class KencoEmailManager {
    private static Logger logger = LoggerFactory.getLogger(KencoEmailManager.class);

    private final Properties SMTP_PROPERTIES = new Properties();

    private static final String CONTENT_HTML  = "text/html";
    private static final String SMTP_HOST     = "smtp.office365.com";
    private static final String SMTP_PORT     = "587";
    private static final String SMTP_USERNAME = "NoReply_SIMS@kencogroup.com";
    private static final String SMTP_PASSWORD = "D13tc0ke!";

    public KencoEmailManager() {
        SMTP_PROPERTIES.put("mail.smtp.host",            SMTP_HOST);
        SMTP_PROPERTIES.put("mail.smtp.port",            SMTP_PORT);
        SMTP_PROPERTIES.put("mail.smtp.auth",            true);
        SMTP_PROPERTIES.put("mail.smtp.starttls.enable", true);
    }

    /**
     * Send an HTML email with an attachment (optional).
     * If the AttacmentId is >0, then look for the attachment and send.
     */
    public void sendHTML(String paSubject, String paEmailText, String paSender, List<?> paEmailRecipients, Integer paAttachmentId) throws MessagingException {
        logger.debug("Starting EmailManager.sendHTML");
        final Session session = Session.getInstance(SMTP_PROPERTIES, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(SMTP_USERNAME, SMTP_PASSWORD);
            }
        });

        // Create a list of recipients.
        InternetAddress[] addresses = new InternetAddress[paEmailRecipients.size()];
        for (int i = 0; i < paEmailRecipients.size(); i++) {
            addresses[i] = new InternetAddress((String) paEmailRecipients.get(i));
            logger.debug("Added email " + (String) paEmailRecipients.get(i));
        }

        final Message message = new MimeMessage(session);
        message.addFrom(new InternetAddress[]{new InternetAddress(SMTP_USERNAME)});
        message.setRecipients(Message.RecipientType.TO, addresses);
        message.setSubject(paSubject);

        // convert to HTML
        MimeBodyPart html_mbp = new MimeBodyPart();
        html_mbp.setText(paEmailText);
        html_mbp.setContent(paEmailText, CONTENT_HTML);

        Multipart mp = new MimeMultipart();
        mp.addBodyPart(html_mbp);

        message.setContent(mp);
        message.setSentDate(new Date());
        //Transport.send(message);
        Thread t1 = new Thread(new Runnable() {
            public void run() {
                try {
                    Transport.send(message);
                } catch (MessagingException e) {
                    e.printStackTrace();
                }
            }
        });
        t1.start();


    }
}
