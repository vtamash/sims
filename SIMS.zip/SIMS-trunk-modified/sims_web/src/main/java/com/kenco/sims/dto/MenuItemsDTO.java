package com.kenco.sims.dto;

import com.kenco.sims.entity.MenuItem;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

/**
 * Required wrapper for (Un)Marshalling a collection of {@code MenuItemDTO} objects.
 */
@XmlRootElement(name = "MenuItems")
@XmlAccessorType(XmlAccessType.FIELD)
public class MenuItemsDTO {
    @XmlElement(name = "MenuItem")
    private List<MenuItem> menuItems;

    public List<MenuItem> getMenuItems() {
        return menuItems;
    }

    public void setMenuItems(List<MenuItem> menuItems) {
        this.menuItems = menuItems;
    }
}
