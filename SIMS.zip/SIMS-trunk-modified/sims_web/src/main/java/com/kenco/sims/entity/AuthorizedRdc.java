package com.kenco.sims.entity;

import javax.persistence.*;
import java.util.Date;

/**
 * Persistent Entity;
 *
 * Represents a single {@code Rdc} that has been assigned to a {@code User}.  This is, effectively, a whole entity
 * to represent a Many-To-Many relation between a {@code User} and a {@code Rdc}.
 *
 * @see com.kenco.sims.entity.User
 * @see com.kenco.sims.entity.Rdc
 */
@Entity
@Table(schema = "SIMS_SYS", name = "USERAUTHORIZEDRDCS")
public class AuthorizedRdc {
    /**
     * Primary Key;
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    /**
     * The {@code User} for the Many-To-Many relation.
     */
    @ManyToOne(optional = false)
    @JoinColumn(name = "USER_ID", referencedColumnName = "ID", nullable = false)
    private User user;

    /**
     * The {@code Rdc} for the Many-To-Many relation.
     */
    @ManyToOne(optional = false)
    @JoinColumn(name = "RDC_ID", referencedColumnName = "ID", nullable = false)
    private Rdc rdc;

    /**
     * When this entity was created.
     */
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATED", insertable = false, updatable = false, nullable = false)
    private Date created = new Date();

    /**
     * Username of the {@code User} who created this.
     */
    @Column(name = "CREATEDBY", nullable = false, length = 128)
    private String creator;

    @Override
    public String toString() {
        return getId().toString();
    }

    @Override
    public boolean equals(Object obj) {
        return obj instanceof AuthorizedDivision &&
                getId().equals(((AuthorizedDivision) obj).getId());
    }

    @Override
    public int hashCode() {
        return getId().hashCode();
    }

    public Integer getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Rdc getRdc() {
        return rdc;
    }

    public void setRdc(Rdc rdc) {
        this.rdc = rdc;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }
}
