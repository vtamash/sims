package com.kenco.struts.formbeans;

import com.kenco.sims.dto.MenuItemDTO;
import com.kenco.struts.utilities.InitServlet;
import org.apache.commons.lang3.StringUtils;
import org.apache.struts.action.ActionForm;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.persistence.EntityManager;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.*;

public class WMSFormBean extends ActionForm {
    private static final long serialVersionUID = -6794982805766534401L;

    static Logger logger = LoggerFactory.getLogger(WMSFormBean.class);
    private List<MenuItemDTO> menuItems = new ArrayList<>();
    private String returnMessage;
    private List<String> javascriptIncludes;
    private String customerNumber;
    private String customerNumberAndLibrary;
    private boolean iscwic;
    private boolean createexcel;
    private String excelfilename;
    private int maxexcelrows;
    private String excelhreflink;
    private String chkcgilib;
    private String cgifileslib;
    private String stysndrcvlib;
    private String stysharedlib;
    private String styfilelib;
    private String stypgmlib;
    private String styjpalib;
    private String omslib;
    private int maxqueryrows;
    private String maxquerymessage;
    private String query;
    private int maxdropdownrows;
    private int rowsreturned;
    private String copyrightstatement;
    private int firstRow;
    private String rowsPerPage;
    private String todayDate;
    private String user;
    private String userRole;
    private int userRoleId;
    private int salesRepRoleId;
    private String stryker;
    private String userDataLib;
    private boolean isPasswordExpired = false;
    //private Connection adminConnection;
    //private Connection wmsDataConnection;
    private Collection<?> customerList;
    private String inventoryList;
    private String selectedCustomerFromDropDown;
    private String selectedCustomerName;
    private String selectedOriginFromDropDown;
    private String selectedDestinationFromDropDown;
    private Short  productTcForm;
    private String productDemoType;
    private String productEmailNewRq;
    private Integer productDivisionId;
    private BigDecimal productValue = BigDecimal.valueOf(0);
    private String productVisible;
    private String productCode;
    private String productModel;
    private String productType;
    private String productVariation;
    private String specialInstructions;
    private String productDescription;
    private String productCodeDesc;
    private BigDecimal salesOpportunity;
    private String salesOpportunityNumber;
    private boolean fromSalesForce = false;
    private String purchaseOrderNumber;
    private String lotID;
    private String code;
    private String codeDescription;
    private String newHoldCode;
    private String currentHoldCode;
    private String serialStatus;
    private String newSerialStatus;
    private String currentSerialStatus;
    private String inventoryStatus;
    private String newInventoryStatus;
    private String currentInventoryStatus;
    private String location;
    private String mui;
    private String group;
    private String expireDt;
    private Collection<?> invInqList;
    private String invbyskupage;
    private Collection<?> displayableCustomerList;
    private boolean searchProcessed;
    private String currentPage;
    private String totalPages;
    private String timeout;
    private Collection<?> javascriptMenu;
    private HashMap<String, String> appTimeout = new HashMap<String, String>();
    private String javascriptPage;
    private String firstName;
    private String lastName;
    private Collection<?> stateList;
    private String state;
    private String email;
    private String emailVerify;
    private String emailServer;
    private String emailSender;
    private String address1;
    private String address2;
    private String city;
    private String zipcode;
    private String phone;
    private String phoneExtension;
    private String company;
    private String comments;
    private Collection<?> ttCustList;
    private Collection<?> ttLdcList;
    private Collection<?> ttLdcListAll;
    private String serialNumber;
    private String selectedTransfer;
    private String currentLocation;
    private String currentLocationNumber;
    private String nextAvailable;
    private String defaultNextAvailable;
    private String custCBValue;
    private String ldcCBValue;
    private String rdcCBValue;
    private String tocustCBValue;
    private String tocustIDCBValue;
    private String toldcCBValue;
    private String custCBValueLoc;
    private String ldcCBValueLoc;
    private String enddt2;
    private String startdt2;
    private String enddt;
    private String startdt;
    private String department;
    private String deliveryDate;
    private String deliveryTime;
    private String pickupDate;
    private String pickupTime;
    private String soldDate;
    private String styDataLib;
    private String manualLotid;
    private String manualSKUNumber;
    private String defaultStayDays;
    private String limit;
    private String start;
    private String export;
    private String webserverPath;
    private String skuNumber;
    private String openEndedDate;
    private String transferRequest;
    private String dateField;
    private String newDate;
    private String showNGo;
    private String stySearch;
    private String stySearchType;
    private String stySearchRdc;
    private String stySearchSerial;
    private String stySearchProductCode;
    private String stySearchFromDate;
    private String stySearchToDate;
    private String stySearchExcel;
    //    private String someVal;
    private String isTrialBed;
    private String isShowSold;
    private String isShowSoldOnly;
    private String searchCustZip;
    private String status;
    private String salesMan;
    private String salesRepID;
    private String cube;
    private String deliveryProfile;
    private String orderContact;
    private String region;
    private String shipmentContact;
    private String orderNumber;
    private String SCAC;
    private String loadNumber;
    private String TName;
    private String fromShipDate;
    private String toShipDate;
    private boolean multiple;
    private String multipleSerials;
    private String multipleCurrLocs;
    private String multipleModels;
    private String multipleCustNos;
    private String deepSearchSerialStatus;
    private String deepSearchInventoryStatus;
    private String orderContactName;
    private String territory = "";
    private String shipWithNumber = "";
    private String transferRequestId = "";
    private String transferCancelReason = "";
    private boolean deleteWesOrder;
    private boolean deleteWesInbound;
    private String fromCustomerNumber = "";
    private String toCustomerNumber = "";
    private String shipWithSearch = "";
    private String helpManualName = "";
    private String webNoticeHTMLText = "";
    private String webNotice = "";
    private String defaultCustomerNumberDisplayed = "";
    private String defaultCustomerNumberHidden = "";
    private String environment = "";
    private String environmentDevNotice = "";
    private String environmentProdNotice = "";
    private String devOrProdNotice = "";
    private String xferid = "";
    private boolean onDate;
    private String intransitCustomerNumber = "";
    private String surface;
    private String surfaceDesc;
    private String surfaceSerialNumber;
    private int orderQuantity;
    private String orderOptions;
    private String[] skuArray;
    private String[] skuDescArray;
    private String[] serialArray;
    private String[] fromCustomerArray;
    private String[] toCustomerArray;
    private String[] showNGoArray;
    private String[] transferRequestArray;
    private boolean noRepRequestNeeded;
    private boolean selectNoRepRequestNeeded;
    private boolean addInventoryDuringPickup;
    private boolean planCanadaTrialRequests;
    private boolean requireSalesOpportunity;
    private boolean requirePONumber;

    private String[] repRequestArray;
    private boolean siteDown;
    private String trialTransferSearchDivisionSelection;
    private String serialDescription;
    private String[] selectedArray;
    private String[] selectedTransfersToCancelArray;
    private String[] selectedSerialsToCancelArray;
    private String[] selectedSkusToCancelArray;
    private String authorizedToCancel;
    private String newOwner;
    private String description;
    private String domain;
    private String ipAddress;
    private String deliveredDate;
    private String deliveredTime;
    private String pickedUpDate;
    private String pickedUpTime;
    private Integer trialDurationId;
    private Integer repDivisionId;
    private String repDivision;
    private String repDivisionDescription;
    private Boolean repDivisionUsesSideTables;
    private Boolean salesRepDivisionUsesSideTables;
    private String repDivisionEmailAddress;
    private String repDivDeliveryTypes;
    private String repDivisionFunctions;
    private String userFunctions;
    private Integer attachmentId;
    private Integer sunshineMaxDays;
    private Integer deliveryTypeId;
    private String type;
    private String model;
    private String wesmodel;
    private String variation;
    private String desc;
    private String compKey;

    public Integer getRepDivisionId() {
        return repDivisionId;
    }

    public void setRepDivisionId(Integer repDivisionId) {
        this.repDivisionId = repDivisionId;
    }

    public String getRepDivision() {
        return repDivision;
    }

    public void setRepDivision(String repDivision) {
        this.repDivision = repDivision;
    }

    public String getRepDivisionDescription() {
        return repDivisionDescription;
    }

    public void setRepDivisionDescription(String repDivisionDescription) {
        this.repDivisionDescription = repDivisionDescription;
    }

    public Boolean getRepDivisionUsesSideTables() {
        return repDivisionUsesSideTables;
    }

    public void setRepDivisionUsesSideTables(boolean repDivisionUsesSideTables) {
        this.repDivisionUsesSideTables = repDivisionUsesSideTables;
    }

    public Boolean getSalesRepDivisionUsesSideTables() {
        return salesRepDivisionUsesSideTables;
    }

    public void setSalesRepDivisionUsesSideTables(Boolean salesRepDivisionUsesSideTables) {
        this.salesRepDivisionUsesSideTables = salesRepDivisionUsesSideTables;
    }

    public String getRepDivisionEmailAddress() {
        return repDivisionEmailAddress;
    }

    public void setRepDivisionEmailAddress(String repDivisionEmailAddress) {
        this.repDivisionEmailAddress = repDivisionEmailAddress;
    }

    public Integer getDeliveryTypeId() {
        return deliveryTypeId;
    }

    public void setDeliveryTypeId(Integer deliveryTypeId) {
        this.deliveryTypeId = deliveryTypeId;
    }

    public String getRepDivDeliveryTypes() {
        return repDivDeliveryTypes;
    }

    public void setRepDivDeliveryTypes(String repDivDeliveryTypes) {
        this.repDivDeliveryTypes = repDivDeliveryTypes;
    }

    public String getRepDivisionFunctions() {
        return repDivisionFunctions;
    }

    public void setRepDivisionFunctions(String repDivisionFunctions) {
        this.repDivisionFunctions = repDivisionFunctions;
    }

    public String getUserFunctions() {
        return userFunctions;
    }

    public void setUserFunctions(String userFunctions) {
        this.userFunctions = userFunctions;
    }

    public Integer getSunshineMaxDays() {
        return sunshineMaxDays;
    }

    public void setSunshineMaxDays(Integer sunshineMaxDays) {
        this.sunshineMaxDays = sunshineMaxDays;
    }

    public List<MenuItemDTO> getMenuItems() {
        return menuItems;
    }

    public void setMenuItems(List<MenuItemDTO> menuItems) {
        this.menuItems = menuItems;
    }

    public String getReturnMessage() {
        return returnMessage;
    }

    public void setReturnMessage(String returnMessage) {
        this.returnMessage = returnMessage;
    }

    public Integer getAttachmentId() {
        return attachmentId;
    }

    public void setAttachmentId(Integer attachmentId) {
        this.attachmentId = attachmentId;
    }

    public String getDeliveredDate() {
        return deliveredDate;
    }

    public void setDeliveredDate(String deliveredDate) {
        this.deliveredDate = deliveredDate;
    }

    public String getDeliveredTime() {
        return deliveredTime;
    }

    public void setDeliveredTime(String deliveredTime) {
        this.deliveredTime = deliveredTime;
    }

    public String getPickedUpDate() {
        return pickedUpDate;
    }

    public void setPickedUpDate(String pickedUpDate) {
        this.pickedUpDate = pickedUpDate;
    }

    public String getPickedUpTime() {
        return pickedUpTime;
    }

    public void setPickedUpTime(String pickedUpTime) {
        this.pickedUpTime = pickedUpTime;
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }

    public String getIpAddress() {
        return ipAddress;
    }

    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getInventoryList() {
        return inventoryList;
    }

    public void setInventoryList(String inventoryList) {
        this.inventoryList = inventoryList;
    }

    public String getNewOwner() {
        return newOwner;
    }

    public void setNewOwner(String newOwner) {
        this.newOwner = newOwner;
    }

    public String getAuthorizedToCancel() {
        return authorizedToCancel;
    }

    public void setAuthorizedToCancel(String authorizedToCancel) {
        this.authorizedToCancel = authorizedToCancel;
    }

    public String[] getSelectedSkusToCancelArray() {
        return selectedSkusToCancelArray;
    }

    public void setSelectedSkusToCancelArray(String[] selectedSkusToCancelArray) {
        this.selectedSkusToCancelArray = selectedSkusToCancelArray;
    }

    public String[] getSelectedSerialsToCancelArray() {
        return selectedSerialsToCancelArray;
    }

    public void setSelectedSerialsToCancelArray(String[] selectedSerialsToCancelArray) {
        this.selectedSerialsToCancelArray = selectedSerialsToCancelArray;
    }

    public String[] getSelectedTransfersToCancelArray() {
        return selectedTransfersToCancelArray;
    }

    public void setSelectedTransfersToCancelArray(String[] selectedTransfersToCancelArray) {
        this.selectedTransfersToCancelArray = selectedTransfersToCancelArray;
    }

    public String[] getSelectedArray() {
        return selectedArray;
    }

    public void setSelectedArray(String[] selectedArray) {
        this.selectedArray = selectedArray;
    }

    public WMSFormBean() {
        super();
    }

    public String getTrialTransferSearchDivisionSelection() {
        return trialTransferSearchDivisionSelection;
    }

    public void setTrialTransferSearchDivisionSelection(String trialTransferSearchDivisionSelection) {
        this.trialTransferSearchDivisionSelection = trialTransferSearchDivisionSelection;
    }

    public String getSerialDescription() {
        return serialDescription;
    }

    public void setSerialDescription(String serialDescription) {
        this.serialDescription = serialDescription;
    }

    public boolean isSiteDown() {
        return siteDown;
    }

    public void setSiteDown(boolean siteDown) {
        this.siteDown = siteDown;
    }

    public String[] getSerialArray() {
        return serialArray;
    }

    public void setSerialArray(String[] serialArray) {
        this.serialArray = serialArray;
    }

    public String[] getSkuArray() {
        return skuArray;
    }

    public void setSkuArray(String[] skuArray) {
        this.skuArray = skuArray;
    }

    public String[] getSkuDescArray() {
        return skuDescArray;
    }

    public void setSkuDescArray(String[] skuDescArray) {
        this.skuDescArray = skuDescArray;
    }

    public String[] getFromCustomerArray() {
        return fromCustomerArray;
    }

    public void setFromCustomerArray(String[] fromCustomerArray) {
        this.fromCustomerArray = fromCustomerArray;
    }

    public String[] getShowNGoArray() {
        return showNGoArray;
    }

    public void setShowNGoArray(String[] showNGoArray) {
        this.showNGoArray = showNGoArray;
    }

    public String[] getToCustomerArray() {
        return toCustomerArray;
    }

    public void setToCustomerArray(String[] toCustomerArray) {
        this.toCustomerArray = toCustomerArray;
    }

    public String[] getTransferRequestArray() {
        return transferRequestArray;
    }

    public void setTransferRequestArray(String[] transferRequestArray) {
        this.transferRequestArray = transferRequestArray;
    }

    public EntityManager getEntityManager() {
//        return this.getPersistenceManager().getEntityManager();
        return InitServlet.getSalesEntityManagerFactory().createEntityManager();
    }

    public boolean getIsCwic() {
        return iscwic;
    }

    public void setIsCwic(boolean iscwic) {
        this.iscwic = iscwic;
    }

    public String getWebNoticeHTMLText() {
        logger.info("Domain = " + getDomain()==null ? "" : getDomain().trim());
        if (getDomain()!=null && !getDomain().trim().startsWith("https://apps.kencogroup.com"))
            return webNoticeHTMLText;
        else
            return "";
    }

    public void setWebNoticeHTMLText(String webNoticeHTMLText) {
        if (webNoticeHTMLText.trim().length() > 0)
            this.webNoticeHTMLText = "-- NOTICE -- &nbsp;&nbsp;";
        else
            this.webNoticeHTMLText = "";

        this.webNoticeHTMLText += webNoticeHTMLText;
    }

    public String getWebNotice() {
        logger.info("Domain = " + StringUtils.trimToEmpty(getDomain()));
        if (getDomain()!=null && !StringUtils.trimToEmpty(getDomain()).startsWith("https://apps.kencogroup.com"))
            return webNotice;
        else
            return "";
    }

    public void setWebNotice(String webNotice) {
        this.webNotice = webNotice;
    }

    //<editor-fold defaultstate="collapsed" desc="CRUD's">
    String crudCustomerComboBox = "";
    String crudSkuComboBox = "";
    String crudLotIdText = "";
    String crudHoldCodeComboBox = "";
    String crudSerialStatusComboBox = "";
    String crudSerialNumberText = "";

    public String getCrudCustomerComboBox() {
        return crudCustomerComboBox;
    }

    public void setCrudCustomerComboBox(String crudCustomerComboBox) {
        this.crudCustomerComboBox = crudCustomerComboBox;
    }

    public String getCrudHoldCodeComboBox() {
        return crudHoldCodeComboBox;
    }

    public void setCrudHoldCodeComboBox(String crudHoldCodeComboBox) {
        this.crudHoldCodeComboBox = crudHoldCodeComboBox;
    }

    public String getCrudSerialStatusComboBox() {
        return crudSerialStatusComboBox;
    }

    public void setCrudSerialStatusComboBox(String crudSerialStatusComboBox) {
        this.crudSerialStatusComboBox = crudSerialStatusComboBox;
    }

    public String getCrudLotIdText() {
        return crudLotIdText;
    }

    public void setCrudLotIdText(String crudLotIdText) {
        this.crudLotIdText = crudLotIdText;
    }

    public String getCrudSerialNumberText() {
        return crudSerialNumberText;
    }

    public void setCrudSerialNumberText(String crudSerialNumberText) {
        this.crudSerialNumberText = crudSerialNumberText;
    }

    public String getCrudSkuComboBox() {
        return crudSkuComboBox;
    }

    public void setCrudSkuComboBox(String crudSkuComboBox) {
        this.crudSkuComboBox = crudSkuComboBox;
    }

    //</editor-fold>
    //<editor-fold defaultstate="collapsed" desc="EXCEL">
    //--------------- EXCEL ----------------------
    public boolean getCreateExcel() {
        return createexcel;
    }

    public void setCreateExcel(boolean createexcel) {
        this.createexcel = createexcel;
    }

    public String getExcelFileName() {
        return excelfilename;
    }

    public void setExcelFileName(String excelfilename) {
        this.excelfilename = excelfilename;
    }

    public int getMaxExcelRows() {
        return maxexcelrows;
    }

    public void setMaxExcelRows(int maxexcelrows) {
        this.maxexcelrows = maxexcelrows;
    }

    public String getExcelHrefLink() {
        return excelhreflink;
    }

    public void setExcelHrefLink(String excelhreflink) {
        this.excelhreflink = excelhreflink;
    }
    //</editor-fold>

    //<editor-fold defaultstate="collapsed" desc="LIBRARY INFORMATION">
    //--------------- LIBRARY INFORMATION ----------------------
    public String getUserDataLib() {
        return userDataLib;
    }

    public void setUserDataLib(String dataLib) {
        this.userDataLib = dataLib;
    }

    /*
     * CGI libraries
     */
    public String getCGIFILESLib() {
        return cgifileslib;
    }

    public void setCGIFILESLib(String cgifileslib) {
        this.cgifileslib = cgifileslib;
    }

    public String getCHKCGILib() {
        return chkcgilib;
    }

    public void setCHKCGILib(String chkcgilib) {
        this.chkcgilib = chkcgilib;
    }

    public void setSTYSNDRCVLib(String stysndrcvlib) {
        this.stysndrcvlib = stysndrcvlib;
    }

    public String getSTYSNDRCVLib() {
        return stysndrcvlib;
    }

    public String getSTYSharedLib() {
        return stysharedlib;
    }

    public void setSTYSharedLib(String stysharedlib) {
        this.stysharedlib = stysharedlib;
    }

    public String getSTYFileLib() {
        return styfilelib;
    }

    public void setSTYFileLib(String styfilelib) {
        this.styfilelib = styfilelib;
    }

    public String getStyjpalib() {
        return styjpalib;
    }

    public void setStyjpalib(String styjpalib) {
        this.styjpalib = styjpalib;
    }

    public String getOmslib() {
        return omslib;
    }

    public void setOmslib(String omslib) {
        this.omslib = omslib;
    }

    public String getStyPgmLib() {
        return stypgmlib;
    }

    public void setStyPgmLib(String stypgmlib) {
        this.stypgmlib = stypgmlib;
    }

    //</editor-fold>
    //<editor-fold defaultstate="collapsed" desc="CONFIG ITEMS">
    public int getMaxQueryRows() {
        return maxqueryrows;
    }

    public void setMaxQueryRows(int maxqueryrows) {
        this.maxqueryrows = maxqueryrows;
    }

    public int getMaxDropDownRows() {
        return maxdropdownrows;
    }

    public void setMaxDropDownRows(int maxdropdownrows) {
        this.maxdropdownrows = maxdropdownrows;
    }

    public String getLiveSearchQuery() {
        return query;
    }

    public void setLiveSearchQuery(String query) {
        this.query = query;
    }

    public int getRowsReturned() {
        return rowsreturned;
    }

    public String getCopyrightStatement() {
        return copyrightstatement;
    }

    public void setCopyrightStatement(String copyrightstatement) {
        this.copyrightstatement = copyrightstatement;
    }

    public int getFirstRow() {
        return firstRow;
    }

    public void setFirstRow(int firstRow) {
        this.firstRow = firstRow;
    }

    public String getRowsPerPage() {
        return rowsPerPage;
    }

    public int getRowsPerPageInt() {
        return this.getStringAsInt(this.rowsPerPage);
    }

    public void setRowsPerPage(String rowsPerPage) {
        this.rowsPerPage = rowsPerPage;
    }

    public String getTodayDate() {
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
        todayDate = dateFormat.format(calendar.getTime());
        return todayDate;
    }

    public void setRowsReturned(int rowsreturned) {
        this.rowsreturned = rowsreturned;
    }

    public String getMaxQueryMessage() {
        return maxquerymessage;
    }

    public void setMaxQueryMessage(String maxquerymessage) {
        this.maxquerymessage = maxquerymessage;
    }
//</editor-fold>

    //<editor-fold defaultstate="collapsed" desc="USER & PASSWORD">
    //--------------- USER & PWD INFORMATION ----------------------

    /*
     * user
     */
    public void setUser(String user) {
        this.user = user.toUpperCase();
    }

    public String getUser() {
        return user;
    }

    public String getUserRole() {
        return userRole;
    }

    public void setUserRole(String userRole) {
        this.userRole = userRole;
    }

    public int getUserRoleId() {
        return userRoleId;
    }

    public void setUserRoleId(int userRoleId) {
        this.userRoleId = userRoleId;
    }

    public int getSalesRepRoleId() {
        return salesRepRoleId;
    }

    public void setSalesRepRoleId(int salesRepRoleId) {
        this.salesRepRoleId = salesRepRoleId;
    }

    public String getPhoneExtension() {
        return phoneExtension;
    }

    public void setPhoneExtension(String phoneExtension) {
        this.phoneExtension = phoneExtension;
    }

    public String getStryker() {
        return stryker;
    }

    public void setStryker(String stryker) {
        this.stryker = stryker;
    }
    //</editor-fold>

    //<editor-fold defaultstate="collapsed" desc="COLLECTIONS">
    /*
    * customer list
    */
    public void setCustomerList(Collection<?> customerList) {
        this.customerList = customerList;
    }

    public Collection<?> getCustomerList() {
        return customerList;
    }

    public Collection<?> getDisplayableCustomerList() {
        return displayableCustomerList;
    }

    public void setDisplayableCustomerList(Collection<?> displayableCustomerList) {
        this.displayableCustomerList = displayableCustomerList;
    }

    public void setInvInqList(Collection<?> invInqList) {
        this.invInqList = invInqList;
    }

    public Collection<?> getInvInqList() {
        return invInqList;
    }
    //</editor-fold>

    //<editor-fold defaultstate="collapsed" desc="FORM SEARCH AND FILTER">
    // ------------- FILTER CRITERIA ------------------------------
    public String getCustomerNumber() {
        return customerNumber;
    }

    public void setCustomerNumber(String customerNumber) {
        this.customerNumber = customerNumber;
    }

    public String getCustomerNumberAndLibrary() {
        return customerNumberAndLibrary;
    }

    public void setCustomerNumberAndLibrary(String customerNumberAndLibrary) {
        this.customerNumberAndLibrary = customerNumberAndLibrary;
    }

    public void setSelectedCustomerFromDropDown(String selectedCustomerFromDropDown) {
        this.selectedCustomerFromDropDown = selectedCustomerFromDropDown;
    }

    public String getSelectedCustomerFromDropDown() {
        return selectedCustomerFromDropDown;
    }

    public String getDefaultCustomerNumberDisplayed() {
        return defaultCustomerNumberDisplayed;
    }

    public void setDefaultCustomerNumberDisplayed(String defaultCustomerNumberDisplayed) {
        this.defaultCustomerNumberDisplayed = defaultCustomerNumberDisplayed;
    }

    public String getDefaultCustomerNumberHidden() {
        return defaultCustomerNumberHidden;
    }

    public void setDefaultCustomerNumberHidden(String defaultCustomerNumberHidden) {
        this.defaultCustomerNumberHidden = defaultCustomerNumberHidden;
    }

    public String getSelectedDestinationFromDropDown() {
        return selectedDestinationFromDropDown;
    }

    public void setSelectedDestinationFromDropDown(String selectedDestinationFromDropDown) {
        this.selectedDestinationFromDropDown = selectedDestinationFromDropDown;
    }

    public String getSelectedOriginFromDropDown() {
        return selectedOriginFromDropDown;
    }

    public void setSelectedOriginFromDropDown(String selectedOriginFromDropDown) {
        this.selectedOriginFromDropDown = selectedOriginFromDropDown;
    }

    public String getProductModel() {
        return productModel;
    }

    public void setProductModel(String productModel) {
        this.productModel = productModel;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getProductDescription() {
        return productDescription;
    }

    public void setProductDescription(String productDescription) {
        this.productDescription = productDescription;
    }

    public Short getProductTcForm() {
        return productTcForm;
    }

    public void setProductTcForm(Short productTcForm) {
        this.productTcForm = productTcForm;
    }

    public String getProductDemoType() {
        return productDemoType;
    }

    public void setProductDemoType(String productDemoType) {
        this.productDemoType = productDemoType;
    }

    public String getProductEmailNewRq() {
        return productEmailNewRq;
    }

    public void setProductEmailNewRq(String productEmailNewRq) {
        this.productEmailNewRq = productEmailNewRq;
    }

    public Integer getProductDivisionId() {
        return productDivisionId;
    }

    public void setProductDivisionId(Integer productDivisionId) {
        this.productDivisionId = productDivisionId;
    }

    public BigDecimal getProductValue() {
        return productValue;
    }

    public void setProductValue(BigDecimal productValue) {
        this.productValue = productValue;
    }

    public String getProductVisible() {
        return productVisible;
    }

    public void setProductVisible(String productVisible) {
        this.productVisible = productVisible;
    }

    public String getProductVariation() {
        return productVariation;
    }

    public void setProductVariation(String productVariation) {
        this.productVariation = productVariation;
    }

    public String getSpecialInstructions() {
        return specialInstructions;
    }

    public void setSpecialInstructions(String specialInstructions) {
        this.specialInstructions = specialInstructions;
    }

    public BigDecimal getSalesOpportunity() {
        return salesOpportunity;
    }

    public String getSalesOpportunityNumber() {
        return salesOpportunityNumber;
    }

    public void setSalesOpportunityNumber(String salesOpportunityNumber) {
        this.salesOpportunityNumber = salesOpportunityNumber;
    }

    public boolean isFromSalesForce() {
        return this.fromSalesForce;
    }

    public void setFromSalesForce(boolean fromSalesForce) {
        this.fromSalesForce = fromSalesForce;
    }

    public String getPurchaseOrderNumber() {
        return purchaseOrderNumber;
    }

    public void setPurchaseOrderNumber(String purchaseOrderNumber) {
        this.purchaseOrderNumber = purchaseOrderNumber;
    }

    public void setSalesOpportunity(BigDecimal salesOpportunity) {
        this.salesOpportunity = salesOpportunity;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getProductCode() {
        return productCode;
    }

    public String getProductCodeDesc() {
        return productCodeDesc;
    }

    public void setProductCodeDesc(String productCodeDesc) {
        this.productCodeDesc = productCodeDesc;
    }

    public String getSurface() {
        return surface;
    }

    public void setSurface(String surface) {
        this.surface = surface;
    }

    public String getSurfaceDesc() {
        return surfaceDesc;
    }

    public void setSurfaceDesc(String surfaceDesc) {
        this.surfaceDesc = surfaceDesc;
    }

    public String getSurfaceSerialNumber() {
        return surfaceSerialNumber;
    }

    public void setSurfaceSerialNumber(String surfaceSerialNumber) {
        this.surfaceSerialNumber = surfaceSerialNumber;
    }

    public int getOrderQuantity() {
        return orderQuantity;
    }

    public void setOrderQuantity(int orderQuantity) {
        this.orderQuantity = orderQuantity;
    }

    public String getOrderOptions() {
        return orderOptions;
    }

    public void setOrderOptions(String orderOptions) {
        this.orderOptions = orderOptions;
    }

    public void setLotID(String lotID) {
        this.lotID = lotID;
    }

    public String getLotID() {
        return lotID;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }

    public String getCurrentHoldCode() {
        return currentHoldCode;
    }

    public void setCurrentHoldCode(String currentHoldCode) {
        this.currentHoldCode = currentHoldCode;
    }

    public String getNewHoldCode() {
        return newHoldCode;
    }

    public void setNewHoldCode(String newHoldCode) {
        this.newHoldCode = newHoldCode;
    }

    public String getCurrentSerialStatus() {
        return currentSerialStatus;
    }

    public void setCurrentSerialStatus(String currentSerialStatus) {
        this.currentSerialStatus = currentSerialStatus;
    }

    public String getNewSerialStatus() {
        return newSerialStatus;
    }

    public void setNewSerialStatus(String newSerialStatus) {
        this.newSerialStatus = newSerialStatus;
    }

    public String getSerialStatus() {
        return serialStatus;
    }

    public void setSerialStatus(String serialStatus) {
        this.serialStatus = serialStatus;
    }

    public String getCurrentInventoryStatus() {
        return currentInventoryStatus;
    }

    public void setCurrentInventoryStatus(String currentInventoryStatus) {
        this.currentInventoryStatus = currentInventoryStatus;
    }

    public String getNewInventoryStatus() {
        return newInventoryStatus;
    }

    public void setNewInventoryStatus(String newInventoryStatus) {
        this.newInventoryStatus = newInventoryStatus;
    }

    public String getInventoryStatus() {
        return inventoryStatus;
    }

    public void setInventoryStatus(String inventoryStatus) {
        this.inventoryStatus = inventoryStatus;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    public String getMui() {
        return mui;
    }

    public void setMui(String mui) {
        this.mui = mui;
    }

    public String getExpireDt() {
        return expireDt;
    }

    public void setExpireDt(String expireDt) {
        this.expireDt = expireDt;
    }
    //</editor-fold>

    public String getInvBySkuPage() {
        return invbyskupage;
    }

    public void setInvBySkuPage(String InvBySkuPage) {
        this.invbyskupage = InvBySkuPage;
    }

    public void setSearchProcessed(boolean searchProcessed) {
        this.searchProcessed = searchProcessed;
    }

    public boolean isSearchProcessed() {
        return searchProcessed;
    }

    public void setTotalPages(String totalPages) {
        this.totalPages = totalPages;
    }

    public String getTotalPages() {
        return totalPages;
    }

    public void setCurrentPage(String currentPage) {
        this.currentPage = currentPage;
    }

    public String getCurrentPage() {
        return currentPage;
    }

    // Here we are dealing with page timeout: GLOBAL
    public void setTimeout(String timeout) {
        this.timeout = timeout;
    }

    public String getTimeout() {
        return timeout;
    }

    // Here we are dealing with a page by page timeout.  Use this if a page
    // needs a timeout value that is different than the global default.
    public void setTimeout(String jspPage, String timeout) {
        appTimeout.put(jspPage, timeout);
    }

    public String getTimeout(String jspPage) {
        return (String) appTimeout.get(jspPage);
    }

    public void setJavascriptMenu(Collection<?> javascriptMenu) {
        this.javascriptMenu = javascriptMenu;
    }

    public Collection<?> getJavascriptMenu() {
        return javascriptMenu;
    }

    public void setJavascriptPage(String javascriptPage) {
        this.javascriptPage = javascriptPage;
    }

    public String getJavascriptPage() {
        return javascriptPage;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getFullName() {
        return lastName + ", " + firstName;
    }

    public Collection<?> getStateList() {
        return stateList;
    }

    public void setStateList(Collection<?> stateList) {
        this.stateList = stateList;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEmailVerify() {
        return emailVerify;
    }

    public void setEmailVerify(String emailVerify) {
        this.emailVerify = emailVerify;
    }

    public String getEmailSender() {
        return emailSender;
    }

    public void setEmailSender(String emailSender) {
        this.emailSender = emailSender;
    }

    public String getEmailServer() {
        return emailServer;
    }

    public void setEmailServer(String emailServer) {
        this.emailServer = emailServer;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getAddress1() {
        return address1;
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public String getAddress2() {
        return address2;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public void setZipcode(String zipcode) {
        this.zipcode = zipcode;
    }

    public String getZipcode() {
        return zipcode;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPhone() {
        return phone;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getCompany() {
        return company;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public String getComments() {
        return comments;
    }

    public Collection<?> getTtCustList() {
        return ttCustList;
    }

    public void setTtCustList(Collection<?> ttCustList) {
        this.ttCustList = ttCustList;
    }

    public Collection<?> getTtLdcList() {
        return ttLdcList;
    }

    public void setTtLdcList(Collection<?> ttLdcList) {
        this.ttLdcList = ttLdcList;
    }

    public Collection<?> getTtLdcListAll() {
        return ttLdcListAll;
    }

    public void setTtLdcListAll(Collection<?> ttLdcListAll) {
        this.ttLdcListAll = ttLdcListAll;
    }

    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }

    public String getSerialNumber() {
        return serialNumber;
    }

    public void setSelectedTransfer(String selectedTransfer) {
        this.selectedTransfer = selectedTransfer;
    }

    public String getSelectedTransfer() {
        return selectedTransfer;
    }

    public void setCurrentLocation(String currentLocation) {
        this.currentLocation = currentLocation;
    }

    public String getCurrentLocation() {
        return currentLocation;
    }

    public void setCurrentLocationNumber(String currentLocationNumber) {
        this.currentLocationNumber = currentLocationNumber;
    }

    public String getCurrentLocationNumber() {
        return currentLocationNumber;
    }

    public void setNextAvailable(String nextAvailable) {
        this.nextAvailable = nextAvailable;
    }

    public String getNextAvailable() {
        return nextAvailable;
    }

    public void setDefaultNextAvailable(String defaultNextAvailable) {
        this.defaultNextAvailable = defaultNextAvailable;
    }

    public String getDefaultNextAvailable() {
        return defaultNextAvailable;
    }

    public void setCustCBValue(String custCBValue) {
        this.custCBValue = custCBValue;
    }

    public String getCustCBValue() {
        return custCBValue;
    }

    public void setTocustCBValue(String tocustCBValue) {
        this.tocustCBValue = tocustCBValue;
    }

    public String getTocustCBValue() {
        return tocustCBValue;
    }

    public void setTocustIDCBValue(String tocustIDCBValue) {
        this.tocustIDCBValue = tocustIDCBValue;
    }

    public String getTocustIDCBValue() {
        return tocustIDCBValue;
    }

    public void setCustCBValueLoc(String custCBValueLoc) {
        this.custCBValueLoc = custCBValueLoc;
    }

    public String getCustCBValueLoc() {
        return custCBValueLoc;
    }

    public void setLdcCBValue(String ldcCBValue) {
        this.ldcCBValue = ldcCBValue;
    }

    public String getLdcCBValue() {
        return ldcCBValue;
    }

    public void setRdcCBValue(String rdcCBValue) {
        this.rdcCBValue = rdcCBValue;
    }

    public String getRdcCBValue() {
        return rdcCBValue;
    }

    public void setToldcCBValue(String toldcCBValue) {
        this.toldcCBValue = toldcCBValue;
    }

    public String getToldcCBValue() {
        return toldcCBValue;
    }

    public void setLdcCBValueLoc(String ldcCBValueLoc) {
        this.ldcCBValueLoc = ldcCBValueLoc;
    }

    public String getLdcCBValueLoc() {
        return ldcCBValueLoc;
    }

    public void setStartdt(String startdt) {
        this.startdt = startdt;
    }

    public String getStartdt() {
        return startdt;
    }

    public void setStartdt2(String startdt2) {
        this.startdt2 = startdt2;
    }

    public String getStartdt2() {
        return startdt2;
    }

    public void setEnddt(String enddt) {
        this.enddt = enddt;
    }

    public String getEnddt() {
        return enddt;
    }

    public void setEnddt2(String enddt2) {
        this.enddt2 = enddt2;
    }

    public String getEnddt2() {
        return enddt2;
    }

    public void setPickupDate(String pickupDate) {
        this.pickupDate = pickupDate;
    }

    public String getPickupDate() {
        return pickupDate;
    }

    public String getPickupTime() {
        return pickupTime;
    }

    public void setPickupTime(String pickupTime) {
        this.pickupTime = pickupTime;
    }

    public String getSoldDate() {
        return soldDate;
    }

    public void setSoldDate(String soldDate) {
        this.soldDate = soldDate;
    }

    public void setDeliveryDate(String deliveryDate) {
        this.deliveryDate = deliveryDate;
    }

    public String getDeliveryDate() {
        return deliveryDate;
    }

    public void setDeliveryTime(String deliveryTime) {
        this.deliveryTime = deliveryTime;
    }

    public String getDeliveryTime() {
        return deliveryTime;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public void setStyDataLib(String styDataLib) {
        this.styDataLib = styDataLib;
    }

    public String getStyDataLib() {
        return styDataLib;
    }

    public void setManualSKUNumber(String manualSKUNumber) {
        this.manualSKUNumber = manualSKUNumber;
    }

    public String getManualSKUNumber() {
        return manualSKUNumber;
    }

    public void setSkuNumber(String skuNumber) {
        this.skuNumber = skuNumber;
    }

    public String getSkuNumber() {
        return skuNumber;
    }

    public void setManualLotid(String manualLotid) {
        this.manualLotid = manualLotid;
    }

    public String getManualLotid() {
        return manualLotid;
    }

    public void setDefaultStayDays(String defaultStayDays) {
        this.defaultStayDays = defaultStayDays;
    }

    public String getDefaultStayDays() {
        return defaultStayDays;
    }

    public void setQuery(String query) {
        this.query = query;
    }

    public String getQuery() {
        return query;
    }

    public void setLimit(String limit) {
        this.limit = limit;
    }

    public String getLimit() {
        return limit;
    }

    public void setStart(String start) {
        this.start = start;
    }

    public String getStart() {
        return start;
    }

    public void setExport(String export) {
        this.export = export;
    }

    public String getExport() {
        return export;
    }

    public void setWebserverPath(String webserverPath) {
        this.webserverPath = webserverPath;
    }

    public String getWebserverPath() {
        return webserverPath;
    }

    public String getOpenEndedDate() {
        return openEndedDate;
    }

    public void setOpenEndedDate(String openEndedDate) {
        this.openEndedDate = openEndedDate;
    }

    public void setTransferRequest(String transferRequest) {
        this.transferRequest = transferRequest;
    }

    public String getTransferRequest() {
        return transferRequest;
    }

    public void setDateField(String dateField) {
        this.dateField = dateField;
    }

    public String getDateField() {
        return dateField;
    }

    public void setNewDate(String newDate) {
        this.newDate = newDate;
    }

    public String getNewDate() {
        return newDate;
    }

    public void setShowNGo(String showNGo) {
        this.showNGo = showNGo;
    }

    public String getShowNGo() {
        return showNGo;
    }

    public void setStySearch(String stySearch) {
        this.stySearch = stySearch;
    }

    public String getStySearch() {
        return stySearch;
    }

    public void setStySearchType(String stySearchType) {
        this.stySearchType = stySearchType;
    }

    public String getStySearchType() {
        return stySearchType;
    }

    public void setStySearchRdc(String stySearchRdc) {
        this.stySearchRdc = stySearchRdc;
    }

    public String getStySearchRdc() {
        return stySearchRdc;
    }

    public void setStySearchSerial(String stySearchSerial) {
        this.stySearchSerial = stySearchSerial;
    }

    public String getStySearchSerial() {
        return stySearchSerial;
    }

    public void setStySearchProductCode(String stySearchProductCode) {
        this.stySearchProductCode = stySearchProductCode;
    }

    public String getStySearchProductCode() {
        return stySearchProductCode;
    }

    public void setStySearchFromDate(String stySearchFromDate) {
        this.stySearchFromDate = stySearchFromDate;
    }

    public String getStySearchFromDate() {
        return stySearchFromDate;
    }

    public void setStySearchToDate(String stySearchToDate) {
        this.stySearchToDate = stySearchToDate;
    }

    public String getStySearchToDate() {
        return stySearchToDate;
    }

    public void setStySearchExcel(String stySearchExcel) {
        this.stySearchExcel = stySearchExcel;
    }

    public String getStySearchExcel() {
        return stySearchExcel;
    }

    public String getIsTrialBed() {
        return isTrialBed;
    }

    public void setIsTrialBed(String isTrialBed) {
        this.isTrialBed = isTrialBed;
    }

    public boolean getIsTrialBedAsBoolean() {
        return getStringAsBoolean(isTrialBed);
    }

    public String getIsShowSoldOnly() {
        return isShowSoldOnly;
    }

    public void setIsShowSoldOnly(String isShowSoldOnly) {
        this.isShowSoldOnly = isShowSoldOnly;
    }

    public boolean getIsShowSoldOnlyAsBoolean() {
        return getStringAsBoolean(isShowSoldOnly);
    }

    public String getIsShowSold() {
        return isShowSold;
    }

    public void setIsShowSold(String isShowSold) {
        this.isShowSold = isShowSold;
    }

    public boolean getIsShowSoldAsBoolean() {
        return getStringAsBoolean(isShowSold);
    }

    public void logErrorFromJSP(Exception e) {

        logger.error("STRUTS EXCEPTION HANDLER HAS CAUGHT THE FOLLOWING ERROR:");
        logger.error(e.getMessage(), e);

    }

    public String getSearchCustZip() {
        return searchCustZip;
    }

    public void setSearchCustZip(String searchCustZip) {
        this.searchCustZip = searchCustZip;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getSalesMan() {
        return salesMan;
    }

    public void setSalesMan(String salesMan) {
        this.salesMan = salesMan;
    }

    public String getCube() {
        return cube;
    }

    public String getSalesRepID() {
        return salesRepID;
    }

    public void setSalesRepID(String salesRepID) {
        this.salesRepID = salesRepID;
    }

    public void setCube(String cube) {
        this.cube = cube;
    }

    public String getDeliveryProfile() {
        return deliveryProfile;
    }

    public void setDeliveryProfile(String deliveryProfile) {
        this.deliveryProfile = deliveryProfile.toUpperCase();
    }

    public String getOrderContact() {
        return orderContact;
    }

    public void setOrderContact(String orderContact) {
        this.orderContact = orderContact.toUpperCase();
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region.toUpperCase();
    }

    public String getShipmentContact() {
        return shipmentContact;
    }

    public void setShipmentContact(String shipmentContact) {
        this.shipmentContact = shipmentContact.toUpperCase();
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    public String getSCAC() {
        return SCAC;
    }

    public void setSCAC(String SCAC) {
        this.SCAC = SCAC;
    }

    public String getLoadNumber() {
        return loadNumber;
    }

    public void setLoadNumber(String loadNumber) {
        this.loadNumber = loadNumber;
    }

    public String getTName() {
        return TName;
    }

    public void setTName(String TName) {
        this.TName = TName;
    }

    public String getFromShipDate() {
        return fromShipDate;
    }

    public void setFromShipDate(String fromShipDate) {
        this.fromShipDate = fromShipDate;
    }

    public String getToShipDate() {
        return toShipDate;
    }

    public void setToShipDate(String toShipDate) {
        this.toShipDate = toShipDate;
    }

    public boolean isMultiple() {
        return multiple;
    }

    public void setMultiple(boolean multiple) {
        this.multiple = multiple;
    }

    public String getMultipleSerials() {
        return multipleSerials;
    }

    public void setMultipleSerials(String multipleSerials) {
        this.multipleSerials = multipleSerials;
    }

    public String getMultipleCurrLocs() {
        return multipleCurrLocs;
    }

    public void setMultipleCurrLocs(String multipleCurrLocs) {
        this.multipleCurrLocs = multipleCurrLocs;
    }

    public String getMultipleCustNos() {
        return multipleCustNos;
    }

    public void setMultipleCustNos(String multipleCustNos) {
        this.multipleCustNos = multipleCustNos;
    }

    public String getMultipleModels() {
        return multipleModels;
    }

    public void setMultipleModels(String multipleModels) {
        this.multipleModels = multipleModels;
    }

    public String getDeepSearchInventoryStatus() {
        return deepSearchInventoryStatus;
    }

    public void setDeepSearchInventoryStatus(String deepSearchInventoryStatus) {
        this.deepSearchInventoryStatus = deepSearchInventoryStatus;
    }

    public String getDeepSearchSerialStatus() {
        return deepSearchSerialStatus;
    }

    public void setDeepSearchSerialStatus(String deepSearchSerialStatus) {
        this.deepSearchSerialStatus = deepSearchSerialStatus;
    }

    public String getOrderContactName() {
        return orderContactName;
    }

    public void setOrderContactName(String orderContactName) {
        this.orderContactName = orderContactName;
    }

    public String getTerritory() {
        return territory;
    }

    public void setTerritory(String territory) {
        this.territory = territory;
    }

    public List<String> getJavascriptIncludes() {
        return javascriptIncludes;
    }

    public void setJavascriptIncludes(List<String> javascriptIncludes) {
        this.javascriptIncludes = javascriptIncludes;
    }

    public void resetJavascriptIncludes() {
        this.javascriptIncludes = new ArrayList<String>();
    }

    public void resetJavascriptIncludes(String javascriptPage) {
        this.javascriptIncludes = new ArrayList<String>();
        this.javascriptIncludes.add(javascriptPage);
    }

    public void appendJavascriptIncludes(String javascriptPage) {
        if (this.javascriptIncludes == null) {
            this.resetJavascriptIncludes();
        }
        this.javascriptIncludes.add(javascriptPage);
    }

    public String getShipWithNumber() {
        return shipWithNumber;
    }

    public void setShipWithNumber(String shipWithNumber) {
        this.shipWithNumber = shipWithNumber;
    }

    public String getTransferRequestId() {
        return transferRequestId;
    }

    public void setTransferRequestId(String transferRequestId) {
        this.transferRequestId = transferRequestId;
    }

    public String getTransferCancelReason() {
        return transferCancelReason.toUpperCase();
    }

    public void setTransferCancelReason(String transferCancelReason) {
        this.transferCancelReason = transferCancelReason;
    }

    public boolean isDeleteWesOrder() {
        return deleteWesOrder;
    }

    public void setDeleteWesOrder(boolean deleteWesOrder) {
        this.deleteWesOrder = deleteWesOrder;
    }

    public boolean isDeleteWesInbound() {
        return deleteWesInbound;
    }

    public void setDeleteWesInbound(boolean deleteWesInbound) {
        this.deleteWesInbound = deleteWesInbound;
    }

    public String getFromCustomerNumber() {
        return fromCustomerNumber;
    }

    public void setFromCustomerNumber(String fromCustomerNumber) {
        this.fromCustomerNumber = fromCustomerNumber;
    }

    public String getToCustomerNumber() {
        return toCustomerNumber;
    }

    public void setToCustomerNumber(String toCustomerNumber) {
        this.toCustomerNumber = toCustomerNumber;
    }

    public String getShipWithSearch() {
        return shipWithSearch;
    }

    public void setShipWithSearch(String shipWithSearch) {
        this.shipWithSearch = shipWithSearch;
    }

    public String getHelpManualName() {
        return helpManualName;
    }

    public void setHelpManualName(String helpManualName) {
        this.helpManualName = helpManualName;
    }

    public String getSelectedCustomerName() {
        return selectedCustomerName;
    }

    public void setSelectedCustomerName(String selectedCustomerName) {
        this.selectedCustomerName = selectedCustomerName;
    }

    public String getCodeDescription() {
        return codeDescription;
    }

    public void setCodeDescription(String codeDescription) {
        this.codeDescription = codeDescription;
    }

    public String getEnvironment() {
        return environment;
    }

    public void setEnvironment(String environment) {
        this.environment = environment;
    }

    public String getEnvironmentDevNotice() {
        return environmentDevNotice;
    }

    public void setEnvironmentDevNotice(String environmentDevNotice) {
        this.environmentDevNotice = environmentDevNotice;
    }

    public String getEnvironmentProdNotice() {
        return environmentProdNotice;
    }

    public void setEnvironmentProdNotice(String environmentProdNotice) {
        this.environmentProdNotice = environmentProdNotice;
    }

    public String getDevOrProdNotice() {
        return devOrProdNotice;
    }

    public void setDevOrProdNotice(String devOrProdNotice) {
        this.devOrProdNotice = devOrProdNotice;
    }

    public String getXferid() {
        return xferid;
    }

    public void setXferid(String xferid) {
        this.xferid = xferid;
    }

    public String getIntransitCustomerNumber() {
        return intransitCustomerNumber;
    }

    public void setIntransitCustomerNumber(String intransitCustomerNumber) {
        this.intransitCustomerNumber = intransitCustomerNumber;
    }

    public boolean isOnDate() {
        return onDate;
    }

    public void setOnDate(boolean onDate) {
        this.onDate = onDate;
    }

    public boolean isNoRepRequestNeeded() {
        return noRepRequestNeeded;
    }

    public void setNoRepRequestNeeded(boolean noRepRequestNeeded) {
        this.noRepRequestNeeded = noRepRequestNeeded;
    }

    public boolean isSelectNoRepRequestNeeded() {
        return selectNoRepRequestNeeded;
    }

    public void setSelectNoRepRequestNeeded(boolean selectNoRepRequestNeeded) {
        this.selectNoRepRequestNeeded = selectNoRepRequestNeeded;
    }

    public boolean isAddInventoryDuringPickup() {
        return addInventoryDuringPickup;
    }

    public void setAddInventoryDuringPickup(boolean addInventoryDuringPickup) {
        this.addInventoryDuringPickup = addInventoryDuringPickup;
    }

    public boolean isPlanCanadaTrialRequests() {
        return planCanadaTrialRequests;
    }

    public void setPlanCanadaTrialRequests(boolean planCanadaTrialRequests) {
        this.planCanadaTrialRequests = planCanadaTrialRequests;
    }

    public boolean isRequireSalesOpportunity() {
        return requireSalesOpportunity;
    }

    public void setRequireSalesOpportunity(boolean requireSalesOpportunity) {
        this.requireSalesOpportunity = requireSalesOpportunity;
    }

    public boolean isRequirePONumber() {
        return requirePONumber;
    }

    public void setRequirePONumber(boolean requirePONumber) {
        this.requirePONumber = requirePONumber;
    }


    public String[] getRepRequestArray() {
        return repRequestArray;
    }

    public void setRepRequestArray(String[] repRequestArray) {
        this.repRequestArray = repRequestArray;
    }

    //<editor-fold defaultstate="collapsed" desc="SalesOrderHeader">
    private String requestedBy;
    private String ownerCode;
    private boolean byUserID;
    private boolean byFirstName;
    private boolean byLastName;
    private String rdcID;
    private String requestType;
    private boolean loaner;
    private String legalAcknowledgement;
    private String legalNotice;
    private String cmbRequestTypeValue;      // this is so trialtransfer newTransfer form submit will send the value to struts...
    private int salesOrderHeaderKey;
    private int salesOrderDetailKey;
    private boolean isSalesOrderUpdateMode;
    private String orderType;
    private String trialType;
    private String scheduleDate;
    private boolean scheduleOnDate;
    private boolean scheduleASAPDate;
    private boolean scheduleNoLaterThanDate;
    private String scheduleTime;
    private String scheduleTimeEnd;
    private String scheduleCustomerID;
    private String scheduleCustomerName;
    private String scheduleAddress;
    private String scheduleCity;
    private String scheduleState;
    private String scheduleZip;
    private String scheduleName;
    private String schedulePhone;
    private String schedulePhoneExtension;
    private String scheduleEmail;
    private boolean scheduleLiftGate;
    private boolean scheduleDockAvailable;
    private boolean scheduleTractorTrailerAccessible;
    private String scheduleOtherInstructions;
    private String customerMasterKey;
    private int salesOrderStopKey;
    private boolean scheduleNewCustomer;
    private boolean scheduleExistingCustomer;
    private boolean pickupDestination;
    private boolean pickupDateTBD;
    private int deliveryDateReasonId;
    private String deliveryDateReason;
    private int pickupDateReasonId;
    private String pickupDateReason;
    private Integer shortTruckOptionId;
    private String rgTrialsForSale;

    public String getRgTrialsForSale() {
        return rgTrialsForSale;
    }

    public void setRgTrialsForSale(String rgTrialsForSale) {
        this.rgTrialsForSale = rgTrialsForSale;
    }

    public Integer getShortTruckOptionId() {
        return shortTruckOptionId;
    }

    public void setShortTruckOptionId(Integer shortTruckOptionId) {
        this.shortTruckOptionId = shortTruckOptionId;
    }

    public int getDeliveryDateReasonId() {
        return deliveryDateReasonId;
    }

    public void setDeliveryDateReasonId(int deliveryDateReasonId) {
        this.deliveryDateReasonId = deliveryDateReasonId;
    }

    public String getDeliveryDateReason() {
        return deliveryDateReason;
    }

    public int getPickupDateReasonId() {
        return pickupDateReasonId;
    }

    public void setPickupDateReasonId(int pickupDateReasonId) {
        this.pickupDateReasonId = pickupDateReasonId;
    }

    public String getPickupDateReason() {
        return pickupDateReason;
    }

    public void setPickupDateReason(String pickupDateReason) {
        this.pickupDateReason = pickupDateReason;
    }

    public void setDeliveryDateReason(String deliveryDateReason) {
        this.deliveryDateReason = deliveryDateReason;
    }

    public boolean isPickupDateTBD() {
        return pickupDateTBD;
    }

    public void setPickupDateTBD(boolean pickupDateTBD) {
        this.pickupDateTBD = pickupDateTBD;
    }

    public boolean isByFirstName() {
        return byFirstName;
    }

    public void setByFirstName(boolean byFirstName) {
        this.byFirstName = byFirstName;
    }

    public boolean isByLastName() {
        return byLastName;
    }

    public void setByLastName(boolean byLastName) {
        this.byLastName = byLastName;
    }

    public boolean isByUserID() {
        return byUserID;
    }

    public void setByUserID(boolean byUserID) {
        this.byUserID = byUserID;
    }

    public boolean isPickupDestination() {
        return pickupDestination;
    }

    public void setPickupDestination(boolean pickupDestination) {
        this.pickupDestination = pickupDestination;
    }

    public boolean isScheduleExistingCustomer() {
        return scheduleExistingCustomer;
    }

    public void setScheduleExistingCustomer(boolean scheduleExistingCustomer) {
        this.scheduleExistingCustomer = scheduleExistingCustomer;
    }

    public boolean isScheduleNewCustomer() {
        return scheduleNewCustomer;
    }

    public void setScheduleNewCustomer(boolean scheduleNewCustomer) {
        this.scheduleNewCustomer = scheduleNewCustomer;
    }

    public boolean isScheduleOnDate() {
        return scheduleOnDate;
    }

    public void setScheduleOnDate(boolean scheduleOnDate) {
        this.scheduleOnDate = scheduleOnDate;
    }

    public boolean isScheduleASAPDate() {
        return scheduleASAPDate;
    }

    public void setScheduleASAPDate(boolean scheduleASAPDate) {
        this.scheduleASAPDate = scheduleASAPDate;
    }

    public boolean isScheduleNoLaterThanDate() {
        return scheduleNoLaterThanDate;
    }

    public void setScheduleNoLaterThanDate(boolean scheduleNoLaterThanDate) {
        this.scheduleNoLaterThanDate = scheduleNoLaterThanDate;
    }

    public int getSalesOrderStopKey() {
        return salesOrderStopKey;
    }

    public void setSalesOrderStopKey(int salesOrderStopKey) {
        this.salesOrderStopKey = salesOrderStopKey;
    }

    public String getCustomerMasterKey() {
        return customerMasterKey;
    }

    public void setCustomerMasterKey(String customerMasterKey) {
        this.customerMasterKey = customerMasterKey;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public String getTrialType() {
        return trialType;
    }

    public void setTrialType(String trialType) {
        this.trialType = trialType;
    }

    public String getRdcID() {
        return rdcID;
    }

    public void setRdcID(String rdcID) {
        this.rdcID = rdcID;
    }

    public boolean isSalesOrderUpdateMode() {
        return isSalesOrderUpdateMode;
    }

    public void setIsSalesOrderUpdateMode(boolean isSalesOrderUpdateMode) {
        this.isSalesOrderUpdateMode = isSalesOrderUpdateMode;
    }

    public int getSalesOrderHeaderKey() {
        return salesOrderHeaderKey;
    }

    public void setSalesOrderHeaderKey(int salesOrderHeaderKey) {
        this.salesOrderHeaderKey = salesOrderHeaderKey;
    }

    public int getSalesOrderDetailKey() {
        return salesOrderDetailKey;
    }

    public void setSalesOrderDetailKey(int salesOrderDetailKey) {
        this.salesOrderDetailKey = salesOrderDetailKey;
    }

    public String getRequestType() {
        return requestType;
    }

    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    public boolean isLoaner() {
        return loaner;
    }

    public void setLoaner(boolean loaner) {
        this.loaner = loaner;
    }

    public String getLegalAcknowledgement() {
        return legalAcknowledgement;
    }

    public void setLegalAcknowledgement(String legalAcknowledgement) {
        this.legalAcknowledgement = legalAcknowledgement;
    }

    public String getLegalNotice() {
        return legalNotice;
    }

    public void setLegalNotice(String legalNotice) {
        this.legalNotice = legalNotice;
    }

    public String getCmbRequestTypeValue() {
        return cmbRequestTypeValue;
    }

    public void setCmbRequestTypeValue(String cmbRequestTypeValue) {
        this.cmbRequestTypeValue = cmbRequestTypeValue;
    }

    public String getRequestedBy() {
        return requestedBy;
    }

    public void setRequestedBy(String requestedBy) {
        this.requestedBy = requestedBy;
    }

    public String getOwnerCode() {
        return ownerCode;
    }

    public void setOwnerCode(String ownerCode) {
        this.ownerCode = ownerCode;
    }

    public String getScheduleAddress() {
        return scheduleAddress;
    }

    public void setScheduleAddress(String scheduleAddress) {
        this.scheduleAddress = scheduleAddress;
    }

    public String getScheduleCity() {
        return scheduleCity;
    }

    public void setScheduleCity(String scheduleCity) {
        this.scheduleCity = scheduleCity;
    }

    public String getScheduleZip() {
        return scheduleZip;
    }

    public void setScheduleZip(String scheduleZip) {
        this.scheduleZip = scheduleZip;
    }

    public String getScheduleCustomer() {
        return scheduleCustomerID;
    }

    public void setScheduleCustomer(String scheduleCustomer) {
        this.scheduleCustomerID = scheduleCustomer;
    }

    public String getScheduleCustomerName() {
        return scheduleCustomerName;
    }

    public void setScheduleCustomerName(String scheduleCustomerName) {
        this.scheduleCustomerName = scheduleCustomerName;
    }

    public String getScheduleCustomerID() {
        return scheduleCustomerID;
    }

    public void setScheduleCustomerID(String scheduleCustomerID) {
        this.scheduleCustomerID = scheduleCustomerID;
    }

    public String getScheduleDate() {
        return scheduleDate;
    }

    public void setScheduleDate(String scheduleDate) {
        this.scheduleDate = scheduleDate;
    }

    public boolean isScheduleDockAvailable() {
        return scheduleDockAvailable;
    }

    public void setScheduleDockAvailable(boolean scheduleDockAvailable) {
        this.scheduleDockAvailable = scheduleDockAvailable;
    }

    public String getScheduleEmail() {
        return scheduleEmail;
    }

    public void setScheduleEmail(String scheduleEmail) {
        this.scheduleEmail = scheduleEmail;
    }

    public boolean isScheduleLiftGate() {
        return scheduleLiftGate;
    }

    public void setScheduleLiftGate(boolean scheduleLiftGate) {
        this.scheduleLiftGate = scheduleLiftGate;
    }

    public String getScheduleName() {
        return scheduleName;
    }

    public void setScheduleName(String scheduleName) {
        this.scheduleName = scheduleName;
    }

    public String getScheduleOtherInstructions() {
        return scheduleOtherInstructions;
    }

    public void setScheduleOtherInstructions(String scheduleOtherInstructions) {
        this.scheduleOtherInstructions = scheduleOtherInstructions;
    }

    public String getSchedulePhone() {
        return schedulePhone;
    }

    public void setSchedulePhone(String schedulePhone) {
        this.schedulePhone = schedulePhone;
    }

    public String getSchedulePhoneExtension() {
        return schedulePhoneExtension;
    }

    public void setSchedulePhoneExtension(String schedulePhoneExtension) {
        this.schedulePhoneExtension = schedulePhoneExtension;
    }

    public String getScheduleState() {
        return scheduleState;
    }

    public void setScheduleState(String scheduleState) {
        this.scheduleState = scheduleState;
    }

    public String getScheduleTime() {
        return scheduleTime;
    }

    public void setScheduleTime(String scheduleTime) {
        this.scheduleTime = scheduleTime;
    }

    public String getScheduleTimeEnd() {
        return scheduleTimeEnd;
    }

    public void setScheduleTimeEnd(String scheduleTimeEnd) {
        this.scheduleTimeEnd = scheduleTimeEnd;
    }

    public boolean isScheduleTractorTrailerAccessible() {
        return scheduleTractorTrailerAccessible;
    }

    public void setScheduleTractorTrailerAccessible(boolean scheduleTractorTrailerAccessible) {
        this.scheduleTractorTrailerAccessible = scheduleTractorTrailerAccessible;
    }
    //</editor-fold>

    //<editor-fold defaultstate="collapsed" desc="Sales Order Room Detail">
    private String trialInstallDate;
    private String trialInstallTime;
    private String trialTakeDownDate;
    private String roomNumber;
    private String installationNotes;
    private String ceilingHeight;
    private Boolean ceilingSupport;
    private Boolean ceilingInconsistencies;
    private Boolean trackLighting;
    private String lightDetails; // This is a JSON-Formatted Array

    public String getTrialInstallDate() {
        return trialInstallDate;
    }

    public void setTrialInstallDate(String trialInstallDate) {
        this.trialInstallDate = trialInstallDate;
    }

    public String getTrialInstallTime() {
        return trialInstallTime;
    }

    public void setTrialInstallTime(String trialInstallTime) {
        this.trialInstallTime = trialInstallTime;
    }

    public String getTrialTakeDownDate() {
        return trialTakeDownDate;
    }

    public void setTrialTakeDownDate(String trialTakeDownDate) {
        this.trialTakeDownDate = trialTakeDownDate;
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    public String getInstallationNotes() {
        return installationNotes;
    }

    public void setInstallationNotes(String installationNotes) {
        this.installationNotes = installationNotes;
    }

    public String getCeilingHeight() {
        return ceilingHeight;
    }

    public void setCeilingHeight(String ceilingHeight) {
        this.ceilingHeight = ceilingHeight;
    }

    public Boolean getCeilingSupport() {
        return ceilingSupport;
    }

    public void setCeilingSupport(Boolean ceilingSupport) {
        this.ceilingSupport = ceilingSupport;
    }

    public Boolean getCeilingInconsistencies() {
        return ceilingInconsistencies;
    }

    public void setCeilingInconsistencies(Boolean ceilingInconsistencies) {
        this.ceilingInconsistencies = ceilingInconsistencies;
    }

    public Boolean getTrackLighting() {
        return trackLighting;
    }

    public void setTrackLighting(Boolean trackLighting) {
        this.trackLighting = trackLighting;
    }

    public String getLightDetails() {
        return lightDetails;
    }

    public void setLightDetails(String lightDetails) {
        this.lightDetails = lightDetails;
    }

    //</editor-fold>

    //<editor-fold defaultstate="collapsed" desc="RepContact">
    private String repContactDate = "";
    private String repContactRepID = "";
    private String repContactName = "";
    private String repContactInitiate = "";
    private String repContactPositive = "";
    private String repContactComments = "";
    private String repRDC = "";
    private String repRdcID = "";
    private String repRDCName = "";
    private String repRDCPhone = "";
    private String repOwnerCode = "";
    private String repEmail = "";
    private String repPhone = "";
    private String repPhoneExtension = "";
    private String salesRepDivision = "";
    private String salesRepRDCName = "";
    private String salesRepEmail = "";
    private String kzooRdcName = "";

    public String getRepRDC() {
        return repRDC;
    }

    public void setRepRDC(String repRDC) {
        this.repRDC = repRDC;
    }

    public String getRepRdcID() {
        return repRdcID;
    }

    public void setRepRdcID(String repRdcID) {
        this.repRdcID = repRdcID;
    }

    public String getRepRDCName() {
        return repRDCName;
    }

    public void setRepRDCName(String repRDCName) {
        this.repRDCName = repRDCName;
    }

    public String getRepRDCPhone() {
        return repRDCPhone;
    }

    public void setRepRDCPhone(String repRDCPhone) {
        this.repRDCPhone = repRDCPhone;
    }

    public String getRepOwnerCode() {
        return repOwnerCode;
    }

    public void setRepOwnerCode(String repOwnerCode) {
        this.repOwnerCode = repOwnerCode;
    }

    public String getRepEmail() {
        return repEmail;
    }

    public void setRepEmail(String repEmail) {
        this.repEmail = repEmail;
    }

    public String getRepPhone() {
        return repPhone;
    }

    public void setRepPhone(String repPhone) {
        this.repPhone = repPhone;
    }

    public String getRepPhoneExtension() {
        return repPhoneExtension;
    }

    public void setRepPhoneExtension(String repPhoneExtension) {
        this.repPhoneExtension = repPhoneExtension;
    }

    public String getSalesRepDivision() {
        return salesRepDivision;
    }

    public void setSalesRepDivision(String salesRepDivision) {
        this.salesRepDivision = salesRepDivision;
    }

    public String getSalesRepEmail() {
        return salesRepEmail;
    }

    public void setSalesRepEmail(String salesRepEmail) {
        this.salesRepEmail = salesRepEmail;
    }

    public String getSalesRepRDCName() {
        return salesRepRDCName;
    }

    public void setSalesRepRDCName(String salesRepRDCName) {
        this.salesRepRDCName = salesRepRDCName;
    }

    public String getKzooRdcName() {
        return kzooRdcName;
    }

    public void setKzooRdcName(String kzooRdcName) {
        this.kzooRdcName = kzooRdcName;
    }

    public String getRepContactComments() {
        return repContactComments;
    }

    public void setRepContactComments(String repContactComments) {
        this.repContactComments = repContactComments;
    }

    public String getRepContactDate() {
        return repContactDate;
    }

    public void setRepContactDate(String repContactDate) {
        this.repContactDate = repContactDate;
    }

    public String getRepContactInitiate() {
        return repContactInitiate;
    }

    public void setRepContactInitiate(String repContactInitiate) {
        this.repContactInitiate = repContactInitiate;
    }

    public String getRepContactName() {
        return repContactName;
    }

    public void setRepContactName(String repContactName) {
        this.repContactName = repContactName;
    }

    public String getRepContactPositive() {
        return repContactPositive;
    }

    public void setRepContactPositive(String repContactPositive) {
        this.repContactPositive = repContactPositive;
    }

    public String getRepContactRepID() {
        return repContactRepID;
    }

    public void setRepContactRepID(String repContactRepID) {
        this.repContactRepID = repContactRepID;
    }

    //</editor-fold>
    //<editor-fold defaultstate="collapsed" desc="trackedProcesses">
    private String processCode = "";
    private String processCodeDescription = "";
    private String processComment = "";
    private String crudTpLogTextArea = "";
    private String crudTpText = "";
    private String crudTpSequence = "";
    private String crudTpDescriptionText = "";
    private String processSeqence = "";

    private String crudTypeText = "";
    private String crudModelText = "";
    private String crudWesModelCombo = "";
    private String crudVariationText = "";
    private String crudDescText = "";
    private Short crudProductTcForm;
    private String crudProductDemoType = "";
    private Integer crudProductDivisionId=0;
    private BigDecimal crudProductValue= BigDecimal.valueOf(0);

    private String navigateSmsUrl;
    private String configSmsUrl;
    private String configItemUrl;
    private String smsQueueUrl;
    private String modelConfigUrl;
    private String dcalApiUrl;

    public String getDcalApiUrl() {
        return dcalApiUrl;
    }

    public void setDcalApiUrl(String dcalApiUrl) {
        this.dcalApiUrl = dcalApiUrl;
    }

    public String getCrudTypeText() {
        return crudTypeText;
    }

    public void setCrudTypeText(String crudTypeText) {
        this.crudTypeText = crudTypeText;
    }

    public String getCrudModelText() {
        return crudModelText;
    }

    public void setCrudModelText(String crudModelText) {
        this.crudModelText = crudModelText;
    }

    public String getCrudWesModelCombo() {
        return crudWesModelCombo;
    }

    public void setCrudWesModelCombo(String crudWesModelCombo) {
        this.crudWesModelCombo = crudWesModelCombo;
    }

    public String getCrudVariationText() {
        return crudVariationText;
    }

    public void setCrudVariationText(String crudVariationText) {
        this.crudVariationText = crudVariationText;
    }

    public String getCrudDescText() {
        return crudDescText;
    }

    public void setCrudDescText(String crudDescText) {
        this.crudDescText = crudDescText;
    }

    public Short getCrudProductTcForm() {
        return crudProductTcForm;
    }
    public void setCrudProductTcForm(Short crudProductTcForm) {
        this.crudProductTcForm = crudProductTcForm;
    }

    public String getCrudProductDemoType() {
        return crudProductDemoType;
    }
    public void setCrudProductDemoType(String crudProductDemoType) {
        this.crudProductDemoType = crudProductDemoType;
    }

    public Integer getCrudProductDivisionId() {
        return crudProductDivisionId;
    }

    public void setCrudProductDivisionId(Integer crudProductDivisionId) {
        this.crudProductDivisionId = crudProductDivisionId;
    }

    public BigDecimal getCrudProductValue() {
        return crudProductValue;
    }

    public void setCrudProductValue(BigDecimal crudProductValue) {
        this.crudProductValue = crudProductValue;
    }

    public String getNavigateSmsUrl() {
        return navigateSmsUrl;
    }

    public void setNavigateSmsUrl(String navigateSmsUrl) {
        this.navigateSmsUrl = navigateSmsUrl;
    }

    public String getConfigSmsUrl() {
        return configSmsUrl;
    }

    public void setConfigSmsUrl(String configSmsUrl) {
        this.configSmsUrl = configSmsUrl;
    }

    public String getConfigItemUrl() {
        return configItemUrl;
    }

    public void setConfigItemUrl(String configItemUrl) {
        this.configItemUrl = configItemUrl;
    }

    public String getSmsQueueUrl() {
        return smsQueueUrl;
    }

    public void setSmsQueueUrl(String smsQueueUrl) {
        this.smsQueueUrl = smsQueueUrl;
    }

    public String getModelConfigUrl() {
        return modelConfigUrl;
    }

    public void setModelConfigUrl(String modelConfigUrl) {
        this.modelConfigUrl = modelConfigUrl;
    }

    public String getProcessCode() {
        return processCode;
    }

    public void setProcessCode(String processCode) {
        this.processCode = processCode;
    }

    public String getProcessCodeDescription() {
        return processCodeDescription;
    }

    public void setProcessCodeDescription(String processCodeDescription) {
        this.processCodeDescription = processCodeDescription;
    }

    public String getProcessComment() {
        return processComment;
    }

    public void setProcessComment(String processComment) {
        this.processComment = processComment;
    }

    public String getCrudTpDescriptionText() {
        return crudTpDescriptionText;
    }

    public void setCrudTpDescriptionText(String crudTpDescriptionText) {
        this.crudTpDescriptionText = crudTpDescriptionText;
    }

    public String getCrudTpText() {
        return crudTpText;
    }

    public void setCrudTpText(String crudTpText) {
        this.crudTpText = crudTpText;
    }

    public String getCrudTpLogTextArea() {
        return crudTpLogTextArea;
    }

    public void setCrudTpLogTextArea(String crudTpLogTextArea) {
        this.crudTpLogTextArea = crudTpLogTextArea;
    }

    public String getProcessSeqence() {
        return processSeqence;
    }

    public void setProcessSeqence(String processSeqence) {
        this.processSeqence = processSeqence;
    }

    public String getCrudTpSequence() {
        return crudTpSequence;
    }

    public void setCrudTpSequence(String crudTpSequence) {
        this.crudTpSequence = crudTpSequence;
    }

    //</editor-fold>
    //<editor-fold defaultstate="collapsed" desc="convertStringMethods">
    // convert string to integer...
    private int getStringAsInt(String paStringValue) {
        logger.info("Starting method getStringAsInt() paStringValue: '" + paStringValue + "'");

        int iReturnValue = 0;
        try {
            iReturnValue = Integer.parseInt(paStringValue);
        } catch (Exception e) {
            logger.error("Error in getStringAsInt() iReturnValue:  " + iReturnValue, e);
            iReturnValue = 0;
        }

        return iReturnValue;

    }

    // convert string to boolean...
    private boolean getStringAsBoolean(String paStringValue) {
        boolean bReturnValue = false;

        if (paStringValue != null && (paStringValue.toUpperCase().equals("TRUE") || paStringValue.toUpperCase().equals("FALSE"))) {
            bReturnValue = Boolean.parseBoolean(paStringValue);
        }

        return bReturnValue;

    }

    //</editor-fold>
    //<editor-fold defaultstate="collapsed" desc="WebTayloringByUser">
    String headerImage = "";
    String leftVerticalBarImage = "";
    String webPageTitle = "";
    String webPageIcon = "";
    String webMenuName = "";
    String webMenuAlignment = "";
    String webExtJSTheme = "";

    public String getWebExtJSTheme() {
        return webExtJSTheme;
    }

    public void setWebExtJSTheme(String webExtJSTheme) {
        this.webExtJSTheme = webExtJSTheme;
    }

    public String getWebMenuAlignment() {
        return webMenuAlignment;
    }

    public void setWebMenuAlignment(String webMenuAlignment) {
        this.webMenuAlignment = webMenuAlignment;
    }

    public String getWebMenuName() {
        return webMenuName;
    }

    public void setWebMenuName(String webMenuName) {
        this.webMenuName = webMenuName;
    }

    public String getWebPageIcon() {
        return webPageIcon;
    }

    public void setWebPageIcon(String webPageIcon) {
        this.webPageIcon = webPageIcon;
    }

    public String getWebPageTitle() {
        return webPageTitle;
    }

    public void setWebPageTitle(String webPageTitle) {
        this.webPageTitle = webPageTitle;
    }

    public String getHeaderImage() {
        return headerImage;
    }

    public void setHeaderImage(String headerImage) {
        this.headerImage = headerImage;
    }

    public String getLeftVerticalBarImage() {
        return leftVerticalBarImage;
    }

    public void setLeftVerticalBarImage(String leftVerticalBarImage) {
        this.leftVerticalBarImage = leftVerticalBarImage;
    }

    //</editor-fold>
    //<editor-fold defaultstate="collapsed" desc="AS400Program">
    String as400ProgramUserId = "";
    String as400ProgramPassword = "";
    String as400Id = "";
    String as400ProgramLibrary = "";

    public String getAs400ProgramLibrary() {
        return as400ProgramLibrary;
    }

    public void setAs400ProgramLibrary(String as400ProgramLibrary) {
        this.as400ProgramLibrary = as400ProgramLibrary;
    }

    public String getAs400Id() {
        return as400Id;
    }

    public void setAs400Id(String as400Id) {
        this.as400Id = as400Id;
    }

    public String getAs400ProgramPassword() {
        return as400ProgramPassword;
    }

    public void setAs400ProgramPassword(String as400ProgramPassword) {
        this.as400ProgramPassword = as400ProgramPassword;
    }

    public String getAs400ProgramUserId() {
        return as400ProgramUserId;
    }

    public void setAs400ProgramUserId(String as400ProgramUserId) {
        this.as400ProgramUserId = as400ProgramUserId;
    }
    //</editor-fold>

    // </editor-fold>
    public Integer getTrialDurationId() {
        return trialDurationId;
    }

    public void setTrialDurationId(Integer trialDurationId) {
        this.trialDurationId = trialDurationId;
    }


    //<editor-fold defaultstate="collapsed" desc="OMS">
    private String omsDefaultInboundOrderReceiptType;
    private String omsDefaultInboundOrderScac;
    private String omsDefaultInboundOrderTrailerNumber;
    private String omsDefaultOutboundOrderOrderType;
    private String omsDefaultOutboundOrderRoutedFlag;
    private String omsDefaultOutboundOrderScheduledDepartureTime;
    private String omsDefaultOutboundOrderScac;
    private String omsDefaultOutboundOrderFreightTerms;
    private String omsDefaultCustomerName;
    private String omsDefaultBusinessUnitName;
    private int omsDefaultCustomerId;
    private int omsDefaultBusinessUnitId;
    private String omsDefaultCustomerDataLibrary;
    private int customerId;
    private Boolean[] active;
    private String team;
    private String businessunit;
    private String records;

    public String getOmsDefaultCustomerDataLibrary() {
        return omsDefaultCustomerDataLibrary;
    }

    public void setOmsDefaultCustomerDataLibrary(String omsDefaultCustomerDataLibrary) {
        this.omsDefaultCustomerDataLibrary = omsDefaultCustomerDataLibrary;
    }

    public String getOmsDefaultCustomerName() {
        return omsDefaultCustomerName;
    }

    public void setOmsDefaultCustomerName(String omsDefaultCustomerName) {
        this.omsDefaultCustomerName = omsDefaultCustomerName;
    }

    public String getOmsDefaultBusinessUnitName() {
        return omsDefaultBusinessUnitName;
    }

    public void setOmsDefaultBusinessUnitName(String omsDefaultBusinessUnitName) {
        this.omsDefaultBusinessUnitName = omsDefaultBusinessUnitName;
    }

    public int getOmsDefaultCustomerId() {
        return omsDefaultCustomerId;
    }

    public void setOmsDefaultCustomerId(int omsDefaultCustomerId) {
        this.omsDefaultCustomerId = omsDefaultCustomerId;
    }

    public int getOmsDefaultBusinessUnitId() {
        return omsDefaultBusinessUnitId;
    }

    public void setOmsDefaultBusinessUnitId(int omsDefaultBusinessUnitId) {
        this.omsDefaultBusinessUnitId = omsDefaultBusinessUnitId;
    }

    public String getOmsDefaultInboundOrderReceiptType() {
        return omsDefaultInboundOrderReceiptType;
    }

    public void setOmsDefaultInboundOrderReceiptType(String omsDefaultInboundOrderReceiptType) {
        this.omsDefaultInboundOrderReceiptType = omsDefaultInboundOrderReceiptType;
    }

    public String getOmsDefaultInboundOrderScac() {
        return omsDefaultInboundOrderScac;
    }

    public void setOmsDefaultInboundOrderScac(String omsDefaultInboundOrderScac) {
        this.omsDefaultInboundOrderScac = omsDefaultInboundOrderScac;
    }

    public String getOmsDefaultInboundOrderTrailerNumber() {
        return omsDefaultInboundOrderTrailerNumber;
    }

    public void setOmsDefaultInboundOrderTrailerNumber(String omsDefaultInboundOrderTrailerNumber) {
        this.omsDefaultInboundOrderTrailerNumber = omsDefaultInboundOrderTrailerNumber;
    }

    public String getOmsDefaultOutboundOrderOrderType() {
        return omsDefaultOutboundOrderOrderType;
    }

    public void setOmsDefaultOutboundOrderOrderType(String omsDefaultOutboundOrderOrderType) {
        this.omsDefaultOutboundOrderOrderType = omsDefaultOutboundOrderOrderType;
    }

    public String getOmsDefaultOutboundOrderRoutedFlag() {
        return omsDefaultOutboundOrderRoutedFlag;
    }

    public void setOmsDefaultOutboundOrderRoutedFlag(String omsDefaultOutboundOrderRoutedFlag) {
        this.omsDefaultOutboundOrderRoutedFlag = omsDefaultOutboundOrderRoutedFlag;
    }

    public String getOmsDefaultOutboundOrderScheduledDepartureTime() {
        return omsDefaultOutboundOrderScheduledDepartureTime;
    }

    public void setOmsDefaultOutboundOrderScheduledDepartureTime(String omsDefaultOutboundOrderScheduledDepartureTime) {
        this.omsDefaultOutboundOrderScheduledDepartureTime = omsDefaultOutboundOrderScheduledDepartureTime;
    }

    public String getOmsDefaultOutboundOrderScac() {
        return omsDefaultOutboundOrderScac;
    }

    public void setOmsDefaultOutboundOrderScac(String omsDefaultOutboundOrderScac) {
        this.omsDefaultOutboundOrderScac = omsDefaultOutboundOrderScac;
    }

    public String getOmsDefaultOutboundOrderFreightTerms() {
        return omsDefaultOutboundOrderFreightTerms;
    }

    public void setOmsDefaultOutboundOrderFreightTerms(String omsDefaultOutboundOrderFreightTerms) {
        this.omsDefaultOutboundOrderFreightTerms = omsDefaultOutboundOrderFreightTerms;
    }

    public Boolean[] isActive() {
        return active;
    }

    public void setActive(Boolean[] active) {
        this.active = active;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public String getTeam() {
        return team;
    }

    public void setTeam(String team) {
        this.team = team;
    }

    public String getBusinessunit() {
        return businessunit;
    }

    public void setBusinessunit(String businessunit) {
        this.businessunit = businessunit;
    }
    //</editor-fold>

    public String getRecords() {
        return records;
    }

    public void setRecords(String records) {
        this.records = records;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getModel() {
        return model;
    }

    public void setWesmodel(String wesmodel) {
        this.wesmodel = wesmodel;
    }

    public String getWesmodel() {
        return wesmodel;
    }

    public void setVariation(String variation) {
        this.variation = variation;
    }

    public String getVariation() {
        return variation;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getDesc() {
        return desc;
    }

    public void setCompKey(String compKey) {
        this.compKey = compKey;
    }

    public String getCompKey() {
        return compKey;
    }
}
