package com.kenco.sims.entity;

import com.kenco.struts.wmsio.tables.Salesorderheader;

import javax.persistence.*;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;

@Entity
@Table(name = "TXRQSTDTL")
@IdClass(TxrqstdtlPK.class)
@XmlRootElement
public class Txrqstdtl  implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    private String txfrrqstId;

    @Id
    private String salesId;

    @ManyToOne(fetch = FetchType.LAZY)
    @PrimaryKeyJoinColumn(name = "SALESID", referencedColumnName = "SALESORDERHEADERKEY")
    Salesorderheader salesorderheader;

    public String getTxfrrqstId() {
        return txfrrqstId;
    }

    public void setTxfrrqstId(String txfrrqstId) {
        this.txfrrqstId = txfrrqstId;
    }

    public String getSalesId() {
        return salesId;
    }

    public void setSalesId(String salesId) {
        this.salesId = salesId;
    }

    public Salesorderheader getSalesorderheader() {
        return salesorderheader;
    }

    public void setSalesorderheader(Salesorderheader salesorderheader) {
        this.salesorderheader = salesorderheader;
    }
}
