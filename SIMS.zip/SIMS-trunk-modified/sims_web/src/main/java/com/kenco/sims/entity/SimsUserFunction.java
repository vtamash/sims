package com.kenco.sims.entity;

import com.kenco.sims.domain.UserFunction;
import javax.persistence.*;

@Entity
@DiscriminatorValue("USER")
public class SimsUserFunction extends SimsFunction {
    @Enumerated(EnumType.STRING)
    @Column(name = "FUNCTION", length = 64, nullable = false)
    private UserFunction function;

    @Override
    public SimsFunctionType getType() {
        return SimsFunctionType.USER;
    }

    @Override
    public boolean equals(Object o) {
        return o instanceof SimsUserFunction &&
                getId().equals(((SimsUserFunction) o).getId());
    }

    @Override
    public int hashCode() {
        return getId().hashCode();
    }

    @Override
    public String toString() {
        return getFunction().toString();
    }

    public UserFunction getFunction() {
        return function;
    }

    public void setFunction(UserFunction function) {
        this.function = function;
    }
}
