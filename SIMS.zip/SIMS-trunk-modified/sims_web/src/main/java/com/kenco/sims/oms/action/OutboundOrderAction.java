package com.kenco.sims.oms.action;

import com.kenco.oms.entity.Customers;
import com.kenco.oms.entity.Outboundorderdetail;
import com.kenco.oms.entity.Outboundorderheader;
import com.kenco.oms.entity.Outboundordernotes;
import com.kenco.oms.search.OutboundOrderSearchRequest;
import com.kenco.oms.service.impl.GenericCustomersService;
import com.kenco.oms.utilities.Enums;
import com.kenco.sims.oms.domain.OutboundOrderStub;
import com.kenco.sims.oms.service.impl.OmsDownloadService;
import com.kenco.sims.oms.service.impl.OutboundOrderService;
import com.kenco.sims.oms.view.JsonView;
import com.kenco.struts.formbeans.WMSFormBean;
import com.kenco.struts.utilities.InitServlet;
import com.kenco.struts.utilities.PojoMapper;
import json.org.JSONArray;
import json.org.JSONObject;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class OutboundOrderAction extends Action {
    private static Logger logger = LoggerFactory.getLogger(OutboundOrderAction.class);
    private final static String SUCCESS = "success";

    /**
     * Access point for and controls of the flow for each outbound (OutboundOrder-releated) request.
     */
    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
        WMSFormBean wfb = (WMSFormBean) form;

        logger.info("USER: " + wfb.getUser() + " Starting execute() method");

        // Setup our Business Services.
        final OmsDownloadService      dService = new OmsDownloadService(InitServlet.getEntityManagerFactory().createEntityManager());
        final GenericCustomersService cService = new GenericCustomersService(InitServlet.getEntityManagerFactory().createEntityManager());
        final OutboundOrderService    service  = new OutboundOrderService(InitServlet.getEntityManagerFactory().createEntityManager(), dService);

        // Route the request.
        JsonView<?> view;
        try {
            String action = request.getParameter("action");
            String bean = request.getParameter("bean");

            // Render the page.
            if (action == null)
                return renderStrut(wfb, mapping);

                // Order Search.
            else if (request.getMethod().equals("GET") && action.equals("search"))
                view = searchOrders(request, service, cService);

			// Read Order Details.
			else if (request.getMethod().equals("GET") && action.equals("read") && bean != null && bean.equals("detail"))
				view = readDetails(request, service);

			// Read Order Notes.
			else if (request.getMethod().equals("GET") && action.equals("read") && bean != null && bean.equals("note"))
				view = readNotes(request, service);

                // Search Order Numbers.
            else if (request.getMethod().equals("GET") && action.equals("searchNumbers"))
                view = new JsonView<>(searchOrderNumbers(request, service, cService));

                // Search Creators.
            else if (request.getMethod().equals("GET") && action.equals("searchCreators"))
                view = new JsonView<>(searchCreators(request, service, cService));

                // Search Ship-Tos.
            else if (request.getMethod().equals("GET") && action.equals("searchShipTos"))
                view = new JsonView<>(searchShipTos(request, service, cService));


                // Create / Update Order Header.
            else if (request.getMethod().equals("POST") && action.equals("update") && bean != null && bean.equals("header"))
                view = routeOrderHeaderRequest(request, wfb, service);

			// Remove Order Header.
			else if (request.getMethod().equals("POST") && action.equals("delete") && bean != null && bean.equals("header"))
				view = deleteOrderHeader(request, service);

			// Create / Update Order Detail.
			else if (request.getMethod().equals("POST") && action.equals("update") && bean != null && bean.equals("detail"))
                view = routeOrderDetailRequest(request, wfb, service);

			// Remove Order Detail.
			else if (request.getMethod().equals("POST") && action.equals("delete") && bean != null && bean.equals("detail"))
				view = removeOrderDetail(request, wfb, service);

			// Create / Update Order Note.
			else if (request.getMethod().equals("POST") && action.equals("update") && bean != null && bean.equals("note"))
                view = routeOrderNoteRequest(request, wfb, service);

			// Remove Order Note.
			else if (request.getMethod().equals("POST") && action.equals("delete") && bean != null && bean.equals("note"))
				view = deleteOrderNote(request, wfb, service);

			// Complete Order.
			else if (request.getMethod().equals("POST") && action.equals("complete"))
				view = completeOrder(request, service, wfb);

                // Catch-all for sanity.
            else
                throw new IllegalArgumentException("Invalid Action.");
		} catch (IllegalStateException ise) {
			logger.warn("Exception caught and handled:", ise);

			view = new JsonView<Object>(ise.getMessage());
		} catch (IllegalArgumentException iae) {
			logger.warn("Exception caught and handled:", iae);

			view = new JsonView<Object>(iae.getMessage());
        } catch (Exception e) {
            // Log the error.
            logger.error("Error processing OutboundOrder-Action request: ", e);

            // Respond to the call negatively for user-feedback.
            view = new JsonView<Object>("There was an error proccessing this request.");
        }

        PrintWriter out = response.getWriter();
        out.print(PojoMapper.toJson(view, true));
        out.flush();
        out.close();

        logger.info("USER: " + wfb.getUser() + " Exiting execute() method");
        return null;
    }

    /**
     * Forwards the caller to the proper JSP for interaction with Outbound Orders.
     */
    private ActionForward renderStrut(WMSFormBean wfb, ActionMapping mapping) {
        wfb.resetJavascriptIncludes("appOutboundOrders.js"); // Use append after this.
        logger.info("USER: " + wfb.getUser() + " Exiting execute() method");
        return mapping.findForward(SUCCESS);
    }

    /**
     * Performs the primary search and returns a Collection (page) of results that match the provided <i>SearchRequest</i>.
     */
    private JsonView<Outboundorderheader> searchOrders(HttpServletRequest request, OutboundOrderService service, GenericCustomersService cService) throws Exception {
        OutboundOrderSearchRequest search = marshallRequest(request, cService.readById(Integer.parseInt(request.getParameter("customerId"))));

        return new JsonView<>(service.readPage(search), service.readSearchTotal(search));
    }

    /**
     * Performs a search of all OutboundOrderHeaders based on the Order Number.
     */
    private List<Map<String, Object>> searchOrderNumbers(HttpServletRequest request, OutboundOrderService service, GenericCustomersService cService) throws Exception {
        // Parse out the Customer Id.
        Integer customerId = parseCustomerNumberFilter(request);

        // Read and return our entities.
        return service.searchOrderNumbers(request.getParameter("orderNumber"), cService.readById(customerId));
    }

    /**
     * Performs a search of all OutboundOrderHeaders based on the CreatedUserName.
     */
    private List<Map<String, Object>> searchCreators(HttpServletRequest request, OutboundOrderService service, GenericCustomersService cService) throws Exception {
        // Parse out the Customer Id.
        Integer customerId = parseCustomerNumberFilter(request);

        // Read and return our entities.
        return service.searchCreators(request.getParameter("creator"), cService.readById(customerId));
    }

    /**
     * Performs a search of all OutboundOrderHeaders based on the Ship-To Name.
     */
    private List<Map<String, Object>> searchShipTos(HttpServletRequest request, OutboundOrderService service, GenericCustomersService cService) throws Exception {
        // Parse out the Customer Id.
        Integer customerId = parseCustomerNumberFilter(request);

        // Read and return our entities.
        return service.searchShipTos(request.getParameter("shipTo"), cService.readById(customerId));
    }


	/**
	 * Updates the OutboundOrderHeader that matches the provided ID (<b>Primary Key</b>) to have a status of "Complete."
	 *
	 * <b>Note</b>: This action will trigger an OmsDownload to be created.
	 *
	 * !!This action is secured!!
	 *
	 * @see com.kenco.oms.utilities.Enums.eOMSOrderStatus
	 * @see com.kenco.sims.oms.service.impl.OmsDownloadService
	 * @see com.kenco.oms.service.OutboundOrderAbstractService
	 */
	private JsonView<Outboundorderheader> completeOrder(HttpServletRequest request, OutboundOrderService service, WMSFormBean wfb) {
		Outboundorderheader order = service.readById(Integer.parseInt(request.getParameter("id")));
		order.setStatus(Enums.eOMSOrderStatus.C.toString());
		order.setUpdateprogram("OutboundOrderModel.setOrderComplete");

		service.update(order, wfb.getUser(), null);

		return new JsonView<>(order);
	}

    private JsonView<Outboundorderheader> routeOrderHeaderRequest(HttpServletRequest request, WMSFormBean wfb, OutboundOrderService service) {
        String orderNumber = request.getParameter("orderNumber");
        if (orderNumber == null || orderNumber.trim().isEmpty() || orderNumber.equals("XXXXXXXX"))
            return createOrderHeader(request, wfb, service);
        else
            return updateOrderHeader(request, wfb, service);

    }

	/**
	 * The request to <b>CREATE</b> or <b>UDATE</b> an <i>OutboundOrderDetail</i> entity is one and the same.  Therefore,
	 * we must find out - programatically - which operation the user is attempting to perform and then route it to the
	 * correct code.
	 *
	 * !!This action is secured!!
	 */
	private JsonView<?> routeOrderDetailRequest(HttpServletRequest request, WMSFormBean wfb, OutboundOrderService service) throws Exception {
		JSONObject jRecords = readJson(request);
		JSONArray jNotes =  ((JSONObject) jRecords.get("records")).getJSONArray("outboundordernotesCollection");
		Collection<Outboundordernotes> notes = new ArrayList<>();
		for (int i=0; i<jNotes.length(); i++)
			notes.add((Outboundordernotes) PojoMapper.fromJson((jNotes.get(i)).toString(), Outboundordernotes.class));
		
		Outboundorderdetail detail = (Outboundorderdetail) PojoMapper.fromJson((jRecords.get("records")).toString(), Outboundorderdetail.class);
		Outboundorderheader order  = service.readById(detail.getOutboundorderheaderId().getId());

		return detail.getId() == null || detail.getId() == 0 ? createOrderDetail(order, detail, notes, wfb, service) : updateOrderDetail(order, detail, notes, wfb, service);
	}

	/**
	 * Creates an OutboundOrderDetail for the user-submitted OutboundOrderHeader.
	 *
	 * !!This action is secured!!
	 */
	private JsonView<?> createOrderDetail(Outboundorderheader order, Outboundorderdetail detail, Collection<Outboundordernotes> notes,  WMSFormBean wfb, OutboundOrderService service) {
		service.addOrderDetail(order, detail, notes, wfb.getUser());

		JsonView<?> view = new JsonView();
		view.setSuccess(true);
		return view;
	}

	/**
	 * Updates an OutboundOrderDetail for the user-submitted OutboundOrderHeader.
	 *
	 * !!This action is secured!!
	 */
	private JsonView<?> updateOrderDetail(Outboundorderheader order, Outboundorderdetail detail, Collection<Outboundordernotes> notes, WMSFormBean wfb, OutboundOrderService service) {
		service.updateOrderDetail(order, detail, notes, wfb.getUser());

		JsonView<?> view = new JsonView();
		view.setSuccess(true);
		return view;
	}

	/**
	 * Retrieves JSON object from request input stream.
	 * parameter HttpServletRequest request
	 * returns JSON object 
	 */
	private JSONObject readJson(HttpServletRequest request) throws Exception {
		ServletInputStream content = request.getInputStream();
		BufferedReader postBufferedReader = new BufferedReader(new InputStreamReader(content));
		StringBuilder records = new StringBuilder();

		String postline;
		try {
			while ((postline = postBufferedReader.readLine()) != null)
				records.append(postline);

			return new JSONObject(records.toString());
		} catch (IOException e) {
			logger.error("Error reading from HttpServletRequest input stream.", e);
			throw new IllegalArgumentException("Error reading from HttpServletRequest input stream.");
		}
	}

	/**
	 * Removes an OutboundOrderDetail for the user-submitted OutboundOrderHeader.
	 *
	 * !!This action is secured!!
	 */
	private JsonView removeOrderDetail(HttpServletRequest request, WMSFormBean wfb, OutboundOrderService service) throws Exception {
		Outboundorderdetail detail = marshallOrderDetail(request);
		Outboundorderheader order  = service.readById(detail.getOutboundorderheaderId().getId());

		service.removeOrderDetail(order, detail, wfb.getUser());

		JsonView view = new JsonView();
		view.setSuccess(true);
		return view;
	}

	/**
	 * Removes an OutboundOrderNote for the user-submitted OutboundOrderHeader and OutboundOrderDetail.
	 *
	 * !!This action is secured!!
	 */
	private JsonView deleteOrderNote(HttpServletRequest request, WMSFormBean wfb, OutboundOrderService service) throws Exception {
		JsonView view = new JsonView();

		Outboundordernotes note  = marshallOrderNote(request);
		if (note.getNotetype().equals("ORDER")) {
			Outboundorderheader order  = service.readById(note.getOutboundorderheaderId().getId());
			service.deleteOrderNote(order, note, wfb.getUser());
			view.setSuccess(true);
		} else {
			view.setMessage(note.getNotetype()+" note type cannot be deleted.");
			view.setSuccess(false);
		}

		return view;
	}

	/**
	 * The request to <b>CREATE</b> or <b>UDATE</b> an <i>OutboundOrderDetail</i> entity is one and the same.  Therefore,
	 * we must find out - programatically - which operation the user is attempting to perform and then route it to the
	 * correct code.
	 *
	 * !!This action is secured!!
	 */
	private JsonView<?> routeOrderNoteRequest(HttpServletRequest request, WMSFormBean wfb, OutboundOrderService service) throws Exception {
		Outboundordernotes note = marshallOrderNote(request);
		Outboundorderheader order  = service.readById(note.getOutboundorderheaderId().getId());

		return note.getId() == null || note.getId() == 0 ? createOrderNote(order, note, wfb, service) : updateOrderNote(order, note, wfb, service);
	}

	/**
	 * Creates an OutboundOrderDetail for the user-submitted OutboundOrderHeader.
	 *
	 * !!This action is secured!!
	 */
	private JsonView<?> createOrderNote(Outboundorderheader order, Outboundordernotes note, WMSFormBean wfb, OutboundOrderService service) {
		service.addOrderNote(order, note, wfb.getUser());

		JsonView<?> view = new JsonView();
		view.setSuccess(true);
		return view;
	}

	/**
	 * Updates an OutboundOrderDetail for the user-submitted OutboundOrderHeader.
	 *
	 * !!This action is secured!!
	 */
	private JsonView<?> updateOrderNote(Outboundorderheader order, Outboundordernotes note, WMSFormBean wfb, OutboundOrderService service) {
		service.updateOrderNote(order, note, wfb.getUser());

		JsonView<?> view = new JsonView();
		view.setSuccess(true);
		return view;
	}

	/**
	 * Lifted exactly as it was.  I have neither the time nor the ability to test this right now, so - out of fear - I
	 * decided not to change this one at all because I'm not entirely certain of the syntax of the outbound request.
	 */
	private Outboundordernotes marshallOrderNote(HttpServletRequest request) throws Exception {
		ServletInputStream content = request.getInputStream();
		BufferedReader postBufferedReader = new BufferedReader(new InputStreamReader(content));
		StringBuilder records = new StringBuilder();

		String postline;
		while ((postline = postBufferedReader.readLine()) != null)
			records.append(postline);

		JSONObject jRecords = new JSONObject(records.toString());

		return (Outboundordernotes) PojoMapper.fromJson((jRecords.get("records")).toString(), Outboundordernotes.class);
	}

	/**
     * Creates a new OutboundOrderHeader after marshalling an OutboundOrderStub
     *
     * @see com.kenco.sims.oms.service.impl.OutboundOrderService
     */
    private JsonView<Outboundorderheader> createOrderHeader(HttpServletRequest request, WMSFormBean wfb, OutboundOrderService service) {
        Outboundorderheader order = new Outboundorderheader();
        OutboundOrderStub stub = marshallStub(request);

        return new JsonView<>(service.create(order, wfb.getUser(), stub));
    }

    /**
     * Updates an OutboundOrderHeader after marshalling an OutboundOrderStub.
     *
     * @see com.kenco.sims.oms.service.impl.OutboundOrderService
     */
    private JsonView<Outboundorderheader> updateOrderHeader(HttpServletRequest request, WMSFormBean wfb, OutboundOrderService service) {
        Outboundorderheader order = service.readByNumber(request.getParameter("orderNumber"));
        OutboundOrderStub stub = marshallStub(request);

        return new JsonView<>(service.update(order, wfb.getUser(), stub));
    }


	/**
	 * Deletes the OutboundOrderHeader entity for the user-submitted ID.
	 *
	 * @throws IllegalArgumentException When the OrderHeader's ID cannot be parsed from the request.
	 */
	private JsonView deleteOrderHeader(HttpServletRequest request, OutboundOrderService service) {
		try { service.delete(service.readById(Integer.parseInt(request.getParameter("id")))); }
		catch (NumberFormatException e) { throw new IllegalArgumentException("Order Header ID must be both present and numeric.", e); }

		JsonView view = new JsonView();
		view.setSuccess(true);
		return view;
	}

    private OutboundOrderStub marshallStub(HttpServletRequest request) {
        OutboundOrderStub stub = new OutboundOrderStub();
		stub.setNumber(request.getParameter("orderNumber"));

		// Customer (required).
		try { stub.setCustomerId(Integer.parseInt(request.getParameter("customerId"))); }
		catch (NumberFormatException e) { throw new IllegalArgumentException("Customer ID Must be both present and numeric."); }

		// Business Unit (required).
		try { stub.setBusinessUnitId(Integer.parseInt(request.getParameter("businessUnitId"))); }
		catch (NumberFormatException e) { throw new IllegalArgumentException("Business Unit ID Must be both present and numeric."); }

		// State (required).
		try { stub.setShipToCustomerStateId(Integer.parseInt(request.getParameter("state"))); }
		catch (NumberFormatException e) { throw new IllegalArgumentException("State ID Must be both present and numeric."); }

		// Scheduled Ship Date (required).
        Boolean noCheck = ( request.getParameter("noCheck")!=null && !request.getParameter("noCheck").isEmpty() && request.getParameter("noCheck").toLowerCase().equals("true") );
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
			Date date = sdf.parse(request.getParameter("sheduledShipDate"));
            if (!noCheck && date.compareTo(sdf.parse(sdf.format(new Date())))<0)
				throw new IllegalArgumentException("Scheduled Date must be later or equal than today's date.");
			stub.setScheduledShipDate(date); 
		} catch (ParseException e) { 
			throw new IllegalArgumentException("Scheduled Date must be presented and properly formatted (MM/DD/YYYY)."); 
		}


		// Scheduled Ship Time (predefined).
		try {
			String sheduledShipTimeStr = request.getParameter("departureTime");
			Long sheduledShipTimeLong = Long.parseLong(sheduledShipTimeStr);
			Date sheduledShipTime = new Date(sheduledShipTimeLong);
			stub.setScheduledShipTime(sheduledShipTime); 
		} catch (NumberFormatException e) { throw new IllegalArgumentException("Scheduled Ship Time Must be both present and properly formatted (hh:mm:ss)."); }

		String shipto = request.getParameter("shipto"); // Apparently, this could be either the ID or the Name.
		stub.setShipToCustomerId(shipto   == null || shipto.trim().isEmpty() || !shipto.matches("\\d+") ? null : Integer.parseInt(shipto));
		stub.setShipToCustomerName(shipto == null || shipto.trim().isEmpty() ||  shipto.matches("\\d+") ? null : shipto.toUpperCase());

		String delivery = request.getParameter("delivery"); // Apparently, this could be either the ID or the Name.
		stub.setDeliveryId(delivery == null || delivery.trim().isEmpty() || !delivery.matches("\\d+") ? null : Integer.parseInt(delivery));
		stub.setDeliveryName(delivery == null || delivery.trim().isEmpty() ||  delivery.matches("\\d+") ? null : delivery.toUpperCase());

		String address = request.getParameter("address");
		stub.setShipToCustomerAddress(address == null || address.trim().isEmpty() ? null : address);

		String city = request.getParameter("city");
		stub.setShipToCustomerCity(city == null || city.trim().isEmpty() ? null : city);

		String zip = request.getParameter("zip");
		stub.setShipToCustomerZip(zip == null || zip.trim().isEmpty() ? null : zip);

		String scac = request.getParameter("scac");
		stub.setScac(scac == null || scac.trim().isEmpty() ? null : scac);

		String orderType = request.getParameter("orderType");
		stub.setOrdertype(orderType == null || orderType.trim().isEmpty() ? null : orderType);

		String routed = request.getParameter("routedFlag");
		stub.setRouted(routed == null || routed.trim().isEmpty() ? null : routed);

		String freightterms = request.getParameter("freightTerms");
		stub.setFreightterms(freightterms == null || freightterms.trim().isEmpty() ? null : freightterms);

		String orderNumber = request.getParameter("orderNumber");
		stub.setNumber(orderNumber == null || orderNumber.trim().isEmpty() ? null : orderNumber);

		return stub;
    }

    /**
     * Marshalls a SearchRequest.
     */
    private OutboundOrderSearchRequest marshallRequest(HttpServletRequest request, Customers customer) throws Exception {
        OutboundOrderSearchRequest search = new OutboundOrderSearchRequest();
        search.setLimit(request.getParameter("limit").trim().isEmpty() ? null : Integer.parseInt(request.getParameter("limit")));
        search.setPage(request.getParameter("page").trim().isEmpty() ? null : Short.parseShort(request.getParameter("page")));
        search.setStart(request.getParameter("start").trim().isEmpty() ? null : Short.parseShort(request.getParameter("start")));

        search.setCustomer(customer);
        search.setNumber(request.getParameter("orderNumber").trim().isEmpty() ? null : request.getParameter("orderNumber"));
        search.setShipTo(request.getParameter("shipTo").trim().isEmpty() ? null : request.getParameter("shipTo"));
        search.setCreator(request.getParameter("creator").trim().isEmpty() ? null : request.getParameter("creator"));

        return search;
    }

	/**
	 * Lifted exactly as it was.  I have neither the time nor the ability to test this right now, so - out of fear - I
	 * decided not to change this one at all because I'm not entirely certain of the syntax of the outbound request.
	 */
	private Outboundorderdetail marshallOrderDetail(HttpServletRequest request) throws Exception {
		ServletInputStream content = request.getInputStream();
		BufferedReader postBufferedReader = new BufferedReader(new InputStreamReader(content));
		StringBuilder records = new StringBuilder();

		String postline;
		while ((postline = postBufferedReader.readLine()) != null)
			records.append(postline);

		JSONObject jRecords = new JSONObject(records.toString());

		return (Outboundorderdetail) PojoMapper.fromJson((jRecords.get("records")).toString(), Outboundorderdetail.class);
	}

    /**
     * Parses the "Filter" sent with the request to determine for which Customer to search.
     */
    private Integer parseCustomerNumberFilter(HttpServletRequest request) throws Exception {
        // Parse the filter.
        JSONObject filter = (JSONObject) new JSONArray(request.getParameter("filter")).get(0);

        // Sanity check our filter.
        if (!filter.has("property") || filter.get("property") == null || !((String) filter.get("property")).equalsIgnoreCase("customerId"))
            throw new IllegalArgumentException("Invalid Search Filter - Customer ID must be present.");

        if (!filter.has("value") || filter.get("value") == null || ((String) filter.get("value")).trim().isEmpty())
            throw new IllegalArgumentException("Invalid Search Filter - Customer ID must be present.");

        return Integer.parseInt((String) filter.get("value"));
    }

	/**
	 * Reads the OutboundOrderHeader entity for the provided ID (<b>Primary Key</b>) and returns its associated Collection
	 * of OutboundOrderDetail entities.
	 *
	 * !!This action is secured!!
	 */
	private JsonView<Outboundorderdetail> readDetails(HttpServletRequest request, OutboundOrderService service) {
		Outboundorderheader order = service.readById(Integer.parseInt(request.getParameter("outboundorderheaderId")));
		return new JsonView<>((List<Outboundorderdetail>)order.getOutboundorderdetailCollection());
	}

	/**
	 * Reads the OutboundOrderHeader entity for the provided ID (<b>Primary Key</b>) and returns its associated Collection
	 * of OutboundOrderDetail entities.
	 *
	 * !!This action is secured!!
	 */
	private JsonView<Outboundordernotes> readNotes(HttpServletRequest request, OutboundOrderService service) {
		Outboundorderheader order = service.readById(Integer.parseInt(request.getParameter("outboundorderheaderId")));
		return new JsonView<>((List<Outboundordernotes>)order.getOutboundordernotesCollection());
	}
}
