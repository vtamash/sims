package com.kenco.sims.entity;

import javax.persistence.*;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.util.*;

@Entity
@Table(name = "SALESORDERHEADER")
@XmlRootElement
public class SalesOrderHeader implements Serializable {
    private static final long serialVersionUID = -148710650240116211L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SalesOrderHeaderKey")
    private Long id;

    @Column(name = "Status")
    private String status;

    @Column(name = "SalesRepID")
    private String salesRepId;

    @Column(name = "OwnerCode")
    private String ownerCode;

    @Column(name = "Email")
    private String email;

    @Column(name = "Phone")
    private String phone;

    @Column(name = "PhoneExtension")
    private String phoneExtension;

    @Column(name = "RDCID")
    private String rdcId;

    @Column(name = "RDCName")
    private String rdcName;

    @Column(name = "RDCMasterKey")
    private Integer rdcMasterKey;

    @Column(name = "OrderType")
    private String orderType;

    @Temporal(TemporalType.DATE)
    @Column(name = "ScheduledDate")
    private Date scheduledDate;

    @Column(name = "DeliveryDateReason")
    private String deliveryDateReason;

    @Column(name = "ScheduleOnDate")
    private Boolean scheduleOnDate;

    @Column(name = "ScheduleNoLaterThanDate")
    private Boolean scheduleNoLaterThanDate;

    @Column(name = "ScheduleASAPDate")
    private Boolean scheduleASAPDate;

    @Temporal(TemporalType.TIME)
    @Column(name = "ScheduledTime")
    private Date scheduledTime;

    @Temporal(TemporalType.TIME)
    @Column(name = "ScheduledTimeEnd")
    private Date scheduledTimeEnd;

    @Temporal(TemporalType.DATE)
    @Column(name = "PickupDate")
    private Date pickupDate;

    @Column(name = "PickupDateReason")
    private String pickupDateReason;

    @Temporal(TemporalType.TIME)
    @Column(name = "PickupTime")
    private Date pickupTime;

    @Column(name = "PickupDateTBD")
    private Boolean pickupDateTBD;
    @Column(name = "CustomerID")
    private String customerId;

    @Column(name = "CustomerName")
    private String customerName;

    @Column(name = "NewCustomer")
    private Boolean newCustomer;

    @Column(name = "Address")
    private String address;

    @Column(name = "City")
    private String city;

    @Column(name = "State")
    private String state;

    @Column(name = "ZipCode")
    private String zipCode;

    @Column(name = "Contact")
    private String contact;

    @Column(name = "ContactPhone")
    private String contactPhone;

    @Column(name = "ContactPhoneExtension")
    private String contactPhoneExtension;

    @Column(name = "ContactEmail")
    private String contactEmail;

    @Column(name = "SpecialInstructions")
    private String specialInstructions;

    @Column(name = "LiftGate")
    private Boolean liftGate;

    @Column(name = "Dock")
    private Boolean dock;

    @Column(name = "TractorTrailer")
    private Boolean tractorTrailer;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "Emailed")
    private Date emailed;

    @Column(name = "Created")
    @Temporal(TemporalType.TIMESTAMP)
    private Date created;

    @Column(name = "Updated", insertable = false, updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date updated;

    @Column(name = "UserName")
    private String userName;

    @Column(name = "ProgramName")
    private String programName;

    @Column(name = "Department")
    private String department;

    @Column(name = "Loaner")
    private Boolean loaner;

    @Column(name = "LegalNotice")
    private String legalNotice;

    @Column(name = "LegalAcknowledgement")
    private String legalAcknowledgement;

    @Column(name = "SHORTTRUCK_ID")
    private Integer shortTruckOptionId;

    @Column(name = "lockeduser")
    private String lockedUser;

    @Column(name = "lockedstamp")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lockedDate;

    @Override
    public String toString() {
        return "SalesOrderHeader{" +
                "id=" + id +
                ", status='" + status + '\'' +
                ", salesRepId='" + salesRepId + '\'' +
                ", ownerCode='" + ownerCode + '\'' +
                ", email='" + email + '\'' +
                ", rdcId='" + rdcId + '\'' +
                ", rdcName='" + rdcName + '\'' +
                ", rdcMasterKey=" + rdcMasterKey +
                ", orderType='" + orderType + '\'' +
                ", scheduledDate=" + scheduledDate +
                ", deliveryDateReason='" + deliveryDateReason + '\'' +
                ", scheduleOnDate=" + scheduleOnDate +
                ", scheduleNoLaterThanDate=" + scheduleNoLaterThanDate +
                ", pickupDate=" + pickupDate +
                ", pickupDateReason='" + pickupDateReason + '\'' +
                ", pickupTime=" + pickupTime +
                ", pickupDateTBD=" + pickupDateTBD +
                ", customerId='" + customerId + '\'' +
                ", customerName='" + customerName + '\'' +
                ", newCustomer=" + newCustomer +
                ", contact='" + contact + '\'' +
                ", contactEmail='" + contactEmail + '\'' +
                ", liftGate=" + liftGate +
                ", userName='" + userName + '\'' +
                ", programName='" + programName + '\'' +
                ", department='" + department + '\'' +
                '}';
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getSalesRepId() {
        return salesRepId;
    }

    public void setSalesRepId(String salesRepId) {
        this.salesRepId = salesRepId;
    }

    public String getOwnerCode() {
        return ownerCode;
    }

    public void setOwnerCode(String ownerCode) {
        this.ownerCode = ownerCode;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPhoneExtension() {
        return phoneExtension;
    }

    public void setPhoneExtension(String phoneExtension) {
        this.phoneExtension = phoneExtension;
    }

    public String getRdcId() {
        return rdcId;
    }

    public void setRdcId(String rdcId) {
        this.rdcId = rdcId;
    }

    public String getRdcName() {
        return rdcName;
    }

    public void setRdcName(String rdcName) {
        this.rdcName = rdcName;
    }

    public Integer getRdcMasterKey() {
        return rdcMasterKey;
    }

    public void setRdcMasterKey(Integer rdcMasterKey) {
        this.rdcMasterKey = rdcMasterKey;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public Date getScheduledDate() {
        return scheduledDate;
    }

    public void setScheduledDate(Date scheduledDate) {
        this.scheduledDate = scheduledDate;
    }

    public String getDeliveryDateReason() {
        return deliveryDateReason;
    }

    public void setDeliveryDateReason(String deliveryDateReason) {
        this.deliveryDateReason = deliveryDateReason;
    }

    public Boolean getScheduleOnDate() {
        return scheduleOnDate;
    }

    public void setScheduleOnDate(Boolean scheduleOnDate) {
        this.scheduleOnDate = scheduleOnDate;
    }

    public Boolean getScheduleNoLaterThanDate() {
        return scheduleNoLaterThanDate;
    }

    public void setScheduleNoLaterThanDate(Boolean scheduleNoLaterThanDate) {
        this.scheduleNoLaterThanDate = scheduleNoLaterThanDate;
    }

    public Boolean getScheduleASAPDate() {
        return scheduleASAPDate;
    }

    public void setScheduleASAPDate(Boolean scheduleASAPDate) {
        this.scheduleASAPDate = scheduleASAPDate;
    }

    public Date getScheduledTime() {
        return scheduledTime;
    }

    public void setScheduledTime(Date scheduledTime) {
        this.scheduledTime = scheduledTime;
    }

    public Date getScheduledTimeEnd() {
        return scheduledTimeEnd;
    }

    public void setScheduledTimeEnd(Date scheduledTimeEnd) {
        this.scheduledTimeEnd = scheduledTimeEnd;
    }

    public Date getPickupDate() {
        return pickupDate;
    }

    public void setPickupDate(Date pickupDate) {
        this.pickupDate = pickupDate;
    }

    public String getPickupDateReason() {
        return pickupDateReason;
    }

    public void setPickupDateReason(String pickupDateReason) {
        this.pickupDateReason = pickupDateReason;
    }

    public Date getPickupTime() {
        return pickupTime;
    }

    public void setPickupTime(Date pickupTime) {
        this.pickupTime = pickupTime;
    }

    public Boolean getPickupDateTBD() {
        return pickupDateTBD;
    }

    public void setPickupDateTBD(Boolean pickupDateTBD) {
        this.pickupDateTBD = pickupDateTBD;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public Boolean getNewCustomer() {
        return newCustomer;
    }

    public void setNewCustomer(Boolean newCustomer) {
        this.newCustomer = newCustomer;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getContactPhone() {
        return contactPhone;
    }

    public void setContactPhone(String contactPhone) {
        this.contactPhone = contactPhone;
    }

    public String getContactPhoneExtension() {
        return contactPhoneExtension;
    }

    public void setContactPhoneExtension(String contactPhoneExtension) {
        this.contactPhoneExtension = contactPhoneExtension;
    }

    public String getContactEmail() {
        return contactEmail;
    }

    public void setContactEmail(String contactEmail) {
        this.contactEmail = contactEmail;
    }

    public String getSpecialInstructions() {
        return specialInstructions;
    }

    public void setSpecialInstructions(String specialInstructions) {
        this.specialInstructions = specialInstructions;
    }

    public Boolean getLiftGate() {
        return liftGate;
    }

    public void setLiftGate(Boolean liftGate) {
        this.liftGate = liftGate;
    }

    public Boolean getDock() {
        return dock;
    }

    public void setDock(Boolean dock) {
        this.dock = dock;
    }

    public Boolean getTractorTrailer() {
        return tractorTrailer;
    }

    public void setTractorTrailer(Boolean tractorTrailer) {
        this.tractorTrailer = tractorTrailer;
    }

    public Date getEmailed() {
        return emailed;
    }

    public void setEmailed(Date emailed) {
        this.emailed = emailed;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public Date getUpdated() {
        return updated;
    }

    public void setUpdated(Date updated) {
        this.updated = updated;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getProgramName() {
        return programName;
    }

    public void setProgramName(String programName) {
        this.programName = programName;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public Boolean getLoaner() {
        return loaner;
    }

    public void setLoaner(Boolean loaner) {
        this.loaner = loaner;
    }

    public String getLegalNotice() {
        return legalNotice;
    }

    public void setLegalNotice(String legalNotice) {
        this.legalNotice = legalNotice;
    }

    public String getLegalAcknowledgement() {
        return legalAcknowledgement;
    }

    public void setLegalAcknowledgement(String legalAcknowledgement) {
        this.legalAcknowledgement = legalAcknowledgement;
    }

    public Integer getShortTruckOptionId() {
        return shortTruckOptionId;
    }

    public void setShortTruckOptionId(Integer shortTruckOptionId) {
        this.shortTruckOptionId = shortTruckOptionId;
    }

    public String getLockedUser() {
        return lockedUser;
    }

    public void setLockedUser(String lockedUser) {
        this.lockedUser = lockedUser;
    }

    public Date getLockedDate() {
        return lockedDate;
    }

    public void setLockedDate(Date lockedDate) {
        this.lockedDate = lockedDate;
    }
}
