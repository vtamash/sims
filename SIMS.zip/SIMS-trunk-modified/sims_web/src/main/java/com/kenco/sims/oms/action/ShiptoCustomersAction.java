package com.kenco.sims.oms.action;

import com.kenco.oms.entity.Shiptocustomers;
import com.kenco.oms.service.impl.GenericCustomersService;
import com.kenco.oms.service.impl.GenericShiptoCustomersService;
import com.kenco.oms.service.impl.GenericStatesService;
import com.kenco.sims.oms.view.JsonView;
import com.kenco.struts.formbeans.WMSFormBean;
import com.kenco.struts.utilities.InitServlet;
import com.kenco.struts.utilities.PojoMapper;
import json.org.JSONObject;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.PrintWriter;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ShiptoCustomersAction extends Action {

	static Logger logger = LoggerFactory.getLogger(ShiptoCustomersAction.class);

	private final static String SUCCESS = "success";

	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		WMSFormBean wfb = (WMSFormBean) form;

		logger.info("USER: " + wfb.getUser() + " Starting execute() method");

		// Setup our Business Services.
		final GenericShiptoCustomersService service = new GenericShiptoCustomersService(InitServlet.getEntityManagerFactory().createEntityManager());
		final GenericCustomersService cService      = new GenericCustomersService(InitServlet.getEntityManagerFactory().createEntityManager());
		final GenericStatesService sService         = new GenericStatesService(InitServlet.getEntityManagerFactory().createEntityManager());

		JsonView view = null;
		try {
			String action = request.getParameter("action");

			// Render the page.
			if (action == null)
				return renderStrut(wfb, mapping);

				// Create request.
			else if (request.getMethod().equals("POST") && action.equals("create"))
				view = new JsonView<Shiptocustomers>(create(request, wfb, service, cService, sService));

				// Read (all) request.
			else if (request.getMethod().equals("GET") && action.equals("read"))
				view = new JsonView<Shiptocustomers>(read(service, wfb));

				// Update request.
			else if (request.getMethod().equals("POST") && action.equals("update"))
				view = new JsonView<Shiptocustomers>(update(request, wfb, service, cService, sService));

				// Delete request.
			else if (request.getMethod().equals("POST") && action.equals("delete"))
				delete(request, wfb, service, cService);

				// Unicity check - Name.
			else if (request.getMethod().equals("GET") && action.equals("checkName"))
				view = new JsonView<Map<String, Object>>(checkNameUnicity(service, request.getParameter("id"), request.getParameter("name")));

				// Unicity check - Number.
			else if (request.getMethod().equals("GET") && action.equals("checkNumber"))
				view = new JsonView<Map<String, Object>>(checkNumberUnicity(service, request.getParameter("id"), request.getParameter("number")));
		} catch (Exception e) {
			// Log the error.
			logger.error("Error processing Shiptocustomers-Action request: ", e);

			// Respond to the call negatively for user-feedback.
			view = new JsonView<Shiptocustomers>("There was an error proccessing this request.");
		}

		PrintWriter out = response.getWriter();
		out.print(PojoMapper.toJson(view, true));
		out.flush();
		out.close();

		logger.info("USER: " + wfb.getUser() + " Exiting execute() method");
		return null;
	}

	/**
	 * Performs a CREATE Operation on the provided Shiptocustomers object.
	 */
	private Shiptocustomers create(HttpServletRequest request, WMSFormBean wfb, GenericShiptoCustomersService service, GenericCustomersService cService, GenericStatesService sService) throws Exception {
		ShipToCustomerStub stub = unmarshallStub(request);

		Shiptocustomers shipToCustomers = new Shiptocustomers();

		// Data from the User.
		shipToCustomers.setCustomer(cService.readById(stub.getCustomerId()));
		shipToCustomers.setActive(stub.getActive());
		shipToCustomers.setName(stub.getName());
		shipToCustomers.setShiptocustomernumber(stub.getNumber());
		shipToCustomers.setAddress1(stub.getAddress1());
		shipToCustomers.setAddress2(stub.getAddress2());
		shipToCustomers.setAddress3(stub.getAddress3());
		shipToCustomers.setCity(stub.getCity());
		shipToCustomers.setState(sService.readById(stub.getStateId()));
		shipToCustomers.setZipcode(stub.getZip());

		// Meta-data.
		shipToCustomers.setCreatetimestamp(new Date());
		shipToCustomers.setCreateusername(wfb.getUser());
		shipToCustomers.setCreateprogram("ShiptoCustomersAction.create(...)");
		shipToCustomers.setUpdateusername(wfb.getUser());
		shipToCustomers.setUpdateprogram("ShiptoCustomersAction.create(...)");

		// Process the create request.
		service.create(shipToCustomers);

		// Return the (persisted) Shiptocustomer.
		return service.readByName(shipToCustomers.getName());
	}

	/**
	 * Performs a READ operation on the ShiptoCustomersService and returns a collection of Shiptocustomers entities Marshalled into JSON.
	 */
	private List<Shiptocustomers> read(GenericShiptoCustomersService service, WMSFormBean wfb) throws Exception {
		return service.readAll(wfb.getOmsDefaultCustomerId());
	}

	/**
	 * Performs an UPDATE operation on the provided Shiptocustomers entity.
	 */
	private Shiptocustomers update(HttpServletRequest request, WMSFormBean wfb, GenericShiptoCustomersService service, GenericCustomersService cService, GenericStatesService sService) throws Exception {
		ShipToCustomerStub stub = unmarshallStub(request);

		Shiptocustomers shipToCustomers = service.readById(stub.getId());

		// Data from the User.
		shipToCustomers.setCustomer(cService.readById(stub.getCustomerId()));
		shipToCustomers.setActive(stub.getActive());
		shipToCustomers.setName(stub.getName());
		shipToCustomers.setShiptocustomernumber(stub.getNumber());
		shipToCustomers.setAddress1(stub.getAddress1());
		shipToCustomers.setAddress2(stub.getAddress2());
		shipToCustomers.setAddress3(stub.getAddress3());
		shipToCustomers.setCity(stub.getCity());
		shipToCustomers.setState(sService.readById(stub.getStateId()));
		shipToCustomers.setZipcode(stub.getZip());

		// Meta-data.
		shipToCustomers.setUpdateusername(wfb.getUser());
		shipToCustomers.setUpdateprogram("ShiptocustomersAction.update(...)");

		// Process the create request.
		service.update(shipToCustomers);

		// Return the (updated) Shiptocustomers.
		return shipToCustomers;
	}

	/**
	 * Performs a DELETE operation on the provided Shiptocustomers entity.
	 */
	private void delete(HttpServletRequest request, WMSFormBean wfb, GenericShiptoCustomersService service, GenericCustomersService cService) throws Exception {
		// Retrieve the Shiptocustomers entity.
		Shiptocustomers shipToCustomers = service.readById(Integer.parseInt(request.getParameter("id")));

		// Perform our delete operation.
		service.delete(shipToCustomers);
	}

	/**
	 * If the ID (<i>Primary Key</i>) is, in any way, absent, this method performs a simple unicity check.  However,
	 * if there is an ID present, then we must compare the <b>name</b> for the entity belonging to the ID.  If they are
	 * the same, then we exempt the unicity check since it already owns the <b>name</b>.  However, if the <b>name</b>
	 * is different, we must still perform a simple unicity check.
	 */
	private Map<String,Object> checkNameUnicity(GenericShiptoCustomersService service, String id, String name) {
		Map<String,Object> isUnique = new HashMap<String,Object>();

		if (id == null || id.trim().isEmpty() || id.trim().equalsIgnoreCase("null"))
			isUnique.put("unique", !service.existsByName(name));
		else
			isUnique.put("unique", service.readById(Integer.parseInt(id)).getName().equalsIgnoreCase(name.trim())
									|| !service.existsByName(name));

		return isUnique;
	}

	/**
	 * If the ID (<i>Primary Key</i>) is, in any way, absent, this method performs a simple unicity check.  However,
	 * if there is an ID present, then we must compare the <b>number</b> for the entity belonging to the ID.  If they are
	 * the same, then we exempt the unicity check since it already owns the <b>number</b>.  However, if the <b>number</b>
	 * is different, we must still perform a simple unicity check.
	 */
	private Map<String,Object> checkNumberUnicity(GenericShiptoCustomersService service, String id, String number) {
		Map<String,Object> isUnique = new HashMap<String,Object>();

		if (id == null || id.trim().isEmpty() || id.trim().equalsIgnoreCase("null"))
			isUnique.put("unique", !service.existsByNumber(number));
		else
			isUnique.put("unique", service.readById(Integer.parseInt(id)).getShiptocustomernumber().equalsIgnoreCase(number.trim())
									|| !service.existsByNumber(number));

		return isUnique;
	}

	/**
	 * Forwards the caller to the proper JSP for interaction with Shiptocustomers.
	 */
	private ActionForward renderStrut(WMSFormBean wfb, ActionMapping mapping) {
		wfb.resetJavascriptIncludes("appShipToCustomer.js"); // This gets used first.
		// wfb.appendJavascriptIncludes(); // This is what we need to use to add other JS to our jsp.
		logger.info("USER: " + wfb.getUser() + " Exiting execute() method");
		return mapping.findForward(SUCCESS);
	}

	/**
	 * Un-Marshalls a JSON String into a ShipToCustomerStub object.
	 */
	private ShipToCustomerStub unmarshallStub(HttpServletRequest request) throws Exception {
		//PojoMapper.fromJson("",ShipToCustomerStub.class); // TODO Use the PojoMapper.

		JSONObject json   = new JSONObject(parseReader(request));
		JSONObject record = (JSONObject) json.get("records");

		ShipToCustomerStub stub = new ShipToCustomerStub();
		stub.setCustomerId((Integer) record.get("customerId"));
		stub.setId(record.get("id") == JSONObject.NULL ? null : (Integer) record.get("id"));
		stub.setActive((Boolean) record.get("active") ? (short) 1 : (short) 0);
		stub.setName((String) record.get("name"));
		stub.setNumber((String) record.get("number"));
		stub.setAddress1((String) record.get("address1"));
		stub.setAddress2((String) record.get("address2"));
		stub.setAddress3((String) record.get("address3"));
		stub.setCity((String) record.get("city"));
		stub.setStateId((Integer) record.get("stateId"));
		stub.setZip((String) record.get("zip"));
		return stub;
	}

	/**
	 * Parses the HttpServletRequest's reader to get any POST Parameters that are present.
	 */
	private String parseReader(HttpServletRequest request) throws Exception {
		StringBuilder builder = new StringBuilder();

		BufferedReader reader = request.getReader();
		for (String curLine = reader.readLine(); curLine != null; curLine = reader.readLine())
			builder.append(curLine);

		return builder.toString();
	}

	private class ShipToCustomerStub {
		private Integer customerId;
		private Integer stateId;
		private Integer id;
		private Short active;
		private String number;
		private String name;
		private String address1;
		private String address2;
		private String address3;
		private String city;
		private String zip;

		private int getCustomerId() {
			return customerId;
		}

		private void setCustomerId(Integer customerId) {
			this.customerId = customerId;
		}

		private int getStateId() {
			return stateId;
		}

		private void setStateId(Integer stateId) {
			this.stateId = stateId;
		}

		private int getId() {
			return id;
		}

		private void setId(Integer id) {
			this.id = id;
		}

		private short getActive() {
			return active;
		}

		private void setActive(Short active) {
			this.active = active;
		}

		private String getNumber() {
			return number;
		}

		private void setNumber(String number) {
			this.number = number;
		}

		private String getName() {
			return name;
		}

		private void setName(String name) {
			this.name = name;
		}

		private String getAddress1() {
			return address1;
		}

		private void setAddress1(String address1) {
			this.address1 = address1;
		}

		private String getAddress2() {
			return address2;
		}

		private void setAddress2(String address2) {
			this.address2 = address2;
		}

		private String getAddress3() {
			return address3;
		}

		private void setAddress3(String address3) {
			this.address3 = address3;
		}

		private String getCity() {
			return city;
		}

		private void setCity(String city) {
			this.city = city;
		}

		private String getZip() {
			return zip;
		}

		private void setZip(String zip) {
			this.zip = zip;
		}
	}
}
