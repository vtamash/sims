package com.kenco.sims.domain.search.impl;

import com.kenco.sims.domain.search.SearchRequest;

import java.util.HashMap;
import java.util.Map;

/**
 * Implementation of the {@code SearchRequest} domain object for the {@code User} entity.
 *
 * @see com.kenco.sims.entity.User
 * @see com.kenco.sims.domain.search.SearchRequest
 */
public class UserSearchRequest extends SearchRequest {
    /**
     * Optional;
     *
     * When present, places a LIKE predicate on the search string that has a wildcard match on both sides of the value
     * for the {@code User} entity's {@code username}.
     */
    private String username;

    /**
     * Optional;
     *
     * When present, places a LIKE predicate on the search string that has a wildcard matching both sides of the value
     * for the {@code User} entity's {@code firstName}.
     */
    private String firstName;

    /**
     * Optional;
     *
     * When present, places a LIKE predicate on the search string that has a wildcard matching both sides of the value
     * for the {@code User} entity's {@code lastName}.
     */
    private String lastName;

    /**
     * Optional;
     *
     * When present, places a LIKE predicate on the search string that has a wildcard match on both sides of the value.
     */
    private String email;

    /**
     * Optional;
     *
     * When present, places a LIKE predicate on the search string that has a wildcard match on both sides of the value.
     */
    private String phone;

    /**
     * Optional;
     *
     * When present, predicates that only {@code User} entities assigned to this {@code Role} will be returned.
     */
    private Integer roleId;

    /**
     * Optional;
     *
     * When present, predicates that only {@code User} having this {@code Rdc} as a {@code homeRdc} will be returned.
     */
    private Integer homeRdcId;

    /**
     * Optional;
     *
     * When present, predicates that only {@code User} entities assigned to this {@code Rdc} will be returned.
     */
    private Integer rdcId;

    /**
     * Optional;
     *
     * When present, predicates that only {@code User} entities assigned to this {@code Division} will be returned.
     */
    private Integer divisionId;

    private boolean enabled;

    private boolean disabled;

    private boolean showAll;

    private boolean havingRepRequests;

    public UserSearchRequest() {}

    public UserSearchRequest(final String username) {
        this.username = username;
    }

    @Override
    protected Map<String, Object> getSearchPredicates() {
        Map<String, Object> predicates = new HashMap<>();
        predicates.put("Username",    username);
        predicates.put("First Name",  firstName);
        predicates.put("Last Name",   lastName);
        predicates.put("Email",       email);
        predicates.put("Role ID",     roleId);
        predicates.put("Home RDC ID", homeRdcId);
        predicates.put("Division ID", divisionId);
        predicates.put("RDC ID",      rdcId);
        predicates.put("Enabled",     enabled);
        predicates.put("Disabled",    disabled);
        predicates.put("Show All",    showAll);
        return predicates;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Integer getRoleId() {
        return roleId;
    }

    public void setRoleId(Integer roleId) {
        this.roleId = roleId;
    }

    public Integer getHomeRdcId() {
        return homeRdcId;
    }

    public void setHomeRdcId(Integer homeRdcId) {
        this.homeRdcId = homeRdcId;
    }

    public Integer getRdcId() {
        return rdcId;
    }

    public void setRdcId(Integer rdcId) {
        this.rdcId = rdcId;
    }

    public Integer getDivisionId() {
        return divisionId;
    }

    public void setDivisionId(Integer divisionId) {
        this.divisionId = divisionId;
    }

    public Boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(Boolean enabled) {
        this.enabled = enabled;
    }

    public Boolean isDisabled() {
        return disabled;
    }

    public void setDisabled(Boolean disabled) {
        this.disabled = disabled;
    }

    public boolean isShowAll() {
        return showAll;
    }

    public void setShowAll(boolean showAll) {
        this.showAll = showAll;
    }

    public boolean isHavingRepRequests() {
        return havingRepRequests;
    }

    public void setHavingRepRequests(boolean havingRepRequests) {
        this.havingRepRequests = havingRepRequests;
    }
}
