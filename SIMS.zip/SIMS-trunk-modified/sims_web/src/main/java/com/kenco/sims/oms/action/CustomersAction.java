package com.kenco.sims.oms.action;

import com.kenco.oms.entity.Customers;
import com.kenco.oms.service.CustomersAbstractService;
import com.kenco.sims.oms.domain.CustomerStub;
import com.kenco.sims.oms.service.impl.CustomerService;
import com.kenco.sims.oms.view.JsonView;
import com.kenco.struts.formbeans.WMSFormBean;
import com.kenco.struts.utilities.PojoMapper;
import json.org.JSONObject;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.PrintWriter;
import java.util.List;

public class CustomersAction extends Action {

    static Logger logger = LoggerFactory.getLogger(CustomersAction.class);
    
    private final static String SUCCESS = "success";

    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		WMSFormBean wfb = (WMSFormBean) form;

		logger.info("USER: " + wfb.getUser() + " Starting execute() method");

		// Setup our Business Services.
		final CustomersAbstractService service = new CustomerService();

		JsonView view = null;
		try {
			String action = request.getParameter("action");

			// Render the page.
			if (action == null)
				return renderStrut(request, wfb, mapping);

			// Create request. TODO This should probably be built...?
			else if (request.getMethod().equals("POST") && action.equals("create"))
				throw new UnsupportedOperationException();
//				view = new JsonView<Customers>(create(request,wfb,service));

			// Read (all) request.
			else if (request.getMethod().equals("GET") && action.equals("read"))
				view = new JsonView<Customers>(read(service));

			// Update request.
			else if (request.getMethod().equals("POST") && action.equals("update"))
				view = new JsonView<Customers>(update(request, wfb, service));

			// Delete request.
			else if (request.getMethod().equals("POST") && action.equals("delete"))
				delete(request, wfb, service);

			// TODO Unicity check - Name.
			//else if (request.getMethod().equals("GET") && action.equals("checkName"))
			//	view = new JsonView<Map<String,Object>>(checkNameUnicity(service, request.getParameter("id"), request.getParameter("name")));

			// Catch-All.
			else
				throw new UnsupportedOperationException("Illegal Action.");
		} catch (Exception e) {
			// Log the error.
			logger.error("Error processing Customers-Action request: ", e);

			// Respond to the call negatively for user-feedback.
			view = new JsonView("There was an error processing this request.");
		}

		PrintWriter out = response.getWriter();
		out.print(PojoMapper.toJson(view, true));
		out.flush();
		out.close();

		logger.info("USER: " + wfb.getUser() + " Exiting execute() method");
		return null;
    }

	/**
	 * Forwards the caller to the proper JSP for interaction with the <i>BusinessUnit</i> entity.
	 *
	 * !!This is a secured action!!
	 */
	private ActionForward renderStrut(HttpServletRequest request, WMSFormBean wfb, ActionMapping mapping) {
		wfb.resetJavascriptIncludes("appCustomer.js"); // Use append after this.
		// wfb.appendJavascriptIncludes(); // This is what we need to use to add other JS to our jsp.
		logger.info("USER: " + wfb.getUser() + " Exiting execute() method");
		return mapping.findForward(SUCCESS);
	}

	/**
	 * Performs a READ operation on the <i>CustomersService</i> and returns a collection of <i>BusinessUnit</i>
	 * entities marshalled into JSON.
	 */
	private List<Customers> read(CustomersAbstractService service) throws Exception {
		return service.readAll();
	}

	/**
	 * Performs an UPDATE operation on the provided <i>Customers</i> entity.
	 *
	 * !!This is a secured action!!
	 */
	private Customers update(HttpServletRequest request, WMSFormBean wfb, CustomersAbstractService service) throws Exception {
		CustomerStub stub  = unmarshallStub(request);
		Customers customer = service.readById(stub.getId());

		return service.update(customer, wfb.getUser(), stub);
	}

	/**
	 * Performs a DELETE operation on the provided <i>Customers</i> entity.
	 *
	 * !!This is a secured action!!
	 */
	private void delete(HttpServletRequest request, WMSFormBean wfb, CustomersAbstractService service) throws Exception {
		// Retrieve the Customers entity.
		Customers businessUnit = service.readById(Integer.parseInt(request.getParameter("id")));

		// Perform our delete operation.
		service.delete(businessUnit, wfb.getUser());
	}

	/**
	 * Un-Marshalls a JSON String into a <i>CustomerStub</i> object.
	 */
	private CustomerStub unmarshallStub(HttpServletRequest request) throws Exception {
		JSONObject json   = new JSONObject(parseReader(request));
		JSONObject record = (JSONObject) json.get("records");

		CustomerStub stub = new CustomerStub();
		stub.setId(record.get("id") == JSONObject.NULL ? null : (Integer) record.get("id"));
		stub.setActive((Boolean) record.get("active") ? (short) 1 : (short) 0);
		return stub;
	}

	/**
	 * Parses the HttpServletRequest's reader to get any POST Parameters that are present.
	 */
	private String parseReader(HttpServletRequest request) throws Exception {
		StringBuilder builder = new StringBuilder();

		BufferedReader reader = request.getReader();
		for (String curLine = reader.readLine(); curLine != null; curLine = reader.readLine())
			builder.append(curLine);

		return builder.toString();
	}
}
