package com.kenco.sims.oms.action;

import com.kenco.sims.oms.model.OMSDropDownModel;
import com.kenco.sims.oms.view.JsonView;
import com.kenco.struts.formbeans.WMSFormBean;
import com.kenco.struts.utilities.PojoMapper;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;
import java.util.List;
import java.util.Map;

public class OMSDropDownAction extends Action {

    static Logger logger = LoggerFactory.getLogger(OMSDropDownAction.class);
    
    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
        WMSFormBean wfb = (WMSFormBean) form;
        logger.info("USER: " + wfb.getUser() + " Starting execute() method");

        PrintWriter out = response.getWriter();
  	  
        String action = request.getParameter("action");

        logger.info("*********************************************************");
        logger.info("Action: " + action);
        logger.info("*********************************************************");

        JsonView<?> jsonView = new JsonView();
        String jsonString = null;
        if (action!=null && !action.isEmpty()) {

    		Map<String, String[]> params = request.getParameterMap();

        	OMSDropDownModel ddm = new OMSDropDownModel();
        	try {
        		List list = ddm.getDropDownList(wfb.getOmsDefaultCustomerId(), params);
        		
        		jsonView.setResults(list);
        		jsonView.setSuccess(true);
        		jsonView.setMessage((list.size()>0 ? list.size() : "No") + " records found.");
        		jsonView.setTotal(list.size());
        	} catch (ClassNotFoundException e) {
        		jsonView.setSuccess(false);
        		jsonView.setMessage("No service found."+action);
        		jsonView.setTotal(0);
        	} catch (NoSuchMethodException e) {
        		jsonView.setSuccess(false);
        		jsonView.setMessage("No read method found");
        		jsonView.setTotal(0);
        	} catch (SecurityException e) {
        		jsonView.setSuccess(false);
        		jsonView.setMessage("Violation in read method invocation.");
        		jsonView.setTotal(0);
        	} catch (InstantiationException e) {
        		jsonView.setSuccess(false);
        		jsonView.setMessage("Read method is not initialized.");
        		jsonView.setTotal(0);
        	} catch (IllegalAccessException e) {
        		jsonView.setSuccess(false);
        		jsonView.setMessage("No access to the read method.");
        		jsonView.setTotal(0);
        	} catch (IllegalArgumentException e) {
        		jsonView.setSuccess(false);
        		jsonView.setMessage("Illegal arguments provided.");
        		jsonView.setTotal(0);
        	} catch (InvocationTargetException e) {
        		jsonView.setSuccess(false);
        		jsonView.setMessage("Method invocation target is wrong.");
        		jsonView.setTotal(0);
        	}

        } else {
    		jsonView = new JsonView();
    		jsonView.setSuccess(false);
    		jsonView.setMessage("No service found.");
    		jsonView.setTotal(0);
        }

        jsonString = PojoMapper.toJson(jsonView, true);

        logger.info("DropDownArray: " + jsonString);
        out.print(jsonString);
        out.flush();
        out.close();

        logger.info("USER: " + wfb.getUser() + " Exiting execute() method");
        return null;
    }
}
