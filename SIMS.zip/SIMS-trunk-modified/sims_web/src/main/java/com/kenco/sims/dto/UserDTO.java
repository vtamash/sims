package com.kenco.sims.dto;

import com.kenco.api.validation.StringUUID;
import com.kenco.sims.entity.User;

import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * The User data transfer object exposed through UserService.
 *
 * @see com.kenco.sims.entity.User
 * @see com.kenco.sims.entity.Rdc
 * @see com.kenco.sims.entity.Division
 */
@XmlRootElement(name = "User")
@XmlAccessorType(XmlAccessType.FIELD)
public class UserDTO {
    /**
     * Primary Key; Read Only;
     */
    @StringUUID
    @XmlAttribute
    public String id;

    /**
     * Read Only;
     */
    @XmlAttribute
    private String email;

    /**
     * Read Only;
     */
    @XmlAttribute
    private String phone;

    /**
     * Read Only;
     */
    @XmlAttribute
    private String firstName;

    /**
     * Read Only;
     */
    @XmlAttribute
    private String lastName;

    /**
     * Read Only;
     */
    @XmlAttribute
    public String userName;

    /**
     * Required;
     */
    @XmlAttribute
    @NotNull(message = "must have a value.")
    public Integer roleId;

    /**
     * Required;
     */
    @XmlAttribute
    @NotNull(message = "must have a value.")
    public Integer homeRdcId;

    /**
     * Required;
     */
    @XmlAttribute
    @NotNull(message = "must have a value.")
    public Boolean enabled;

    @XmlAttribute
    public String salesRepId;

    public UserDTO() {}

    public UserDTO(User user) {
        id        = user.getId().toString();
        userName  = user.getUsername();
        enabled   = user.isEnabled();
        email     = user.getEmail();
        phone     = user.getPhone();
        firstName = user.getFirstName();
        lastName  = user.getLastName();

        if (user.getRole() != null)
            roleId = user.getRole().getId();

        if (user.getHomeRdc() != null)
            homeRdcId = user.getHomeRdc().getId();
    }

    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getFirstName() {
        return firstName;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getUserName() {
        return userName;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }

    public Integer getRoleId() {
        return roleId;
    }
    public void setRoleId(Integer roleId) {
        this.roleId = roleId;
    }

    public Integer getHomeRdcId() {
        return homeRdcId;
    }
    public void setHomeRdcId(Integer homeRdcId) {
        this.homeRdcId = homeRdcId;
    }

    public Boolean isEnabled() {
        return enabled;
    }
    public void setEnabled(Boolean enabled) {
        this.enabled = enabled;
    }

    public String getSalesRepId() {
        return salesRepId;
    }
    public void setSalesRepId(String salesRepId) {
        this.salesRepId = salesRepId;
    }
}
