package com.kenco.sims.repository.jpa;

import com.kenco.sims.domain.search.impl.SalesorderheaderSearchRequest;
import com.kenco.sims.repository.SalesorderheaderRepository;
import com.kenco.sims.entity.Txfrrqst;
import com.kenco.sims.entity.Txrqstdtl;
import com.kenco.struts.utilities.InitServlet;
import com.kenco.struts.wmsio.tables.Salesorderheader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;
import javax.persistence.criteria.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Sole point-of-access for interaction with {@code Salesorderheader} entities.
 *
 * @see SalesorderheaderRepository
 */
@Repository
public class SalesorderheaderJpaRepository implements SalesorderheaderRepository {
    private static final Logger logger = LoggerFactory.getLogger(SalesorderheaderJpaRepository.class);

    private EntityManager entityManager;

    /**
     * {@inheritDoc}
     */
    @Override
    public Salesorderheader create(Salesorderheader soh) {
        logger.trace(String.format("Data Request; Creating Salesorderheader [%s]; Persisting.", soh));
        EntityTransaction tx = entityManager.getTransaction();
        try {
            tx.begin();
            entityManager.persist(soh);
            tx.commit();
            logger.info(String.format("Data Request; Salesorderheader Successfully Created [%s].", soh));
        } catch (Exception ex) {
            tx.rollback();
            logger.error(String.format("Data Request; Salesorderheader Failed Creating [%s].", soh));
        }

        return soh;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Salesorderheader readBySalesOrderHeaderKey(int salesOrderHeaderKey) {
        logger.trace(String.format("Data Request; Retrieving Salesorderheader [%s]; Building Criteria Query For Request.", salesOrderHeaderKey));
        CriteriaBuilder builder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Salesorderheader> query = builder.createQuery(Salesorderheader.class);
        CriteriaQuery<Txfrrqst> subQuery = builder.createQuery(Txfrrqst.class);

        logger.trace(String.format("Data Request; Retrieving Salesorderheader [%s]; Criteria Query Built; Setting Root.", salesOrderHeaderKey));
        Root<Salesorderheader> root = query.from(Salesorderheader.class);

        logger.trace(String.format("Data Request; Retrieving Salesorderheader [%s]; Root Set; Setting Predicates.", salesOrderHeaderKey));
        query.where(builder.equal(root.<Integer>get("salesOrderHeaderKey"), salesOrderHeaderKey));

        logger.trace(String.format("Data Request; Retrieving Salesorderheader [%s]; Predicates Set; Executing Query.", salesOrderHeaderKey));
        Salesorderheader entity = entityManager.createQuery(query).getSingleResult();

        // If anybody sees this as a redundancy plaese think again. If changes been made outside of current EntityManager you won't see them here until calling this refresh method!
        entityManager.refresh(entity);

        if (entity.getTxrqstdtls()!=null && entity.getTxrqstdtls().size()>0) {
            logger.trace(String.format("Data Request; Retrieving Txfrrqst(s) for Salesorderheader [%s]; Criteria Query Built; Setting Root.", salesOrderHeaderKey));
            Root<Txfrrqst> subRoot = query.from(Txfrrqst.class);

            logger.trace(String.format("Data Request; Building List of Txrqstdtl for Salesorderheader [%s]; Root Set; Setting In Clause.", salesOrderHeaderKey));
            List<String> myList = new ArrayList<String> ();
            for (Txrqstdtl r : entity.getTxrqstdtls())
                myList.add(r.getTxfrrqstId());

            logger.trace(String.format("Data Request; Retrieving Txfrrqst(s) for Salesorderheader [%s]; Root Set; Setting Predicates.", salesOrderHeaderKey));
            subQuery.where(subRoot.<String>get("shipwithno").in(myList));

            logger.trace(String.format("Data Request; Retrieving List of Txfrrqst's for Salesorderheader [%s]; Predicates Set; Executing Query.", salesOrderHeaderKey));
            List<Txfrrqst> entities = entityManager.createQuery(subQuery).getResultList();

            for (Txfrrqst ent : entities)
                entityManager.refresh(ent);

            entity.setTxfrrqsts(entities);
        }

        logger.info(String.format("Data Request; Salesorderheader [%s] Successfully Retrieved.", entity));
        return entity;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public List<Salesorderheader> read(SalesorderheaderSearchRequest request) {
        logger.trace(String.format("Data Request; Salesorderheader Search Request; Building Criteria Query: %s", request));
        CriteriaBuilder     builder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Salesorderheader> query   = builder.createQuery(Salesorderheader.class);

        logger.trace("Data Request; Salesorderheader Search Request; Criteria Query Built; Setting Root.");
        Root<Salesorderheader> root = query.from(Salesorderheader.class);

        logger.trace("Data Request; Salesorderheader Search Request; Root Set; Setting Predicates.");
        query.where(getPredicates(builder, null, root, request));

        logger.trace("Data Request; Salesorderheader Search Request; Predicates Set; Setting Order.");
        query.orderBy(builder.desc(root.<Integer>get("salesOrderHeaderKey")));

        logger.trace("Data Request; Salesorderheader Search Request; Order Set; Executing Query.");
        List<Salesorderheader> results = entityManager.createQuery(query).setFirstResult(request.getStart())
                                                                         .setMaxResults(request.getLimit())
                                                                         .getResultList();

        logger.info(String.format("Data Request; [%s] Salesorderheaders Successfully Retrieved for Request: [%s]", results.size(), request));
        return results;
    }

    /**
     * Retrieves a single page of Incomplete Request {@code Salesorderheader} entities for the given {@code SearchRequest}
     *
     * @param request
     * @return A {@code List} containing a the desired page of {@code Salesorderheader} entity results.
     */
    @Override
    public List<Salesorderheader> findAllIncompletes(SalesorderheaderSearchRequest request) {
        logger.trace(String.format("Data Request; Salesorderheader Search Request; Building Criteria Query: " + request));
        CriteriaBuilder     builder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Salesorderheader> query   = builder.createQuery(Salesorderheader.class);

        logger.trace("Data Request; Salesorderheader Search Request; Criteria Query Built; Setting Root.");
        Root<Salesorderheader> root = query.from(Salesorderheader.class);

        Join<Salesorderheader, Txfrrqst> txfrrqstJoin = root.join("txfrrqsts");

        final List<Predicate> predicates = new ArrayList<>();

        predicates.add(builder.notEqual(builder.upper(root.<String>get("status")), "V"));
        predicates.add(builder.isNotNull(root.<Date>get("emailed")));
        predicates.add(builder.equal(txfrrqstJoin.<String>get("status"), "A"));

        predicates.addAll(getPredicatesList(builder, root, request));

        logger.trace("Data Request; Salesorderheader Search Request; Root Set; Setting Predicates.");
        query.where(builder.and(predicates.toArray(new Predicate[predicates.size()])));

        logger.trace("Data Request; Salesorderheader Search Request; Predicates Set; Setting Order.");
        query.orderBy(builder.desc(root.<Integer>get("salesOrderHeaderKey")));

        logger.trace("Data Request; Salesorderheader Search Request; Order Set; Executing Query.");
        List<Salesorderheader> results = entityManager.createQuery(query).setFirstResult(request.getStart()).setMaxResults(request.getLimit()).getResultList();

        logger.info(String.format("Data Request; [%s] Salesorderheaders Successfully Retrieved for Request: [%s]", results.size(), request));
        return results;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public long getSearchTotal(SalesorderheaderSearchRequest request) {
        logger.trace(String.format("Data Request; Counting Salesorderheader Search Total; Building Criteria Query: [%s] ", request));
        CriteriaBuilder     builder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Long> query   = builder.createQuery(Long.class);

        logger.trace("Data Request; Counting Salesorderheader Search Total; Criteria Query Built; Setting Root.");
        Root<Salesorderheader> root = query.from(Salesorderheader.class);

        logger.trace("Data Request; Counting Salesorderheader Search Total; Root Set; Setting Aggregation.");
        query.select(builder.count(root));

        logger.trace("Data Request; Counting Salesorderheader Search Total; Aggregation Set; Setting Predicates.");
        query.where(getPredicates(builder, null, root, request));

        logger.trace("Data Request; Counting Salesorderheader Search Total; Predicates Set; Executing Query.");
        long count = entityManager.createQuery(query).getSingleResult();

        logger.info(String.format("Data Request; [%s] Total Salesorderheaders Found for Search Request: [%s]", count, request));
        return count;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public long getAllIncompletesCount(SalesorderheaderSearchRequest request) {
        logger.trace(String.format("Data Request; Counting Salesorderheader Search Total; Building Criteria Query: [%s] ", request));
        CriteriaBuilder     builder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Long> query   = builder.createQuery(Long.class);

        logger.trace("Data Request; Counting Salesorderheader Search Total; Criteria Query Built; Setting Root.");
        Root<Salesorderheader> root = query.from(Salesorderheader.class);

        logger.trace("Data Request; Counting Salesorderheader Search Total; Root Set; Setting Aggregation.");
        query.select(builder.count(root));

        Join<Salesorderheader, Txfrrqst> txfrrqstJoin = root.join("txfrrqsts");

        final List<Predicate> predicates = new ArrayList<>();

        predicates.add(builder.notEqual(builder.upper(root.<String>get("status")), "V"));
        predicates.add(builder.isNotNull(root.<Date>get("emailed")));
        predicates.add(builder.equal(txfrrqstJoin.<String>get("status"), "A"));

        predicates.addAll(getPredicatesList(builder, root, request));
        logger.trace("Data Request; Counting Salesorderheader Search Total; Aggregation Set; Setting Predicates.");
        query.where(getPredicates(builder, null, root, request));

        logger.trace("Data Request; Counting Salesorderheader Search Total; Predicates Set; Executing Query.");
        long count = entityManager.createQuery(query).getSingleResult();

        logger.info(String.format("Data Request; [%s] Total Salesorderheaders Found for Search Request: [%s]", count, request));
        return count;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PreAuthorize("hasRole('STRYKER_SIMS_SALESREP')")
    public void update(Salesorderheader soh) {
        logger.trace(String.format("Data Request; Updating Salesorderheader [%s]; Merging.", soh));
        EntityTransaction tx = entityManager.getTransaction();
        try {
            tx.begin();
            entityManager.merge(soh);
            tx.commit();
            logger.info(String.format("Data Request; Salesorderheader Successfully Updated [%s].", soh));
        } catch (Exception ex) {
            tx.rollback();
            logger.error(String.format("Data Request; Salesorderheader Failed Updating [%s].", soh));
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PreAuthorize("hasRole('STRYKER_SIMS_SALESREP')")
    public void updateTransfers(Salesorderheader soh) {
        logger.trace(String.format("Data Request; Updating Salesorderheader [%s]; Merging.", soh));
        EntityTransaction tx = entityManager.getTransaction();
        try {
            tx.begin();

            for (Txfrrqst txfrrqst : soh.getTxfrrqsts())
                entityManager.merge(txfrrqst);

            tx.commit();
            logger.debug(String.format("Data Request; Salesorderheader Successfully Updated [%s].", soh));
        } catch (Exception ex) {
            tx.rollback();
            logger.error(String.format("Data Request; Salesorderheader Failed Updating [%s].", soh));
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Predicate[] getPredicates(CriteriaBuilder builder, CriteriaQuery<?> query, Root<Salesorderheader> root, SalesorderheaderSearchRequest request) {
        final List<Predicate> predicates = getPredicatesList(builder, root, request);
        return predicates.toArray(new Predicate[predicates.size()]);
    }

    private List<Predicate> getPredicatesList(CriteriaBuilder builder, Root<Salesorderheader> root, SalesorderheaderSearchRequest request) {
        final List<Predicate> predicates = new ArrayList<>();

        final String status = request.getStatus();
        if (status != null && !status.trim().isEmpty())
            predicates.add(builder.equal(builder.upper(root.<String>get("status")), status.trim().toUpperCase()));

        final String salesRepID = request.getSalesRepID();
        if (salesRepID != null && !salesRepID.trim().isEmpty())
            predicates.add(builder.equal(builder.upper(root.<String>get("salesRepID")), salesRepID.trim().toUpperCase()));

        final String ownerCode = request.getOwnerCode();
        if (ownerCode != null && !ownerCode.trim().isEmpty())
            predicates.add(builder.like(builder.upper(root.<String>get("ownerCode")), String.format("%%%s%%", ownerCode.trim().toUpperCase())));

        final String email = request.getEmail();
        if (email != null && !email.trim().isEmpty())
            predicates.add(builder.like(builder.upper(root.<String>get("email")), String.format("%%%s%%", email.trim().toUpperCase())));

        final String phone = request.getPhone();
        if (phone != null && !phone.trim().isEmpty())
            predicates.add(builder.like(builder.upper(root.<String>get("phone")), String.format("%%%s%%", phone.trim().toUpperCase())));

        final String phoneExtension = request.getPhoneExtension();
        if (phoneExtension != null && !phoneExtension.trim().isEmpty())
            predicates.add(builder.like(builder.upper(root.<String>get("phoneExtension")), String.format("%%%s%%", phoneExtension.trim().toUpperCase())));

        final String rdcid = request.getRdcid();
        if (rdcid != null && !rdcid.trim().isEmpty())
            predicates.add(builder.equal(builder.upper(root.<String>get("rdcid")), rdcid.trim().toUpperCase()));

        final String rDCName = request.getrDCName();
        if (rDCName != null && !rDCName.trim().isEmpty())
            predicates.add(builder.like(builder.upper(root.<String>get("rDCName")), String.format("%%%s%%", rDCName.trim().toUpperCase())));

        return predicates;
    }

    public EntityManager getEntityManager() {
        return entityManager;
    }

    public void setEntityManager(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    @Override
    public boolean isGenerated(int salesOrderHeaderKey) {
        Query query = getEntityManager().createNativeQuery(String.format("select count(*) from %s.PENDINGPICKUPEMAILHEADER where REPREQUESTID=%d", InitServlet.getStySndRcvLib(), salesOrderHeaderKey));
        int quantity = ((Integer) query.getSingleResult()).intValue();
        return quantity > 0;
    };
}
