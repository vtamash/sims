package com.kenco.sims.domain;

import com.kenco.api.security.domain.KencoUser;
import com.kenco.sims.entity.Division;
import com.kenco.sims.entity.User;
import org.apache.commons.lang.StringUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class SIMSKencoUser extends KencoUser {
    private static final long serialVersionUID = -7613548726014174786L;

    private String email;
    private Division division;
    private Set<UserFunction> userFunctions = new HashSet<>();

    public SIMSKencoUser(User user) {
        super(user.getId(), user.getUsername(), user.getRole().getName());

        setFirstName(user.getFirstName());
        setLastName(user.getLastName());
        setPhone(StringUtils.trimToEmpty(user.getPhone()).replaceAll("-", ""));

        email    = user.getEmail();
        division = user.getDivisions().isEmpty() ?
                null : new ArrayList<>(user.getDivisions()).get(0).getDivision();
    }

    public String getEmail() {
        return email;
    }

    public Division getDivision() {
        return division;
    }

    public Set<UserFunction> getUserFunctions() {
        return Collections.unmodifiableSet(userFunctions);
    }

    @Override
    public String getFormattedPhone() {
        return super.getFormattedPhone().replace("(","").replace(")","").replace(" ","-");
    }

    @Override
    public String toString() {
        return "ID: " + id.toString() + " || Username: " + username;
    }
}
