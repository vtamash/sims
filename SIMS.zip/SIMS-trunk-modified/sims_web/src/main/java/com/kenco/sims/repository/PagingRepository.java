package com.kenco.sims.repository;

import com.kenco.sims.domain.search.SearchRequest;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.List;

/**
 * Interface for interacting with entities that are or should be paginated in their result sets.
 */
public interface PagingRepository<Entity, Search extends SearchRequest> {
    /**
     * Retrieves a single page of typed results predicated by the given {@code SearchRequest}.
     *
     * @param request The {@code SearchRequest} containing the predicates to apply to this READ Operation.
     * @return Typed {@code List} of {@code Entity} containing only a single "page" of results matching any predicates
     * defined within the given {@code SearchRequest}.
     */
    List<Entity> read(Search request);

    /**
     * Retrieves the total number of entities matching the predicates in the given {@code SearchReqeust}.
     *
     * @param request The {@code SearchRequest} containing the predicates to apply to this READ Operation.
     * @return The total number of entities which match the predicates contained within the given {@code SearchRequest}.
     */
    long getSearchTotal(Search request);

    /**
     * Should be predominately used as an internal function, this breaks a {@code SearchRequest} apart into individual
     * Predicates to be placed upon the query via the JPA Criteria Interface.
     *
     * @param builder The {@code CriteriaBuilder} being used to construct the query.
     * @param root The {@code Root} of the query being constructed.
     * @param query The {@code Query} object itself being constructed.
     * @param request The {@code SearchRequest} containing the predicates for the query.
     * @return A Predicate Array containing each predicate to be applied to the query.
     */
    Predicate[] getPredicates(CriteriaBuilder builder, CriteriaQuery<?> query, Root<Entity> root, Search request);
}
