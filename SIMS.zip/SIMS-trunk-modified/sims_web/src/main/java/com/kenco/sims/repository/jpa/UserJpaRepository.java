package com.kenco.sims.repository.jpa;

import com.kenco.sims.domain.search.impl.UserSearchRequest;
import com.kenco.sims.entity.*;
import com.kenco.sims.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.hierarchicalroles.RoleHierarchy;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.*;
import java.util.*;

/**
 * Sole point-of-access for interaction with {@code User} entities.
 *
 * @see com.kenco.sims.repository.UserRepository
 */
@Repository
public class UserJpaRepository implements UserRepository {
    private static final Logger logger = LoggerFactory.getLogger(UserJpaRepository.class);

    @PersistenceContext
    private EntityManager entityManager;

    @Autowired
    private RoleHierarchy hierarchy;

    /**
     * {@inheritDoc}
     */
    @Override
    @Transactional
    public User create(User user) {
        logger.trace(String.format("Data Request; Creating User [%s]; Persisting.", user));
        entityManager.persist(user);

        logger.info(String.format("Data Request; User Successfully Created [%s].", user));
        return user;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @Transactional(readOnly = true)
    public User readById(UUID id) {
        logger.trace(String.format("Data Request; Retrieving User [%s]; Building Criteria Query For Request.", id));
        CriteriaBuilder     builder = entityManager.getCriteriaBuilder();
        CriteriaQuery<User> query   = builder.createQuery(User.class);

        logger.trace(String.format("Data Request; Retrieving User [%s]; Criteria Query Built; Setting Root.", id));
        Root<User> root = query.from(User.class);

        logger.trace(String.format("Data Request; Retrieving User [%s]; Root Set; Setting Predicates.", id));
        query.where(builder.equal(root.<String>get("id"), id.toString()));

        logger.trace(String.format("Data Request; Retrieving User [%s]; Predicates Set; Executing Query.", id));
        User entity = entityManager.createQuery(query)
                .getSingleResult();

        logger.info(String.format("Data Request; User [%s] Successfully Retrieved.", entity));
        return entity;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @Transactional(readOnly = true)
    public User readByEmail(String email) {
        logger.trace(String.format("Data Request; Retrieving User [%s]; Building Criteria Query For Request.", email));
        CriteriaBuilder     builder = entityManager.getCriteriaBuilder();
        CriteriaQuery<User> query   = builder.createQuery(User.class);

        logger.trace(String.format("Data Request; Retrieving User [%s]; Criteria Query Built; Setting Root.", email));
        Root<User> root = query.from(User.class);

        logger.trace(String.format("Data Request; Retrieving User [%s]; Root Set; Setting Predicates.", email));
        query.where(builder.equal(builder.upper(root.<String>get("email")), email.toUpperCase()));

        logger.trace(String.format("Data Request; Retrieving User [%s]; Predicates Set; Executing Query.", email));
        User entity = entityManager.createQuery(query).getSingleResult();

        logger.info(String.format("Data Request; User [%s] Successfully Retrieved.", entity));
        return entity;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @Transactional(readOnly = true)
    public List<User> read(UserSearchRequest request) {
        logger.trace(String.format("Data Request; User Search Request; Building Criteria Query: " + request));
        CriteriaBuilder     builder = entityManager.getCriteriaBuilder();
        CriteriaQuery<User> query   = builder.createQuery(User.class);

        logger.trace("Data Request; User Search Request; Criteria Query Built; Setting Root.");
        Root<User> root = query.from(User.class);

        logger.trace("Data Request; User Search Request; Root Set; Setting Predicates.");
        query.where(getPredicates(builder, query, root, request));

        logger.trace("Data Request; User Search Request; Predicates Set; Setting Order.");
        query.orderBy(builder.asc(root.<Integer>get("username")));

        logger.trace("Data Request; User Search Request; Order Set; Executing Query.");
        List<User> results = entityManager.createQuery(query)
                .setFirstResult(request.getStart())
                .setMaxResults(request.getLimit())
                .getResultList();

        logger.info(String.format("Data Request; [%s] Users Successfully Retrieved for Request: [%s]", results.size(), request));
        return results;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @Transactional(readOnly = true)
    public long getSearchTotal(UserSearchRequest request) {
        logger.trace(String.format("Data Request; Counting User Search Total; Building Criteria Query: [%s] ", request));
        CriteriaBuilder     builder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Long> query   = builder.createQuery(Long.class);

        logger.trace("Data Request; Counting User Search Total; Criteria Query Built; Setting Root.");
        Root<User> root = query.from(User.class);

        logger.trace("Data Request; Counting User Search Total; Root Set; Setting Aggregation.");
        query.select(builder.count(root));

        logger.trace("Data Request; Counting User Search Total; Aggregation Set; Setting Predicates.");
        query.where(getPredicates(builder, query, root, request));

        logger.trace("Data Request; Counting User Search Total; Predicates Set; Executing Query.");
        long count = entityManager.createQuery(query)
                .getSingleResult();

        logger.info(String.format("Data Request; [%s] Total Users Found for Search Request: [%s]", count, request));
        return count;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @Transactional
    @PreAuthorize("hasRole('STRYKER_SIMS_SUPERUSER') and hasPermission(#user, 'write')")
    public void update(User user) {
        logger.trace(String.format("Data Request; Updating User [%s]; Merging.", user));
        entityManager.merge(user);
        logger.info(String.format("Data Request; User Successfully Updated [%s].", user));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Predicate[] getPredicates(CriteriaBuilder builder, CriteriaQuery<?> query, Root<User> root, UserSearchRequest request) {
        final List<Predicate> predicates = new ArrayList<>();
        if (!request.isShowAll() && SecurityContextHolder.getContext().getAuthentication() != null) {
            final List<String> roleNames = new ArrayList<>();
            for (GrantedAuthority curAuthority : hierarchy.getReachableGrantedAuthorities(SecurityContextHolder.getContext().getAuthentication().getAuthorities()))
                roleNames.add(curAuthority.getAuthority().toUpperCase());

            final Join<User, Role> security = root.join("role", JoinType.LEFT);
            security.alias("security");

            predicates.add(builder.or(security.isNull(), security.<String>get("name").in(roleNames)));
        }

        final String username = request.getUsername();
        if (username != null && !username.trim().isEmpty())
            predicates.add(builder.like(builder.upper(root.<String>get("username")), String.format("%%%s%%", username.trim().toUpperCase())));

        final String firstName = request.getFirstName();
        if (firstName != null && !firstName.trim().isEmpty())
            predicates.add(builder.like(builder.upper(root.<String>get("firstName")), String.format("%%%s%%", firstName.trim().toUpperCase())));

        final String lastName = request.getLastName();
        if (lastName != null && !lastName.trim().isEmpty())
            predicates.add(builder.like(builder.upper(root.<String>get("lastName")), String.format("%%%s%%", lastName.trim().toUpperCase())));

        final String email = request.getEmail();
        if (email != null && !email.trim().isEmpty())
            predicates.add(builder.like(builder.upper(root.<String>get("email")), String.format("%%%s%%", email.trim().toUpperCase())));

        final String phone = request.getPhone();
        if (phone != null && !phone.trim().isEmpty())
            predicates.add(builder.like(builder.upper(root.<String>get("phone")), String.format("%%%s%%", phone.trim().toUpperCase())));

        final Integer roleId = request.getRoleId();
        if (roleId != null) {
            final Join<User, Role> role = root.join("role");
            role.alias("role");

            predicates.add(builder.equal(role.<Integer>get("id"), roleId));
        }

        final Integer homeRdcId = request.getHomeRdcId();
        if (homeRdcId != null) {
            final Join<User, Rdc> homeRdc = root.join("homeRdc");
            homeRdc.alias("homeRdc");

            predicates.add(builder.equal(homeRdc.<Integer>get("id"), homeRdcId));
        }

        final Integer divisionId = request.getDivisionId();
        if (divisionId != null) {
            final Join<User, AuthorizedDivision> authorizedDivisions = root.join("divisions");
            authorizedDivisions.alias("authorizedDivisions");

            final Join<AuthorizedDivision, Division> division = authorizedDivisions.join("division");
            division.alias("division");

            predicates.add(builder.equal(division.<Integer>get("id"), divisionId));
        }

        final Integer rdcId = request.getRdcId();
        if (rdcId != null) {
            final Join<User, AuthorizedRdc> authorizedRdcs = root.join("rdcs");
            authorizedRdcs.alias("authorizedRdcs");

            final Join<AuthorizedRdc, Rdc> rdc = authorizedRdcs.join("rdc");
            rdc.alias("rdc");

            predicates.add(builder.equal(rdc.<Integer>get("id"), rdcId));
        }

        final Boolean enabled  = request.isEnabled(),
                      disabled = request.isDisabled();
        if (enabled && !disabled)
            predicates.add(builder.equal(root.<Boolean>get("enabled"), true));
        else if (!enabled && disabled)
            predicates.add(builder.equal(root.<Boolean>get("enabled"), false));
        else if (enabled && disabled) {
            if (request.isHavingRepRequests() && query!=null) {
                Subquery<String> subquery = query.subquery(String.class);
                Root fromRequests = subquery.from(SalesOrderHeader.class);
                subquery.select(fromRequests.get("email"));
                subquery.where(builder.notEqual(fromRequests.<String>get("status"), "V"));

                predicates.add(builder.or( builder.equal(root.<Boolean>get("enabled"), true),
                                           builder.and( builder.equal(root.<Boolean>get("enabled"), false),
                                                        builder.in(root.<String>get("email")).value(subquery) ) ) );
            }
        }

        return predicates.toArray(new Predicate[predicates.size()]);
    }
}
