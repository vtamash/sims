package com.kenco.sims.domain.search;

import java.util.Map;

/**
 * The purpose is to provide an abstraction of the common search criteria.  Extending classes should be expected for
 * any entity for which we (may) need to provide a <i>search</i> function.  In other words, any entity which may grow
 * in number to be too large to load all at once.
 * 
 * Extending classes are encouraged to take advantage of the JSR-303 Bean Validators available to us and leverage the
 * spring-provided automatic bean validation within Controller method invocations when applicable.
 */
public abstract class SearchRequest {
    /**
     * The <b>maximum</b> number of results that will ever be returned by a {@code SearchRequest}.
     */
    protected static final int MAX_PAGE_SIZE = 100;

    /**
     * Default: 0;
     *
     * Search functions must maintain a static ordering for the search between pages.  This order may be static (hard-
     * coded in the server code) or dynamic (submitted with the web request).  In either case, the search needs to know
     * where it should begin the result set.  Essentially, this tells us where the "next" page begins for the user.
     *
     * This can <u>never</u> surpass the maximum allowed.  Even if it does, only the maximum will be returned.
     */
    protected int start = 0;

    /**
     * Default: 50;
     *
     * Search functions must maintain a static number of results between pages within the same "search."  This is,
     * essentially, the size of the page(s) for a particular search.
     */
    protected int limit = 50;

    /**
     * This is used strictly for logging.  The goal is for extending classes to return something <u>helpful</u> to be
     * appended to the {@code toString} when called.
     *
     * @return {@code Collection} of all predicates that are contained within the concrete {@code SearchRequest}.
     */
    protected abstract Map<String, Object> getSearchPredicates();

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder("Search Request\n");
        builder.append(String.format("--%s: [%s]\n", "Start", getStart()));
        builder.append(String.format("--%s: [%s]\n", "Limit", getLimit()));

        Map<String, Object> predicates = getSearchPredicates();
        for (String curKey : predicates.keySet())
            builder.append(String.format("--%s: [%s]\n", curKey, predicates.get(curKey)));

        return builder.toString();
    }

    public Integer getStart() {
        return start;
    }

    public void setStart(Integer start) {
        this.start = start;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }
}
