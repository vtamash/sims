package com.kenco.sims.oms.service.impl;

import com.kenco.oms.entity.Vendors;
import com.kenco.oms.service.CustomersAbstractService;
import com.kenco.oms.service.StatesAbstractService;
import com.kenco.oms.service.VendorsAbstractService;
import com.kenco.oms.service.impl.GenericCustomersService;
import com.kenco.oms.service.impl.GenericStatesService;
import com.kenco.sims.oms.domain.VendorStub;
import com.kenco.struts.utilities.InitServlet;

import javax.persistence.EntityManager;
import java.util.List;

/**
 * SIMS Implementation of the <i>VendorsAbstractService</i>.  Business logic relating to the <i>Vendors</i> entity and
 * specific to SIMS is located here.
 *
 * @see com.kenco.oms.service.VendorsAbstractService
 * @see com.kenco.oms.service.StatesAbstractService
 * @see com.kenco.oms.service.CustomersAbstractService
 */
public final class VendorsService extends VendorsAbstractService {
	private static final EntityManager entityManager = InitServlet.getEntityManagerFactory().createEntityManager();

	private final CustomersAbstractService cService;
	private final StatesAbstractService    sService;

	/**
	 * Constructs a <i>VendorsService</i> along with the required <i>CustomersService</i> and <i>StatesService</i>
	 * that it will need for processing.
	 */
	public VendorsService() {
		super(entityManager);

		cService = new GenericCustomersService(entityManager);
		sService = new GenericStatesService(entityManager);
	}

	/**
	 * SIMS Implementation of the <i>VendorsAbstractService</i>.  The <b>create</b> process requires one argument to be
	 * passed in for processing: A <i>VendorStub</i> object which will be used to construct the <i>Vendors</i> entity.
	 *
	 * @param vendor The <i>Vendors</i> entity that is being created.  This is passed in by the <i>AbstractService</i>.
	 * @param args Array of size one (1) containing a <i>VendorStub</i> object which is to be used to create the
	 *             <i>Vendors</i> entity.
	 * @return The processed <i>Vendors</i> entity.
	 */
	@Override
	protected Vendors createPreProcess(Vendors vendor, Object... args) {
		if (args == null || args.length != 1)
			throw new UnsupportedOperationException("The <b>create</b> method requires arguments to be passed in.");
		else if (args[0] == null || !(args[0] instanceof VendorStub))
			throw new IllegalArgumentException("Invalid argument(s) passed to the <b>create</b> method.");

		VendorStub stub = (VendorStub) args[0];
		vendor.setActive(stub.getActive());
		vendor.setName(stub.getName());
		vendor.setVendornumber(stub.getNumber());
		vendor.setAddress1(stub.getAddress1());
		vendor.setAddress2(stub.getAddress2());
		vendor.setAddress3(stub.getAddress3());
		vendor.setCity(stub.getCity());
		vendor.setZipcode(stub.getZip());
		vendor.setCustomerId(cService.readById(stub.getCustomerId()));
		vendor.setState(sService.readById(stub.getStateId()));
		return vendor;
	}

	/**
	 * SIMS Implementation of the <i>VendorsAbstractService</i>.  The <b>update</b> process requires one argument to be
	 * passed in for processing: A <i>VendorStub</i> object which will be used to update the <i>Vendors</i> entity.
	 *
	 * @param vendor The <i>Vendors</i> entity that is being created.  This is passed in by the <i>AbstractService</i>.
	 * @param args Array of size one (1) containing a <i>VendorStub</i> object which is to be used to create the
	 *             <i>Vendors</i> entity.
	 * @return The processed <i>Vendors</i> entity.
	 */
	@Override
	protected Vendors updatePreProcess(Vendors vendor, Object... args) {
		if (args == null || args.length != 1)
			throw new UnsupportedOperationException("The <b>create</b> method requires arguments to be passed in.");
		else if (args[0] == null || !(args[0] instanceof VendorStub))
			throw new IllegalArgumentException("Invalid argument(s) passed to the <b>update</b> method.");

		VendorStub stub = (VendorStub) args[0];

        if (stub.getId()==null || stub.getId()<=0)
            throw new UnsupportedOperationException("VendorID is required.");

        vendor = readById(stub.getId());
        if (vendor==null)
            throw new IllegalArgumentException("No Vendor found for this ID : "+stub.getId());

		vendor.setActive(stub.getActive());
		vendor.setName(stub.getName());
		vendor.setVendornumber(stub.getNumber());
		vendor.setAddress1(stub.getAddress1());
		vendor.setAddress2(stub.getAddress2());
		vendor.setAddress3(stub.getAddress3());
		vendor.setCity(stub.getCity());
		vendor.setZipcode(stub.getZip());
		vendor.setCustomerId(cService.readById(stub.getCustomerId()));
		vendor.setState(sService.readById(stub.getStateId()));
		return vendor;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected Vendors deletePreProcess(Vendors vendor, Object... args) {
		return vendor;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected Vendors createPostProcess(Vendors vendor, Object... args) {
		return vendor;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected List<Vendors> readPostProcess(List<Vendors> vendors, Object... args) {
		return vendors;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected Vendors readSinglePostProcess(Vendors vendor, Object... args) {
		return vendor;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected Vendors updatePostProcess(Vendors vendor, Object... args) {
		return vendor;
	}
}
