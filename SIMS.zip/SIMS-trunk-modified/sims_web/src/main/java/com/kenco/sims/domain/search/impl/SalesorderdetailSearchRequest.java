package com.kenco.sims.domain.search.impl;

import com.kenco.sims.domain.search.SearchRequest;

import java.util.HashMap;
import java.util.Map;

public class SalesorderdetailSearchRequest extends SearchRequest {

    String serialNumber;
    String productType;
    String productCode;
    String productVariation;
    String productDescription;
    String surface;
    String surfaceDescription;
    String surfaceSerialNumber;
    String specialInstructions;

    public String getSerialNumber() {
        return serialNumber;
    }

    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getProductVariation() {
        return productVariation;
    }

    public void setProductVariation(String productVariation) {
        this.productVariation = productVariation;
    }

    public String getProductDescription() {
        return productDescription;
    }

    public void setProductDescription(String productDescription) {
        this.productDescription = productDescription;
    }

    public String getSurface() {
        return surface;
    }

    public void setSurface(String surface) {
        this.surface = surface;
    }

    public String getSurfaceDescription() {
        return surfaceDescription;
    }

    public void setSurfaceDescription(String surfaceDescription) {
        this.surfaceDescription = surfaceDescription;
    }

    public String getSurfaceSerialNumber() {
        return surfaceSerialNumber;
    }

    public void setSurfaceSerialNumber(String surfaceSerialNumber) {
        this.surfaceSerialNumber = surfaceSerialNumber;
    }

    public String getSpecialInstructions() {
        return specialInstructions;
    }

    public void setSpecialInstructions(String specialInstructions) {
        this.specialInstructions = specialInstructions;
    }

    @Override
    protected Map<String, Object> getSearchPredicates() {
        Map<String, Object> predicates = new HashMap<>();

        predicates.put("serialNumber", serialNumber);
        predicates.put("productType", productType);
        predicates.put("productCode", productCode);
        predicates.put("productVariation", productVariation);
        predicates.put("productDescription", productDescription);
        predicates.put("surface", surface);
        predicates.put("surfaceDescription", surfaceDescription);
        predicates.put("surfaceSerialNumber", surfaceSerialNumber);
        predicates.put("specialInstructions", specialInstructions);

        return predicates;
    }
}
