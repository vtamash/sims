package com.kenco.sims.oms.action;

import com.kenco.oms.entity.Shiptodeliverylocations;
import com.kenco.oms.service.impl.GenericShipToDeliveryLocationService;
import com.kenco.oms.service.impl.GenericShiptoCustomersService;
import com.kenco.sims.oms.view.JsonView;
import com.kenco.struts.formbeans.WMSFormBean;
import com.kenco.struts.utilities.InitServlet;
import com.kenco.struts.utilities.PojoMapper;
import json.org.JSONArray;
import json.org.JSONObject;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.PrintWriter;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ShipToDeliveryLocationsAction extends Action {
	private static final Logger logger = LoggerFactory.getLogger(ShipToDeliveryLocationsAction.class);

	private final static String SUCCESS = "success";

	/**
	 * Access point for and controls of the flow for each inbound (ShipToDeliveryLocations-related) request.
	 */
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		WMSFormBean wfb = (WMSFormBean) form;

		logger.info("USER: " + wfb.getUser() + " Starting execute() method");

		// Setup our Business Services.
		final GenericShipToDeliveryLocationService service  = new GenericShipToDeliveryLocationService(InitServlet.getEntityManagerFactory().createEntityManager());
		final GenericShiptoCustomersService        sService = new GenericShiptoCustomersService(InitServlet.getEntityManagerFactory().createEntityManager());

		JsonView view = null;
		try {
			String action = request.getParameter("action");

			// Render the page.
			if (action == null)
				return renderStrut(request, wfb, mapping);

			// Create request.
			else if (request.getMethod().equals("POST") && action.equals("create"))
				view = new JsonView<>(create(request, wfb, service, sService));

			// Read request.
			else if (request.getMethod().equals("GET") && action.equals("read"))
				view = new JsonView<>(read(request, service));

			// Update request.
			else if (request.getMethod().equals("POST") && action.equals("update"))
				view = new JsonView<>(update(request, wfb, service));

			// Delete request.
			else if (request.getMethod().equals("POST") && action.equals("delete"))
				delete(request, service);

			// Unicity check - Name.
			else if (request.getMethod().equals("GET") && action.equals("checkName"))
				view = new JsonView<>(checkNameUnicity(service, request.getParameter("id"), request.getParameter("name")));
		} catch (Exception e) {
			// Log the error.
			logger.error("Error processing ShipToDeliveryLocations-Action request: ", e);

			// Respond to the call negatively for user-feedback.
			view = new JsonView("There was an error processing this request.");
		}

		PrintWriter out = response.getWriter();
		out.print(PojoMapper.toJson(view, true));
		out.flush();
		out.close();

		logger.info("USER: " + wfb.getUser() + " Exiting execute() method");
		return null;
	}

	/**
	 * Forwards the caller to the proper JSP for interaction with ShipToDeliveryLocations.
     *
     * !!This is a secure method!!
	 */
	private ActionForward renderStrut(HttpServletRequest request, WMSFormBean wfb, ActionMapping mapping) {
		wfb.resetJavascriptIncludes("appShipToDelivery.js"); // This gets used first.
		// wfb.appendJavascriptIncludes(); // This is what we need to use to add other JS to our jsp.
		logger.info("USER: " + wfb.getUser() + " Exiting execute() method");
		return mapping.findForward(SUCCESS);
	}

	/**
	 * Performs a CREATE Operation on the provided ShipToDeliveryLocations object.
     *
     * !!This is a secure method!!
	 */
	private Shiptodeliverylocations create(HttpServletRequest request, WMSFormBean wfb, GenericShipToDeliveryLocationService service, GenericShiptoCustomersService sService) throws Exception {
		DeliveryStub stub = unmarshallStub(request);

		Shiptodeliverylocations delivery = new Shiptodeliverylocations();

		// Data from the User.
		delivery.setActive(stub.getActive());
		delivery.setShiptocustomerId(sService.readById(stub.getShipToCustomerId()));
		delivery.setDeliverylocation(stub.getName());

		// Meta-data.
		delivery.setCreatetimestamp(new Date());
		delivery.setCreateusername(wfb.getUser());
		delivery.setCreateprogram("ShipToDeliveryLocationsAction.create(...)");
		delivery.setUpdateusername(wfb.getUser());
		delivery.setUpdateprogram("ShipToDeliveryLocationsAction.create(...)");

		// Process the create request.
		service.create(delivery);

		// Return the (persisted) ShipToDeliveryLocations.
		return service.readByName(delivery.getDeliverylocation());
	}

	/**
	 * Performs a READ operation on the GenericShiptoCustomersService and returns a collection of Shiptodeliverylocations
	 * entities Marshalled into JSON.
	 */
	private List<Shiptodeliverylocations> read(HttpServletRequest request, GenericShipToDeliveryLocationService service) throws Exception {
		JSONArray  ary = new JSONArray(request.getParameter("filter"));
		JSONObject obj = (JSONObject) ary.get(0);
		Integer    id  = (Integer) obj.get("value");

		return service.readByShipToCustomerId(id);
	}

	/**
	 * Performs an UPDATE operation on the provided Shiptodeliverylocations entity.
     *
     * !!This is a secure method!!
	 */
	private Shiptodeliverylocations update(HttpServletRequest request, WMSFormBean wfb, GenericShipToDeliveryLocationService service) throws Exception {
		DeliveryStub stub = unmarshallStub(request);

		Shiptodeliverylocations delivery = service.readById(stub.getId());

		// Data from the User.
		delivery.setActive(stub.getActive());
		delivery.setDeliverylocation(stub.getName());

		// Meta-data.
		delivery.setUpdateusername(wfb.getUser());
		delivery.setUpdateprogram("ShipToDeliveryLocationsAction.update(...)");

		// Process the create request.
		service.update(delivery);

		// Return the (updated) Shiptodeliverylocations.
		return delivery;
	}

	/**
	 * Performs a DELETE operation on the provided Shiptodeliverylocations entity.
     *
     * !!This is a secure method!!
	 */
	private void delete(HttpServletRequest request, GenericShipToDeliveryLocationService service) throws Exception {
		// Retrieve the Shiptodeliverylocations entity.
		Shiptodeliverylocations delivery = service.readById(Integer.parseInt(request.getParameter("id")));

		// Perform our delete operation.
		service.delete(delivery);
	}

	/**
	 * If the ID (<i>Primary Key</i>) is, in any way, absent, this method performs a simple unicity check.  However,
	 * if there is an ID present, then we must compare the <b>name</b> for the entity belonging to the ID.  If they are
	 * the same, then we exempt the unicity check since it already owns the <b>name</b>.  However, if the <b>name</b>
	 * is different, we must still perform a simple unicity check.
	 */
	private Map<String,Object> checkNameUnicity(GenericShipToDeliveryLocationService service, String id, String name) {
		Map<String,Object> isUnique = new HashMap<>();

		if (id == null || id.trim().isEmpty() || id.trim().equalsIgnoreCase("null"))
			isUnique.put("unique", !service.existsByName(name));
		else
			isUnique.put("unique", service.readById(Integer.parseInt(id)).getDeliverylocation().trim().equalsIgnoreCase(name.trim())
									|| !service.existsByName(name));

		return isUnique;
	}

	/**
	 * Un-Marshalls a JSON String into a DeliveryStub object.
	 */
	private DeliveryStub unmarshallStub(HttpServletRequest request) throws Exception {
		JSONObject json   = new JSONObject(parseReader(request));
		JSONObject record = (JSONObject) json.get("records");

		DeliveryStub stub = new DeliveryStub();
		stub.setId(record.get("id") == JSONObject.NULL ? null : (Integer) record.get("id"));
		stub.setShipToCustomerId((Integer) record.get("shipToCustomerId"));
		stub.setActive((Boolean) record.get("active") ? (short) 1 : (short) 0);
		stub.setName(((String) record.get("name")).trim());
		return stub;
	}

	/**
	 * Parses the HttpServletRequest's reader to get any POST Parameters that are present.
	 */
	private String parseReader(HttpServletRequest request) throws Exception {
		StringBuilder builder = new StringBuilder();

		BufferedReader reader = request.getReader();
		for (String curLine = reader.readLine(); curLine != null; curLine = reader.readLine())
			builder.append(curLine);

		return builder.toString();
	}

	/**
	 * We don't have the full Customers entity on an inbound Create or Update request.  Instead, we are only given the
	 * Customers ID value.  For this reason, we can't outright instantiate a Customers object.  Instead, we create one
	 * of these (thin) wrappers to use during the Un-Marshalling process and instantiate a ShipToDeliveryLocations object
	 * once we can load up the relevant Customers entity.
	 */
	private class DeliveryStub {
		private Integer id;
		private Integer shipToCustomerId;
		private Short active;
		private String name;

		private Integer getId() {
			return id;
		}

		private void setId(Integer id) {
			this.id = id;
		}

		private Integer getShipToCustomerId() {
			return shipToCustomerId;
		}

		private void setShipToCustomerId(Integer shipToCustomerId) {
			this.shipToCustomerId = shipToCustomerId;
		}

		private Short getActive() {
			return active;
		}

		private void setActive(Short active) {
			this.active = active;
		}

		private String getName() {
			return name;
		}

		private void setName(String name) {
			this.name = name;
		}
	}
}
