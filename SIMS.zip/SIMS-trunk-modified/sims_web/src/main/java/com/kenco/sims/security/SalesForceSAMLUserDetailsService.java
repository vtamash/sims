package com.kenco.sims.security;

import com.kenco.api.security.domain.KencoUser;
import com.kenco.api.security.service.KencoUserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.InsufficientAuthenticationException;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.saml.SAMLCredential;
import org.springframework.security.saml.userdetails.SAMLUserDetailsService;

public class SalesForceSAMLUserDetailsService implements SAMLUserDetailsService {
    private static final Logger LOGGER = LoggerFactory.getLogger(SalesForceSAMLUserDetailsService.class);
    private KencoUserService service;

    @Override
    public Object loadUserBySAML(SAMLCredential credential) throws UsernameNotFoundException {
        LOGGER.info("Loading User Details By SAML. User Email : [{}]",credential!=null ? credential.getAttributeAsString("email") : "Not Provided");
        KencoUser user = service.retrieveKencoUser(credential.getAttributeAsString("email"));

        if (user!=null && !user.getAuthorities().contains(new SimpleGrantedAuthority("STRYKER_SIMS_SALESREP")))
            throw new InsufficientAuthenticationException("You are not authorized to reach the requested resource.");

        LOGGER.info("Loaded User Details By SAML for user : [{}]", user.getUsername());
        return user;
    }

    public void setService(KencoUserService service) {
        this.service = service;
    }
}
