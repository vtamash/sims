package com.kenco.sims.oms.service.impl;

import com.kenco.oms.entity.BusinessUnits;
import com.kenco.oms.service.BusinessUnitsAbstractService;
import com.kenco.oms.service.CustomersAbstractService;
import com.kenco.sims.oms.domain.BusinessUnitStub;
import com.kenco.struts.utilities.InitServlet;
import javax.persistence.EntityManager;
import java.util.List;

/**
 * SIMS Implementation of the <i>BusinessUnitsAbstractService</i>.  Business logic relating to the <i>BusinessUnits</i>
 * entity and specific to SIMS is located here.
 *
 * @see com.kenco.sims.oms.domain.BusinessUnitStub
 * @see com.kenco.oms.service.BusinessUnitsAbstractService
 * @see com.kenco.oms.service.CustomersAbstractService
 */
public final class BusinessUnitService extends BusinessUnitsAbstractService {
	private static final EntityManager entityManager = InitServlet.getEntityManagerFactory().createEntityManager();

	private final CustomersAbstractService cService;

	/**
	 * Constructs a <i>BusinessUnitService</i> along with the required <i>CustomersService</i> that it will need for
	 * processing.
	 */
	public BusinessUnitService() {
		super(entityManager);

		this.cService = new CustomerService();
	}

	/**
	 * SIMS Implementation of the <i>BusinessUnitsAbstractService</i>.  The <b>create</b> process requires one argument
	 * to be passed in for processing: A <i>BusinessUnitStub</i> object which will be used to construct the
	 * <i>BusinessUnits</i> entity.
	 *
	 * @param businessUnit The <i>BusinessUnits</i> entity that is being created.
	 * @param args         Array of size one (1) containing a <i>BusinessUnitStub</i> object which is to be used to
	 *                     create the <i>BusinessUnits</i> entity.
	 * @return The processed <i>BusinessUnits</i> entity.
	 */
	@Override
	protected BusinessUnits createPreProcess(BusinessUnits businessUnit, Object... args) {
		if (args == null || args.length != 1)
			throw new UnsupportedOperationException("The <b>create</b> method requires arguments to be passed in.");
		else if (args[0] == null || !(args[0] instanceof BusinessUnitStub))
			throw new IllegalArgumentException("Invalid argument(s) passed to the <b>create</b> method.");

		BusinessUnitStub stub = (BusinessUnitStub) args[0];
		businessUnit.setCustomer(cService.readById(stub.getCustomerId()));
		businessUnit.setActive(stub.getActive());
		businessUnit.setBusinessunit(stub.getName());
		businessUnit.setCreateprogram("SIMS: BusinessUnitService.create(...)");
		return businessUnit;
	}

	/**
	 * SIMS Implementation of the <i>BusinessUnitsAbstractService</i>.  The <b>update</b> process requires one argument
	 * to be passed in for processing: A <i>BusinessUnitStub</i> object which will be used to update the
	 * <i>BusinessUnits</i> entity.
	 *
	 * @param businessUnit The <i>BusinessUnits</i> entity that is being updated.
	 * @param args         Array of size one (1) containing a <i>BusinessUnitStub</i> object which is to be used to update the
	 *                     <i>BusinessUnits</i> entity.
	 * @return The processed <i>BusinessUnits</i> entity.
	 */
	@Override
	protected BusinessUnits updatePreProcess(BusinessUnits businessUnit, Object... args) {
		if (args == null || args.length != 1)
			throw new UnsupportedOperationException("The <b>update</b> method requires arguments to be passed in.");
		else if (args[0] == null || !(args[0] instanceof BusinessUnitStub))
			throw new IllegalArgumentException("Invalid argument(s) passed to the <b>update</b> method.");

		BusinessUnitStub stub = (BusinessUnitStub) args[0];
		businessUnit.setCustomer(cService.readById(stub.getCustomerId()));
		businessUnit.setActive(stub.getActive());
		businessUnit.setBusinessunit(stub.getName());
		businessUnit.setUpdateprogram("SIMS: BusinessUnitService.update(...)");
		return businessUnit;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected BusinessUnits deletePreProcess(BusinessUnits businessUnit, Object... args) {
		businessUnit.setUpdateprogram("SIMS: BusinessUnitService.update(...)");
		return businessUnit;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected BusinessUnits createPostProcess(BusinessUnits businessUnit, Object... args) {
		return businessUnit;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected List<BusinessUnits> readPostProcess(List<BusinessUnits> businessUnit, Object... args) {
		return businessUnit;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected BusinessUnits readSinglePostProcess(BusinessUnits businessUnit, Object... args) {
		return businessUnit;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected BusinessUnits updatePostProcess(BusinessUnits businessUnit, Object... args) {
		return businessUnit;
	}
}
