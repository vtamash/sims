package com.kenco.sims.repository;

import com.kenco.sims.domain.search.impl.UserSearchRequest;
import com.kenco.sims.entity.User;

import java.util.List;
import java.util.UUID;

/**
 * Specifies behavior for interaction with the {@code User} entity.
 *
 * @see com.kenco.sims.entity.User
 * @see com.kenco.sims.repository.PagingRepository
 * @see com.kenco.sims.repository.jpa.UserJpaRepository
 */
public interface UserRepository extends PagingRepository<User, UserSearchRequest> {
    /**
     * Persists the given {@code User} entity.
     *
     * @param user The transient {@code User} entity to be persisted.
     * @return The persisted {@code User} entity.
     */
    User create(User user);

    /**
     * Retrieves the {@code User} entity for the given Primary Key.
     *
     * @param id The Primary Key of the {@code User} entity to be retrieved.
     * @return The persistent {@code User} for the given Primary Key.
     * @throws javax.persistence.NoResultException When no result is found for the given {@code email}.
     * @throws javax.persistence.NonUniqueResultException When multiple results are found for the given {@code email}.
     */
    User readById(UUID id);

    /**
     * Retrieves the {@code User} entity for the given {@code email}.
     *
     * Note: The {@code email} field is a Unique Constraint and is also the "username" for the
     * user's Single Sign On account.  Because the Single Sign On Server will provide this to
     * SIMS when the user attempts to visit the SIMS Application, we must be able to retrieve
     * an account based upon it.
     *
     * @param email The email address of the {@code User} entity to be retrieved.
     * @return The persistent {@code User} entity for the given email.
     * @throws javax.persistence.NoResultException When no result is found for the given {@code email}.
     * @throws javax.persistence.NonUniqueResultException When multiple results are found for the given {@code email}.
     */
    User readByEmail(String email);

    /**
     * Retrieves a single page of {@code User} entities for the given {@code SearchRequest}.
     *
     * @return A {@code List} containing a the desired page of {@code User} entity results.
     */
    List<User> read(UserSearchRequest request);

    /**
     * Updates the persistent context for the given user to the given state.
     *
     * @param user The state to which the persistent context should be updated.
     */
    void update(User user);
}
