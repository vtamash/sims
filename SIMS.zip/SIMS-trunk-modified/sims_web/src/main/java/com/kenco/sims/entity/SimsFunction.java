package com.kenco.sims.entity;

import javax.persistence.*;
import java.util.Date;

@Entity
@DiscriminatorColumn(name="FUNCTIONTYPE")
@Inheritance(strategy= InheritanceType.SINGLE_TABLE)
@Table(schema = "SIMS_SYS", name="SIMSFUNCTIONS")
public abstract class SimsFunction {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID", unique = true, nullable = false)
    private long id;

    @Column(name = "DESCRIPTION", length = 64, nullable = false)
    private String description;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATED", nullable = false)
    private Date created = new Date();

    @Column(name = "CREATEDBY", length = 128, nullable = false)
    private String createdBy;

    public abstract SimsFunctionType getType();

    public Long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
