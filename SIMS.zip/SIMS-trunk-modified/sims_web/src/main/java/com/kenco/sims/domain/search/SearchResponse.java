package com.kenco.sims.domain.search;

import java.util.List;

public final class SearchResponse<T> {
    /**
     * TODO Documentation.
     */
    private Long pageSize;

    /**
     * TODO Documentation.
     */
    private Long totalSize;

    /**
     * TODO Documentation.
     */
    private List<T> content;

    /**
     * Default Constructor.
     */
    public SearchResponse() {}

    /**
     * Constructs an instance with the given parameters.  This constructor will use the size of the {@code content}
     * as the value for the {@code pageSize}.
     *
     * @param totalSize Total number of results that match the predicates given.  This may be greater than or equal to
     *                  the {@code pageSize}.
     * @param content The results for the current page.
     */
    public SearchResponse(long totalSize, List<T> content) {
        this.pageSize  = (long) content.size();
        this.totalSize = totalSize;
        this.content   = content;
    }

    public Long getPageSize() {
        return pageSize;
    }

    public void setPageSize(Long pageSize) {
        this.pageSize = pageSize;
    }

    public Long getTotalSize() {
        return totalSize;
    }

    public void setTotalSize(Long totalSize) {
        this.totalSize = totalSize;
    }

    public List<T> getContent() {
        return content;
    }

    public void setContent(List<T> content) {
        this.content = content;
    }
}
